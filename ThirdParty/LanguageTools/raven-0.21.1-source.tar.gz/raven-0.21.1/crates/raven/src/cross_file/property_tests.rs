//
// cross_file/property_tests.rs
//
// Property-based tests for cross-file awareness
//

#![cfg(test)]

use proptest::prelude::*;
use std::collections::HashSet;
use std::path::PathBuf;
use std::sync::Arc;

use super::directive::parse_directives;
use super::path_resolve::{PathContext, resolve_working_directory};
use super::types::{CallSiteSpec, CrossFileMetadata, SourceLocality};

// ============================================================================
// Generators for valid R file paths
// ============================================================================

/// R reserved words and special values that cannot be used as identifiers
const R_RESERVED: &[&str] = &[
    "if", "else", "for", "in", "while", "repeat", "next", "break", "function", "NA", "NaN", "Inf",
    "NULL", "TRUE", "FALSE", "T", "F", "na", "nan", "inf", "null", "true", "false",
];

/// Check if a name is a valid R identifier (not reserved)
fn is_valid_r_identifier(name: &str) -> bool {
    !R_RESERVED.contains(&name)
}

/// Generate a valid R identifier (lowercase to avoid reserved words)
fn r_identifier() -> impl Strategy<Value = String> {
    "[a-z][a-z0-9_]{0,5}".prop_filter("not reserved", |s| is_valid_r_identifier(s))
}

/// Generate a valid R file path component (no special chars that break parsing)
fn path_component() -> impl Strategy<Value = String> {
    // Lower-case alpha only. Several property tests materialize real files from
    // these names and compare the resulting `Url`s; on a case-insensitive
    // filesystem (macOS/Windows) two names differing only in case are the SAME
    // file, and cross-file path resolution correctly case-folds the resolved URI
    // to the on-disk entry (issue #476). Generating distinct *strings* that alias
    // as files would make those tests assert an impossible distinctness. Keeping
    // the alphabet single-case makes string-distinct ⟹ file-distinct on every
    // platform without weakening the structural properties under test.
    "[a-z][a-z0-9_]{0,10}"
}

/// Generate a valid relative R file path
fn relative_path() -> impl Strategy<Value = String> {
    prop::collection::vec(path_component(), 1..=3)
        .prop_map(|parts| format!("{}.R", parts.join("/")))
}

/// Generate a valid relative path with optional parent directory navigation
fn relative_path_with_parents() -> impl Strategy<Value = String> {
    (0..3usize, relative_path()).prop_map(|(parents, path)| {
        let prefix = "../".repeat(parents);
        format!("{}{}", prefix, path)
    })
}

// ============================================================================
// Property 1: Backward Directive Synonym Equivalence
// Validates: Requirements 1.1, 1.2, 1.3
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 1: For any valid path string, parsing @lsp-sourced-by, @lsp-run-by,
    /// and @lsp-included-by SHALL produce equivalent BackwardDirective structures.
    #[test]
    fn prop_backward_directive_synonym_equivalence(path in relative_path_with_parents()) {
        let sourced_by = format!("# @lsp-sourced-by {}", path);
        let run_by = format!("# @lsp-run-by {}", path);
        let included_by = format!("# @lsp-included-by {}", path);

        let meta1 = parse_directives(&sourced_by);
        let meta2 = parse_directives(&run_by);
        let meta3 = parse_directives(&included_by);

        // All should produce exactly one backward directive
        prop_assert_eq!(meta1.sourced_by.len(), 1);
        prop_assert_eq!(meta2.sourced_by.len(), 1);
        prop_assert_eq!(meta3.sourced_by.len(), 1);

        // All should have the same path
        prop_assert_eq!(&meta1.sourced_by[0].path, &path);
        prop_assert_eq!(&meta2.sourced_by[0].path, &path);
        prop_assert_eq!(&meta3.sourced_by[0].path, &path);

        // All should have the same call site (Default)
        prop_assert_eq!(&meta1.sourced_by[0].call_site, &CallSiteSpec::Default);
        prop_assert_eq!(&meta2.sourced_by[0].call_site, &CallSiteSpec::Default);
        prop_assert_eq!(&meta3.sourced_by[0].call_site, &CallSiteSpec::Default);
    }

    /// Property 1 extended: Synonyms with colon should also be equivalent
    #[test]
    fn prop_backward_directive_synonym_with_colon(path in relative_path_with_parents()) {
        let sourced_by = format!("# @lsp-sourced-by: {}", path);
        let run_by = format!("# @lsp-run-by: {}", path);
        let included_by = format!("# @lsp-included-by: {}", path);

        let meta1 = parse_directives(&sourced_by);
        let meta2 = parse_directives(&run_by);
        let meta3 = parse_directives(&included_by);

        prop_assert_eq!(meta1.sourced_by.len(), 1);
        prop_assert_eq!(meta2.sourced_by.len(), 1);
        prop_assert_eq!(meta3.sourced_by.len(), 1);

        prop_assert_eq!(&meta1.sourced_by[0].path, &path);
        prop_assert_eq!(&meta2.sourced_by[0].path, &path);
        prop_assert_eq!(&meta3.sourced_by[0].path, &path);
    }

    /// Property 1 extended: Synonyms with quotes should also be equivalent
    #[test]
    fn prop_backward_directive_synonym_with_quotes(path in relative_path_with_parents()) {
        let sourced_by = format!("# @lsp-sourced-by \"{}\"", path);
        let run_by = format!("# @lsp-run-by \"{}\"", path);
        let included_by = format!("# @lsp-included-by \"{}\"", path);

        let meta1 = parse_directives(&sourced_by);
        let meta2 = parse_directives(&run_by);
        let meta3 = parse_directives(&included_by);

        prop_assert_eq!(meta1.sourced_by.len(), 1);
        prop_assert_eq!(meta2.sourced_by.len(), 1);
        prop_assert_eq!(meta3.sourced_by.len(), 1);

        prop_assert_eq!(&meta1.sourced_by[0].path, &path);
        prop_assert_eq!(&meta2.sourced_by[0].path, &path);
        prop_assert_eq!(&meta3.sourced_by[0].path, &path);
    }
}

// ============================================================================
// Property 2: Working Directory Synonym Equivalence
// Validates: Requirements 3.1-3.6
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 2: For any valid path string, all working directory directive synonyms
    /// SHALL produce equivalent working directory configurations.
    #[test]
    fn prop_working_directory_synonym_equivalence(path in relative_path_with_parents()) {
        let synonyms = [
            "@lsp-working-directory",
            "@lsp-working-dir",
            "@lsp-current-directory",
            "@lsp-current-dir",
            "@lsp-cd",
            "@lsp-wd",
        ];

        let results: Vec<_> = synonyms
            .iter()
            .map(|syn| {
                let content = format!("# {} {}", syn, path);
                parse_directives(&content)
            })
            .collect();

        // All should produce the same working directory
        for (i, meta) in results.iter().enumerate() {
            prop_assert_eq!(
                meta.working_directory.as_ref(),
                Some(&path),
                "Synonym {} failed", synonyms[i]
            );
        }
    }

    /// Property 2 extended: Working directory synonyms with colon
    #[test]
    fn prop_working_directory_synonym_with_colon(path in relative_path_with_parents()) {
        let synonyms = [
            "@lsp-working-directory:",
            "@lsp-working-dir:",
            "@lsp-current-directory:",
            "@lsp-current-dir:",
            "@lsp-cd:",
            "@lsp-wd:",
        ];

        let results: Vec<_> = synonyms
            .iter()
            .map(|syn| {
                let content = format!("# {} {}", syn, path);
                parse_directives(&content)
            })
            .collect();

        for (i, meta) in results.iter().enumerate() {
            prop_assert_eq!(
                meta.working_directory.as_ref(),
                Some(&path),
                "Synonym {} failed", synonyms[i]
            );
        }
    }

    /// Property 2 extended: Working directory synonyms with quotes
    #[test]
    fn prop_working_directory_synonym_with_quotes(path in relative_path_with_parents()) {
        let synonyms = [
            "@lsp-working-directory",
            "@lsp-wd",
            "@lsp-cd",
        ];

        for syn in synonyms {
            let double_quoted = format!("# {} \"{}\"", syn, path);
            let single_quoted = format!("# {} '{}'", syn, path);

            let meta1 = parse_directives(&double_quoted);
            let meta2 = parse_directives(&single_quoted);

            prop_assert_eq!(meta1.working_directory.as_ref(), Some(&path));
            prop_assert_eq!(meta2.working_directory.as_ref(), Some(&path));
        }
    }
}

// ============================================================================
// Property 2a: Workspace-Root-Relative Path Resolution
// Validates: Requirements 3.9
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 2a: Paths starting with / SHALL resolve relative to workspace root.
    #[test]
    fn prop_workspace_root_relative_path(subpath in relative_path()) {
        let workspace_root = PathBuf::from("/workspace");
        let file_path = PathBuf::from("/workspace/src/main.R");

        let ctx = PathContext {
            file_path,
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            workspace_root: Some(workspace_root.clone()),
            implicit_test_working_directory: None,
        };

        let path_str = format!("/{}", subpath);
        let resolved = resolve_working_directory(&path_str, &ctx);

        prop_assert!(resolved.is_some());
        let resolved = resolved.unwrap();

        // Should start with workspace root
        prop_assert!(resolved.starts_with(&workspace_root));

        // Should NOT be filesystem root
        prop_assert!(!resolved.starts_with("/") || resolved.starts_with(&workspace_root));
    }

    /// Property 2a extended: Workspace-root-relative without workspace returns None
    #[test]
    fn prop_workspace_root_relative_no_workspace(subpath in relative_path()) {
        let ctx = PathContext {
            file_path: PathBuf::from("/some/file.R"),
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            workspace_root: None,
            implicit_test_working_directory: None,
        };

        let path_str = format!("/{}", subpath);
        let resolved = resolve_working_directory(&path_str, &ctx);

        prop_assert!(resolved.is_none());
    }
}

// ============================================================================
// Property 2b: File-Relative Path Resolution
// Validates: Requirements 3.10
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 2b: Paths not starting with / SHALL resolve relative to file's directory.
    #[test]
    fn prop_file_relative_path(subpath in relative_path()) {
        let file_path = PathBuf::from("/project/src/main.R");
        let file_dir = PathBuf::from("/project/src");

        let ctx = PathContext {
            file_path,
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            workspace_root: Some(PathBuf::from("/project")),
            implicit_test_working_directory: None,
        };

        let resolved = resolve_working_directory(&subpath, &ctx);

        prop_assert!(resolved.is_some());
        let resolved = resolved.unwrap();

        // Should start with file's directory
        prop_assert!(resolved.starts_with(&file_dir));
    }

    /// Property 2b extended: Parent directory navigation
    #[test]
    fn prop_file_relative_with_parent_nav(
        parents in 1..3usize,
        subpath in relative_path()
    ) {
        let file_path = PathBuf::from("/project/a/b/c/main.R");

        let ctx = PathContext {
            file_path,
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            workspace_root: Some(PathBuf::from("/project")),
            implicit_test_working_directory: None,
        };

        let prefix = "../".repeat(parents);
        let path_str = format!("{}{}", prefix, subpath);
        let resolved = resolve_working_directory(&path_str, &ctx);

        prop_assert!(resolved.is_some());
        let resolved = resolved.unwrap();

        // Should still be under /project (not escape workspace)
        prop_assert!(resolved.starts_with("/project"));
    }
}

// ============================================================================
// Property 8: Directive Serialization Round-Trip
// Validates: Requirements 14.1-14.4
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 8: Parsing then serializing then parsing SHALL produce equivalent structures.
    #[test]
    fn prop_directive_round_trip(path in relative_path_with_parents()) {
        let content = format!("# @lsp-sourced-by {}", path);
        let meta1 = parse_directives(&content);

        // Serialize to JSON
        let json = serde_json::to_string(&meta1).unwrap();

        // Deserialize back
        let meta2: CrossFileMetadata = serde_json::from_str(&json).unwrap();

        // Should be equivalent
        prop_assert_eq!(meta1.sourced_by.len(), meta2.sourced_by.len());
        if !meta1.sourced_by.is_empty() {
            prop_assert_eq!(&meta1.sourced_by[0].path, &meta2.sourced_by[0].path);
            prop_assert_eq!(&meta1.sourced_by[0].call_site, &meta2.sourced_by[0].call_site);
        }
    }

    /// Property 8 extended: Round-trip with all directive types
    #[test]
    fn prop_full_metadata_round_trip(
        backward_path in relative_path_with_parents(),
        forward_path in relative_path(),
        wd_path in relative_path(),
    ) {
        let content = format!(
            "# @lsp-sourced-by {}\n# @lsp-source {}\n# @lsp-working-directory {}\n# @lsp-ignore\n# @lsp-ignore-next",
            backward_path, forward_path, wd_path
        );
        let meta1 = parse_directives(&content);

        let json = serde_json::to_string(&meta1).unwrap();
        let meta2: CrossFileMetadata = serde_json::from_str(&json).unwrap();

        prop_assert_eq!(meta1.sourced_by.len(), meta2.sourced_by.len());
        prop_assert_eq!(meta1.sources.len(), meta2.sources.len());
        prop_assert_eq!(meta1.working_directory, meta2.working_directory);
        prop_assert_eq!(meta1.ignored_lines, meta2.ignored_lines);
        prop_assert_eq!(meta1.ignored_next_lines, meta2.ignored_next_lines);
    }
}

// ============================================================================
// Property 9: Call Site Line Parameter Extraction
// Validates: Requirements 1.6
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 9: For any backward directive with line=N, the parsed CallSiteSpec
    /// SHALL be Line(N-1) (converted to 0-based).
    #[test]
    fn prop_call_site_line_extraction(
        path in relative_path_with_parents(),
        line in 1..1000u32
    ) {
        let content = format!("# @lsp-sourced-by {} line={}", path, line);
        let meta = parse_directives(&content);

        prop_assert_eq!(meta.sourced_by.len(), 1);
        prop_assert_eq!(
            &meta.sourced_by[0].call_site,
            &CallSiteSpec::Line(line - 1) // 0-based
        );
    }

    /// Property 9 extended: Line=1 should become Line(0)
    #[test]
    fn prop_call_site_line_one_based_to_zero_based(path in relative_path_with_parents()) {
        let content = format!("# @lsp-sourced-by {} line=1", path);
        let meta = parse_directives(&content);

        prop_assert_eq!(meta.sourced_by.len(), 1);
        prop_assert_eq!(&meta.sourced_by[0].call_site, &CallSiteSpec::Line(0));
    }

    /// Property 9 extended: Line extraction with different directive synonyms
    #[test]
    fn prop_call_site_line_with_synonyms(
        path in relative_path_with_parents(),
        line in 1..100u32
    ) {
        let synonyms = ["@lsp-sourced-by", "@lsp-run-by", "@lsp-included-by"];

        for syn in synonyms {
            let content = format!("# {} {} line={}", syn, path, line);
            let meta = parse_directives(&content);

            prop_assert_eq!(meta.sourced_by.len(), 1);
            prop_assert_eq!(
                &meta.sourced_by[0].call_site,
                &CallSiteSpec::Line(line - 1)
            );
        }
    }
}

// ============================================================================
// Property 10: Call Site Match Parameter Extraction
// Validates: Requirements 1.7
// ============================================================================

/// Generate a valid match pattern (no quotes inside)
fn match_pattern() -> impl Strategy<Value = String> {
    "[a-zA-Z0-9_()., ]{1,20}"
}

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 10: For any backward directive with match="pattern", the parsed
    /// CallSiteSpec SHALL be Match(pattern) with the exact pattern string.
    #[test]
    fn prop_call_site_match_extraction(
        path in relative_path_with_parents(),
        pattern in match_pattern()
    ) {
        let content = format!("# @lsp-sourced-by {} match=\"{}\"", path, pattern);
        let meta = parse_directives(&content);

        prop_assert_eq!(meta.sourced_by.len(), 1);
        prop_assert_eq!(
            &meta.sourced_by[0].call_site,
            &CallSiteSpec::Match(pattern)
        );
    }

    /// Property 10 extended: Match with single quotes
    #[test]
    fn prop_call_site_match_single_quotes(
        path in relative_path_with_parents(),
        pattern in match_pattern()
    ) {
        let content = format!("# @lsp-sourced-by {} match='{}'", path, pattern);
        let meta = parse_directives(&content);

        prop_assert_eq!(meta.sourced_by.len(), 1);
        prop_assert_eq!(
            &meta.sourced_by[0].call_site,
            &CallSiteSpec::Match(pattern)
        );
    }

    /// Property 10 extended: Match extraction with different directive synonyms
    #[test]
    fn prop_call_site_match_with_synonyms(
        path in relative_path_with_parents(),
        pattern in match_pattern()
    ) {
        let synonyms = ["@lsp-sourced-by", "@lsp-run-by", "@lsp-included-by"];

        for syn in synonyms {
            let content = format!("# {} {} match=\"{}\"", syn, path, pattern);
            let meta = parse_directives(&content);

            prop_assert_eq!(meta.sourced_by.len(), 1);
            prop_assert_eq!(
                &meta.sourced_by[0].call_site,
                &CallSiteSpec::Match(pattern.clone())
            );
        }
    }
}

// ============================================================================
// Property 3: Quote Style Equivalence for Source Detection
// Validates: Requirements 4.1, 4.2
// ============================================================================

use super::source_detect::detect_source_calls;
use tree_sitter::Parser;

fn parse_r(code: &str) -> tree_sitter::Tree {
    let mut parser = Parser::new();
    parser
        .set_language(&tree_sitter_r::LANGUAGE.into())
        .unwrap();
    parser.parse(code, None).unwrap()
}

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 3: For any valid path string p, detecting source("p") and source('p')
    /// SHALL produce equivalent SourceCall structures with the same path.
    #[test]
    fn prop_quote_style_equivalence(path in relative_path()) {
        let double_quoted = format!("source(\"{}\")", path);
        let single_quoted = format!("source('{}')", path);

        let tree1 = parse_r(&double_quoted);
        let tree2 = parse_r(&single_quoted);

        let sources1 = detect_source_calls(&tree1, &double_quoted);
        let sources2 = detect_source_calls(&tree2, &single_quoted);

        prop_assert_eq!(sources1.len(), 1);
        prop_assert_eq!(sources2.len(), 1);
        prop_assert_eq!(&sources1[0].path, &path);
        prop_assert_eq!(&sources2[0].path, &path);
        prop_assert_eq!(sources1[0].is_sys_source, sources2[0].is_sys_source);
        prop_assert_eq!(sources1[0].locality, sources2[0].locality);
        prop_assert_eq!(sources1[0].chdir, sources2[0].chdir);
    }
}

// ============================================================================
// Property 15: Named Argument Source Detection
// Validates: Requirements 4.3
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 15: For any source() call using source(file = "path.R") syntax,
    /// the Source_Detector SHALL extract "path.R" as the path.
    #[test]
    fn prop_named_argument_source_detection(path in relative_path()) {
        let code = format!("source(file = \"{}\")", path);
        let tree = parse_r(&code);
        let sources = detect_source_calls(&tree, &code);

        prop_assert_eq!(sources.len(), 1);
        prop_assert_eq!(&sources[0].path, &path);
    }

    /// Property 15 extended: Named argument with other arguments
    #[test]
    fn prop_named_argument_with_other_args(path in relative_path()) {
        let code = format!("source(file = \"{}\", local = TRUE)", path);
        let tree = parse_r(&code);
        let sources = detect_source_calls(&tree, &code);

        prop_assert_eq!(sources.len(), 1);
        prop_assert_eq!(&sources[0].path, &path);
        prop_assert_eq!(sources[0].locality, SourceLocality::CurrentFrame);
    }
}

// ============================================================================
// Property 16: sys.source Detection
// Validates: Requirements 4.4
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 16: For any sys.source() call with a string literal path,
    /// the Source_Detector SHALL extract the path and mark is_sys_source as true.
    #[test]
    fn prop_sys_source_detection(path in relative_path()) {
        let code = format!("sys.source(\"{}\", envir = globalenv())", path);
        let tree = parse_r(&code);
        let sources = detect_source_calls(&tree, &code);

        prop_assert_eq!(sources.len(), 1);
        prop_assert_eq!(&sources[0].path, &path);
        prop_assert!(sources[0].is_sys_source);
    }

    /// Property 16 extended: sys.source with single quotes
    #[test]
    fn prop_sys_source_single_quotes(path in relative_path()) {
        let code = format!("sys.source('{}', envir = globalenv())", path);
        let tree = parse_r(&code);
        let sources = detect_source_calls(&tree, &code);

        prop_assert_eq!(sources.len(), 1);
        prop_assert_eq!(&sources[0].path, &path);
        prop_assert!(sources[0].is_sys_source);
    }
}

// ============================================================================
// Property 17: Dynamic Path Graceful Handling
// Validates: Requirements 4.5, 4.6
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 17: For any source() call where the path argument is a variable,
    /// the Source_Detector SHALL not extract a path and SHALL not emit an error.
    #[test]
    fn prop_dynamic_path_variable_skipped(varname in "[a-zA-Z][a-zA-Z0-9_]{0,10}") {
        let code = format!("source({})", varname);
        let tree = parse_r(&code);
        let sources = detect_source_calls(&tree, &code);

        // Should skip, not error
        prop_assert_eq!(sources.len(), 0);
    }

    /// Property 17 extended: paste0() calls should be skipped
    #[test]
    fn prop_dynamic_path_paste0_skipped(
        prefix in "[a-zA-Z]{1,5}",
        varname in r_identifier()
    ) {
        let code = format!("source(paste0(\"{}/\", {}))", prefix, varname);
        let tree = parse_r(&code);
        let sources = detect_source_calls(&tree, &code);

        prop_assert_eq!(sources.len(), 0);
    }

    /// Property 17 extended: Expression paths should be skipped
    #[test]
    fn prop_dynamic_path_expression_skipped(
        base in "[a-zA-Z]{1,5}",
        suffix in "[a-zA-Z]{1,5}"
    ) {
        let code = format!("source(paste({}, \"{}\"))", base, suffix);
        let tree = parse_r(&code);
        let sources = detect_source_calls(&tree, &code);

        prop_assert_eq!(sources.len(), 0);
    }
}

// ============================================================================
// Property 18: Source Call Parameter Extraction
// Validates: Requirements 4.7, 4.8
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 18: For any source() call with local = TRUE, the extracted
    /// SourceCall SHALL have local = true.
    #[test]
    fn prop_source_local_true_extraction(path in relative_path()) {
        let code = format!("source(\"{}\", local = TRUE)", path);
        let tree = parse_r(&code);
        let sources = detect_source_calls(&tree, &code);

        prop_assert_eq!(sources.len(), 1);
        prop_assert_eq!(sources[0].locality, SourceLocality::CurrentFrame);
    }

    /// Property 18 extended: local = FALSE should have local = false
    #[test]
    fn prop_source_local_false_extraction(path in relative_path()) {
        let code = format!("source(\"{}\", local = FALSE)", path);
        let tree = parse_r(&code);
        let sources = detect_source_calls(&tree, &code);

        prop_assert_eq!(sources.len(), 1);
        prop_assert_eq!(sources[0].locality, SourceLocality::Global);
    }

    /// Property 18: For any source() call with chdir = TRUE, the extracted
    /// SourceCall SHALL have chdir = true.
    #[test]
    fn prop_source_chdir_true_extraction(path in relative_path()) {
        let code = format!("source(\"{}\", chdir = TRUE)", path);
        let tree = parse_r(&code);
        let sources = detect_source_calls(&tree, &code);

        prop_assert_eq!(sources.len(), 1);
        prop_assert!(sources[0].chdir);
    }

    /// Property 18 extended: chdir = FALSE should have chdir = false
    #[test]
    fn prop_source_chdir_false_extraction(path in relative_path()) {
        let code = format!("source(\"{}\", chdir = FALSE)", path);
        let tree = parse_r(&code);
        let sources = detect_source_calls(&tree, &code);

        prop_assert_eq!(sources.len(), 1);
        prop_assert!(!sources[0].chdir);
    }

    /// Property 18 extended: Both local and chdir together
    #[test]
    fn prop_source_local_and_chdir_extraction(path in relative_path()) {
        let code = format!("source(\"{}\", local = TRUE, chdir = TRUE)", path);
        let tree = parse_r(&code);
        let sources = detect_source_calls(&tree, &code);

        prop_assert_eq!(sources.len(), 1);
        prop_assert_eq!(sources[0].locality, SourceLocality::CurrentFrame);
        prop_assert!(sources[0].chdir);
    }
}

// ============================================================================
// Property 11: Relative Path Resolution
// Validates: Requirements 1.8, 1.9, 3.9
// ============================================================================

use super::path_resolve::resolve_path;

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 11: For any file at path /a/b/c.R and relative directive path ../d/e.R,
    /// the Path_Resolver SHALL resolve to /a/d/e.R.
    #[test]
    fn prop_relative_path_resolution(
        dir_a in path_component(),
        dir_b in path_component(),
        dir_c in path_component(),
        dir_d in path_component(),
        file_e in path_component()
    ) {
        let file_path = PathBuf::from(format!("/{}/{}/{}/main.R", dir_a, dir_b, dir_c));
        let workspace_root = PathBuf::from(format!("/{}", dir_a));

        let ctx = PathContext {
            file_path,
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            workspace_root: Some(workspace_root),
            implicit_test_working_directory: None,
        };

        let relative_path = format!("../{}/{}.R", dir_d, file_e);
        let resolved = resolve_path(&relative_path, &ctx);

        prop_assert!(resolved.is_some());
        let resolved = resolved.unwrap();

        // Should resolve to /dir_a/dir_b/dir_d/file_e.R
        let expected = PathBuf::from(format!("/{}/{}/{}/{}.R", dir_a, dir_b, dir_d, file_e));
        prop_assert_eq!(resolved, expected);
    }

    /// Property 11 extended: Multiple parent directory navigation
    #[test]
    fn prop_multiple_parent_navigation(
        dir_a in path_component(),
        dir_b in path_component(),
        dir_c in path_component(),
        file in path_component()
    ) {
        let file_path = PathBuf::from(format!("/{}/{}/{}/main.R", dir_a, dir_b, dir_c));
        let workspace_root = PathBuf::from(format!("/{}", dir_a));

        let ctx = PathContext {
            file_path,
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            workspace_root: Some(workspace_root),
            implicit_test_working_directory: None,
        };

        // Go up two levels
        let relative_path = format!("../../{}.R", file);
        let resolved = resolve_path(&relative_path, &ctx);

        prop_assert!(resolved.is_some());
        let resolved = resolved.unwrap();

        // Should resolve to /dir_a/file.R
        let expected = PathBuf::from(format!("/{}/{}.R", dir_a, file));
        prop_assert_eq!(resolved, expected);
    }
}

// ============================================================================
// Property 13: Working Directory Inheritance
// Validates: Requirements 3.11
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 13: For any source chain A → B → C where only A has a working directory
    /// directive, files B and C SHALL inherit A's working directory for path resolution.
    #[test]
    fn prop_working_directory_inheritance(
        workspace in path_component(),
        wd_dir in path_component(),
        file_b in path_component(),
        file_c in path_component()
    ) {
        let workspace_root = PathBuf::from(format!("/{}", workspace));
        let working_dir = PathBuf::from(format!("/{}/{}", workspace, wd_dir));

        // File A has explicit working directory
        let ctx_a = PathContext {
            file_path: PathBuf::from(format!("/{}/src/a.R", workspace)),
            working_directory: Some(working_dir.clone()),
            application_working_directory: None,
            inherited_working_directory: None,
            workspace_root: Some(workspace_root.clone()),
            implicit_test_working_directory: None,
        };

        // File B inherits from A (via child_context)
        let ctx_b = ctx_a.child_context(&PathBuf::from(format!("/{}/src/{}.R", workspace, file_b)));

        // File C inherits from B (which inherited from A)
        let ctx_c = ctx_b.child_context(&PathBuf::from(format!("/{}/src/{}.R", workspace, file_c)));

        // All should have the same effective working directory
        prop_assert_eq!(ctx_a.effective_working_directory(), working_dir.clone());
        prop_assert_eq!(ctx_b.effective_working_directory(), working_dir.clone());
        prop_assert_eq!(ctx_c.effective_working_directory(), working_dir);
    }

    /// Property 13 extended: chdir=TRUE breaks inheritance
    #[test]
    fn prop_chdir_breaks_inheritance(
        workspace in path_component(),
        wd_dir in path_component(),
        child_dir in path_component()
    ) {
        let workspace_root = PathBuf::from(format!("/{}", workspace));
        let working_dir = PathBuf::from(format!("/{}/{}", workspace, wd_dir));
        let child_path = PathBuf::from(format!("/{}/{}/child.R", workspace, child_dir));

        // Parent has explicit working directory
        let ctx_parent = PathContext {
            file_path: PathBuf::from(format!("/{}/src/parent.R", workspace)),
            working_directory: Some(working_dir.clone()),
            application_working_directory: None,
            inherited_working_directory: None,
            workspace_root: Some(workspace_root.clone()),
            implicit_test_working_directory: None,
        };

        // Child with chdir=TRUE gets its own directory as working directory
        let ctx_child = ctx_parent.child_context_with_chdir(&child_path);

        // Child's effective working directory should be its own directory, not parent's
        let expected_child_wd = PathBuf::from(format!("/{}/{}", workspace, child_dir));
        prop_assert_eq!(ctx_child.effective_working_directory(), expected_child_wd);
    }
}

// ============================================================================
// Property 14: Default Working Directory
// Validates: Requirements 3.12
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 14: For any file at path /a/b/c.R with no working directory directive
    /// and no inherited working directory, the effective working directory SHALL be /a/b/.
    #[test]
    fn prop_default_working_directory(
        dir_a in path_component(),
        dir_b in path_component(),
        file in path_component()
    ) {
        let file_path = PathBuf::from(format!("/{}/{}/{}.R", dir_a, dir_b, file));

        let ctx = PathContext {
            file_path,
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            workspace_root: Some(PathBuf::from(format!("/{}", dir_a))),
            implicit_test_working_directory: None,
        };

        let expected = PathBuf::from(format!("/{}/{}", dir_a, dir_b));
        prop_assert_eq!(ctx.effective_working_directory(), expected);
    }

    /// Property 14 extended: Explicit working directory takes precedence
    #[test]
    fn prop_explicit_wd_takes_precedence(
        dir_a in path_component(),
        dir_b in path_component(),
        explicit_wd in path_component()
    ) {
        let file_path = PathBuf::from(format!("/{}/{}/main.R", dir_a, dir_b));
        let explicit_working_dir = PathBuf::from(format!("/{}/{}", dir_a, explicit_wd));

        let ctx = PathContext {
            file_path,
            working_directory: Some(explicit_working_dir.clone()),
            application_working_directory: None,
            inherited_working_directory: Some(PathBuf::from(format!("/{}/inherited", dir_a))),
            workspace_root: Some(PathBuf::from(format!("/{}", dir_a))),
            implicit_test_working_directory: None,
        };

        // Explicit should take precedence over inherited
        prop_assert_eq!(ctx.effective_working_directory(), explicit_working_dir);
    }

    /// Property 14 extended: Inherited takes precedence over default
    #[test]
    fn prop_inherited_wd_takes_precedence(
        dir_a in path_component(),
        dir_b in path_component(),
        inherited_wd in path_component()
    ) {
        let file_path = PathBuf::from(format!("/{}/{}/main.R", dir_a, dir_b));
        let inherited_working_dir = PathBuf::from(format!("/{}/{}", dir_a, inherited_wd));

        let ctx = PathContext {
            file_path,
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: Some(inherited_working_dir.clone()),
            workspace_root: Some(PathBuf::from(format!("/{}", dir_a))),
            implicit_test_working_directory: None,
        };

        // Inherited should take precedence over default (file's directory)
        prop_assert_eq!(ctx.effective_working_directory(), inherited_working_dir);
    }
}

// ============================================================================
// Feature: fix-backward-directive-path-resolution
// Property 1: Backward directive path resolution ignores @lsp-cd
// Validates: Requirements 1.2, 1.3, 3.1
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: fix-backward-directive-path-resolution, Property 1: Backward directive path resolution ignores @lsp-cd
    /// **Validates: Requirements 1.2, 1.3, 3.1**
    ///
    /// For any file with an @lsp-cd directive and any backward directive (@lsp-run-by,
    /// @lsp-sourced-by, @lsp-included-by), the backward directive path SHALL be resolved
    /// relative to the file's own directory, producing the same result as if @lsp-cd
    /// were not present.
    #[test]
    fn prop_backward_directive_ignores_lsp_cd(
        workspace in path_component(),
        subdir in path_component(),
        wd_dir in path_component(),
        parent_path in relative_path_with_parents()
    ) {
        // Create file URI: /workspace/subdir/child.R
        let file_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, subdir)).unwrap();
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Create metadata with @lsp-cd pointing to a different directory
        let meta_with_cd = CrossFileMetadata {
            working_directory: Some(format!("/{}", wd_dir)),
            ..Default::default()
        };

        // Create metadata without @lsp-cd
        let meta_without_cd = CrossFileMetadata::default();

        // PathContext::new ignores @lsp-cd (used for backward directives)
        let ctx_new = PathContext::new(&file_uri, Some(&workspace_uri)).unwrap();

        // PathContext::from_metadata with @lsp-cd (used for forward sources)
        let ctx_from_meta_with_cd = PathContext::from_metadata(
            &file_uri,
            &meta_with_cd,
            Some(&workspace_uri)
        ).unwrap();

        // PathContext::from_metadata without @lsp-cd
        let ctx_from_meta_without_cd = PathContext::from_metadata(
            &file_uri,
            &meta_without_cd,
            Some(&workspace_uri)
        ).unwrap();

        // Resolve the backward directive path using PathContext::new (correct behavior)
        let resolved_with_new = resolve_path(&parent_path, &ctx_new);

        // Resolve using from_metadata without @lsp-cd (should match PathContext::new)
        let resolved_without_cd = resolve_path(&parent_path, &ctx_from_meta_without_cd);

        // Property: PathContext::new should produce the same result as from_metadata without @lsp-cd
        // This validates that backward directive resolution ignores @lsp-cd
        prop_assert_eq!(
            resolved_with_new, resolved_without_cd,
            "PathContext::new should produce same result as from_metadata without @lsp-cd. \
             Path: '{}', file: '/{}/{}/child.R'",
            parent_path, workspace, subdir
        );

        // Additional check: PathContext::new should NOT use the working directory
        prop_assert!(
            ctx_new.working_directory.is_none(),
            "PathContext::new should have no working_directory set"
        );

        // Verify that from_metadata WITH @lsp-cd has a different effective working directory
        // (This confirms @lsp-cd is being applied to from_metadata)
        if wd_dir != subdir {
            prop_assert_ne!(
                ctx_new.effective_working_directory(),
                ctx_from_meta_with_cd.effective_working_directory(),
                "from_metadata with @lsp-cd should have different effective_working_directory. \
                 wd_dir: '{}', subdir: '{}'",
                wd_dir, subdir
            );
        }
    }

    /// Feature: fix-backward-directive-path-resolution, Property 1 extended: All backward directive synonyms ignore @lsp-cd
    /// **Validates: Requirements 1.2, 1.3**
    ///
    /// All backward directive synonyms (@lsp-sourced-by, @lsp-run-by, @lsp-included-by)
    /// should resolve paths the same way, ignoring @lsp-cd.
    #[test]
    fn prop_all_backward_directive_synonyms_ignore_lsp_cd(
        workspace in path_component(),
        subdir in path_component(),
        wd_dir in path_component(),
        parent_file in path_component()
    ) {
        let file_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, subdir)).unwrap();
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Create metadata with @lsp-cd
        let meta_with_cd = CrossFileMetadata {
            working_directory: Some(format!("/{}", wd_dir)),
            ..Default::default()
        };

        // PathContext::new (correct for backward directives)
        let ctx_new = PathContext::new(&file_uri, Some(&workspace_uri)).unwrap();

        // PathContext::from_metadata with @lsp-cd (incorrect for backward directives)
        let _ctx_from_meta = PathContext::from_metadata(
            &file_uri,
            &meta_with_cd,
            Some(&workspace_uri)
        ).unwrap();
        // Test with parent directory navigation (common pattern for backward directives)
        let parent_path = format!("../{}.R", parent_file);

        // Parse all backward directive synonyms to ensure synonym handling is exercised
        let sourced_by = format!("# @lsp-sourced-by {}", parent_path);
        let run_by = format!("# @lsp-run-by {}", parent_path);
        let included_by = format!("# @lsp-included-by {}", parent_path);

        let meta_sourced = parse_directives(&sourced_by);
        let meta_run = parse_directives(&run_by);
        let meta_included = parse_directives(&included_by);

        prop_assert_eq!(meta_sourced.sourced_by.len(), 1);
        prop_assert_eq!(meta_run.sourced_by.len(), 1);
        prop_assert_eq!(meta_included.sourced_by.len(), 1);

        prop_assert_eq!(&meta_sourced.sourced_by[0].path, &parent_path);
        prop_assert_eq!(&meta_run.sourced_by[0].path, &parent_path);
        prop_assert_eq!(&meta_included.sourced_by[0].path, &parent_path);

        let resolved_new = resolve_path(&parent_path, &ctx_new);

        // When @lsp-cd points to a different directory, from_metadata will resolve differently
        // PathContext::new should always resolve relative to file's directory
        prop_assert!(
            resolved_new.is_some(),
            "PathContext::new should resolve '../{}.R' from '/{}/{}/child.R'",
            parent_file, workspace, subdir
        );

        // The resolved path from PathContext::new should be in the workspace directory
        // (one level up from subdir)
        let resolved = resolved_new.unwrap();
        let expected_parent = format!("/{}/{}.R", workspace, parent_file);
        prop_assert_eq!(
            resolved, PathBuf::from(&expected_parent),
            "Backward directive '../{}.R' should resolve to '{}' (relative to file's directory), \
             not using @lsp-cd directory '/{}'",
            parent_file, expected_parent, wd_dir
        );
    }

    /// Feature: fix-backward-directive-path-resolution, Property 1 extended: Backward directive resolution ignores @lsp-cd
    /// **Validates: Requirements 1.2, 1.3, 3.1**
    ///
    /// This test demonstrates that PathContext::new (used for backward directives) produces
    /// results based solely on the file's directory, while PathContext::from_metadata
    /// (used for source() calls) uses the @lsp-cd working directory.
    #[test]
    fn prop_backward_directive_resolution_deterministic(
        workspace in path_component(),
        subdir in path_component(),
        wd_dir in path_component(),
        filename in path_component()
    ) {
        // Ensure working directory differs from file's directory
        prop_assume!(wd_dir != subdir);

        let file_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, subdir)).unwrap();
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Metadata with @lsp-cd pointing to a different directory
        let meta = CrossFileMetadata {
            working_directory: Some(format!("/{}", wd_dir)),
            ..Default::default()
        };

        // PathContext::new (for backward directives) - ignores metadata entirely
        let ctx_new = PathContext::new(&file_uri, Some(&workspace_uri)).unwrap();

        // PathContext::from_metadata (for source() calls) - uses working_directory
        let ctx_meta = PathContext::from_metadata(&file_uri, &meta, Some(&workspace_uri)).unwrap();

        // Key assertion: effective_working_directory differs between the two contexts
        // This is the fundamental difference that causes different path resolution
        let wd_new = ctx_new.effective_working_directory();
        let wd_meta = ctx_meta.effective_working_directory();

        prop_assert_ne!(
            wd_new.clone(), wd_meta.clone(),
            "PathContext::new should use file's directory ({}), not @lsp-cd directory ({})",
            wd_new.display(), wd_meta.display()
        );

        // Verify PathContext::new uses the file's parent directory
        let expected_file_dir = PathBuf::from(format!("/{}/{}", workspace, subdir));
        prop_assert_eq!(
            wd_new, expected_file_dir,
            "PathContext::new should use file's directory"
        );

        // Verify PathContext::from_metadata uses the @lsp-cd directory
        let expected_wd = PathBuf::from(format!("/{}/{}", workspace, wd_dir));
        prop_assert_eq!(
            wd_meta, expected_wd,
            "PathContext::from_metadata should use @lsp-cd directory"
        );

        // For a simple filename (no ..), resolution should differ
        let simple_path = format!("{}.R", filename);
        let resolved_new = resolve_path(&simple_path, &ctx_new);
        let resolved_meta = resolve_path(&simple_path, &ctx_meta);

        prop_assert_ne!(
            resolved_new.clone(), resolved_meta.clone(),
            "Simple path '{}' should resolve differently: new={:?}, meta={:?}",
            simple_path, resolved_new, resolved_meta
        );
    }
}

// ============================================================================
// Property 23: Dependency Graph Update on Change
// Validates: Requirements 0.1, 0.2, 6.1, 6.2
// ============================================================================

use super::dependency::DependencyGraph;
use super::types::ForwardSource;
use tower_lsp::lsp_types::Url;

fn make_url(name: &str) -> Url {
    Url::parse(&format!("file:///{}.R", name)).unwrap()
}

/// Build the set of filler variable names used in generated test code.
///
/// Tests generate `x0, x1, …` before a directive and `y0, y1, y2` after it.
/// Use `prop_assume!` with the result to skip cases where a generated symbol
/// name collides with a filler name.
fn filler_names(x_count: usize, y_count: usize) -> HashSet<String> {
    (0..x_count)
        .map(|i| format!("x{}", i))
        .chain((0..y_count).map(|i| format!("y{}", i)))
        .collect()
}

fn make_meta_with_sources(sources: Vec<(&str, u32)>) -> CrossFileMetadata {
    CrossFileMetadata {
        sources: sources
            .into_iter()
            .map(|(path, line)| ForwardSource {
                path: path.to_string(),
                line,
                column: 0,
                is_directive: false,
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            })
            .collect(),
        ..Default::default()
    }
}

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 23: When a file is opened or changed, the Dependency_Graph SHALL
    /// update edges for that file.
    #[test]
    fn prop_dependency_graph_update_on_change(
        parent in path_component(),
        child in path_component(),
        line in 0..100u32
    ) {
        let mut graph = DependencyGraph::new();
        let parent_uri = make_url(&parent);
        let child_uri = make_url(&child);

        let meta = make_meta_with_sources(vec![(&format!("{}.R", child), line)]);
        graph.update_file(&parent_uri, &meta, None, |_| None);

        let deps = graph.get_dependencies(&parent_uri);
        prop_assert_eq!(deps.len(), 1);
        prop_assert_eq!(&deps[0].to, &child_uri);
        prop_assert_eq!(deps[0].call_site_line, Some(line));
    }

    /// Property 23 extended: Multiple sources create multiple edges
    #[test]
    fn prop_multiple_sources_create_edges(
        parent in path_component(),
        child1 in path_component(),
        child2 in path_component()
    ) {
        prop_assume!(child1 != child2);

        let mut graph = DependencyGraph::new();
        let parent_uri = make_url(&parent);

        let meta = make_meta_with_sources(vec![
            (&format!("{}.R", child1), 5),
            (&format!("{}.R", child2), 10),
        ]);

        graph.update_file(&parent_uri, &meta, None, |_| None);

        let deps = graph.get_dependencies(&parent_uri);
        prop_assert_eq!(deps.len(), 2);
    }
}

// ============================================================================
// Property 25: Dependency Graph Edge Removal
// Validates: Requirements 6.3, 13.3
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 25: For any file that is deleted, the Dependency_Graph SHALL contain
    /// no edges where that file is either source or target.
    #[test]
    fn prop_dependency_graph_edge_removal(
        parent in path_component(),
        child in path_component()
    ) {
        let mut graph = DependencyGraph::new();
        let parent_uri = make_url(&parent);
        let child_uri = make_url(&child);

        // Add edge
        let meta = make_meta_with_sources(vec![(&format!("{}.R", child), 5)]);
        graph.update_file(&parent_uri, &meta, None, |_| None);

        // Verify edge exists
        prop_assert_eq!(graph.get_dependencies(&parent_uri).len(), 1);
        prop_assert_eq!(graph.get_dependents(&child_uri).len(), 1);

        // Remove parent file
        graph.remove_file(&parent_uri);

        // No edges should remain
        prop_assert!(graph.get_dependencies(&parent_uri).is_empty());
        prop_assert!(graph.get_dependents(&child_uri).is_empty());
    }

    /// Property 25 extended: Removing child file removes backward edges
    #[test]
    fn prop_remove_child_removes_backward_edges(
        parent in path_component(),
        child in path_component()
    ) {
        let mut graph = DependencyGraph::new();
        let parent_uri = make_url(&parent);
        let child_uri = make_url(&child);

        // Add edge
        let meta = make_meta_with_sources(vec![(&format!("{}.R", child), 5)]);
        graph.update_file(&parent_uri, &meta, None, |_| None);

        // Remove child file
        graph.remove_file(&child_uri);

        // Forward edge from parent should be removed
        prop_assert!(graph.get_dependencies(&parent_uri).is_empty());
    }
}

// ============================================================================
// Property 26: Transitive Dependency Query
// Validates: Requirements 6.4, 6.5
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 26: For any file A that sources B, and B sources C, querying
    /// dependents of C SHALL include both B and A.
    #[test]
    fn prop_transitive_dependency_query(
        file_a in path_component(),
        file_b in path_component(),
        file_c in path_component()
    ) {
        prop_assume!(file_a != file_b && file_b != file_c && file_a != file_c);

        let mut graph = DependencyGraph::new();
        let uri_a = make_url(&file_a);
        let uri_b = make_url(&file_b);
        let uri_c = make_url(&file_c);

        // A sources B
        let meta_a = make_meta_with_sources(vec![(&format!("{}.R", file_b), 1)]);
        graph.update_file(&uri_a, &meta_a, None, |_| None);

        // B sources C
        let meta_b = make_meta_with_sources(vec![(&format!("{}.R", file_c), 1)]);
        graph.update_file(&uri_b, &meta_b, None, |_| None);

        // Transitive dependents of C should include both B and A
        let dependents = graph.get_transitive_dependents(&uri_c, 10, 200);
        prop_assert!(dependents.contains(&uri_b));
        prop_assert!(dependents.contains(&uri_a));
    }

    /// Property 26 extended: Depth limit is respected
    #[test]
    fn prop_transitive_depth_limit(
        file_a in path_component(),
        file_b in path_component(),
        file_c in path_component()
    ) {
        prop_assume!(file_a != file_b && file_b != file_c && file_a != file_c);

        let mut graph = DependencyGraph::new();
        let uri_a = make_url(&file_a);
        let uri_b = make_url(&file_b);
        let uri_c = make_url(&file_c);

        // A sources B sources C
        let meta_a = make_meta_with_sources(vec![(&format!("{}.R", file_b), 1)]);
        graph.update_file(&uri_a, &meta_a, None, |_| None);

        let meta_b = make_meta_with_sources(vec![(&format!("{}.R", file_c), 1)]);
        graph.update_file(&uri_b, &meta_b, None, |_| None);

        // With depth 1, only B should be returned (not A)
        let dependents = graph.get_transitive_dependents(&uri_c, 1, 200);
        prop_assert!(dependents.contains(&uri_b));
        prop_assert!(!dependents.contains(&uri_a));
    }
}

// ============================================================================
// Property 50: Edge Deduplication
// Validates: Requirements 6.1, 6.2, 12.5
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 50: For any file where both a directive and AST detection identify
    /// the same relationship, the Dependency_Graph SHALL contain exactly one edge.
    #[test]
    fn prop_edge_deduplication(
        parent in path_component(),
        child in path_component(),
        line in 0..100u32
    ) {
        let mut graph = DependencyGraph::new();
        let parent_uri = make_url(&parent);

        // Create metadata with duplicate sources (directive and AST)
        let meta = CrossFileMetadata {
            sources: vec![
                ForwardSource {
                    path: format!("{}.R", child),
                    line,
                    column: 0,
                    is_directive: false, // AST detected
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
                ForwardSource {
                    path: format!("{}.R", child),
                    line,
                    column: 0,
                    is_directive: true, // Directive
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
            ],
            ..Default::default()
        };

        graph.update_file(&parent_uri, &meta, None, |_| None);

        // Should have exactly one edge (deduplicated)
        let deps = graph.get_dependencies(&parent_uri);
        prop_assert_eq!(deps.len(), 1);
    }

    /// Property 50 extended: Different call sites create separate edges
    #[test]
    fn prop_different_call_sites_separate_edges(
        parent in path_component(),
        child in path_component(),
        line1 in 0..50u32,
        line2 in 50..100u32
    ) {
        let mut graph = DependencyGraph::new();
        let parent_uri = make_url(&parent);

        let meta = CrossFileMetadata {
            sources: vec![
                ForwardSource {
                    path: format!("{}.R", child),
                    line: line1,
                    column: 0,
                    is_directive: false,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
                ForwardSource {
                    path: format!("{}.R", child),
                    line: line2,
                    column: 0,
                    is_directive: false,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
            ],
            ..Default::default()
        };

        graph.update_file(&parent_uri, &meta, None, |_| None);

        // Should have two edges (different call sites)
        let deps = graph.get_dependencies(&parent_uri);
        prop_assert_eq!(deps.len(), 2);
    }
}

// ============================================================================
// Property 58: Directive Overrides AST For Same (from,to)
// Validates: Requirements 6.8
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 58: For any file where both @lsp-source directive and AST detection
    /// identify a relationship to the same target URI, the directive SHALL be
    /// authoritative (first one wins in deduplication).
    ///
    /// Note: This test uses actual files because forward directives skip edge creation
    /// for non-existent files (Requirement 3.3).
    #[test]
    fn prop_directive_overrides_ast(
        parent in path_component(),
        child in path_component(),
        line in 0..100u32
    ) {
        use std::fs::File;
        use tempfile::TempDir;

        // Create temp workspace with actual files
        let temp_dir = TempDir::new().unwrap();
        let parent_file = format!("{}.R", parent);
        let child_file = format!("{}.R", child);
        File::create(temp_dir.path().join(&parent_file)).unwrap();
        File::create(temp_dir.path().join(&child_file)).unwrap();

        let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
        let parent_uri = Url::from_file_path(temp_dir.path().join(&parent_file)).unwrap();

        let mut graph = DependencyGraph::new();

        // Directive comes first in the list
        let meta = CrossFileMetadata {
            sources: vec![
                ForwardSource {
                    path: child_file.clone(),
                    line,
                    column: 0,
                    is_directive: true, // Directive first
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
                ForwardSource {
                    path: child_file,
                    line,
                    column: 0,
                    is_directive: false, // AST second
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
            ],
            ..Default::default()
        };

        graph.update_file(&parent_uri, &meta, Some(&workspace_url), |_| None);

        let deps = graph.get_dependencies(&parent_uri);
        prop_assert_eq!(deps.len(), 1);
        // First one (directive) wins
        prop_assert!(deps[0].is_directive);
    }
}

// ============================================================================
// Property 4: Local Symbol Precedence
// Validates: Requirements 5.4, 7.3, 8.3, 9.2, 9.3
// ============================================================================

use super::scope::{ScopeArtifacts, compute_artifacts};

fn parse_r_tree(code: &str) -> tree_sitter::Tree {
    let mut parser = Parser::new();
    parser
        .set_language(&tree_sitter_r::LANGUAGE.into())
        .unwrap();
    parser.parse(code, None).unwrap()
}

// ============================================================================
// Property: V1 R Symbol Model
// Validates: Requirements 17.1-17.7
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// V1 R Symbol Model: Only recognized constructs contribute to exported interface.
    /// - name <- function(...) is recognized
    /// - name = function(...) is recognized
    /// - name <<- function(...) is recognized
    /// - name <- <expr> is recognized
    /// - assign("name", <expr>) with string literal is recognized
    /// - assign(dynamic_name, <expr>) is NOT recognized
    #[test]
    fn prop_v1_symbol_model_recognized_constructs(
        func_name in r_identifier(),
        var_name in r_identifier(),
        assign_name in r_identifier()
    ) {
        // Ensure names are distinct
        prop_assume!(func_name != var_name && var_name != assign_name && func_name != assign_name);

        let uri = make_url("test");

        // Code with various recognized constructs
        let code = format!(
            "{} <- function(x) {{ x }}\n{} <- 42\nassign(\"{}\", 100)",
            func_name, var_name, assign_name
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // All three should be in exported interface
        prop_assert!(artifacts.exported_interface.contains_key(func_name.as_str()));
        prop_assert!(artifacts.exported_interface.contains_key(var_name.as_str()));
        prop_assert!(artifacts.exported_interface.contains_key(assign_name.as_str()));

        // Function should have Function kind
        let func_symbol = artifacts.exported_interface.get(func_name.as_str()).unwrap();
        prop_assert_eq!(func_symbol.kind, super::scope::SymbolKind::Function);

        // Variable should have Variable kind
        let var_symbol = artifacts.exported_interface.get(var_name.as_str()).unwrap();
        prop_assert_eq!(var_symbol.kind, super::scope::SymbolKind::Variable);
    }

    /// V1 R Symbol Model: Dynamic assign() is NOT recognized
    #[test]
    fn prop_v1_symbol_model_dynamic_assign_not_recognized(
        var_name in r_identifier()
    ) {
        let uri = make_url("test");

        // Code with dynamic assign (variable name, not string literal)
        let code = format!("assign({}, 42)", var_name);
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Should NOT be in exported interface (dynamic name)
        prop_assert!(artifacts.exported_interface.is_empty());
    }

    /// V1 R Symbol Model: Super-assignment (<<-) is recognized
    #[test]
    fn prop_v1_symbol_model_super_assignment(
        name in r_identifier()
    ) {
        let uri = make_url("test");

        let code = format!("{} <<- 42", name);
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        prop_assert!(artifacts.exported_interface.contains_key(name.as_str()));
    }

    /// V1 R Symbol Model: Equals assignment (=) is recognized
    #[test]
    fn prop_v1_symbol_model_equals_assignment(
        name in r_identifier()
    ) {
        let uri = make_url("test");

        let code = format!("{} = 42", name);
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        prop_assert!(artifacts.exported_interface.contains_key(name.as_str()));
    }
}

// ============================================================================
// Property 5: Function-local variable scope boundaries
// Validates: Variables defined inside function NOT available outside
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 5: For any function definition containing a local variable definition,
    /// that variable SHALL NOT be available in scope outside the function body.
    #[test]
    fn prop_function_local_variable_scope_boundaries(
        func_name in r_identifier(),
        local_var in r_identifier(),
        global_var in r_identifier()
    ) {
        prop_assume!(func_name != local_var && local_var != global_var && func_name != global_var);

        let uri = make_url("test");

        // Code with function containing local variable, followed by global variable
        let code = format!(
            "{} <- function() {{ {} <- 42 }}\n{} <- 100",
            func_name, local_var, global_var
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // At end of file (outside function), local variable should NOT be available
        let scope_outside = scope_at_position(&artifacts, 10, 0, false);

        prop_assert!(scope_outside.symbols.contains_key(func_name.as_str()),
            "Function name should be available outside function");
        prop_assert!(scope_outside.symbols.contains_key(global_var.as_str()),
            "Global variable should be available outside function");
        prop_assert!(!scope_outside.symbols.contains_key(local_var.as_str()),
            "Function-local variable should NOT be available outside function");

        // Inside function body, local variable SHOULD be available.
        // Query at the closing `}` of the body so the local assignment has
        // ended and its binding is visible (R installs the LHS binding only
        // after the RHS finishes evaluating).
        let col_in_body = code
            .find('}')
            .map(|i| i as u32)
            .expect("expected '}' in generated function-body code");
        let scope_inside = scope_at_position(&artifacts, 0, col_in_body, false);
        prop_assert!(scope_inside.symbols.contains_key(func_name.as_str()),
            "Function name should be available inside function");
        prop_assert!(scope_inside.symbols.contains_key(local_var.as_str()),
            "Function-local variable should be available inside function");
        // Global variable defined after function should NOT be available inside
        prop_assert!(!scope_inside.symbols.contains_key(global_var.as_str()),
            "Global variable defined after function should NOT be available inside function");
    }

    /// Property 5 extended: Nested functions have separate scopes
    #[test]
    fn prop_nested_function_separate_scopes(
        outer_func in r_identifier(),
        inner_func in r_identifier(),
        outer_var in r_identifier(),
        inner_var in r_identifier()
    ) {
        prop_assume!(outer_func != inner_func && outer_var != inner_var);
        prop_assume!(outer_func != outer_var && outer_func != inner_var);
        prop_assume!(inner_func != outer_var && inner_func != inner_var);

        let uri = make_url("test");

        // Code with nested functions
        let code = format!(
            "{} <- function() {{ {} <- 1; {} <- function() {{ {} <- 2 }} }}",
            outer_func, outer_var, inner_func, inner_var
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Outside all functions - only outer function should be available
        let scope_outside = scope_at_position(&artifacts, 10, 0, false);
        prop_assert!(scope_outside.symbols.contains_key(outer_func.as_str()),
            "Outer function should be available outside");
        prop_assert!(!scope_outside.symbols.contains_key(inner_func.as_str()),
            "Inner function should NOT be available outside outer function");
        prop_assert!(!scope_outside.symbols.contains_key(outer_var.as_str()),
            "Outer function variable should NOT be available outside");
        prop_assert!(!scope_outside.symbols.contains_key(inner_var.as_str()),
            "Inner function variable should NOT be available outside");

        // Inside outer function but outside inner function.
        // Choose a position inside the outer body *after* the inner function
        // definition begins. The generated code template always contains
        // `; {inner_func} <- function` (with the leading `; `) or — once the
        // first needle has been ruled out — ` {inner_func} <- function` with
        // a leading space, so both needles are delimiter-aware and cannot
        // match a substring of another identifier (`r_identifier` allows only
        // `[a-z0-9_]`, so neither `;` nor ` ` can occur inside it). Avoid a
        // bare-name `rfind(&inner_func)` fallback: with no surrounding
        // delimiters it could match `inner_func` inside a longer identifier
        // such as `outer_func`.
        let inner_def_needle = format!("; {} <- function", inner_func);
        let inner_def_needle2 = format!(" {} <- function", inner_func);
        let col_in_outer_after_inner_def = code
            .rfind(&inner_def_needle)
            .map(|i| (i + 3) as u32) // skip "; " then move inside identifier
            .or_else(|| code.rfind(&inner_def_needle2).map(|i| (i + 2) as u32))
            .expect("expected inner-function-definition locator in generated code");
        let scope_outer = scope_at_position(&artifacts, 0, col_in_outer_after_inner_def, false);
        prop_assert!(scope_outer.symbols.contains_key(outer_func.as_str()),
            "Outer function should be available inside itself");
        prop_assert!(scope_outer.symbols.contains_key(outer_var.as_str()),
            "Outer function variable should be available inside outer function");
        prop_assert!(scope_outer.symbols.contains_key(inner_func.as_str()),
            "Inner function should be available inside outer function");
        prop_assert!(!scope_outer.symbols.contains_key(inner_var.as_str()),
            "Inner function variable should NOT be available outside inner function");

        // Inside inner function. Query at the position immediately after
        // `{inner_var} <- 2` ends so the local binding is in scope (R only
        // installs the LHS binding once the RHS finishes evaluating).
        let inner_var_assignment = format!("{} <- 2", inner_var);
        let col_in_inner_after_inner_var_def = code
            .rfind(&inner_var_assignment)
            .map(|i| (i + inner_var_assignment.len()) as u32)
            .expect("expected inner-variable-assignment locator in generated code");
        let scope_inner = scope_at_position(&artifacts, 0, col_in_inner_after_inner_var_def, false);
        prop_assert!(scope_inner.symbols.contains_key(outer_func.as_str()),
            "Outer function should be available inside inner function");
        prop_assert!(scope_inner.symbols.contains_key(outer_var.as_str()),
            "Outer function variable should be available inside inner function");
        prop_assert!(scope_inner.symbols.contains_key(inner_func.as_str()),
            "Inner function should be available inside itself");
        prop_assert!(scope_inner.symbols.contains_key(inner_var.as_str()),
            "Inner function variable should be available inside inner function");
    }
}

// ============================================================================
// Property 6: Function parameter scope boundaries
// Validates: Parameters NOT available outside function body
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 6: For any function definition with parameters, those parameters
    /// SHALL NOT be available in scope outside the function body.
    #[test]
    fn prop_function_parameter_scope_boundaries(
        func_name in r_identifier(),
        param1 in r_identifier(),
        param2 in r_identifier(),
        global_var in r_identifier()
    ) {
        prop_assume!(func_name != param1 && param1 != param2 && func_name != param2);
        prop_assume!(global_var != func_name && global_var != param1 && global_var != param2);

        let uri = make_url("test");

        // Function with parameters, followed by global variable
        let code = format!(
            "{} <- function({}, {}) {{ {} + {} }}\n{} <- 100",
            func_name, param1, param2, param1, param2, global_var
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Outside function - parameters should NOT be available
        let scope_outside = scope_at_position(&artifacts, 10, 0, false);
        prop_assert!(scope_outside.symbols.contains_key(func_name.as_str()),
            "Function name should be available outside function");
        prop_assert!(scope_outside.symbols.contains_key(global_var.as_str()),
            "Global variable should be available outside function");
        prop_assert!(!scope_outside.symbols.contains_key(param1.as_str()),
            "Function parameter 1 should NOT be available outside function");
        prop_assert!(!scope_outside.symbols.contains_key(param2.as_str()),
            "Function parameter 2 should NOT be available outside function");

        // Inside function - parameters SHOULD be available
        // Use a position derived from the generated code so it is always within the braces.
        let col_in_body = code.find('{').map(|i| (i + 2) as u32).unwrap_or(0);
        let scope_inside = scope_at_position(&artifacts, 0, col_in_body, false);
        prop_assert!(scope_inside.symbols.contains_key(func_name.as_str()),
            "Function name should be available inside function");
        prop_assert!(scope_inside.symbols.contains_key(param1.as_str()),
            "Function parameter 1 should be available inside function");
        prop_assert!(scope_inside.symbols.contains_key(param2.as_str()),
            "Function parameter 2 should be available inside function");
        // Global variable defined after function should NOT be available inside
        prop_assert!(!scope_inside.symbols.contains_key(global_var.as_str()),
            "Global variable defined after function should NOT be available inside function");
    }

    /// Property 6 extended: Function parameters with default values
    #[test]
    fn prop_function_parameter_default_values_scope(
        func_name in r_identifier(),
        param_name in r_identifier()
    ) {
        prop_assume!(func_name != param_name);

        let uri = make_url("test");

        let code = format!("{} <- function({} = 42) {{ {} * 2 }}", func_name, param_name, param_name);
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Outside function - parameter should NOT be available
        let scope_outside = scope_at_position(&artifacts, 10, 0, false);
        prop_assert!(scope_outside.symbols.contains_key(func_name.as_str()),
            "Function name should be available outside function");
        prop_assert!(!scope_outside.symbols.contains_key(param_name.as_str()),
            "Function parameter with default should NOT be available outside function");

        // Inside function - parameter SHOULD be available
        // Use a position derived from the generated code so it is always within the braces.
        let col_in_body = code.find('{').map(|i| (i + 2) as u32).unwrap_or(0);
        let scope_inside = scope_at_position(&artifacts, 0, col_in_body, false);
        prop_assert!(scope_inside.symbols.contains_key(param_name.as_str()),
            "Function parameter with default should be available inside function");
    }

    /// Property 6 extended: Ellipsis parameter scope
    #[test]
    fn prop_function_ellipsis_parameter_scope(
        func_name in r_identifier(),
        param_name in r_identifier()
    ) {
        prop_assume!(func_name != param_name);

        let uri = make_url("test");

        let code = format!("{} <- function({}, ...) {{ list({}, ...) }}", func_name, param_name, param_name);
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Outside function - parameters should NOT be available
        let scope_outside = scope_at_position(&artifacts, 10, 0, false);
        prop_assert!(scope_outside.symbols.contains_key(func_name.as_str()),
            "Function name should be available outside function");
        prop_assert!(!scope_outside.symbols.contains_key(param_name.as_str()),
            "Named parameter should NOT be available outside function");
        prop_assert!(!scope_outside.symbols.contains_key("..."),
            "Ellipsis parameter should NOT be available outside function");

        // Inside function - parameters SHOULD be available
        // Use a position derived from the generated code so it is always within the braces.
        let col_in_body = code.find('{').map(|i| (i + 2) as u32).unwrap_or(0);
        let scope_inside = scope_at_position(&artifacts, 0, col_in_body, false);
        prop_assert!(scope_inside.symbols.contains_key(param_name.as_str()),
            "Named parameter should be available inside function");
        prop_assert!(scope_inside.symbols.contains_key("..."),
            "Ellipsis parameter should be available inside function");
    }
}

// ============================================================================
// Property 12: Forward Directive Order Preservation
// Validates: Requirements 2.4
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 12: For any file containing multiple @lsp-source directives,
    /// the parsed ForwardSource list SHALL maintain the same order as they
    /// appear in the document.
    #[test]
    fn prop_forward_directive_order_preservation(
        file1 in path_component(),
        file2 in path_component(),
        file3 in path_component()
    ) {
        prop_assume!(file1 != file2 && file2 != file3 && file1 != file3);

        let content = format!(
            "# @lsp-source {}.R\n# @lsp-source {}.R\n# @lsp-source {}.R",
            file1, file2, file3
        );
        let meta = parse_directives(&content);

        prop_assert_eq!(meta.sources.len(), 3);
        prop_assert_eq!(&meta.sources[0].path, &format!("{}.R", file1));
        prop_assert_eq!(&meta.sources[1].path, &format!("{}.R", file2));
        prop_assert_eq!(&meta.sources[2].path, &format!("{}.R", file3));

        // Lines should be in order
        prop_assert!(meta.sources[0].line < meta.sources[1].line);
        prop_assert!(meta.sources[1].line < meta.sources[2].line);
    }
}

// ============================================================================
// Property 46: Forward Directive as Explicit Source
// Validates: Requirements 2.1
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 46: For any file containing @lsp-source <path> at line N,
    /// the Directive_Parser SHALL treat it as an explicit source() declaration at line N.
    #[test]
    fn prop_forward_directive_as_explicit_source(
        path in relative_path(),
        prefix_lines in 0..5u32
    ) {
        let mut lines = Vec::new();
        for i in 0..prefix_lines {
            lines.push(format!("x{} <- {}", i, i));
        }
        lines.push(format!("# @lsp-source {}", path));
        let content = lines.join("\n");

        let meta = parse_directives(&content);

        prop_assert_eq!(meta.sources.len(), 1);
        prop_assert_eq!(&meta.sources[0].path, &path);
        prop_assert_eq!(meta.sources[0].line, prefix_lines);
        prop_assert!(meta.sources[0].is_directive);
    }
}

// ============================================================================
// Property 24: Scope Cache Invalidation on Interface Change
// Validates: Requirements 0.3, 12.4, 12.5
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(50))]

    /// Property 24: For any file whose exported interface changes, all files that
    /// depend on it SHALL have their scope caches invalidated.
    #[test]
    fn prop_scope_cache_invalidation_on_interface_change(
        symbol1 in "[a-zA-Z][a-zA-Z0-9_]{0,5}",
        symbol2 in "[a-zA-Z][a-zA-Z0-9_]{0,5}"
    ) {
        prop_assume!(symbol1 != symbol2);

        let uri = make_url("test");

        // First version: defines symbol1
        let code1 = format!("{} <- 42", symbol1);
        let tree1 = parse_r_tree(&code1);
        let artifacts1 = compute_artifacts(&uri, &tree1, &code1);

        // Second version: defines symbol2 (different interface)
        let code2 = format!("{} <- 42", symbol2);
        let tree2 = parse_r_tree(&code2);
        let artifacts2 = compute_artifacts(&uri, &tree2, &code2);

        // Interface hashes should be different
        prop_assert_ne!(artifacts1.interface_hash, artifacts2.interface_hash);
    }
}

// ============================================================================
// Property 39: Interface Hash Optimization
// Validates: Requirements 12.11
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(50))]

    /// Property 39: For any file change where the exported interface hash remains
    /// identical and the edge set remains identical, dependent files SHALL NOT
    /// have their scope caches invalidated.
    #[test]
    fn prop_interface_hash_optimization(
        symbol in "[a-zA-Z][a-zA-Z0-9_]{0,5}",
        value1 in 1..100i32,
        value2 in 100..200i32
    ) {
        let uri = make_url("test");

        // Two versions with same symbol name but different values
        // Interface hash should be the same (same symbol name and kind)
        let code1 = format!("{} <- {}", symbol, value1);
        let code2 = format!("{} <- {}", symbol, value2);

        let tree1 = parse_r_tree(&code1);
        let tree2 = parse_r_tree(&code2);

        let artifacts1 = compute_artifacts(&uri, &tree1, &code1);
        let artifacts2 = compute_artifacts(&uri, &tree2, &code2);

        // Interface hashes should be the same (same exported symbols)
        prop_assert_eq!(artifacts1.interface_hash, artifacts2.interface_hash);
    }
}

// ============================================================================
// Property 19: Backward-First Resolution Order
// Validates: Requirements 5.1, 5.2
// ============================================================================

use super::scope::scope_at_position_with_graph;
use super::types::BackwardDirective;

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 19: For any file with both backward directives and forward source() calls,
    /// the Scope_Resolver SHALL process backward directives before forward sources,
    /// resulting in parent symbols being available before sourced file symbols.
    #[test]
    fn prop_backward_first_resolution_order(
        parent_symbol in r_identifier(),
        child_symbol in r_identifier(),
        sibling_symbol in r_identifier()
    ) {
        // Ensure all symbols are distinct
        prop_assume!(parent_symbol != child_symbol && child_symbol != sibling_symbol && parent_symbol != sibling_symbol);

        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let sibling_uri = make_url("sibling");
        let workspace_root = Url::parse("file:///workspace").unwrap();

        // Parent file: defines parent_symbol
        let parent_code = format!("{} <- 1", parent_symbol);
        let parent_tree = parse_r_tree(&parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, &parent_code);

        // Sibling file: defines sibling_symbol
        let sibling_code = format!("{} <- 2", sibling_symbol);
        let sibling_tree = parse_r_tree(&sibling_code);
        let sibling_artifacts = compute_artifacts(&sibling_uri, &sibling_tree, &sibling_code);

        // Child file: has backward directive to parent, forward source to sibling, and defines child_symbol
        // The backward directive means parent's symbols are available at the START
        // The forward source means sibling's symbols are available AFTER the source() call
        let child_code = format!(
            "# @lsp-sourced-by ../parent.R\n{} <- 3\nsource(\"sibling.R\")",
            child_symbol
        );
        let child_tree = parse_r_tree(&child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, &child_code);

        // Create metadata for child (with backward directive)
        let child_metadata = CrossFileMetadata {
            sourced_by: vec![BackwardDirective {
                path: "../parent.R".to_string(),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        graph.update_file(
            &child_uri,
            &child_metadata,
            Some(&workspace_root),
            |parent_uri_check| {
                if parent_uri_check == &parent_uri {
                    Some(parent_code.clone())
                } else {
                    None
                }
            },
        );

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);
        let sibling_artifacts = Arc::new(sibling_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else if uri == &sibling_uri { Some(Arc::clone(&sibling_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &child_uri { Some(std::sync::Arc::new(child_metadata.clone())) }
            else { None }
        };

        // At line 0 (before any code), parent symbols should be available (from backward directive)
        // but sibling symbols should NOT be available (forward source hasn't been processed yet)
        let scope_at_start = scope_at_position_with_graph(
            &child_uri, 0, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );
        prop_assert!(scope_at_start.symbols.contains_key(parent_symbol.as_str()),
            "Parent symbol should be available at start due to backward directive");
        prop_assert!(!scope_at_start.symbols.contains_key(sibling_symbol.as_str()),
            "Sibling symbol should NOT be available at start (before source() call)");

        // At line 1 (after child_symbol definition, before source() call).
        // Query at the column immediately after `{child_symbol} <- 3` ends so
        // the binding is installed; querying mid-assignment would correctly
        // not yet show the symbol (RHS-before-binding semantics).
        let line1_end = format!("{} <- 3", child_symbol).len() as u32;
        let scope_at_middle = scope_at_position_with_graph(
            &child_uri, 1, line1_end, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );
        prop_assert!(scope_at_middle.symbols.contains_key(parent_symbol.as_str()),
            "Parent symbol should still be available");
        prop_assert!(scope_at_middle.symbols.contains_key(child_symbol.as_str()),
            "Child symbol should be available after its definition");
        prop_assert!(!scope_at_middle.symbols.contains_key(sibling_symbol.as_str()),
            "Sibling symbol should NOT be available (before source() call)");

        // At line 3 (after source() call), all symbols should be available
        let scope_at_end = scope_at_position_with_graph(
            &child_uri, 3, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );
        prop_assert!(scope_at_end.symbols.contains_key(parent_symbol.as_str()),
            "Parent symbol should be available at end");
        prop_assert!(scope_at_end.symbols.contains_key(child_symbol.as_str()),
            "Child symbol should be available at end");
        prop_assert!(scope_at_end.symbols.contains_key(sibling_symbol.as_str()),
            "Sibling symbol should be available after source() call");
    }

    /// Property 19 extended: Backward directive symbols are available at position (0, 0)
    #[test]
    fn prop_backward_symbols_available_at_start(
        parent_symbol in r_identifier()
    ) {
        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///workspace").unwrap();

        // Parent file: defines symbol
        let parent_code = format!("{} <- 42", parent_symbol);
        let parent_tree = parse_r_tree(&parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, &parent_code);

        // Child file: has backward directive to parent
        let child_code = "# @lsp-sourced-by ../parent.R\nx <- 1";
        let child_tree = parse_r_tree(child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, child_code);

        let child_metadata = CrossFileMetadata {
            sourced_by: vec![BackwardDirective {
                path: "../parent.R".to_string(),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        graph.update_file(
            &child_uri,
            &child_metadata,
            Some(&workspace_root),
            |parent_uri_check| {
                if parent_uri_check == &parent_uri {
                    Some(parent_code.clone())
                } else {
                    None
                }
            },
        );

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &child_uri { Some(std::sync::Arc::new(child_metadata.clone())) }
            else { None }
        };

        // At position (0, 0), parent symbol should be available
        let scope = scope_at_position_with_graph(
            &child_uri, 0, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );
        prop_assert!(scope.symbols.contains_key(parent_symbol.as_str()),
            "Parent symbol from backward directive should be available at (0, 0)");
    }
}

// ============================================================================
// Property 20: Call Site Symbol Filtering
// Validates: Requirements 5.5
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 20: For any backward directive with line=N (user-facing 1-based),
    /// after conversion to internal 0-based call_site_line, the scope inherited
    /// from the parent MUST include exactly the definitions at positions
    /// (def_line, def_col) such that (def_line, def_col) <= (call_site_line, call_site_col).
    #[test]
    fn prop_call_site_symbol_filtering(
        symbol_before in r_identifier(),
        symbol_after in r_identifier(),
        call_site_line in 2..5u32 // 1-based line number
    ) {
        prop_assume!(symbol_before != symbol_after);
        // Ensure symbol_after doesn't conflict with intermediate variables (x1, x2, etc.)
        prop_assume!(!symbol_after.starts_with('x') || symbol_after.len() < 2 || !symbol_after[1..].chars().all(|c| c.is_ascii_digit()));

        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///workspace").unwrap();

        // Parent file: defines symbol_before on line 0, symbol_after on line call_site_line + 1
        // (one line AFTER the call site)
        let mut parent_lines = vec![format!("{} <- 1", symbol_before)];
        for i in 1..=call_site_line {
            parent_lines.push(format!("filler{} <- {}", i, i));
        }
        // symbol_after is defined AFTER the call site line
        parent_lines.push(format!("{} <- 2", symbol_after));
        let parent_code = parent_lines.join("\n");
        let parent_tree = parse_r_tree(&parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, &parent_code);

        // Child file: has backward directive with line= parameter
        // Use a unique variable name that won't conflict with symbol_before or symbol_after
        let child_code = format!("# @lsp-sourced-by ../parent.R line={}\nchild_local_var <- 3", call_site_line);
        let child_tree = parse_r_tree(&child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, &child_code);

        // line= is 1-based, so line=N means call site is at 0-based line N-1
        // We treat line= as end-of-line, so symbols on that line ARE included
        let child_metadata = CrossFileMetadata {
            sourced_by: vec![BackwardDirective {
                path: "../parent.R".to_string(),
                call_site: CallSiteSpec::Line(call_site_line - 1), // 0-based
                directive_line: 0,
            }],
            ..Default::default()
        };

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        graph.update_file(
            &child_uri,
            &child_metadata,
            Some(&workspace_root),
            |parent_uri_check| {
                if parent_uri_check == &parent_uri {
                    Some(parent_code.clone())
                } else {
                    None
                }
            },
        );

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &child_uri { Some(std::sync::Arc::new(child_metadata.clone())) }
            else { None }
        };

        // Get scope at child
        let scope = scope_at_position_with_graph(
            &child_uri, 10, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );

        // symbol_before (defined on line 0) should be available (before call site)
        prop_assert!(scope.symbols.contains_key(symbol_before.as_str()),
            "Symbol defined before call site should be available");

        // symbol_after (defined on line call_site_line + 1) should NOT be available
        // because it's defined AFTER the call site line
        prop_assert!(!scope.symbols.contains_key(symbol_after.as_str()),
            "Symbol defined after call site should NOT be available");
    }
}

// ============================================================================
// Property 21: Default Call Site Behavior
// Validates: Requirements 5.6
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 21: For any backward directive without a call site specification,
    /// when assumeCallSite is "end", all symbols from the parent SHALL be included;
    /// when "start", no symbols from the parent SHALL be included.
    #[test]
    fn prop_default_call_site_behavior(
        parent_symbol in r_identifier()
    ) {
        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///workspace").unwrap();

        // Parent file: defines symbol
        let parent_code = format!("{} <- 42", parent_symbol);
        let parent_tree = parse_r_tree(&parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, &parent_code);

        // Child file: has backward directive with Default call site
        let child_code = "# @lsp-sourced-by ../parent.R\nx <- 1";
        let child_tree = parse_r_tree(child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, child_code);

        let child_metadata = CrossFileMetadata {
            sourced_by: vec![BackwardDirective {
                path: "../parent.R".to_string(),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        graph.update_file(
            &child_uri,
            &child_metadata,
            Some(&workspace_root),
            |parent_uri_check| {
                if parent_uri_check == &parent_uri {
                    Some(parent_code.clone())
                } else {
                    None
                }
            },
        );

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &child_uri { Some(std::sync::Arc::new(child_metadata.clone())) }
            else { None }
        };

        // With default call site (which defaults to "end"), all parent symbols should be available
        let scope = scope_at_position_with_graph(
            &child_uri, 10, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );

        // Default is "end", so all parent symbols should be included
        prop_assert!(scope.symbols.contains_key(parent_symbol.as_str()),
            "With default call site (end), parent symbol should be available");
    }
}

// ============================================================================
// Property 34: Configuration Change Re-resolution
// Validates: Requirements 11.11
// ============================================================================

use super::config::{CallSiteDefault, CrossFileConfig};

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 34: For any configuration change affecting scope resolution
    /// (e.g., assumeCallSite), all open documents SHALL have their scope chains re-resolved.
    #[test]
    fn prop_configuration_change_re_resolution(
        parent_symbol in r_identifier()
    ) {
        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///workspace").unwrap();

        // Parent file: defines symbol at line 5
        let parent_code = format!("x <- 1\ny <- 2\nz <- 3\nw <- 4\n{} <- 5", parent_symbol);
        let parent_tree = parse_r_tree(&parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, &parent_code);

        // Child file: has backward directive with Default call site
        let child_code = "# @lsp-sourced-by ../parent.R\na <- 1";
        let child_tree = parse_r_tree(child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, child_code);

        let child_metadata = CrossFileMetadata {
            sourced_by: vec![BackwardDirective {
                path: "../parent.R".to_string(),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        graph.update_file(
            &child_uri,
            &child_metadata,
            Some(&workspace_root),
            |parent_uri_check| {
                if parent_uri_check == &parent_uri {
                    Some(parent_code.clone())
                } else {
                    None
                }
            },
        );

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &child_uri { Some(std::sync::Arc::new(child_metadata.clone())) }
            else { None }
        };

        // With default config (assume_call_site = End), parent symbol should be available
        let config_end = CrossFileConfig::default();
        prop_assert_eq!(config_end.assume_call_site, CallSiteDefault::End);

        let scope_with_end = scope_at_position_with_graph(
            &child_uri, 10, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );
        prop_assert!(scope_with_end.symbols.contains_key(parent_symbol.as_str()),
            "With assume_call_site=End, parent symbol should be available");

        // Verify that scope_settings_changed detects the change
        let mut config_start = CrossFileConfig::default();
        config_start.assume_call_site = CallSiteDefault::Start;
        prop_assert!(config_end.scope_settings_changed(&config_start),
            "Config change should be detected");

        // Note: The actual re-resolution would happen in the revalidation system.
        // This test verifies that the configuration change detection works correctly.
    }

    /// Property 34 extended: Changing max_chain_depth should trigger re-resolution
    #[test]
    fn prop_config_max_depth_change_detected(
        new_depth in 1..50usize
    ) {
        let config1 = CrossFileConfig::default();
        let mut config2 = CrossFileConfig::default();
        config2.max_chain_depth = new_depth;

        if new_depth != config1.max_chain_depth {
            prop_assert!(config1.scope_settings_changed(&config2),
                "Changing max_chain_depth should trigger scope settings change");
        }
    }
}

// ============================================================================
// Undefined Variables Configuration
// Validates: Requirements 11.9, 11.10
// ============================================================================

/// Verifies the struct-level contract for `undefined_variable_severity`: the
/// default is `Some(WARNING)`, it is freely assignable to `None` ("off"), and
/// toggling it does not trip `scope_settings_changed` (it only affects
/// diagnostic emission, not scope resolution).
///
/// End-to-end "no diagnostics emitted when severity is None" coverage lives in
/// `handlers.rs` (the gate at the start of `diagnostics_from_snapshot` skips
/// `collect_undefined_variables_from_snapshot` entirely when severity is None).
#[test]
fn test_undefined_variable_severity_configuration() {
    use tower_lsp::lsp_types::DiagnosticSeverity;

    let mut config = CrossFileConfig::default();
    assert_eq!(
        config.undefined_variable_severity,
        Some(DiagnosticSeverity::WARNING),
        "Default undefined_variable_severity should be Some(WARNING)"
    );

    config.undefined_variable_severity = None;
    assert!(
        config.undefined_variable_severity.is_none(),
        "undefined_variable_severity should be settable to None"
    );

    // Toggling severity is not scope-affecting.
    let config1 = CrossFileConfig::default();
    let mut config2 = CrossFileConfig::default();
    config2.undefined_variable_severity = None;
    assert!(
        !config1.scope_settings_changed(&config2),
        "Changing undefined_variable_severity to None should NOT trigger scope change"
    );

    // Non-None -> non-None transitions (e.g. WARNING -> ERROR) are also not
    // scope-affecting; severity only impacts diagnostic emission.
    let mut config3 = CrossFileConfig::default();
    config3.undefined_variable_severity = Some(DiagnosticSeverity::ERROR);
    assert!(
        !config1.scope_settings_changed(&config3),
        "Changing undefined_variable_severity from WARNING to ERROR should NOT trigger scope change"
    );
}

// ============================================================================
// Property 35: Diagnostics Fanout to Open Files
// Validates: Requirements 0.4, 13.4
// ============================================================================

use super::revalidation::{
    CrossFileActivityState, CrossFileDiagnosticsGate, CrossFileRevalidationState,
};

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 35: For any file change that invalidates dependent files, all affected
    /// open files SHALL receive updated diagnostics without requiring user edits.
    ///
    /// This test verifies the revalidation scheduling mechanism works correctly.
    #[test]
    fn prop_diagnostics_fanout_to_open_files(
        num_files in 1..10usize
    ) {
        let state = CrossFileRevalidationState::new();
        let mut tokens = Vec::new();

        // Schedule revalidation for multiple files
        for i in 0..num_files {
            let uri = make_url(&format!("file{}", i));
            let (_, token) = state.schedule(uri);
            tokens.push(token);
        }

        // All tokens should be valid (not cancelled)
        for token in &tokens {
            prop_assert!(!token.is_cancelled(),
                "Scheduled revalidation tokens should not be cancelled");
        }
    }
}

// ============================================================================
// Property 36: Debounce Cancellation
// Validates: Requirements 0.5
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 36: For any sequence of rapid changes to a file, only the final
    /// change SHALL result in published diagnostics; intermediate pending
    /// revalidations SHALL be cancelled.
    #[test]
    fn prop_debounce_cancellation(
        num_changes in 2..10usize
    ) {
        let state = CrossFileRevalidationState::new();
        let uri = make_url("test");
        let mut tokens = Vec::new();

        // Simulate rapid changes by scheduling multiple times
        for _ in 0..num_changes {
            let (_, token) = state.schedule(uri.clone());
            tokens.push(token);
        }

        // All but the last token should be cancelled
        for (i, token) in tokens.iter().enumerate() {
            if i < num_changes - 1 {
                prop_assert!(token.is_cancelled(),
                    "Intermediate revalidation should be cancelled");
            } else {
                prop_assert!(!token.is_cancelled(),
                    "Final revalidation should not be cancelled");
            }
        }
    }
}

// ============================================================================
// Property 41: Freshness Guard Prevents Stale Diagnostics
// Validates: Requirements 0.6
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 41: For any debounced/background diagnostics task, if either the
    /// document version OR the document content hash/revision changes between task
    /// scheduling and publishing, the task SHALL NOT publish diagnostics.
    ///
    /// This test verifies the diagnostics gate mechanism.
    #[test]
    fn prop_freshness_guard_prevents_stale(
        initial_version in 1..100i32,
        new_version in 1..100i32
    ) {
        let gate = CrossFileDiagnosticsGate::new();
        let uri = make_url("test");

        // Record initial publish
        gate.record_publish(&uri, initial_version);

        // Check if new version can be published
        let can_publish = gate.can_publish(&uri, new_version);

        if new_version > initial_version {
            prop_assert!(can_publish, "Newer version should be publishable");
        } else if new_version < initial_version {
            prop_assert!(!can_publish, "Older version should be blocked");
        } else {
            // Same version without force should be blocked
            prop_assert!(!can_publish, "Same version without force should be blocked");
        }
    }
}

// ============================================================================
// Property 47: Monotonic Diagnostic Publishing
// Validates: Requirements 0.7
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 47: For any sequence of diagnostic publish attempts for a document,
    /// the server SHALL never publish diagnostics for a document version older than
    /// the most recently published version for that document.
    #[test]
    fn prop_monotonic_diagnostic_publishing(
        versions in prop::collection::vec(1..100i32, 1..10)
    ) {
        let gate = CrossFileDiagnosticsGate::new();
        let uri = make_url("test");

        let mut max_published = 0i32;

        for version in versions {
            let can_publish = gate.can_publish(&uri, version);

            if version > max_published {
                // Should be able to publish newer versions
                prop_assert!(can_publish, "Should be able to publish version {} > {}", version, max_published);
                gate.record_publish(&uri, version);
                max_published = version;
            } else {
                // Should NOT be able to publish older or same versions
                prop_assert!(!can_publish, "Should NOT be able to publish version {} <= {}", version, max_published);
            }
        }
    }
}

// ============================================================================
// Property 48: Force Republish on Dependency Change
// Validates: Requirements 0.8
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 48: For any open document whose dependency-driven scope/diagnostic
    /// inputs change without changing its text document version, the server SHALL
    /// provide a mechanism to force republish updated diagnostics.
    #[test]
    fn prop_force_republish_on_dependency_change(
        version in 1..100i32
    ) {
        let gate = CrossFileDiagnosticsGate::new();
        let uri = make_url("test");

        // Initial publish
        gate.record_publish(&uri, version);

        // Without force, same version should be blocked
        prop_assert!(!gate.can_publish(&uri, version),
            "Same version without force should be blocked");

        // Mark for force republish (simulating dependency change)
        gate.mark_force_republish(&uri);

        // With force, same version should be allowed
        prop_assert!(gate.can_publish(&uri, version),
            "Same version with force should be allowed");

        // But older versions should still be blocked
        if version > 1 {
            prop_assert!(!gate.can_publish(&uri, version - 1),
                "Older version should still be blocked even with force");
        }
    }
}

// ============================================================================
// Property 42: Revalidation Prioritization
// Validates: Requirements 0.9
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 42: For any invalidation affecting multiple open documents, the
    /// trigger document SHALL be revalidated before other open documents.
    /// If the client provides active/visible document hints, the server SHOULD
    /// prioritize: active > visible > other open.
    #[test]
    fn prop_revalidation_prioritization(
        num_files in 2..10usize
    ) {
        let mut state = CrossFileActivityState::new();

        // Create URIs
        let uris: Vec<_> = (0..num_files)
            .map(|i| make_url(&format!("file{}", i)))
            .collect();

        // Set first as active, second as visible, rest as recent
        if !uris.is_empty() {
            state.update(Some(uris[0].clone()), vec![], 0);
        }
        if uris.len() > 1 {
            state.update(state.active_uri.clone(), vec![uris[1].clone()], 0);
        }
        for uri in uris.iter().skip(2) {
            state.record_recent(uri.clone());
        }

        // Verify priority ordering
        if !uris.is_empty() {
            prop_assert_eq!(state.priority_score(&uris[0]), 0, "Active should have priority 0");
        }
        if uris.len() > 1 {
            prop_assert_eq!(state.priority_score(&uris[1]), 1, "Visible should have priority 1");
        }
        // Recent files get priority = position_in_recent + 2
        // Since we add them in order (2, 3, 4, ...), the last one added is at position 0
        // So file[2] is at position num_files-3, file[3] is at position num_files-4, etc.
        // Actually, record_recent adds to front, so the order is reversed
        for (i, uri) in uris.iter().enumerate().skip(2) {
            let position_in_recent = num_files - 1 - i; // Last added is at position 0
            let expected_priority = position_in_recent + 2;
            prop_assert_eq!(state.priority_score(uri), expected_priority,
                "Recent file {} should have priority {}", i, expected_priority);
        }
    }
}

// ============================================================================
// Property 43: Revalidation Cap Enforcement
// Validates: Requirements 0.9, 0.10
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 43: For any invalidation affecting more open documents than
    /// maxRevalidationsPerTrigger, only the first N documents (prioritized)
    /// SHALL be scheduled.
    #[test]
    fn prop_revalidation_cap_enforcement(
        num_files in 1..20usize,
        cap in 1..10usize
    ) {
        let mut state = CrossFileActivityState::new();

        // Create URIs and add to recent
        let uris: Vec<_> = (0..num_files)
            .map(|i| make_url(&format!("file{}", i)))
            .collect();

        for uri in &uris {
            state.record_recent(uri.clone());
        }

        // Sort by priority
        let mut sorted_uris = uris.clone();
        sorted_uris.sort_by_key(|u| state.priority_score(u));

        // Take only up to cap
        let scheduled: Vec<_> = sorted_uris.into_iter().take(cap).collect();

        // Verify cap is respected
        prop_assert!(scheduled.len() <= cap,
            "Scheduled count {} should not exceed cap {}", scheduled.len(), cap);

        // Verify prioritization (lower priority scores come first)
        for i in 1..scheduled.len() {
            let prev_score = state.priority_score(&scheduled[i - 1]);
            let curr_score = state.priority_score(&scheduled[i]);
            prop_assert!(prev_score <= curr_score,
                "Priority should be non-decreasing: {} <= {}", prev_score, curr_score);
        }
    }
}

// ============================================================================
// Property 44: Workspace Index Version Monotonicity
// Validates: Requirements 13.5
// ============================================================================

use super::file_cache::{CrossFileFileCache, FileSnapshot};
use std::time::SystemTime;
// ============================================================================
// Property 45: Watched File Cache Invalidation
// Validates: Requirements 13.2
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 45: For any watched file that is created or changed on disk,
    /// the disk-backed caches for that file SHALL be invalidated.
    #[test]
    fn prop_watched_file_cache_invalidation(
        file_name in path_component(),
        content1 in "[a-zA-Z_][a-zA-Z0-9_]{0,10} <- [0-9]{1,5}",
        content2 in "[a-zA-Z_][a-zA-Z0-9_]{0,10} <- [0-9]{1,5}"
    ) {
        let cache = CrossFileFileCache::new();
        let uri = make_url(&file_name);

        let snapshot1 = FileSnapshot {
            mtime: SystemTime::UNIX_EPOCH,
            size: content1.len() as u64,
            content_hash: None,
        };

        // Insert initial content
        cache.insert(uri.clone(), snapshot1.clone(), content1.clone());
        prop_assert_eq!(cache.get(&uri), Some(content1.clone()));

        // Simulate file change by invalidating
        cache.invalidate(&uri);

        // Cache should be empty after invalidation
        prop_assert!(cache.get(&uri).is_none(),
            "Cache should be empty after invalidation");

        // Insert new content with a different, deterministic snapshot.
        // Fixed time strictly after snapshot1's UNIX_EPOCH so snapshot1 != snapshot2
        // without depending on the wall clock.
        let snapshot2 = FileSnapshot {
            mtime: SystemTime::UNIX_EPOCH + std::time::Duration::from_secs(1),
            size: content2.len() as u64,
            content_hash: None,
        };
        cache.insert(uri.clone(), snapshot2.clone(), content2.clone());

        // Should have new content
        prop_assert_eq!(cache.get(&uri), Some(content2.clone()));

        // Old snapshot should not match
        prop_assert!(cache.get_if_fresh(&uri, &snapshot1).is_none(),
            "Old snapshot should not match after file change");

        // New snapshot should match
        prop_assert_eq!(cache.get_if_fresh(&uri, &snapshot2), Some(content2));
    }

    /// Property 45 extended: Invalidate all clears entire cache
    #[test]
    fn prop_watched_file_cache_invalidate_all(
        num_files in 1..10usize
    ) {
        let cache = CrossFileFileCache::new();

        // Insert multiple files
        for i in 0..num_files {
            let uri = make_url(&format!("file{}", i));
            let snapshot = FileSnapshot {
                mtime: SystemTime::UNIX_EPOCH,
                size: 10,
                content_hash: None,
            };
            cache.insert(uri, snapshot, format!("content{}", i));
        }

        // Verify all files are cached
        for i in 0..num_files {
            let uri = make_url(&format!("file{}", i));
            prop_assert!(cache.get(&uri).is_some());
        }

        // Invalidate all
        cache.invalidate_all();

        // All files should be gone
        for i in 0..num_files {
            let uri = make_url(&format!("file{}", i));
            prop_assert!(cache.get(&uri).is_none());
        }
    }
}

// ============================================================================
// Property 5: Diagnostic Suppression
// Validates: Requirements 2.2, 2.3, 10.4, 10.5
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 5: For any file containing `# @lsp-ignore` on line n, no diagnostics
    /// SHALL be emitted for line n. For any file containing `# @lsp-ignore-next` on
    /// line n, no diagnostics SHALL be emitted for line n+1.
    #[test]
    fn prop_diagnostic_suppression(
        line_num in 0u32..10
    ) {
        use super::directive::{parse_directives, is_line_ignored};

        // Test @lsp-ignore suppresses diagnostics on same line
        let code_ignore = format!(
            "{}undefined_var # @lsp-ignore",
            "\n".repeat(line_num as usize)
        );
        let metadata = parse_directives(&code_ignore);

        // The @lsp-ignore directive should be parsed
        prop_assert!(metadata.ignored_lines.contains_key(&line_num),
            "Line {} should be in ignored_lines", line_num);
        prop_assert!(is_line_ignored(&metadata, line_num),
            "Line {} should be ignored", line_num);

        // Test @lsp-ignore-next suppresses diagnostics on next line
        let code_ignore_next = format!(
            "{}# @lsp-ignore-next\nundefined_var",
            "\n".repeat(line_num as usize)
        );
        let metadata_next = parse_directives(&code_ignore_next);

        // The line after @lsp-ignore-next should be in ignored_next_lines
        prop_assert!(metadata_next.ignored_next_lines.contains_key(&(line_num + 1)),
            "Line {} should be in ignored_next_lines (from @lsp-ignore-next)", line_num + 1);
        prop_assert!(is_line_ignored(&metadata_next, line_num + 1),
            "Line {} should be ignored (from @lsp-ignore-next)", line_num + 1);
    }
}

// ============================================================================
// Property 6: Missing File Diagnostics
// Validates: Requirements 1.8, 2.5, 10.2
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 6: For any directive or source() call referencing a non-existent
    /// file path, the Diagnostic_Engine SHALL emit exactly one warning diagnostic
    /// at the location of that reference.
    #[test]
    fn prop_missing_file_diagnostics(
        missing_path in "[a-z]{3,8}\\.R"
    ) {
        use super::source_detect::detect_source_calls;

        let code = format!("source(\"{}\")", missing_path);
        let tree = parse_r_tree(&code);
        let sources = detect_source_calls(&tree, &code);

        // Should detect the source() call
        prop_assert_eq!(sources.len(), 1,
            "Should detect exactly one source() call");

        // The forward source should have the path
        let forward = &sources[0];
        prop_assert_eq!(&forward.path, &missing_path,
            "Forward source should have the missing path");

        // When path resolution fails, a diagnostic should be emitted
        // (This is tested at the handler level - here we verify the path is captured)
        prop_assert!(forward.line == 0,
            "Source call should be on line 0");
    }
}

// ============================================================================
// Property 54: Diagnostics Gate Cleanup on Close
// Validates: Requirements 0.7, 0.8
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 54: For any document that is closed via textDocument/didClose,
    /// the server SHALL clear all diagnostics gate state for that URI.
    #[test]
    fn prop_diagnostics_gate_cleanup_on_close(
        version in 1i32..1000
    ) {
        let gate = CrossFileDiagnosticsGate::new();
        let uri = make_url("test");

        // Publish some diagnostics
        gate.record_publish(&uri, version);

        // Mark for force republish
        gate.mark_force_republish(&uri);

        // Verify state exists
        prop_assert!(!gate.can_publish(&uri, version - 1),
            "Should not be able to publish older version");

        // Clear state (simulating document close)
        gate.clear(&uri);

        // After clear, any version should be publishable (no history)
        prop_assert!(gate.can_publish(&uri, 1),
            "After clear, version 1 should be publishable");
        prop_assert!(gate.can_publish(&uri, version),
            "After clear, same version should be publishable");
        prop_assert!(gate.can_publish(&uri, version + 1),
            "After clear, newer version should be publishable");
    }
}

// ============================================================================
// Property 49: Client Activity Signal Processing
// Validates: Requirements 15.4, 15.5
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 49: For any rlsp/activeDocumentsChanged notification received
    /// from the client, the server SHALL update its internal activity model
    /// and use it to prioritize subsequent cross-file revalidations.
    #[test]
    fn prop_client_activity_signal_processing(
        active_idx in 0usize..5,
        visible_count in 1usize..5,
        timestamp in 0u64..10000
    ) {
        let mut state = CrossFileActivityState::new();

        // Create some URIs
        let uris: Vec<Url> = (0..5).map(|i| make_url(&format!("file{}", i))).collect();
        let active_uri = uris.get(active_idx).cloned();
        let visible_uris: Vec<Url> = uris.iter().take(visible_count).cloned().collect();

        // Update activity state (simulating client notification)
        state.update(active_uri.clone(), visible_uris.clone(), timestamp);

        // Verify state was updated
        prop_assert_eq!(&state.active_uri, &active_uri);
        prop_assert_eq!(&state.visible_uris, &visible_uris);
        prop_assert_eq!(state.timestamp_ms, timestamp);

        // Verify priority scoring
        if let Some(ref active) = active_uri {
            prop_assert_eq!(state.priority_score(active), 0,
                "Active document should have highest priority (0)");
        }

        for visible in &visible_uris {
            if active_uri.as_ref() != Some(visible) {
                prop_assert_eq!(state.priority_score(visible), 1,
                    "Visible (non-active) document should have priority 1");
            }
        }

        // Non-visible, non-active should have lower priority
        let other_uri = make_url("other");
        prop_assert!(state.priority_score(&other_uri) > 1,
            "Non-visible, non-active document should have priority > 1");
    }
}

// ============================================================================
// Integration Tests - Task 21
// ============================================================================

// 21.3 Edge cases and error handling

proptest! {
    #![proptest_config(ProptestConfig::with_cases(50))]

    /// Test UTF-16 correctness with emoji characters in paths
    #[test]
    fn prop_utf16_emoji_in_path(
        prefix in "[a-z]{1,5}",
        suffix in "[a-z]{1,5}"
    ) {
        // Path with emoji
        let path = format!("{}_🎉_{}.R", prefix, suffix);
        let code = format!("source(\"{}\")", path);
        let tree = parse_r_tree(&code);

        use super::source_detect::detect_source_calls;
        let sources = detect_source_calls(&tree, &code);

        prop_assert_eq!(sources.len(), 1);
        prop_assert_eq!(&sources[0].path, &path);
    }

    /// Test UTF-16 correctness with CJK characters in paths
    #[test]
    fn prop_utf16_cjk_in_path(
        prefix in "[a-z]{1,5}",
        suffix in "[a-z]{1,5}"
    ) {
        // Path with CJK characters
        let path = format!("{}_日本語_{}.R", prefix, suffix);
        let code = format!("source(\"{}\")", path);
        let tree = parse_r_tree(&code);

        use super::source_detect::detect_source_calls;
        let sources = detect_source_calls(&tree, &code);

        prop_assert_eq!(sources.len(), 1);
        prop_assert_eq!(&sources[0].path, &path);
    }
}

// 21.5 Position-aware scope edge cases

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Test multiple source() calls on same line
    #[test]
    fn prop_multiple_source_calls_same_line(
        path1 in "[a-z]{3,8}\\.R",
        path2 in "[a-z]{3,8}\\.R"
    ) {
        // Two source() calls on same line
        let code = format!("source(\"{}\"); source(\"{}\")", path1, path2);
        let tree = parse_r_tree(&code);

        use super::source_detect::detect_source_calls;
        let sources = detect_source_calls(&tree, &code);

        // Should detect both source() calls
        prop_assert_eq!(sources.len(), 2);

        // Both should be on line 0
        prop_assert_eq!(sources[0].line, 0);
        prop_assert_eq!(sources[1].line, 0);

        // Paths should be correct
        let paths: Vec<&str> = sources.iter().map(|s| s.path.as_str()).collect();
        prop_assert!(paths.contains(&path1.as_str()));
        prop_assert!(paths.contains(&path2.as_str()));
    }
}

// 21.4 v1 R symbol model edge cases

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Test that assign() with string literal is recognized
    #[test]
    fn prop_assign_string_literal_recognized(
        symbol_name in r_identifier()
    ) {
        let code = format!("assign(\"{}\", 42)", symbol_name);
        let tree = parse_r_tree(&code);
        let uri = make_url("test");
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // assign() with string literal should be recognized
        prop_assert!(artifacts.exported_interface.contains_key(symbol_name.as_str()),
            "assign() with string literal should be recognized");
    }

    /// Test that assign() with variable is NOT recognized (dynamic)
    #[test]
    fn prop_assign_variable_not_recognized(
        var_name in r_identifier()
    ) {
        let code = format!("assign({}, 42)", var_name);
        let tree = parse_r_tree(&code);
        let uri = make_url("test");
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // assign() with variable should NOT be recognized (dynamic)
        prop_assert!(!artifacts.exported_interface.contains_key(var_name.as_str()),
            "assign() with variable should NOT be recognized (dynamic)");
    }
}

// ============================================================================
// Property 1: Loop Iterator Scope Inclusion
// Validates: Loop iterator detection and scope persistence
// ============================================================================

use super::scope::scope_at_position;

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 1: For any for loop with iterator variable i, the iterator SHALL
    /// be included in the exported interface and available in scope after the
    /// for statement position.
    #[test]
    fn prop_loop_iterator_scope_inclusion(
        iterator_name in r_identifier()
    ) {
        let uri = make_url("test");

        // Code with for loop
        let code = format!("for ({} in 1:10) {{ print({}) }}", iterator_name, iterator_name);
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Iterator should be in exported interface
        prop_assert!(artifacts.exported_interface.contains_key(iterator_name.as_str()),
            "Loop iterator should be in exported interface");

        // Iterator should have Variable kind
        let symbol = artifacts.exported_interface.get(iterator_name.as_str()).unwrap();
        prop_assert_eq!(symbol.kind, super::scope::SymbolKind::Variable,
            "Loop iterator should have Variable kind");

        // Iterator should be available in timeline as Def event
        let has_def_event = artifacts.timeline.iter().any(|event| {
            matches!(event, super::scope::ScopeEvent::Def { symbol, .. } if *symbol.name == *iterator_name)
        });
        prop_assert!(has_def_event, "Loop iterator should have Def event in timeline");
    }

    /// Property 1 extended: Loop iterator persists after loop completion
    #[test]
    fn prop_loop_iterator_persists_after_loop(
        iterator_name in r_identifier(),
        var_name in r_identifier()
    ) {
        prop_assume!(iterator_name != var_name);

        let uri = make_url("test");

        // Code with for loop followed by variable assignment
        let code = format!(
            "for ({} in 1:5) {{ }}\n{} <- {}",
            iterator_name, var_name, iterator_name
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Both iterator and variable should be in exported interface
        prop_assert!(artifacts.exported_interface.contains_key(iterator_name.as_str()),
            "Loop iterator should persist after loop");
        prop_assert!(artifacts.exported_interface.contains_key(var_name.as_str()),
            "Variable should be in exported interface");

        // Get scope at end of code - iterator should be available
        let scope = scope_at_position(&artifacts, 10, 0, false);
        prop_assert!(scope.symbols.contains_key(iterator_name.as_str()),
            "Loop iterator should be available in scope after loop");
        prop_assert!(scope.symbols.contains_key(var_name.as_str()),
            "Variable should be available in scope");
    }

    /// Property 1 extended: Nested loops create multiple iterators
    #[test]
    fn prop_nested_loops_multiple_iterators(
        outer_iterator in r_identifier(),
        inner_iterator in r_identifier()
    ) {
        prop_assume!(outer_iterator != inner_iterator);

        let uri = make_url("test");

        // Code with nested for loops
        let code = format!(
            "for ({} in 1:3) {{ for ({} in 1:2) {{ print({}, {}) }} }}",
            outer_iterator, inner_iterator, outer_iterator, inner_iterator
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Both iterators should be in exported interface
        prop_assert!(artifacts.exported_interface.contains_key(outer_iterator.as_str()),
            "Outer loop iterator should be in exported interface");
        prop_assert!(artifacts.exported_interface.contains_key(inner_iterator.as_str()),
            "Inner loop iterator should be in exported interface");

        // Both should have Def events
        let outer_has_def = artifacts.timeline.iter().any(|event| {
            matches!(event, super::scope::ScopeEvent::Def { symbol, .. } if *symbol.name == *outer_iterator)
        });
        let inner_has_def = artifacts.timeline.iter().any(|event| {
            matches!(event, super::scope::ScopeEvent::Def { symbol, .. } if *symbol.name == *inner_iterator)
        });
        prop_assert!(outer_has_def, "Outer iterator should have Def event");
        prop_assert!(inner_has_def, "Inner iterator should have Def event");
    }
}

// ============================================================================
// Property 8: Function Parameter Scope Inclusion
// Validates: Function parameter detection and scope boundaries
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 8: For any function definition with parameters, the parameters
    /// SHALL be available in scope within the function body boundaries.
    #[test]
    fn prop_function_parameter_scope_inclusion(
        func_name in r_identifier(),
        param1 in r_identifier(),
        param2 in r_identifier()
    ) {
        prop_assume!(func_name != param1 && param1 != param2 && func_name != param2);

        let uri = make_url("test");

        // Function with multiple parameters
        let code = format!("{} <- function({}, {}) {{ {} + {} }}", func_name, param1, param2, param1, param2);
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Function should be in exported interface
        prop_assert!(artifacts.exported_interface.contains_key(func_name.as_str()),
            "Function should be in exported interface");

        // Should have FunctionScope event in timeline
        let has_function_scope = artifacts.timeline.iter().any(|event| {
            matches!(event, super::scope::ScopeEvent::FunctionScope { parameters, .. }
                if parameters.iter().any(|p| *p.name == *param1) &&
                   parameters.iter().any(|p| *p.name == *param2))
        });
        prop_assert!(has_function_scope, "Should have FunctionScope event with parameters");

        // Get scope within function body (should include parameters)
        // Use a position derived from the generated code so it is always within the braces.
        let col_in_body = code.find('{').map(|i| (i + 2) as u32).unwrap_or(0);
        let scope_in_body = scope_at_position(&artifacts, 0, col_in_body, false);
        prop_assert!(scope_in_body.symbols.contains_key(param1.as_str()),
            "Parameter 1 should be available within function body");
        prop_assert!(scope_in_body.symbols.contains_key(param2.as_str()),
            "Parameter 2 should be available within function body");
        prop_assert!(scope_in_body.symbols.contains_key(func_name.as_str()),
            "Function name should be available within function body");
    }

    /// Property 8 extended: Function with no parameters
    #[test]
    fn prop_function_no_parameters_scope(
        func_name in r_identifier()
    ) {
        let uri = make_url("test");

        let code = format!("{} <- function() {{ 42 }}", func_name);
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Should have FunctionScope event with empty parameters
        let has_function_scope = artifacts.timeline.iter().any(|event| {
            matches!(event, super::scope::ScopeEvent::FunctionScope { parameters, .. }
                if parameters.is_empty())
        });
        prop_assert!(has_function_scope, "Should have FunctionScope event with empty parameters");
    }

    /// Property 8 extended: Function with default parameter values
    #[test]
    fn prop_function_default_parameter_scope(
        func_name in r_identifier(),
        param_name in r_identifier()
    ) {
        prop_assume!(func_name != param_name);

        let uri = make_url("test");

        let code = format!("{} <- function({} = 42) {{ {} * 2 }}", func_name, param_name, param_name);
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Should have FunctionScope event with parameter
        let has_function_scope = artifacts.timeline.iter().any(|event| {
            matches!(event, super::scope::ScopeEvent::FunctionScope { parameters, .. }
                if parameters.iter().any(|p| *p.name == *param_name))
        });
        prop_assert!(has_function_scope, "Should have FunctionScope event with default parameter");

        // Parameter should be available within function body
        // Use a position derived from the generated code so it is always within the braces.
        let col_in_body = code.find('{').map(|i| (i + 2) as u32).unwrap_or(0);
        let scope_in_body = scope_at_position(&artifacts, 0, col_in_body, false);
        prop_assert!(scope_in_body.symbols.contains_key(param_name.as_str()),
            "Parameter with default value should be available within function body");
    }
}

// ============================================================================
// Task 11 Property Tests: Scope Resolution Invariants
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    // Feature: enhanced-variable-detection-hover, Property 2: Loop iterator persistence after loop
    #[test]
    fn prop_loop_iterator_persistence_after_loop(
        iterator_name in r_identifier()
    ) {
        let uri = make_url("test");

        // For loop with iterator variable
        let code = format!("for ({} in 1:10) {{ print({}) }}\nafter_loop <- {}",
                          iterator_name, iterator_name, iterator_name);
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Get scope at position after loop body completes
        let scope_after_loop = scope_at_position(&artifacts, 10, 0, false);

        // Iterator variable should still be included in available symbols
        prop_assert!(scope_after_loop.symbols.contains_key(iterator_name.as_str()),
            "Loop iterator should persist in scope after loop completes");
    }

    // Feature: enhanced-variable-detection-hover, Property 3: Nested loop iterator tracking
    #[test]
    fn prop_nested_loop_iterator_tracking(
        outer_iterator in r_identifier(),
        inner_iterator in r_identifier()
    ) {
        prop_assume!(outer_iterator != inner_iterator);

        let uri = make_url("test");

        // Nested for loops
        let code = format!(
            "for ({} in 1:3) {{ for ({} in 1:2) {{ print({}, {}) }} }}",
            outer_iterator, inner_iterator, outer_iterator, inner_iterator
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Get scope at position after both loops complete
        let scope_after_loops = scope_at_position(&artifacts, 10, 0, false);

        // Both outer and inner iterator variables should be available in scope
        prop_assert!(scope_after_loops.symbols.contains_key(outer_iterator.as_str()),
            "Outer loop iterator should be available after nested loops complete");
        prop_assert!(scope_after_loops.symbols.contains_key(inner_iterator.as_str()),
            "Inner loop iterator should be available after nested loops complete");
    }

    // Feature: enhanced-variable-detection-hover, Property 4: Loop iterator shadowing
    #[test]
    fn prop_loop_iterator_shadowing(
        var_name in r_identifier()
    ) {
        let uri = make_url("test");

        // Variable defined, then for loop uses same name as iterator
        let code = format!(
            "{} <- 42\nfor ({} in 1:5) {{ print({}) }}",
            var_name, var_name, var_name
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Get scope after the for statement
        let scope_after_for = scope_at_position(&artifacts, 10, 0, false);

        // Iterator definition should take precedence over original variable
        prop_assert!(scope_after_for.symbols.contains_key(var_name.as_str()),
            "Variable should be in scope after for loop");

        // The symbol should be the iterator (most recent definition)
        let symbol = scope_after_for.symbols.get(var_name.as_str()).unwrap();
        prop_assert_eq!(symbol.kind, super::scope::SymbolKind::Variable,
            "Symbol should be Variable kind (iterator)");
    }

    // Feature: enhanced-variable-detection-hover, Property 7: Function-local undefined variable diagnostics
    #[test]
    fn prop_function_local_undefined_variable_diagnostics(
        func_name in r_identifier(),
        local_var in r_identifier(),
        usage_var in r_identifier()
    ) {
        prop_assume!(func_name != local_var && local_var != usage_var && func_name != usage_var);

        let uri = make_url("test");

        // Function with local variable, then usage outside function
        let code = format!(
            "{} <- function() {{ {} <- 42 }}\nresult <- {}",
            func_name, local_var, local_var
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Get scope outside function body (where local_var is referenced)
        let scope_outside = scope_at_position(&artifacts, 1, 15, false);

        // Function-local variable should NOT be available outside function
        prop_assert!(!scope_outside.symbols.contains_key(local_var.as_str()),
            "Function-local variable should NOT be available outside function body");

        // Function name should be available
        prop_assert!(scope_outside.symbols.contains_key(func_name.as_str()),
            "Function name should be available outside function");
    }

    // Feature: enhanced-variable-detection-hover, Property 9: Function parameter with default value recognition
    #[test]
    fn prop_function_parameter_default_value_recognition(
        func_name in r_identifier(),
        param_with_default in r_identifier(),
        param_without_default in r_identifier()
    ) {
        prop_assume!(func_name != param_with_default && param_with_default != param_without_default && func_name != param_without_default);

        let uri = make_url("test");

        // Function with parameter with default value and parameter without
        let code = format!(
            "{} <- function({}, {} = 42) {{ {} + {} }}",
            func_name, param_without_default, param_with_default, param_without_default, param_with_default
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Get scope within function body
        // Use a position derived from the generated code so it is always within the braces.
        let col_in_body = code.find('{').map(|i| (i + 2) as u32).unwrap_or(0);
        let scope_in_body = scope_at_position(&artifacts, 0, col_in_body, false);

        // Both parameters should be recognized and included in function body scope
        prop_assert!(scope_in_body.symbols.contains_key(param_with_default.as_str()),
            "Parameter with default value should be recognized in function body scope");
        prop_assert!(scope_in_body.symbols.contains_key(param_without_default.as_str()),
            "Parameter without default value should be recognized in function body scope");

        // Both should have Parameter kind
        let param_with_default_symbol = scope_in_body.symbols.get(param_with_default.as_str()).unwrap();
        let param_without_default_symbol = scope_in_body.symbols.get(param_without_default.as_str()).unwrap();

        prop_assert_eq!(param_with_default_symbol.kind, super::scope::SymbolKind::Parameter,
            "Parameter with default should have Parameter kind");
        prop_assert_eq!(param_without_default_symbol.kind, super::scope::SymbolKind::Parameter,
            "Parameter without default should have Parameter kind");
    }
}

// ============================================================================
// Feature: rm-remove-support, Property 1: Bare Symbol Extraction
// Validates: Requirements 1.1, 1.2, 1.3
// ============================================================================

use super::source_detect::detect_rm_calls;

/// Generate rm() calls with bare symbols
fn rm_bare_symbols(symbols: &[String]) -> String {
    format!("rm({})", symbols.join(", "))
}

/// Generate remove() calls with bare symbols
fn remove_bare_symbols(symbols: &[String]) -> String {
    format!("remove({})", symbols.join(", "))
}

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: rm-remove-support, Property 1: Bare Symbol Extraction
    /// **Validates: Requirements 1.1, 1.2, 1.3**
    ///
    /// For any rm() or remove() call containing bare symbol arguments, the resulting
    /// Removal event SHALL contain exactly those symbol names, regardless of how many
    /// symbols are specified or whether they are currently defined in scope.
    #[test]
    fn prop_rm_bare_symbol_extraction_single(symbol in r_identifier()) {
        let code = rm_bare_symbols(std::slice::from_ref(&symbol));
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should detect exactly one rm() call
        prop_assert_eq!(rm_calls.len(), 1, "Expected exactly one rm() call");

        // Should extract exactly the symbol we provided
        prop_assert_eq!(rm_calls[0].symbols.len(), 1, "Expected exactly one symbol");
        prop_assert_eq!(&rm_calls[0].symbols[0], &symbol, "Symbol should match input");
    }

    /// Feature: rm-remove-support, Property 1: Bare Symbol Extraction (multiple symbols)
    /// **Validates: Requirements 1.1, 1.2, 1.3**
    ///
    /// For any rm() call with multiple bare symbol arguments, all symbols should be extracted.
    #[test]
    fn prop_rm_bare_symbol_extraction_multiple(
        symbols in prop::collection::vec(r_identifier(), 2..=5)
            .prop_filter("unique symbols", |v| {
                let mut sorted = v.clone();
                sorted.sort();
                sorted.dedup();
                sorted.len() == v.len()
            })
    ) {
        let code = rm_bare_symbols(&symbols);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should detect exactly one rm() call
        prop_assert_eq!(rm_calls.len(), 1, "Expected exactly one rm() call");

        // Should extract exactly the symbols we provided
        prop_assert_eq!(rm_calls[0].symbols.len(), symbols.len(),
            "Number of extracted symbols should match input");

        // All symbols should be present in the same order
        for (i, expected_symbol) in symbols.iter().enumerate() {
            prop_assert_eq!(&rm_calls[0].symbols[i], expected_symbol,
                "Symbol at position {} should match", i);
        }
    }

    /// Feature: rm-remove-support, Property 1: Bare Symbol Extraction (remove() alias)
    /// **Validates: Requirements 1.1, 1.2, 1.3**
    ///
    /// For any remove() call containing bare symbol arguments, the resulting
    /// Removal event SHALL contain exactly those symbol names.
    #[test]
    fn prop_remove_bare_symbol_extraction_single(symbol in r_identifier()) {
        let code = remove_bare_symbols(std::slice::from_ref(&symbol));
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should detect exactly one remove() call
        prop_assert_eq!(rm_calls.len(), 1, "Expected exactly one remove() call");

        // Should extract exactly the symbol we provided
        prop_assert_eq!(rm_calls[0].symbols.len(), 1, "Expected exactly one symbol");
        prop_assert_eq!(&rm_calls[0].symbols[0], &symbol, "Symbol should match input");
    }

    /// Feature: rm-remove-support, Property 1: Bare Symbol Extraction (remove() with multiple)
    /// **Validates: Requirements 1.1, 1.2, 1.3**
    ///
    /// For any remove() call with multiple bare symbol arguments, all symbols should be extracted.
    #[test]
    fn prop_remove_bare_symbol_extraction_multiple(
        symbols in prop::collection::vec(r_identifier(), 2..=5)
            .prop_filter("unique symbols", |v| {
                let mut sorted = v.clone();
                sorted.sort();
                sorted.dedup();
                sorted.len() == v.len()
            })
    ) {
        let code = remove_bare_symbols(&symbols);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should detect exactly one remove() call
        prop_assert_eq!(rm_calls.len(), 1, "Expected exactly one remove() call");

        // Should extract exactly the symbols we provided
        prop_assert_eq!(rm_calls[0].symbols.len(), symbols.len(),
            "Number of extracted symbols should match input");

        // All symbols should be present in the same order
        for (i, expected_symbol) in symbols.iter().enumerate() {
            prop_assert_eq!(&rm_calls[0].symbols[i], expected_symbol,
                "Symbol at position {} should match", i);
        }
    }

    /// Feature: rm-remove-support, Property 1: Bare Symbol Extraction (undefined symbols)
    /// **Validates: Requirements 1.1, 1.2, 1.3**
    ///
    /// Bare symbols in rm() should be extracted regardless of whether they are
    /// currently defined in scope (no error should occur).
    #[test]
    fn prop_rm_bare_symbol_extraction_undefined(symbol in r_identifier()) {
        // Symbol is not defined anywhere, just used in rm()
        let code = rm_bare_symbols(std::slice::from_ref(&symbol));
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should still detect the rm() call and extract the symbol
        prop_assert_eq!(rm_calls.len(), 1, "Expected exactly one rm() call");
        prop_assert_eq!(rm_calls[0].symbols.len(), 1, "Expected exactly one symbol");
        prop_assert_eq!(&rm_calls[0].symbols[0], &symbol, "Symbol should match input");
    }

    /// Feature: rm-remove-support, Property 1: Bare Symbol Extraction (position tracking)
    /// **Validates: Requirements 1.1, 1.2, 1.3**
    ///
    /// The rm() call should be detected at the correct line position.
    #[test]
    fn prop_rm_bare_symbol_extraction_position(
        symbol in r_identifier(),
        prefix_lines in 0..5usize
    ) {
        // Add some prefix lines before the rm() call
        let prefix = "\n".repeat(prefix_lines);
        let code = format!("{}rm({})", prefix, symbol);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should detect exactly one rm() call
        prop_assert_eq!(rm_calls.len(), 1, "Expected exactly one rm() call");

        // Line should match the number of prefix newlines
        prop_assert_eq!(rm_calls[0].line, prefix_lines as u32,
            "rm() call should be on line {}", prefix_lines);

        // Symbol should still be extracted correctly
        prop_assert_eq!(rm_calls[0].symbols.len(), 1, "Expected exactly one symbol");
        prop_assert_eq!(&rm_calls[0].symbols[0], &symbol, "Symbol should match input");
    }
}

// ============================================================================
// Feature: rm-remove-support, Property 2: remove() Equivalence
// Validates: Requirements 2.1, 2.2, 2.3
// ============================================================================

/// Generate rm() call with list= argument containing a single string
fn rm_list_single(symbol: &str) -> String {
    format!(r#"rm(list = "{}")"#, symbol)
}

/// Generate remove() call with list= argument containing a single string
fn remove_list_single(symbol: &str) -> String {
    format!(r#"remove(list = "{}")"#, symbol)
}

/// Generate rm() call with list= argument containing c() with multiple strings
fn rm_list_c(symbols: &[String]) -> String {
    let quoted: Vec<_> = symbols.iter().map(|s| format!(r#""{}""#, s)).collect();
    format!("rm(list = c({}))", quoted.join(", "))
}

/// Generate remove() call with list= argument containing c() with multiple strings
fn remove_list_c(symbols: &[String]) -> String {
    let quoted: Vec<_> = symbols.iter().map(|s| format!(r#""{}""#, s)).collect();
    format!("remove(list = c({}))", quoted.join(", "))
}

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: rm-remove-support, Property 2: remove() Equivalence
    /// **Validates: Requirements 2.1, 2.2, 2.3**
    ///
    /// For any R code using remove(), replacing remove with rm SHALL produce
    /// an identical scope timeline (same Removal events with same symbols and positions).
    /// Test case: Single bare symbol
    #[test]
    fn prop_remove_equivalence_bare_single(symbol in r_identifier()) {
        let rm_code = rm_bare_symbols(std::slice::from_ref(&symbol));
        let remove_code = remove_bare_symbols(std::slice::from_ref(&symbol));

        let rm_tree = parse_r(&rm_code);
        let remove_tree = parse_r(&remove_code);

        let rm_calls = detect_rm_calls(&rm_tree, &rm_code);
        let remove_calls = detect_rm_calls(&remove_tree, &remove_code);

        // Both should detect exactly one call
        prop_assert_eq!(rm_calls.len(), 1, "rm() should produce exactly one call");
        prop_assert_eq!(remove_calls.len(), 1, "remove() should produce exactly one call");

        // Both should extract the same symbols
        prop_assert_eq!(&rm_calls[0].symbols, &remove_calls[0].symbols,
            "rm() and remove() should extract identical symbols");

        // Both should have the same line position (both start at line 0)
        prop_assert_eq!(rm_calls[0].line, remove_calls[0].line,
            "rm() and remove() should have the same line position");
    }

    /// Feature: rm-remove-support, Property 2: remove() Equivalence
    /// **Validates: Requirements 2.1, 2.2, 2.3**
    ///
    /// Test case: Multiple bare symbols
    #[test]
    fn prop_remove_equivalence_bare_multiple(
        symbols in prop::collection::vec(r_identifier(), 2..=5)
            .prop_filter("unique symbols", |v| {
                let mut sorted = v.clone();
                sorted.sort();
                sorted.dedup();
                sorted.len() == v.len()
            })
    ) {
        let rm_code = rm_bare_symbols(&symbols);
        let remove_code = remove_bare_symbols(&symbols);

        let rm_tree = parse_r(&rm_code);
        let remove_tree = parse_r(&remove_code);

        let rm_calls = detect_rm_calls(&rm_tree, &rm_code);
        let remove_calls = detect_rm_calls(&remove_tree, &remove_code);

        // Both should detect exactly one call
        prop_assert_eq!(rm_calls.len(), 1, "rm() should produce exactly one call");
        prop_assert_eq!(remove_calls.len(), 1, "remove() should produce exactly one call");

        // Both should extract the same symbols in the same order
        prop_assert_eq!(&rm_calls[0].symbols, &remove_calls[0].symbols,
            "rm() and remove() should extract identical symbols");

        // Both should have the same line position
        prop_assert_eq!(rm_calls[0].line, remove_calls[0].line,
            "rm() and remove() should have the same line position");
    }

    /// Feature: rm-remove-support, Property 2: remove() Equivalence
    /// **Validates: Requirements 2.1, 2.2, 2.3**
    ///
    /// Test case: list= argument with single string literal
    #[test]
    fn prop_remove_equivalence_list_single(symbol in r_identifier()) {
        let rm_code = rm_list_single(&symbol);
        let remove_code = remove_list_single(&symbol);

        let rm_tree = parse_r(&rm_code);
        let remove_tree = parse_r(&remove_code);

        let rm_calls = detect_rm_calls(&rm_tree, &rm_code);
        let remove_calls = detect_rm_calls(&remove_tree, &remove_code);

        // Both should detect exactly one call
        prop_assert_eq!(rm_calls.len(), 1, "rm(list=...) should produce exactly one call");
        prop_assert_eq!(remove_calls.len(), 1, "remove(list=...) should produce exactly one call");

        // Both should extract the same symbols
        prop_assert_eq!(&rm_calls[0].symbols, &remove_calls[0].symbols,
            "rm(list=...) and remove(list=...) should extract identical symbols");

        // Both should have the same line position
        prop_assert_eq!(rm_calls[0].line, remove_calls[0].line,
            "rm(list=...) and remove(list=...) should have the same line position");
    }

    /// Feature: rm-remove-support, Property 2: remove() Equivalence
    /// **Validates: Requirements 2.1, 2.2, 2.3**
    ///
    /// Test case: list= argument with c() containing multiple strings
    #[test]
    fn prop_remove_equivalence_list_c(
        symbols in prop::collection::vec(r_identifier(), 2..=5)
            .prop_filter("unique symbols", |v| {
                let mut sorted = v.clone();
                sorted.sort();
                sorted.dedup();
                sorted.len() == v.len()
            })
    ) {
        let rm_code = rm_list_c(&symbols);
        let remove_code = remove_list_c(&symbols);

        let rm_tree = parse_r(&rm_code);
        let remove_tree = parse_r(&remove_code);

        let rm_calls = detect_rm_calls(&rm_tree, &rm_code);
        let remove_calls = detect_rm_calls(&remove_tree, &remove_code);

        // Both should detect exactly one call
        prop_assert_eq!(rm_calls.len(), 1, "rm(list=c(...)) should produce exactly one call");
        prop_assert_eq!(remove_calls.len(), 1, "remove(list=c(...)) should produce exactly one call");

        // Both should extract the same symbols in the same order
        prop_assert_eq!(&rm_calls[0].symbols, &remove_calls[0].symbols,
            "rm(list=c(...)) and remove(list=c(...)) should extract identical symbols");

        // Both should have the same line position
        prop_assert_eq!(rm_calls[0].line, remove_calls[0].line,
            "rm(list=c(...)) and remove(list=c(...)) should have the same line position");
    }

    /// Feature: rm-remove-support, Property 2: remove() Equivalence
    /// **Validates: Requirements 2.1, 2.2, 2.3**
    ///
    /// Test case: Mixed bare symbols and list= argument
    #[test]
    fn prop_remove_equivalence_mixed(
        bare_symbols in prop::collection::vec(r_identifier(), 1..=3)
            .prop_filter("unique symbols", |v| {
                let mut sorted = v.clone();
                sorted.sort();
                sorted.dedup();
                sorted.len() == v.len()
            }),
        list_symbols in prop::collection::vec(r_identifier(), 1..=3)
            .prop_filter("unique symbols", |v| {
                let mut sorted = v.clone();
                sorted.sort();
                sorted.dedup();
                sorted.len() == v.len()
            })
    ) {
        // Ensure bare_symbols and list_symbols don't overlap
        let has_overlap = bare_symbols.iter().any(|s| list_symbols.contains(s));
        prop_assume!(!has_overlap);

        // Generate rm() and remove() calls with both bare symbols and list= argument
        let bare_part = bare_symbols.join(", ");
        let list_quoted: Vec<_> = list_symbols.iter().map(|s| format!(r#""{}""#, s)).collect();
        let list_part = if list_symbols.len() == 1 {
            format!(r#"list = "{}""#, list_symbols[0])
        } else {
            format!("list = c({})", list_quoted.join(", "))
        };

        let rm_code = format!("rm({}, {})", bare_part, list_part);
        let remove_code = format!("remove({}, {})", bare_part, list_part);

        let rm_tree = parse_r(&rm_code);
        let remove_tree = parse_r(&remove_code);

        let rm_calls = detect_rm_calls(&rm_tree, &rm_code);
        let remove_calls = detect_rm_calls(&remove_tree, &remove_code);

        // Both should detect exactly one call
        prop_assert_eq!(rm_calls.len(), 1, "rm() with mixed args should produce exactly one call");
        prop_assert_eq!(remove_calls.len(), 1, "remove() with mixed args should produce exactly one call");

        // Both should extract the same symbols (bare symbols first, then list symbols)
        prop_assert_eq!(&rm_calls[0].symbols, &remove_calls[0].symbols,
            "rm() and remove() with mixed args should extract identical symbols");

        // Both should have the same line position
        prop_assert_eq!(rm_calls[0].line, remove_calls[0].line,
            "rm() and remove() with mixed args should have the same line position");
    }

    /// Feature: rm-remove-support, Property 2: remove() Equivalence
    /// **Validates: Requirements 2.1, 2.2, 2.3**
    ///
    /// Test case: Verify column positions are relative to the call (both start at column 0)
    #[test]
    fn prop_remove_equivalence_column_position(symbol in r_identifier()) {
        let rm_code = rm_bare_symbols(std::slice::from_ref(&symbol));
        let remove_code = remove_bare_symbols(std::slice::from_ref(&symbol));

        let rm_tree = parse_r(&rm_code);
        let remove_tree = parse_r(&remove_code);

        let rm_calls = detect_rm_calls(&rm_tree, &rm_code);
        let remove_calls = detect_rm_calls(&remove_tree, &remove_code);

        // Both should detect exactly one call
        prop_assert_eq!(rm_calls.len(), 1, "rm() should produce exactly one call");
        prop_assert_eq!(remove_calls.len(), 1, "remove() should produce exactly one call");

        // Both should start at column 0 (beginning of line)
        prop_assert_eq!(rm_calls[0].column, 0, "rm() should start at column 0");
        prop_assert_eq!(remove_calls[0].column, 0, "remove() should start at column 0");
    }
}

// ============================================================================
// Feature: rm-remove-support, Property 3: list= String Literal Extraction
// Validates: Requirements 3.1, 3.2
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: rm-remove-support, Property 3: list= String Literal Extraction
    /// **Validates: Requirements 3.1, 3.2**
    ///
    /// For any rm() call with a list= argument containing string literals (either a
    /// single string or a c() call with strings), the Removal event SHALL contain
    /// exactly those string values as symbol names.
    ///
    /// Test case: Single string literal with double quotes
    #[test]
    fn prop_rm_list_single_string_extraction(symbol in r_identifier()) {
        let code = format!(r#"rm(list = "{}")"#, symbol);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should detect exactly one rm() call
        prop_assert_eq!(rm_calls.len(), 1, "Expected exactly one rm() call");

        // Should extract exactly the symbol from the string literal
        prop_assert_eq!(rm_calls[0].symbols.len(), 1, "Expected exactly one symbol");
        prop_assert_eq!(&rm_calls[0].symbols[0], &symbol,
            "Symbol should match the string literal content");
    }

    /// Feature: rm-remove-support, Property 3: list= String Literal Extraction
    /// **Validates: Requirements 3.1, 3.2**
    ///
    /// Test case: Single string literal with single quotes
    #[test]
    fn prop_rm_list_single_string_single_quotes(symbol in r_identifier()) {
        let code = format!("rm(list = '{}')", symbol);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should detect exactly one rm() call
        prop_assert_eq!(rm_calls.len(), 1, "Expected exactly one rm() call");

        // Should extract exactly the symbol from the string literal
        prop_assert_eq!(rm_calls[0].symbols.len(), 1, "Expected exactly one symbol");
        prop_assert_eq!(&rm_calls[0].symbols[0], &symbol,
            "Symbol should match the string literal content (single quotes)");
    }

    /// Feature: rm-remove-support, Property 3: list= String Literal Extraction
    /// **Validates: Requirements 3.1, 3.2**
    ///
    /// Test case: Multiple strings in c() call
    #[test]
    fn prop_rm_list_c_multiple_strings(
        symbols in prop::collection::vec(r_identifier(), 2..=5)
            .prop_filter("unique symbols", |v| {
                let mut sorted = v.clone();
                sorted.sort();
                sorted.dedup();
                sorted.len() == v.len()
            })
    ) {
        let quoted: Vec<_> = symbols.iter().map(|s| format!(r#""{}""#, s)).collect();
        let code = format!("rm(list = c({}))", quoted.join(", "));
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should detect exactly one rm() call
        prop_assert_eq!(rm_calls.len(), 1, "Expected exactly one rm() call");

        // Should extract exactly the symbols from the c() call
        prop_assert_eq!(rm_calls[0].symbols.len(), symbols.len(),
            "Number of extracted symbols should match input");

        // All symbols should be present in the same order
        for (i, expected_symbol) in symbols.iter().enumerate() {
            prop_assert_eq!(&rm_calls[0].symbols[i], expected_symbol,
                "Symbol at position {} should match", i);
        }
    }

    /// Feature: rm-remove-support, Property 3: list= String Literal Extraction
    /// **Validates: Requirements 3.1, 3.2**
    ///
    /// Test case: Single string in c() call (edge case)
    #[test]
    fn prop_rm_list_c_single_string(symbol in r_identifier()) {
        let code = format!(r#"rm(list = c("{}"))"#, symbol);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should detect exactly one rm() call
        prop_assert_eq!(rm_calls.len(), 1, "Expected exactly one rm() call");

        // Should extract exactly the symbol from the c() call
        prop_assert_eq!(rm_calls[0].symbols.len(), 1, "Expected exactly one symbol");
        prop_assert_eq!(&rm_calls[0].symbols[0], &symbol,
            "Symbol should match the string literal content in c()");
    }

    /// Feature: rm-remove-support, Property 3: list= String Literal Extraction
    /// **Validates: Requirements 3.1, 3.2**
    ///
    /// Test case: c() with mixed quote styles (double and single quotes)
    #[test]
    fn prop_rm_list_c_mixed_quotes(
        symbols in prop::collection::vec(r_identifier(), 2..=4)
            .prop_filter("unique symbols", |v| {
                let mut sorted = v.clone();
                sorted.sort();
                sorted.dedup();
                sorted.len() == v.len()
            })
    ) {
        // Alternate between double and single quotes
        let quoted: Vec<_> = symbols.iter().enumerate()
            .map(|(i, s)| {
                if i % 2 == 0 {
                    format!(r#""{}""#, s)
                } else {
                    format!("'{}'", s)
                }
            })
            .collect();
        let code = format!("rm(list = c({}))", quoted.join(", "));
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should detect exactly one rm() call
        prop_assert_eq!(rm_calls.len(), 1, "Expected exactly one rm() call");

        // Should extract exactly the symbols regardless of quote style
        prop_assert_eq!(rm_calls[0].symbols.len(), symbols.len(),
            "Number of extracted symbols should match input");

        // All symbols should be present in the same order
        for (i, expected_symbol) in symbols.iter().enumerate() {
            prop_assert_eq!(&rm_calls[0].symbols[i], expected_symbol,
                "Symbol at position {} should match (mixed quotes)", i);
        }
    }

    /// Feature: rm-remove-support, Property 3: list= String Literal Extraction
    /// **Validates: Requirements 3.1, 3.2**
    ///
    /// Test case: remove() with list= argument (should work identically to rm())
    #[test]
    fn prop_remove_list_single_string_extraction(symbol in r_identifier()) {
        let code = format!(r#"remove(list = "{}")"#, symbol);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should detect exactly one remove() call
        prop_assert_eq!(rm_calls.len(), 1, "Expected exactly one remove() call");

        // Should extract exactly the symbol from the string literal
        prop_assert_eq!(rm_calls[0].symbols.len(), 1, "Expected exactly one symbol");
        prop_assert_eq!(&rm_calls[0].symbols[0], &symbol,
            "Symbol should match the string literal content");
    }

    /// Feature: rm-remove-support, Property 3: list= String Literal Extraction
    /// **Validates: Requirements 3.1, 3.2**
    ///
    /// Test case: remove() with list= c() argument
    #[test]
    fn prop_remove_list_c_multiple_strings(
        symbols in prop::collection::vec(r_identifier(), 2..=5)
            .prop_filter("unique symbols", |v| {
                let mut sorted = v.clone();
                sorted.sort();
                sorted.dedup();
                sorted.len() == v.len()
            })
    ) {
        let quoted: Vec<_> = symbols.iter().map(|s| format!(r#""{}""#, s)).collect();
        let code = format!("remove(list = c({}))", quoted.join(", "));
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should detect exactly one remove() call
        prop_assert_eq!(rm_calls.len(), 1, "Expected exactly one remove() call");

        // Should extract exactly the symbols from the c() call
        prop_assert_eq!(rm_calls[0].symbols.len(), symbols.len(),
            "Number of extracted symbols should match input");

        // All symbols should be present in the same order
        for (i, expected_symbol) in symbols.iter().enumerate() {
            prop_assert_eq!(&rm_calls[0].symbols[i], expected_symbol,
                "Symbol at position {} should match", i);
        }
    }

    /// Feature: rm-remove-support, Property 3: list= String Literal Extraction
    /// **Validates: Requirements 3.1, 3.2**
    ///
    /// Test case: Position tracking for list= argument
    #[test]
    fn prop_rm_list_string_position(
        symbol in r_identifier(),
        prefix_lines in 0..5usize
    ) {
        // Add some prefix lines before the rm() call
        let prefix = "\n".repeat(prefix_lines);
        let code = format!(r#"{}rm(list = "{}")"#, prefix, symbol);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should detect exactly one rm() call
        prop_assert_eq!(rm_calls.len(), 1, "Expected exactly one rm() call");

        // Line should match the number of prefix newlines
        prop_assert_eq!(rm_calls[0].line, prefix_lines as u32,
            "rm() call should be on line {}", prefix_lines);

        // Symbol should still be extracted correctly
        prop_assert_eq!(rm_calls[0].symbols.len(), 1, "Expected exactly one symbol");
        prop_assert_eq!(&rm_calls[0].symbols[0], &symbol, "Symbol should match input");
    }
}

// ============================================================================
// Feature: rm-remove-support, Property 4: Dynamic Expression Filtering
// Validates: Requirements 3.3, 3.4
// ============================================================================

/// Generate a valid R function name for dynamic expressions
fn r_function_name() -> impl Strategy<Value = String> {
    prop::sample::select(vec![
        "ls".to_string(),
        "objects".to_string(),
        "get".to_string(),
        "paste0".to_string(),
        "paste".to_string(),
        "sprintf".to_string(),
        "grep".to_string(),
        "setdiff".to_string(),
        "intersect".to_string(),
        "union".to_string(),
    ])
}

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: rm-remove-support, Property 4: Dynamic Expression Filtering
    /// **Validates: Requirements 3.3, 3.4**
    ///
    /// For any rm() call with a list= argument containing a non-literal expression
    /// (variable reference, function call other than c() with literals, etc.),
    /// no Removal event SHALL be created for that call.
    ///
    /// Test case: Variable reference in list= argument
    #[test]
    fn prop_rm_dynamic_variable_reference_filtered(varname in r_identifier()) {
        let code = format!("rm(list = {})", varname);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should NOT detect any rm() call (no symbols extracted)
        prop_assert_eq!(rm_calls.len(), 0,
            "rm(list = {}) should not produce any RmCall since variable is dynamic", varname);
    }

    /// Feature: rm-remove-support, Property 4: Dynamic Expression Filtering
    /// **Validates: Requirements 3.3, 3.4**
    ///
    /// Test case: ls() function call in list= argument
    #[test]
    fn prop_rm_dynamic_ls_call_filtered(_dummy in Just(())) {
        // Simple ls() call
        let code = "rm(list = ls())";
        let tree = parse_r(code);
        let rm_calls = detect_rm_calls(&tree, code);

        // Should NOT detect any rm() call
        prop_assert_eq!(rm_calls.len(), 0,
            "rm(list = ls()) should not produce any RmCall since ls() is dynamic");
    }

    /// Feature: rm-remove-support, Property 4: Dynamic Expression Filtering
    /// **Validates: Requirements 3.3, 3.4**
    ///
    /// Test case: ls() with pattern argument in list= argument
    #[test]
    fn prop_rm_dynamic_ls_pattern_filtered(pattern in "[a-z]{1,5}") {
        let code = format!(r#"rm(list = ls(pattern = "^{}"))"#, pattern);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should NOT detect any rm() call
        prop_assert_eq!(rm_calls.len(), 0,
            "rm(list = ls(pattern = ...)) should not produce any RmCall since ls() is dynamic");
    }

    /// Feature: rm-remove-support, Property 4: Dynamic Expression Filtering
    /// **Validates: Requirements 3.3, 3.4**
    ///
    /// Test case: Various function calls in list= argument
    #[test]
    fn prop_rm_dynamic_function_call_filtered(func_name in r_function_name()) {
        let code = format!("rm(list = {}())", func_name);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should NOT detect any rm() call
        prop_assert_eq!(rm_calls.len(), 0,
            "rm(list = {}()) should not produce any RmCall since function call is dynamic", func_name);
    }

    /// Feature: rm-remove-support, Property 4: Dynamic Expression Filtering
    /// **Validates: Requirements 3.3, 3.4**
    ///
    /// Test case: paste0() with variable in list= argument
    #[test]
    fn prop_rm_dynamic_paste0_filtered(
        prefix in "[a-z]{1,5}",
        varname in r_identifier()
    ) {
        let code = format!(r#"rm(list = paste0("{}", {}))"#, prefix, varname);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should NOT detect any rm() call
        prop_assert_eq!(rm_calls.len(), 0,
            "rm(list = paste0(...)) should not produce any RmCall since paste0() is dynamic");
    }

    /// Feature: rm-remove-support, Property 4: Dynamic Expression Filtering
    /// **Validates: Requirements 3.3, 3.4**
    ///
    /// Test case: Expression with operators in list= argument
    #[test]
    fn prop_rm_dynamic_expression_filtered(
        var1 in r_identifier(),
        var2 in r_identifier()
    ) {
        // Ensure different variable names
        prop_assume!(var1 != var2);

        // Test with setdiff() expression
        let code = format!("rm(list = setdiff({}, {}))", var1, var2);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should NOT detect any rm() call
        prop_assert_eq!(rm_calls.len(), 0,
            "rm(list = setdiff(...)) should not produce any RmCall since expression is dynamic");
    }

    /// Feature: rm-remove-support, Property 4: Dynamic Expression Filtering
    /// **Validates: Requirements 3.3, 3.4**
    ///
    /// Test case: c() with variable (not all literals) in list= argument
    #[test]
    fn prop_rm_dynamic_c_with_variable_partial_extraction(
        literal_symbol in r_identifier(),
        varname in r_identifier()
    ) {
        // Ensure different names
        prop_assume!(literal_symbol != varname);

        // c() with mixed literals and variables - only literals should be extracted
        let code = format!(r#"rm(list = c("{}", {}))"#, literal_symbol, varname);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should extract only the string literal, not the variable
        // If no string literals are extracted, no RmCall is created
        // If at least one string literal is extracted, RmCall is created with only those
        if rm_calls.len() == 1 {
            // Only the string literal should be extracted
            prop_assert_eq!(rm_calls[0].symbols.len(), 1,
                "Only string literals should be extracted from c() with mixed args");
            prop_assert_eq!(&rm_calls[0].symbols[0], &literal_symbol,
                "The extracted symbol should be the string literal");
        }
        // If no RmCall is created, that's also acceptable behavior
    }

    /// Feature: rm-remove-support, Property 4: Dynamic Expression Filtering
    /// **Validates: Requirements 3.3, 3.4**
    ///
    /// Test case: remove() with dynamic expression (should behave same as rm())
    #[test]
    fn prop_remove_dynamic_variable_reference_filtered(varname in r_identifier()) {
        let code = format!("remove(list = {})", varname);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should NOT detect any remove() call (no symbols extracted)
        prop_assert_eq!(rm_calls.len(), 0,
            "remove(list = {}) should not produce any RmCall since variable is dynamic", varname);
    }

    /// Feature: rm-remove-support, Property 4: Dynamic Expression Filtering
    /// **Validates: Requirements 3.3, 3.4**
    ///
    /// Test case: remove() with ls() call (should behave same as rm())
    #[test]
    fn prop_remove_dynamic_ls_call_filtered(_dummy in Just(())) {
        let code = "remove(list = ls())";
        let tree = parse_r(code);
        let rm_calls = detect_rm_calls(&tree, code);

        // Should NOT detect any remove() call
        prop_assert_eq!(rm_calls.len(), 0,
            "remove(list = ls()) should not produce any RmCall since ls() is dynamic");
    }

    /// Feature: rm-remove-support, Property 4: Dynamic Expression Filtering
    /// **Validates: Requirements 3.3, 3.4**
    ///
    /// Test case: Numeric literal in list= argument (not a valid symbol name)
    #[test]
    fn prop_rm_dynamic_numeric_literal_filtered(num in 0..1000i32) {
        let code = format!("rm(list = {})", num);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should NOT detect any rm() call (numeric is not a valid symbol)
        prop_assert_eq!(rm_calls.len(), 0,
            "rm(list = {}) should not produce any RmCall since numeric is not a symbol", num);
    }

    /// Feature: rm-remove-support, Property 4: Dynamic Expression Filtering
    /// **Validates: Requirements 3.3, 3.4**
    ///
    /// Test case: Binary expression in list= argument
    #[test]
    fn prop_rm_dynamic_binary_expression_filtered(
        var1 in r_identifier(),
        var2 in r_identifier()
    ) {
        // Ensure different variable names
        prop_assume!(var1 != var2);

        // Test with concatenation expression using c() with variables
        let code = format!("rm(list = c({}, {}))", var1, var2);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should NOT detect any rm() call since c() contains only variables, not string literals
        prop_assert_eq!(rm_calls.len(), 0,
            "rm(list = c(var1, var2)) should not produce any RmCall since c() contains only variables");
    }

    /// Feature: rm-remove-support, Property 4: Dynamic Expression Filtering
    /// **Validates: Requirements 3.3, 3.4**
    ///
    /// Test case: Subscript expression in list= argument
    #[test]
    fn prop_rm_dynamic_subscript_filtered(
        varname in r_identifier(),
        index in 1..10i32
    ) {
        let code = format!("rm(list = {}[{}])", varname, index);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should NOT detect any rm() call
        prop_assert_eq!(rm_calls.len(), 0,
            "rm(list = var[index]) should not produce any RmCall since subscript is dynamic");
    }

    /// Feature: rm-remove-support, Property 4: Dynamic Expression Filtering
    /// **Validates: Requirements 3.3, 3.4**
    ///
    /// Test case: Bare symbols should still work even when list= has dynamic expression
    #[test]
    fn prop_rm_bare_symbols_with_dynamic_list(
        bare_symbol in r_identifier(),
        dynamic_var in r_identifier()
    ) {
        // Ensure different names
        prop_assume!(bare_symbol != dynamic_var);

        // rm() with both bare symbol and dynamic list= argument
        let code = format!("rm({}, list = {})", bare_symbol, dynamic_var);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should detect the rm() call with only the bare symbol
        prop_assert_eq!(rm_calls.len(), 1,
            "rm() with bare symbol and dynamic list= should produce one RmCall");
        prop_assert_eq!(rm_calls[0].symbols.len(), 1,
            "Only the bare symbol should be extracted");
        prop_assert_eq!(&rm_calls[0].symbols[0], &bare_symbol,
            "The extracted symbol should be the bare symbol");
    }
}

// ============================================================================
// Feature: rm-remove-support, Property 5: envir= Argument Filtering
// Validates: Requirements 4.1, 4.2, 4.3
// ============================================================================

/// Generate a non-global environment expression for envir= argument
fn non_global_envir_expression() -> impl Strategy<Value = String> {
    prop::sample::select(vec![
        "my_env".to_string(),
        "new.env()".to_string(),
        "parent.frame()".to_string(),
        "baseenv()".to_string(),
        "emptyenv()".to_string(),
        "as.environment(2)".to_string(),
        "e".to_string(),
        "env".to_string(),
        "local_env".to_string(),
        "custom_env".to_string(),
    ])
}

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: rm-remove-support, Property 5: envir= Argument Filtering
    /// **Validates: Requirements 4.1, 4.2, 4.3**
    ///
    /// For any rm() call with an envir= argument, a Removal event SHALL be created
    /// if and only if the envir value is globalenv() or .GlobalEnv (or omitted entirely).
    ///
    /// Test case: rm() without envir= creates Removal events
    #[test]
    fn prop_rm_without_envir_creates_removal(symbol in r_identifier()) {
        let code = format!("rm({})", symbol);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should detect exactly one rm() call (envir= omitted means default global env)
        prop_assert_eq!(rm_calls.len(), 1,
            "rm() without envir= should create a Removal event");
        prop_assert_eq!(rm_calls[0].symbols.len(), 1,
            "Should extract exactly one symbol");
        prop_assert_eq!(&rm_calls[0].symbols[0], &symbol,
            "Symbol should match input");
    }

    /// Feature: rm-remove-support, Property 5: envir= Argument Filtering
    /// **Validates: Requirements 4.1, 4.2, 4.3**
    ///
    /// Test case: rm() with envir = globalenv() creates Removal events
    #[test]
    fn prop_rm_with_envir_globalenv_creates_removal(symbol in r_identifier()) {
        let code = format!("rm({}, envir = globalenv())", symbol);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should detect exactly one rm() call (globalenv() is equivalent to default)
        prop_assert_eq!(rm_calls.len(), 1,
            "rm() with envir = globalenv() should create a Removal event");
        prop_assert_eq!(rm_calls[0].symbols.len(), 1,
            "Should extract exactly one symbol");
        prop_assert_eq!(&rm_calls[0].symbols[0], &symbol,
            "Symbol should match input");
    }

    /// Feature: rm-remove-support, Property 5: envir= Argument Filtering
    /// **Validates: Requirements 4.1, 4.2, 4.3**
    ///
    /// Test case: rm() with envir = .GlobalEnv creates Removal events
    #[test]
    fn prop_rm_with_envir_dot_globalenv_creates_removal(symbol in r_identifier()) {
        let code = format!("rm({}, envir = .GlobalEnv)", symbol);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should detect exactly one rm() call (.GlobalEnv is equivalent to default)
        prop_assert_eq!(rm_calls.len(), 1,
            "rm() with envir = .GlobalEnv should create a Removal event");
        prop_assert_eq!(rm_calls[0].symbols.len(), 1,
            "Should extract exactly one symbol");
        prop_assert_eq!(&rm_calls[0].symbols[0], &symbol,
            "Symbol should match input");
    }

    /// Feature: rm-remove-support, Property 5: envir= Argument Filtering
    /// **Validates: Requirements 4.1, 4.2, 4.3**
    ///
    /// Test case: rm() with non-default envir= does NOT create Removal events
    #[test]
    fn prop_rm_with_non_default_envir_no_removal(
        symbol in r_identifier(),
        envir_expr in non_global_envir_expression()
    ) {
        let code = format!("rm({}, envir = {})", symbol, envir_expr);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should NOT detect any rm() call (non-default envir= means skip)
        prop_assert_eq!(rm_calls.len(), 0,
            "rm() with envir = {} should NOT create a Removal event", envir_expr);
    }

    /// Feature: rm-remove-support, Property 5: envir= Argument Filtering
    /// **Validates: Requirements 4.1, 4.2, 4.3**
    ///
    /// Test case: remove() without envir= creates Removal events (same as rm())
    #[test]
    fn prop_remove_without_envir_creates_removal(symbol in r_identifier()) {
        let code = format!("remove({})", symbol);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should detect exactly one remove() call
        prop_assert_eq!(rm_calls.len(), 1,
            "remove() without envir= should create a Removal event");
        prop_assert_eq!(rm_calls[0].symbols.len(), 1,
            "Should extract exactly one symbol");
        prop_assert_eq!(&rm_calls[0].symbols[0], &symbol,
            "Symbol should match input");
    }

    /// Feature: rm-remove-support, Property 5: envir= Argument Filtering
    /// **Validates: Requirements 4.1, 4.2, 4.3**
    ///
    /// Test case: remove() with envir = globalenv() creates Removal events
    #[test]
    fn prop_remove_with_envir_globalenv_creates_removal(symbol in r_identifier()) {
        let code = format!("remove({}, envir = globalenv())", symbol);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should detect exactly one remove() call
        prop_assert_eq!(rm_calls.len(), 1,
            "remove() with envir = globalenv() should create a Removal event");
        prop_assert_eq!(rm_calls[0].symbols.len(), 1,
            "Should extract exactly one symbol");
        prop_assert_eq!(&rm_calls[0].symbols[0], &symbol,
            "Symbol should match input");
    }

    /// Feature: rm-remove-support, Property 5: envir= Argument Filtering
    /// **Validates: Requirements 4.1, 4.2, 4.3**
    ///
    /// Test case: remove() with envir = .GlobalEnv creates Removal events
    #[test]
    fn prop_remove_with_envir_dot_globalenv_creates_removal(symbol in r_identifier()) {
        let code = format!("remove({}, envir = .GlobalEnv)", symbol);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should detect exactly one remove() call
        prop_assert_eq!(rm_calls.len(), 1,
            "remove() with envir = .GlobalEnv should create a Removal event");
        prop_assert_eq!(rm_calls[0].symbols.len(), 1,
            "Should extract exactly one symbol");
        prop_assert_eq!(&rm_calls[0].symbols[0], &symbol,
            "Symbol should match input");
    }

    /// Feature: rm-remove-support, Property 5: envir= Argument Filtering
    /// **Validates: Requirements 4.1, 4.2, 4.3**
    ///
    /// Test case: remove() with non-default envir= does NOT create Removal events
    #[test]
    fn prop_remove_with_non_default_envir_no_removal(
        symbol in r_identifier(),
        envir_expr in non_global_envir_expression()
    ) {
        let code = format!("remove({}, envir = {})", symbol, envir_expr);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should NOT detect any remove() call
        prop_assert_eq!(rm_calls.len(), 0,
            "remove() with envir = {} should NOT create a Removal event", envir_expr);
    }

    /// Feature: rm-remove-support, Property 5: envir= Argument Filtering
    /// **Validates: Requirements 4.1, 4.2, 4.3**
    ///
    /// Test case: Multiple symbols with envir = globalenv() creates Removal events
    #[test]
    fn prop_rm_multiple_symbols_with_envir_globalenv(
        symbols in prop::collection::vec(r_identifier(), 2..=5)
            .prop_filter("unique symbols", |v| {
                let mut sorted = v.clone();
                sorted.sort();
                sorted.dedup();
                sorted.len() == v.len()
            })
    ) {
        let code = format!("rm({}, envir = globalenv())", symbols.join(", "));
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should detect exactly one rm() call with all symbols
        prop_assert_eq!(rm_calls.len(), 1,
            "rm() with multiple symbols and envir = globalenv() should create a Removal event");
        prop_assert_eq!(rm_calls[0].symbols.len(), symbols.len(),
            "Should extract all symbols");

        for (i, expected_symbol) in symbols.iter().enumerate() {
            prop_assert_eq!(&rm_calls[0].symbols[i], expected_symbol,
                "Symbol at position {} should match", i);
        }
    }

    /// Feature: rm-remove-support, Property 5: envir= Argument Filtering
    /// **Validates: Requirements 4.1, 4.2, 4.3**
    ///
    /// Test case: Multiple symbols with non-default envir= does NOT create Removal events
    #[test]
    fn prop_rm_multiple_symbols_with_non_default_envir_no_removal(
        symbols in prop::collection::vec(r_identifier(), 2..=5)
            .prop_filter("unique symbols", |v| {
                let mut sorted = v.clone();
                sorted.sort();
                sorted.dedup();
                sorted.len() == v.len()
            }),
        envir_expr in non_global_envir_expression()
    ) {
        let code = format!("rm({}, envir = {})", symbols.join(", "), envir_expr);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should NOT detect any rm() call
        prop_assert_eq!(rm_calls.len(), 0,
            "rm() with multiple symbols and envir = {} should NOT create a Removal event", envir_expr);
    }

    /// Feature: rm-remove-support, Property 5: envir= Argument Filtering
    /// **Validates: Requirements 4.1, 4.2, 4.3**
    ///
    /// Test case: list= argument with envir = globalenv() creates Removal events
    #[test]
    fn prop_rm_list_with_envir_globalenv_creates_removal(symbol in r_identifier()) {
        let code = format!(r#"rm(list = "{}", envir = globalenv())"#, symbol);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should detect exactly one rm() call
        prop_assert_eq!(rm_calls.len(), 1,
            "rm(list=...) with envir = globalenv() should create a Removal event");
        prop_assert_eq!(rm_calls[0].symbols.len(), 1,
            "Should extract exactly one symbol");
        prop_assert_eq!(&rm_calls[0].symbols[0], &symbol,
            "Symbol should match input");
    }

    /// Feature: rm-remove-support, Property 5: envir= Argument Filtering
    /// **Validates: Requirements 4.1, 4.2, 4.3**
    ///
    /// Test case: list= argument with non-default envir= does NOT create Removal events
    #[test]
    fn prop_rm_list_with_non_default_envir_no_removal(
        symbol in r_identifier(),
        envir_expr in non_global_envir_expression()
    ) {
        let code = format!(r#"rm(list = "{}", envir = {})"#, symbol, envir_expr);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should NOT detect any rm() call
        prop_assert_eq!(rm_calls.len(), 0,
            "rm(list=...) with envir = {} should NOT create a Removal event", envir_expr);
    }

    /// Feature: rm-remove-support, Property 5: envir= Argument Filtering
    /// **Validates: Requirements 4.1, 4.2, 4.3**
    ///
    /// Test case: Mixed bare symbols and list= with envir = .GlobalEnv creates Removal events
    #[test]
    fn prop_rm_mixed_with_envir_dot_globalenv_creates_removal(
        bare_symbol in r_identifier(),
        list_symbol in r_identifier()
    ) {
        // Ensure different symbols
        prop_assume!(bare_symbol != list_symbol);

        let code = format!(r#"rm({}, list = "{}", envir = .GlobalEnv)"#, bare_symbol, list_symbol);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should detect exactly one rm() call with both symbols
        prop_assert_eq!(rm_calls.len(), 1,
            "rm() with mixed args and envir = .GlobalEnv should create a Removal event");
        prop_assert_eq!(rm_calls[0].symbols.len(), 2,
            "Should extract both symbols");
        prop_assert_eq!(&rm_calls[0].symbols[0], &bare_symbol,
            "First symbol should be the bare symbol");
        prop_assert_eq!(&rm_calls[0].symbols[1], &list_symbol,
            "Second symbol should be from list=");
    }

    /// Feature: rm-remove-support, Property 5: envir= Argument Filtering
    /// **Validates: Requirements 4.1, 4.2, 4.3**
    ///
    /// Test case: Mixed bare symbols and list= with non-default envir= does NOT create Removal events
    #[test]
    fn prop_rm_mixed_with_non_default_envir_no_removal(
        bare_symbol in r_identifier(),
        list_symbol in r_identifier(),
        envir_expr in non_global_envir_expression()
    ) {
        // Ensure different symbols
        prop_assume!(bare_symbol != list_symbol);

        let code = format!(r#"rm({}, list = "{}", envir = {})"#, bare_symbol, list_symbol, envir_expr);
        let tree = parse_r(&code);
        let rm_calls = detect_rm_calls(&tree, &code);

        // Should NOT detect any rm() call
        prop_assert_eq!(rm_calls.len(), 0,
            "rm() with mixed args and envir = {} should NOT create a Removal event", envir_expr);
    }

    /// Feature: rm-remove-support, Property 5: envir= Argument Filtering
    /// **Validates: Requirements 4.1, 4.2, 4.3**
    ///
    /// Test case: Equivalence between globalenv() and .GlobalEnv
    #[test]
    fn prop_rm_envir_globalenv_equivalence(symbol in r_identifier()) {
        let code_globalenv = format!("rm({}, envir = globalenv())", symbol);
        let code_dot_globalenv = format!("rm({}, envir = .GlobalEnv)", symbol);

        let tree_globalenv = parse_r(&code_globalenv);
        let tree_dot_globalenv = parse_r(&code_dot_globalenv);

        let rm_calls_globalenv = detect_rm_calls(&tree_globalenv, &code_globalenv);
        let rm_calls_dot_globalenv = detect_rm_calls(&tree_dot_globalenv, &code_dot_globalenv);

        // Both should produce exactly one rm() call
        prop_assert_eq!(rm_calls_globalenv.len(), 1,
            "rm() with envir = globalenv() should create a Removal event");
        prop_assert_eq!(rm_calls_dot_globalenv.len(), 1,
            "rm() with envir = .GlobalEnv should create a Removal event");

        // Both should extract the same symbols
        prop_assert_eq!(&rm_calls_globalenv[0].symbols, &rm_calls_dot_globalenv[0].symbols,
            "globalenv() and .GlobalEnv should produce identical symbol extraction");
    }

    /// Feature: rm-remove-support, Property 5: envir= Argument Filtering
    /// **Validates: Requirements 4.1, 4.2, 4.3**
    ///
    /// Test case: Equivalence between omitted envir= and explicit globalenv()
    #[test]
    fn prop_rm_envir_omitted_vs_explicit_globalenv(symbol in r_identifier()) {
        let code_omitted = format!("rm({})", symbol);
        let code_explicit = format!("rm({}, envir = globalenv())", symbol);

        let tree_omitted = parse_r(&code_omitted);
        let tree_explicit = parse_r(&code_explicit);

        let rm_calls_omitted = detect_rm_calls(&tree_omitted, &code_omitted);
        let rm_calls_explicit = detect_rm_calls(&tree_explicit, &code_explicit);

        // Both should produce exactly one rm() call
        prop_assert_eq!(rm_calls_omitted.len(), 1,
            "rm() without envir= should create a Removal event");
        prop_assert_eq!(rm_calls_explicit.len(), 1,
            "rm() with envir = globalenv() should create a Removal event");

        // Both should extract the same symbols
        prop_assert_eq!(&rm_calls_omitted[0].symbols, &rm_calls_explicit[0].symbols,
            "Omitted envir= and explicit globalenv() should produce identical symbol extraction");
    }
}

// ============================================================================
// Feature: rm-remove-support, Property 6: Function Scope Isolation
// Validates: Requirements 5.1, 5.2, 5.3
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: rm-remove-support, Property 6: Function Scope Isolation
    /// **Validates: Requirements 5.1, 5.2, 5.3**
    ///
    /// For any rm() call inside a function body, the removal SHALL only affect scope
    /// queries within that function body. Scope queries outside the function (before
    /// or after) SHALL NOT be affected by the removal.
    ///
    /// Test pattern:
    /// ```r
    /// x <- 1  # Global definition
    /// my_func <- function() {
    ///   y <- 2
    ///   rm(y)  # Function-local removal
    /// }
    /// # After function: x should be in scope, y should NOT be in global scope
    /// ```
    #[test]
    fn prop_rm_function_scope_isolation_global_unaffected(
        global_var in r_identifier(),
        func_name in r_identifier(),
        local_var in r_identifier()
    ) {
        // Ensure all names are distinct
        prop_assume!(global_var != func_name && global_var != local_var && func_name != local_var);

        let uri = make_url("test");

        // Code: global definition, function with local definition and rm() inside
        let code = format!(
            "{} <- 1\n{} <- function() {{\n  {} <- 2\n  rm({})\n}}",
            global_var, func_name, local_var, local_var
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // At end of file (outside function), global variable should still be in scope
        // The rm() inside the function should NOT affect global scope
        let scope_outside = scope_at_position(&artifacts, 10, 0, false);

        prop_assert!(scope_outside.symbols.contains_key(global_var.as_str()),
            "Global variable should be available outside function (rm inside function should not affect it)");
        prop_assert!(scope_outside.symbols.contains_key(func_name.as_str()),
            "Function name should be available outside function");
        prop_assert!(!scope_outside.symbols.contains_key(local_var.as_str()),
            "Function-local variable should NOT be available outside function (never exported)");
    }

    /// Feature: rm-remove-support, Property 6: Function Scope Isolation
    /// **Validates: Requirements 5.1, 5.2, 5.3**
    ///
    /// Test that rm() inside a function DOES affect scope within that function body.
    /// After rm(y), y should not be in scope within the function.
    #[test]
    fn prop_rm_function_scope_isolation_affects_function_body(
        func_name in r_identifier(),
        local_var in r_identifier()
    ) {
        // Ensure names are distinct
        prop_assume!(func_name != local_var);

        let uri = make_url("test");

        // Code: function with local definition, then rm() of that variable
        // We need to query scope AFTER the rm() call within the function body
        let code = format!(
            "{} <- function() {{\n  {} <- 2\n  rm({})\n  # position after rm\n}}",
            func_name, local_var, local_var
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Find position after rm() but still inside function body
        // The rm() is on line 2 (0-indexed), so line 3 is after rm()
        // We need to find a position inside the function body after the rm() call
        let rm_line = code.lines().enumerate()
            .find(|(_, line)| line.contains("rm("))
            .map(|(i, _)| i as u32)
            .unwrap_or(2);

        // Query scope at position after rm() but inside function
        // Use the line after rm() which should be the comment line
        let scope_after_rm = scope_at_position(&artifacts, rm_line + 1, 5, false);

        prop_assert!(scope_after_rm.symbols.contains_key(func_name.as_str()),
            "Function name should be available inside function");
        prop_assert!(!scope_after_rm.symbols.contains_key(local_var.as_str()),
            "Local variable should NOT be in scope after rm() within function body");
    }

    /// Feature: rm-remove-support, Property 6: Function Scope Isolation
    /// **Validates: Requirements 5.1, 5.2, 5.3**
    ///
    /// Test that rm() at global level DOES affect global scope.
    /// This contrasts with rm() inside a function which only affects function scope.
    #[test]
    fn prop_rm_global_level_affects_global_scope(
        var_name in r_identifier()
    ) {
        let uri = make_url("test");

        // Code: global definition, then rm() at global level
        let code = format!(
            "{} <- 1\nrm({})\n# position after rm",
            var_name, var_name
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Query scope at position after rm() at global level
        let scope_after_rm = scope_at_position(&artifacts, 10, 0, false);

        prop_assert!(!scope_after_rm.symbols.contains_key(var_name.as_str()),
            "Variable should NOT be in scope after rm() at global level");
    }

    /// Feature: rm-remove-support, Property 6: Function Scope Isolation
    /// **Validates: Requirements 5.1, 5.2, 5.3**
    ///
    /// Test that rm() of a global variable inside a function does NOT affect global scope.
    /// Even if the variable name matches a global variable, the rm() inside a function
    /// should only affect the function's local scope.
    #[test]
    fn prop_rm_global_var_name_inside_function_no_global_effect(
        var_name in r_identifier(),
        func_name in r_identifier()
    ) {
        // Ensure names are distinct
        prop_assume!(var_name != func_name);

        let uri = make_url("test");

        // Code: global definition, function that tries to rm() the same-named variable
        let code = format!(
            "{} <- 1\n{} <- function() {{\n  rm({})\n}}\n# after function",
            var_name, func_name, var_name
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Query scope at position after function definition (global scope)
        let scope_after_func = scope_at_position(&artifacts, 10, 0, false);

        prop_assert!(scope_after_func.symbols.contains_key(var_name.as_str()),
            "Global variable should still be in scope after function with rm() inside");
        prop_assert!(scope_after_func.symbols.contains_key(func_name.as_str()),
            "Function name should be available");
    }

    /// Feature: rm-remove-support, Property 6: Function Scope Isolation
    /// **Validates: Requirements 5.1, 5.2, 5.3**
    ///
    /// Test that rm() inside nested functions only affects the innermost function scope.
    #[test]
    fn prop_rm_nested_function_scope_isolation(
        outer_func in r_identifier(),
        inner_func in r_identifier(),
        outer_var in r_identifier(),
        inner_var in r_identifier()
    ) {
        // Ensure all names are distinct
        prop_assume!(outer_func != inner_func && outer_func != outer_var && outer_func != inner_var);
        prop_assume!(inner_func != outer_var && inner_func != inner_var);
        prop_assume!(outer_var != inner_var);

        let uri = make_url("test");

        // Code: nested functions where inner function has rm()
        let code = format!(
            "{} <- function() {{\n  {} <- 1\n  {} <- function() {{\n    {} <- 2\n    rm({})\n  }}\n  # after inner func\n}}",
            outer_func, outer_var, inner_func, inner_var, inner_var
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Query scope at position after inner function definition but inside outer function
        // This should be on the line with "# after inner func"
        let comment_line = code.lines().enumerate()
            .find(|(_, line)| line.contains("# after inner func"))
            .map(|(i, _)| i as u32)
            .unwrap_or(6);

        let scope_outer_after_inner = scope_at_position(&artifacts, comment_line, 5, false);

        prop_assert!(scope_outer_after_inner.symbols.contains_key(outer_func.as_str()),
            "Outer function should be available inside itself");
        prop_assert!(scope_outer_after_inner.symbols.contains_key(outer_var.as_str()),
            "Outer variable should still be in scope (rm in inner function should not affect it)");
        prop_assert!(scope_outer_after_inner.symbols.contains_key(inner_func.as_str()),
            "Inner function should be available inside outer function");
        // inner_var is local to inner function, so it should NOT be available in outer function
        prop_assert!(!scope_outer_after_inner.symbols.contains_key(inner_var.as_str()),
            "Inner variable should NOT be available outside inner function");
    }

    /// Feature: rm-remove-support, Property 6: Function Scope Isolation
    /// **Validates: Requirements 5.1, 5.2, 5.3**
    ///
    /// Test that rm() with remove() alias inside function also respects function scope isolation.
    #[test]
    fn prop_remove_function_scope_isolation(
        global_var in r_identifier(),
        func_name in r_identifier(),
        local_var in r_identifier()
    ) {
        // Ensure all names are distinct
        prop_assume!(global_var != func_name && global_var != local_var && func_name != local_var);

        let uri = make_url("test");

        // Code: global definition, function with local definition and remove() inside
        let code = format!(
            "{} <- 1\n{} <- function() {{\n  {} <- 2\n  remove({})\n}}",
            global_var, func_name, local_var, local_var
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // At end of file (outside function), global variable should still be in scope
        let scope_outside = scope_at_position(&artifacts, 10, 0, false);

        prop_assert!(scope_outside.symbols.contains_key(global_var.as_str()),
            "Global variable should be available outside function (remove inside function should not affect it)");
        prop_assert!(scope_outside.symbols.contains_key(func_name.as_str()),
            "Function name should be available outside function");
        prop_assert!(!scope_outside.symbols.contains_key(local_var.as_str()),
            "Function-local variable should NOT be available outside function");
    }

    /// Feature: rm-remove-support, Property 6: Function Scope Isolation
    /// **Validates: Requirements 5.1, 5.2, 5.3**
    ///
    /// Test that rm(list=...) inside function also respects function scope isolation.
    #[test]
    fn prop_rm_list_function_scope_isolation(
        global_var in r_identifier(),
        func_name in r_identifier(),
        local_var in r_identifier()
    ) {
        // Ensure all names are distinct
        prop_assume!(global_var != func_name && global_var != local_var && func_name != local_var);

        let uri = make_url("test");

        // Code: global definition, function with local definition and rm(list=...) inside
        let code = format!(
            "{} <- 1\n{} <- function() {{\n  {} <- 2\n  rm(list = \"{}\")\n}}",
            global_var, func_name, local_var, local_var
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // At end of file (outside function), global variable should still be in scope
        let scope_outside = scope_at_position(&artifacts, 10, 0, false);

        prop_assert!(scope_outside.symbols.contains_key(global_var.as_str()),
            "Global variable should be available outside function (rm(list=...) inside function should not affect it)");
        prop_assert!(scope_outside.symbols.contains_key(func_name.as_str()),
            "Function name should be available outside function");
        prop_assert!(!scope_outside.symbols.contains_key(local_var.as_str()),
            "Function-local variable should NOT be available outside function");
    }
}

// ============================================================================
// Feature: rm-remove-support, Property 8: Timeline-Based Scope Resolution
// Validates: Requirements 7.1, 7.2, 7.3, 7.4
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: rm-remove-support, Property 8: Timeline-Based Scope Resolution
    /// **Validates: Requirements 7.1, 7.2, 7.3, 7.4**
    ///
    /// For any sequence of definitions and removals of a symbol, scope at position P
    /// SHALL include the symbol if and only if there exists a definition before P
    /// with no removal between that definition and P.
    ///
    /// Test pattern: Define then remove - symbol NOT in scope after removal
    /// ```r
    /// x <- 1
    /// rm(x)
    /// # x NOT in scope here
    /// ```
    #[test]
    fn prop_timeline_define_then_remove_not_in_scope(
        symbol in r_identifier()
    ) {
        let uri = make_url("test");

        // Code: define symbol, then remove it
        let code = format!(
            "{} <- 1\nrm({})\n# after rm",
            symbol, symbol
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Query scope at position after rm() - symbol should NOT be in scope
        let scope_after_rm = scope_at_position(&artifacts, 10, 0, false);

        prop_assert!(!scope_after_rm.symbols.contains_key(symbol.as_str()),
            "Symbol should NOT be in scope after rm() (define then remove)");
    }

    /// Feature: rm-remove-support, Property 8: Timeline-Based Scope Resolution
    /// **Validates: Requirements 7.1, 7.2, 7.3, 7.4**
    ///
    /// Test pattern: Remove then define - symbol IS in scope after definition
    /// ```r
    /// rm(x)  # removal of undefined symbol has no effect
    /// x <- 1
    /// # x IS in scope here
    /// ```
    #[test]
    fn prop_timeline_remove_then_define_in_scope(
        symbol in r_identifier()
    ) {
        let uri = make_url("test");

        // Code: remove symbol (before it's defined), then define it
        let code = format!(
            "rm({})\n{} <- 1\n# after define",
            symbol, symbol
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Query scope at position after definition - symbol SHOULD be in scope
        let scope_after_define = scope_at_position(&artifacts, 10, 0, false);

        prop_assert!(scope_after_define.symbols.contains_key(symbol.as_str()),
            "Symbol should be in scope after definition (remove then define)");
    }

    /// Feature: rm-remove-support, Property 8: Timeline-Based Scope Resolution
    /// **Validates: Requirements 7.1, 7.2, 7.3, 7.4**
    ///
    /// Test pattern: Define, remove, define - symbol IS in scope after second definition
    /// ```r
    /// x <- 1
    /// rm(x)
    /// x <- 2
    /// # x IS in scope here
    /// ```
    #[test]
    fn prop_timeline_define_remove_define_in_scope(
        symbol in r_identifier()
    ) {
        let uri = make_url("test");

        // Code: define, remove, then define again
        let code = format!(
            "{} <- 1\nrm({})\n{} <- 2\n# after second define",
            symbol, symbol, symbol
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Query scope at position after second definition - symbol SHOULD be in scope
        let scope_after_second_define = scope_at_position(&artifacts, 10, 0, false);

        prop_assert!(scope_after_second_define.symbols.contains_key(symbol.as_str()),
            "Symbol should be in scope after second definition (define, remove, define)");
    }

    /// Feature: rm-remove-support, Property 8: Timeline-Based Scope Resolution
    /// **Validates: Requirements 7.1, 7.2, 7.3, 7.4**
    ///
    /// Test pattern: Position-aware queries - scope at position between definition and removal
    /// ```r
    /// x <- 1  # line 0
    /// # x IS in scope here (line 1)
    /// rm(x)   # line 2
    /// # x NOT in scope here (line 3)
    /// ```
    #[test]
    fn prop_timeline_position_aware_between_def_and_rm(
        symbol in r_identifier()
    ) {
        let uri = make_url("test");

        // Code: define on line 0, rm on line 2
        let code = format!(
            "{} <- 1\n# between\nrm({})\n# after",
            symbol, symbol
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Query scope at line 1 (between definition and removal) - symbol SHOULD be in scope
        let scope_between = scope_at_position(&artifacts, 1, 0, false);
        prop_assert!(scope_between.symbols.contains_key(symbol.as_str()),
            "Symbol should be in scope between definition and removal");

        // Query scope at line 3 (after removal) - symbol should NOT be in scope
        let scope_after = scope_at_position(&artifacts, 3, 0, false);
        prop_assert!(!scope_after.symbols.contains_key(symbol.as_str()),
            "Symbol should NOT be in scope after removal");
    }

    /// Feature: rm-remove-support, Property 8: Timeline-Based Scope Resolution
    /// **Validates: Requirements 7.1, 7.2, 7.3, 7.4**
    ///
    /// Test pattern: Position-aware queries at different points in define-remove-define sequence
    /// ```r
    /// x <- 1  # line 0: first definition
    /// # line 1: x IS in scope
    /// rm(x)   # line 2: removal
    /// # line 3: x NOT in scope
    /// x <- 2  # line 4: second definition
    /// # line 5: x IS in scope
    /// ```
    #[test]
    fn prop_timeline_position_aware_define_remove_define_sequence(
        symbol in r_identifier()
    ) {
        let uri = make_url("test");

        // Code with clear line positions
        let code = format!(
            "{} <- 1\n# after first def\nrm({})\n# after rm\n{} <- 2\n# after second def",
            symbol, symbol, symbol
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Line 1: after first definition, before removal - symbol SHOULD be in scope
        let scope_after_first_def = scope_at_position(&artifacts, 1, 0, false);
        prop_assert!(scope_after_first_def.symbols.contains_key(symbol.as_str()),
            "Symbol should be in scope after first definition");

        // Line 3: after removal, before second definition - symbol should NOT be in scope
        let scope_after_rm = scope_at_position(&artifacts, 3, 0, false);
        prop_assert!(!scope_after_rm.symbols.contains_key(symbol.as_str()),
            "Symbol should NOT be in scope after removal");

        // Line 5: after second definition - symbol SHOULD be in scope
        let scope_after_second_def = scope_at_position(&artifacts, 5, 0, false);
        prop_assert!(scope_after_second_def.symbols.contains_key(symbol.as_str()),
            "Symbol should be in scope after second definition");
    }

    /// Feature: rm-remove-support, Property 8: Timeline-Based Scope Resolution
    /// **Validates: Requirements 7.1, 7.2, 7.3, 7.4**
    ///
    /// Test pattern: Multiple symbols with interleaved definitions and removals
    /// ```r
    /// x <- 1
    /// y <- 2
    /// rm(x)
    /// # x NOT in scope, y IS in scope
    /// ```
    #[test]
    fn prop_timeline_multiple_symbols_interleaved(
        symbol_x in r_identifier(),
        symbol_y in r_identifier()
    ) {
        // Ensure different symbols
        prop_assume!(symbol_x != symbol_y);

        let uri = make_url("test");

        // Code: define x, define y, remove x
        let code = format!(
            "{} <- 1\n{} <- 2\nrm({})\n# after rm",
            symbol_x, symbol_y, symbol_x
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Query scope at end - x should NOT be in scope, y SHOULD be in scope
        let scope_end = scope_at_position(&artifacts, 10, 0, false);

        prop_assert!(!scope_end.symbols.contains_key(symbol_x.as_str()),
            "Symbol x should NOT be in scope after rm(x)");
        prop_assert!(scope_end.symbols.contains_key(symbol_y.as_str()),
            "Symbol y should still be in scope (not removed)");
    }

    /// Feature: rm-remove-support, Property 8: Timeline-Based Scope Resolution
    /// **Validates: Requirements 7.1, 7.2, 7.3, 7.4**
    ///
    /// Test pattern: Multiple removals of same symbol (idempotent)
    /// ```r
    /// x <- 1
    /// rm(x)
    /// rm(x)  # second removal has no effect (already removed)
    /// # x NOT in scope
    /// ```
    #[test]
    fn prop_timeline_multiple_removals_idempotent(
        symbol in r_identifier()
    ) {
        let uri = make_url("test");

        // Code: define, remove, remove again
        let code = format!(
            "{} <- 1\nrm({})\nrm({})\n# after double rm",
            symbol, symbol, symbol
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Query scope at end - symbol should NOT be in scope
        let scope_end = scope_at_position(&artifacts, 10, 0, false);

        prop_assert!(!scope_end.symbols.contains_key(symbol.as_str()),
            "Symbol should NOT be in scope after multiple removals");
    }

    /// Feature: rm-remove-support, Property 8: Timeline-Based Scope Resolution
    /// **Validates: Requirements 7.1, 7.2, 7.3, 7.4**
    ///
    /// Test pattern: Using remove() alias follows same timeline rules
    /// ```r
    /// x <- 1
    /// remove(x)
    /// # x NOT in scope
    /// ```
    #[test]
    fn prop_timeline_remove_alias_same_behavior(
        symbol in r_identifier()
    ) {
        let uri = make_url("test");

        // Code: define, then remove using remove() alias
        let code = format!(
            "{} <- 1\nremove({})\n# after remove",
            symbol, symbol
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Query scope at end - symbol should NOT be in scope
        let scope_end = scope_at_position(&artifacts, 10, 0, false);

        prop_assert!(!scope_end.symbols.contains_key(symbol.as_str()),
            "Symbol should NOT be in scope after remove() (same as rm())");
    }

    /// Feature: rm-remove-support, Property 8: Timeline-Based Scope Resolution
    /// **Validates: Requirements 7.1, 7.2, 7.3, 7.4**
    ///
    /// Test pattern: Using rm(list=...) follows same timeline rules
    /// ```r
    /// x <- 1
    /// rm(list = "x")
    /// # x NOT in scope
    /// ```
    #[test]
    fn prop_timeline_rm_list_same_behavior(
        symbol in r_identifier()
    ) {
        let uri = make_url("test");

        // Code: define, then remove using rm(list=...)
        let code = format!(
            "{} <- 1\nrm(list = \"{}\")\n# after rm list",
            symbol, symbol
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Query scope at end - symbol should NOT be in scope
        let scope_end = scope_at_position(&artifacts, 10, 0, false);

        prop_assert!(!scope_end.symbols.contains_key(symbol.as_str()),
            "Symbol should NOT be in scope after rm(list=...) (same as rm())");
    }

    /// Feature: rm-remove-support, Property 8: Timeline-Based Scope Resolution
    /// **Validates: Requirements 7.1, 7.2, 7.3, 7.4**
    ///
    /// Test pattern: rm() with multiple symbols removes all of them
    /// ```r
    /// x <- 1
    /// y <- 2
    /// rm(x, y)
    /// # neither x nor y in scope
    /// ```
    #[test]
    fn prop_timeline_rm_multiple_symbols_at_once(
        symbol_x in r_identifier(),
        symbol_y in r_identifier()
    ) {
        // Ensure different symbols
        prop_assume!(symbol_x != symbol_y);

        let uri = make_url("test");

        // Code: define both, then remove both at once
        let code = format!(
            "{} <- 1\n{} <- 2\nrm({}, {})\n# after rm",
            symbol_x, symbol_y, symbol_x, symbol_y
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Query scope at end - neither symbol should be in scope
        let scope_end = scope_at_position(&artifacts, 10, 0, false);

        prop_assert!(!scope_end.symbols.contains_key(symbol_x.as_str()),
            "Symbol x should NOT be in scope after rm(x, y)");
        prop_assert!(!scope_end.symbols.contains_key(symbol_y.as_str()),
            "Symbol y should NOT be in scope after rm(x, y)");
    }

    /// Feature: rm-remove-support, Property 8: Timeline-Based Scope Resolution
    /// **Validates: Requirements 7.1, 7.2, 7.3, 7.4**
    ///
    /// Test pattern: Complex sequence with multiple definitions and removals
    /// ```r
    /// x <- 1  # line 0
    /// y <- 2  # line 1
    /// rm(x)   # line 2
    /// x <- 3  # line 3: redefine x
    /// rm(y)   # line 4
    /// # line 5: x IS in scope, y NOT in scope
    /// ```
    #[test]
    fn prop_timeline_complex_sequence(
        symbol_x in r_identifier(),
        symbol_y in r_identifier()
    ) {
        // Ensure different symbols
        prop_assume!(symbol_x != symbol_y);

        let uri = make_url("test");

        // Complex sequence
        let code = format!(
            "{} <- 1\n{} <- 2\nrm({})\n{} <- 3\nrm({})\n# end",
            symbol_x, symbol_y, symbol_x, symbol_x, symbol_y
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Query scope at end
        let scope_end = scope_at_position(&artifacts, 10, 0, false);

        prop_assert!(scope_end.symbols.contains_key(symbol_x.as_str()),
            "Symbol x should be in scope (redefined after removal)");
        prop_assert!(!scope_end.symbols.contains_key(symbol_y.as_str()),
            "Symbol y should NOT be in scope (removed and not redefined)");
    }

    /// Feature: rm-remove-support, Property 8: Timeline-Based Scope Resolution
    /// **Validates: Requirements 7.1, 7.2, 7.3, 7.4**
    ///
    /// Test pattern: Removal before any definition has no effect
    /// ```r
    /// rm(x)  # x was never defined
    /// # x NOT in scope (was never defined)
    /// ```
    #[test]
    fn prop_timeline_removal_of_undefined_no_effect(
        symbol in r_identifier()
    ) {
        let uri = make_url("test");

        // Code: just rm() without any definition
        let code = format!(
            "rm({})\n# after rm of undefined",
            symbol
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Query scope at end - symbol should NOT be in scope (was never defined)
        let scope_end = scope_at_position(&artifacts, 10, 0, false);

        prop_assert!(!scope_end.symbols.contains_key(symbol.as_str()),
            "Symbol should NOT be in scope (was never defined, rm had no effect)");
    }

    /// Feature: rm-remove-support, Property 8: Timeline-Based Scope Resolution
    /// **Validates: Requirements 7.1, 7.2, 7.3, 7.4**
    ///
    /// Test pattern: Same-line definition and removal - position-aware
    /// ```r
    /// x <- 1; rm(x)
    /// # x NOT in scope at end of line
    /// ```
    #[test]
    fn prop_timeline_same_line_def_and_rm(
        symbol in r_identifier()
    ) {
        let uri = make_url("test");

        // Code: define and remove on same line
        let code = format!(
            "{} <- 1; rm({})",
            symbol, symbol
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Query scope at end of line - symbol should NOT be in scope
        let scope_end = scope_at_position(&artifacts, 0, 100, false);

        prop_assert!(!scope_end.symbols.contains_key(symbol.as_str()),
            "Symbol should NOT be in scope at end of line after same-line rm()");
    }

    /// Feature: rm-remove-support, Property 8: Timeline-Based Scope Resolution
    /// **Validates: Requirements 7.1, 7.2, 7.3, 7.4**
    ///
    /// Test pattern: Position between same-line definition and removal
    /// The symbol should be in scope after definition but before removal on same line.
    #[test]
    fn prop_timeline_same_line_position_between_def_and_rm(
        symbol in r_identifier()
    ) {
        let uri = make_url("test");

        // Code: define and remove on same line with space between
        // x <- 1; rm(x)
        // Position after definition (col ~7) but before rm() (col ~9)
        let code = format!(
            "{} <- 1; rm({})",
            symbol, symbol
        );
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Find the position of rm() call
        let rm_pos = code.find("rm(").unwrap_or(0) as u32;

        // Query scope just before rm() - symbol SHOULD be in scope
        let scope_before_rm = scope_at_position(&artifacts, 0, rm_pos.saturating_sub(1), false);
        prop_assert!(scope_before_rm.symbols.contains_key(symbol.as_str()),
            "Symbol should be in scope between definition and rm() on same line");

        // Query scope after rm() - symbol should NOT be in scope
        let scope_after_rm = scope_at_position(&artifacts, 0, rm_pos + 10, false);
        prop_assert!(!scope_after_rm.symbols.contains_key(symbol.as_str()),
            "Symbol should NOT be in scope after rm() on same line");
    }
}

// ============================================================================
// Feature: rm-remove-support, Property 7: Cross-File Removal Propagation
// Validates: Requirements 6.1, 6.2, 6.3
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: rm-remove-support, Property 7: Cross-File Removal Propagation
    /// **Validates: Requirements 6.1, 6.2, 6.3**
    ///
    /// For any file that sources another file defining symbol `s` and then calls `rm(s)`,
    /// scope queries after the `rm()` call SHALL NOT include `s`, while scope queries
    /// between the `source()` and `rm()` calls SHALL include `s`.
    ///
    /// Test pattern:
    /// ```r
    /// # parent.R
    /// source("child.R")  # child.R defines helper_func
    /// # helper_func IS in scope here
    /// rm(helper_func)
    /// # helper_func is NOT in scope here
    /// ```
    #[test]
    fn prop_cross_file_removal_propagation_basic(
        symbol in r_identifier()
    ) {
        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: sources child.R, then removes the symbol
        let parent_code = format!("source(\"child.R\")\nrm({})", symbol);
        let parent_tree = parse_r_tree(&parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, &parent_code);

        // Child code: defines the symbol
        let child_code = format!("{} <- function() {{ 1 }}", symbol);
        let child_tree = parse_r_tree(&child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, &child_code);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta = make_meta_with_sources(vec![("child.R", 0)]);
        graph.update_file(&parent_uri, &parent_meta, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta.clone())) }
            else { None }
        };

        // After source() but before rm() (line 0, after source call), symbol should be in scope
        let scope_before_rm = scope_at_position_with_graph(
            &parent_uri, 0, 20, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );
        prop_assert!(scope_before_rm.symbols.contains_key(symbol.as_str()),
            "Symbol from sourced file should be in scope after source() but before rm()");

        // After rm() (line 1), symbol should NOT be in scope
        let scope_after_rm = scope_at_position_with_graph(
            &parent_uri, 1, 20, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );
        prop_assert!(!scope_after_rm.symbols.contains_key(symbol.as_str()),
            "Symbol should NOT be in scope after rm()");

        // At end of file, symbol should NOT be in scope
        let scope_eof = scope_at_position_with_graph(
            &parent_uri, 10, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );
        prop_assert!(!scope_eof.symbols.contains_key(symbol.as_str()),
            "Symbol should NOT be in scope at end of file after rm()");
    }

    /// Feature: rm-remove-support, Property 7: Cross-File Removal Propagation
    /// **Validates: Requirements 6.1, 6.2, 6.3**
    ///
    /// Test that rm() only removes the specified symbol, not others from the sourced file.
    #[test]
    fn prop_cross_file_removal_propagation_selective(
        symbol_to_remove in r_identifier(),
        symbol_to_keep in r_identifier()
    ) {
        // Ensure different symbols
        prop_assume!(symbol_to_remove != symbol_to_keep);

        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: sources child.R, then removes only one symbol
        let parent_code = format!("source(\"child.R\")\nrm({})", symbol_to_remove);
        let parent_tree = parse_r_tree(&parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, &parent_code);

        // Child code: defines both symbols
        let child_code = format!(
            "{} <- function() {{ 1 }}\n{} <- function() {{ 2 }}",
            symbol_to_remove, symbol_to_keep
        );
        let child_tree = parse_r_tree(&child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, &child_code);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta = make_meta_with_sources(vec![("child.R", 0)]);
        graph.update_file(&parent_uri, &parent_meta, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta.clone())) }
            else { None }
        };

        // After rm(), only the removed symbol should be gone
        let scope_after_rm = scope_at_position_with_graph(
            &parent_uri, 1, 20, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );
        prop_assert!(!scope_after_rm.symbols.contains_key(symbol_to_remove.as_str()),
            "Removed symbol should NOT be in scope after rm()");
        prop_assert!(scope_after_rm.symbols.contains_key(symbol_to_keep.as_str()),
            "Non-removed symbol should still be in scope after rm()");
    }

    /// Feature: rm-remove-support, Property 7: Cross-File Removal Propagation
    /// **Validates: Requirements 6.1, 6.2, 6.3**
    ///
    /// Test that rm() with multiple symbols removes all specified symbols from sourced file.
    #[test]
    fn prop_cross_file_removal_propagation_multiple_symbols(
        symbol_a in r_identifier(),
        symbol_b in r_identifier(),
        symbol_c in r_identifier()
    ) {
        // Ensure all symbols are different
        prop_assume!(symbol_a != symbol_b && symbol_b != symbol_c && symbol_a != symbol_c);

        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: sources child.R, then removes symbol_a and symbol_b
        let parent_code = format!("source(\"child.R\")\nrm({}, {})", symbol_a, symbol_b);
        let parent_tree = parse_r_tree(&parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, &parent_code);

        // Child code: defines all three symbols
        let child_code = format!(
            "{} <- function() {{ 1 }}\n{} <- function() {{ 2 }}\n{} <- function() {{ 3 }}",
            symbol_a, symbol_b, symbol_c
        );
        let child_tree = parse_r_tree(&child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, &child_code);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta = make_meta_with_sources(vec![("child.R", 0)]);
        graph.update_file(&parent_uri, &parent_meta, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta.clone())) }
            else { None }
        };

        // Before rm() (line 0), all three symbols should be in scope
        let scope_before_rm = scope_at_position_with_graph(
            &parent_uri, 0, 20, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );
        prop_assert!(scope_before_rm.symbols.contains_key(symbol_a.as_str()),
            "symbol_a should be in scope before rm()");
        prop_assert!(scope_before_rm.symbols.contains_key(symbol_b.as_str()),
            "symbol_b should be in scope before rm()");
        prop_assert!(scope_before_rm.symbols.contains_key(symbol_c.as_str()),
            "symbol_c should be in scope before rm()");

        // After rm() (line 1), symbol_a and symbol_b should NOT be in scope, but symbol_c should be
        let scope_after_rm = scope_at_position_with_graph(
            &parent_uri, 1, 20, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );
        prop_assert!(!scope_after_rm.symbols.contains_key(symbol_a.as_str()),
            "symbol_a should NOT be in scope after rm()");
        prop_assert!(!scope_after_rm.symbols.contains_key(symbol_b.as_str()),
            "symbol_b should NOT be in scope after rm()");
        prop_assert!(scope_after_rm.symbols.contains_key(symbol_c.as_str()),
            "symbol_c should still be in scope after rm()");
    }

    /// Feature: rm-remove-support, Property 7: Cross-File Removal Propagation
    /// **Validates: Requirements 6.1, 6.2, 6.3**
    ///
    /// Test that remove() alias works the same as rm() for cross-file removal.
    #[test]
    fn prop_cross_file_removal_propagation_remove_alias(
        symbol in r_identifier()
    ) {
        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: sources child.R, then removes the symbol using remove()
        let parent_code = format!("source(\"child.R\")\nremove({})", symbol);
        let parent_tree = parse_r_tree(&parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, &parent_code);

        // Child code: defines the symbol
        let child_code = format!("{} <- function() {{ 1 }}", symbol);
        let child_tree = parse_r_tree(&child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, &child_code);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta = make_meta_with_sources(vec![("child.R", 0)]);
        graph.update_file(&parent_uri, &parent_meta, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta.clone())) }
            else { None }
        };

        // After source() but before remove() (line 0), symbol should be in scope
        let scope_before_remove = scope_at_position_with_graph(
            &parent_uri, 0, 20, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );
        prop_assert!(scope_before_remove.symbols.contains_key(symbol.as_str()),
            "Symbol from sourced file should be in scope after source() but before remove()");

        // After remove() (line 1), symbol should NOT be in scope
        let scope_after_remove = scope_at_position_with_graph(
            &parent_uri, 1, 20, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );
        prop_assert!(!scope_after_remove.symbols.contains_key(symbol.as_str()),
            "Symbol should NOT be in scope after remove()");
    }

    /// Feature: rm-remove-support, Property 7: Cross-File Removal Propagation
    /// **Validates: Requirements 6.1, 6.2, 6.3**
    ///
    /// Test that rm(list=...) works for cross-file removal.
    #[test]
    fn prop_cross_file_removal_propagation_list_arg(
        symbol in r_identifier()
    ) {
        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: sources child.R, then removes the symbol using rm(list=...)
        let parent_code = format!("source(\"child.R\")\nrm(list = \"{}\")", symbol);
        let parent_tree = parse_r_tree(&parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, &parent_code);

        // Child code: defines the symbol
        let child_code = format!("{} <- function() {{ 1 }}", symbol);
        let child_tree = parse_r_tree(&child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, &child_code);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta = make_meta_with_sources(vec![("child.R", 0)]);
        graph.update_file(&parent_uri, &parent_meta, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta.clone())) }
            else { None }
        };

        // After source() but before rm(list=...) (line 0), symbol should be in scope
        let scope_before_rm = scope_at_position_with_graph(
            &parent_uri, 0, 20, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );
        prop_assert!(scope_before_rm.symbols.contains_key(symbol.as_str()),
            "Symbol from sourced file should be in scope after source() but before rm(list=...)");

        // After rm(list=...) (line 1), symbol should NOT be in scope
        let scope_after_rm = scope_at_position_with_graph(
            &parent_uri, 1, 20, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );
        prop_assert!(!scope_after_rm.symbols.contains_key(symbol.as_str()),
            "Symbol should NOT be in scope after rm(list=...)");
    }

    /// Feature: rm-remove-support, Property 7: Cross-File Removal Propagation
    /// **Validates: Requirements 6.1, 6.2, 6.3**
    ///
    /// Test that rm(list=c(...)) works for cross-file removal of multiple symbols.
    #[test]
    fn prop_cross_file_removal_propagation_list_c_arg(
        symbol_a in r_identifier(),
        symbol_b in r_identifier(),
        symbol_c in r_identifier()
    ) {
        // Ensure all symbols are different
        prop_assume!(symbol_a != symbol_b && symbol_b != symbol_c && symbol_a != symbol_c);

        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: sources child.R, then removes symbol_a and symbol_b using rm(list=c(...))
        let parent_code = format!(
            "source(\"child.R\")\nrm(list = c(\"{}\", \"{}\"))",
            symbol_a, symbol_b
        );
        let parent_tree = parse_r_tree(&parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, &parent_code);

        // Child code: defines all three symbols
        let child_code = format!(
            "{} <- function() {{ 1 }}\n{} <- function() {{ 2 }}\n{} <- function() {{ 3 }}",
            symbol_a, symbol_b, symbol_c
        );
        let child_tree = parse_r_tree(&child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, &child_code);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta = make_meta_with_sources(vec![("child.R", 0)]);
        graph.update_file(&parent_uri, &parent_meta, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta.clone())) }
            else { None }
        };

        // After rm(list=c(...)) (line 1), symbol_a and symbol_b should NOT be in scope
        let scope_after_rm = scope_at_position_with_graph(
            &parent_uri, 1, 40, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );
        prop_assert!(!scope_after_rm.symbols.contains_key(symbol_a.as_str()),
            "symbol_a should NOT be in scope after rm(list=c(...))");
        prop_assert!(!scope_after_rm.symbols.contains_key(symbol_b.as_str()),
            "symbol_b should NOT be in scope after rm(list=c(...))");
        prop_assert!(scope_after_rm.symbols.contains_key(symbol_c.as_str()),
            "symbol_c should still be in scope after rm(list=c(...))");
    }

    /// Feature: rm-remove-support, Property 7: Cross-File Removal Propagation
    /// **Validates: Requirements 6.1, 6.2, 6.3**
    ///
    /// Test that rm() of a sourced symbol followed by redefinition works correctly.
    #[test]
    fn prop_cross_file_removal_then_redefine(
        symbol in r_identifier()
    ) {
        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: sources child.R, removes the symbol, then redefines it
        let parent_code = format!(
            "source(\"child.R\")\nrm({})\n{} <- function() {{ 99 }}",
            symbol, symbol
        );
        let parent_tree = parse_r_tree(&parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, &parent_code);

        // Child code: defines the symbol
        let child_code = format!("{} <- function() {{ 1 }}", symbol);
        let child_tree = parse_r_tree(&child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, &child_code);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta = make_meta_with_sources(vec![("child.R", 0)]);
        graph.update_file(&parent_uri, &parent_meta, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta.clone())) }
            else { None }
        };

        // After source() but before rm() (line 0), symbol should be in scope
        let scope_after_source = scope_at_position_with_graph(
            &parent_uri, 0, 20, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );
        prop_assert!(scope_after_source.symbols.contains_key(symbol.as_str()),
            "Symbol should be in scope after source() but before rm()");

        // After rm() but before redefinition (line 1), symbol should NOT be in scope
        let scope_after_rm = scope_at_position_with_graph(
            &parent_uri, 1, 20, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );
        prop_assert!(!scope_after_rm.symbols.contains_key(symbol.as_str()),
            "Symbol should NOT be in scope after rm() but before redefinition");

        // After redefinition (line 2), symbol should be in scope again
        let scope_after_redef = scope_at_position_with_graph(
            &parent_uri, 2, 40, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );
        prop_assert!(scope_after_redef.symbols.contains_key(symbol.as_str()),
            "Symbol should be in scope after redefinition");
    }

    /// Feature: rm-remove-support, Property 7: Cross-File Removal Propagation
    /// **Validates: Requirements 6.1, 6.2, 6.3**
    ///
    /// Test that rm() in parent does NOT affect the child file's own scope.
    /// The child file should still have its own definition available.
    #[test]
    fn prop_cross_file_removal_does_not_affect_child_scope(
        symbol in r_identifier()
    ) {
        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: sources child.R, then removes the symbol
        let parent_code = format!("source(\"child.R\")\nrm({})", symbol);
        let parent_tree = parse_r_tree(&parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, &parent_code);

        // Child code: defines the symbol
        let child_code = format!("{} <- function() {{ 1 }}", symbol);
        let child_tree = parse_r_tree(&child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, &child_code);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta = make_meta_with_sources(vec![("child.R", 0)]);
        graph.update_file(&parent_uri, &parent_meta, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta.clone())) }
            else { None }
        };

        // In child file, the symbol should still be in scope (child's own definition)
        let scope_in_child = scope_at_position_with_graph(
            &child_uri, 0, 40, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );
        prop_assert!(scope_in_child.symbols.contains_key(symbol.as_str()),
            "Symbol should still be in scope in child file (child's own definition)");

        // In parent file after rm(), the symbol should NOT be in scope
        let scope_in_parent = scope_at_position_with_graph(
            &parent_uri, 1, 20, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );
        prop_assert!(!scope_in_parent.symbols.contains_key(symbol.as_str()),
            "Symbol should NOT be in scope in parent file after rm()");
    }
}

// ============================================================================
// Property 3: Position-Aware Package Scope
// Feature: package-function-awareness
// **Validates: Requirements 2.1, 2.2, 2.3**
//
// For any R source file with a library() call at position P, and any symbol S
// exported by that package:
// - Scope resolution at any position before P SHALL NOT include S
// - Scope resolution at any position after P SHALL include S
//
// Note: Since package exports are not yet integrated into scope resolution (task 7),
// this test verifies that:
// - PackageLoad events are correctly positioned in the timeline
// - The package name is correctly captured
// - The position ordering is correct
// ============================================================================

use super::scope::{ScopeEvent, event_effect_position};

/// R reserved words that cannot be used as package names
const R_RESERVED_PKG: &[&str] = &[
    "if", "else", "for", "in", "while", "repeat", "next", "break", "function", "NA", "NaN", "Inf",
    "NULL", "TRUE", "FALSE", "T", "F", "na", "nan", "inf", "null", "true", "false",
];

/// Check if a name is a valid R package name (not reserved)
fn is_valid_pkg_name(name: &str) -> bool {
    !R_RESERVED_PKG.contains(&name) && !name.is_empty()
}

/// Generate a valid R package name (lowercase letters and dots, starting with letter)
fn pkg_name() -> impl Strategy<Value = String> {
    "[a-z][a-z0-9\\.]{0,8}".prop_filter("not reserved", |s| is_valid_pkg_name(s))
}

/// Generate a library call function name
fn library_func() -> impl Strategy<Value = &'static str> {
    prop_oneof![Just("library"), Just("require"), Just("loadNamespace"),]
}

/// Quote style for package names
#[derive(Debug, Clone, Copy)]
enum PkgQuoteStyle {
    None,   // library(dplyr)
    Double, // library("dplyr")
    Single, // library('dplyr')
}

fn pkg_quote_style() -> impl Strategy<Value = PkgQuoteStyle> {
    prop_oneof![
        Just(PkgQuoteStyle::None),
        Just(PkgQuoteStyle::Double),
        Just(PkgQuoteStyle::Single),
    ]
}

/// Generate R code for a library call
fn generate_library_call(func: &str, package: &str, quote_style: PkgQuoteStyle) -> String {
    let quoted_pkg = match quote_style {
        PkgQuoteStyle::None => package.to_string(),
        PkgQuoteStyle::Double => format!("\"{}\"", package),
        PkgQuoteStyle::Single => format!("'{}'", package),
    };
    format!("{}({})", func, quoted_pkg)
}

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 3: Position-Aware Package Scope
    /// **Validates: Requirements 2.1, 2.2, 2.3**
    ///
    /// For any R source file with a library() call at position P:
    /// - PackageLoad events SHALL appear in the timeline at position P
    /// - PackageLoad events SHALL have the correct package name
    /// - Timeline SHALL be sorted by position (PackageLoad at correct position relative to other events)
    #[test]
    fn prop_position_aware_package_scope(
        package in pkg_name(),
        func in library_func(),
        quote_style in pkg_quote_style(),
        lines_before in 0..5usize,
        lines_after in 0..5usize,
    ) {
        let uri = make_url("test_pkg_scope");

        // Build code with library call at a specific position
        let mut code_lines = Vec::new();

        // Add filler lines before library call
        for i in 0..lines_before {
            code_lines.push(format!("x{} <- {}", i, i));
        }

        // Add library call
        let library_line = lines_before;
        code_lines.push(generate_library_call(func, &package, quote_style));

        // Add filler lines after library call
        for i in 0..lines_after {
            code_lines.push(format!("y{} <- {}", i, i));
        }

        let code = code_lines.join("\n");
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Extract PackageLoad events from timeline
        let package_load_events: Vec<_> = artifacts.timeline.iter()
            .filter_map(|e| {
                if let ScopeEvent::PackageLoad { line, column, package: pkg, function_scope, .. } = e {
                    Some((*line, *column, pkg.clone(), *function_scope))
                } else {
                    None
                }
            })
            .collect();

        // 1. Should have exactly one PackageLoad event
        prop_assert_eq!(
            package_load_events.len(), 1,
            "Expected exactly one PackageLoad event, got {}. Code:\n{}",
            package_load_events.len(), code
        );

        let (event_line, _event_column, event_package, event_function_scope) = &package_load_events[0];

        // 2. PackageLoad should be on the correct line
        prop_assert_eq!(
            *event_line, library_line as u32,
            "PackageLoad event on wrong line. Expected {}, got {}. Code:\n{}",
            library_line, event_line, code
        );

        // 3. Package name should be correctly captured
        prop_assert_eq!(
            event_package, &package,
            "Package name mismatch. Expected '{}', got '{}'. Code:\n{}",
            package, event_package, code
        );

        // 4. Global library call should have function_scope=None
        prop_assert!(
            event_function_scope.is_none(),
            "Global library() call should have function_scope=None. Code:\n{}",
            code
        );

        // 5. Timeline should be sorted by each event's *effect* position
        //    (for `Def` events that's `visible_from_*`, not the LHS anchor; see
        //    `event_effect_position` in scope.rs and the AGENTS.md learning that
        //    locks down this invariant).
        let mut prev_pos = (0u32, 0u32);
        for event in &artifacts.timeline {
            let pos = event_effect_position(event);
            prop_assert!(
                pos >= prev_pos,
                "Timeline not sorted: event at ({}, {}) comes after ({}, {}). Code:\n{}",
                pos.0, pos.1, prev_pos.0, prev_pos.1, code
            );
            prev_pos = pos;
        }

        // 6. Position-aware property: definitions before the library call come before
        //    PackageLoad in the timeline, and definitions after it come after. This is
        //    implicitly verified by the sorted-timeline check in step 5 above, so there
        //    is no separate assertion here.
    }

    /// Property 3 extended: Multiple library calls should create multiple PackageLoad events in order
    /// **Validates: Requirements 2.1, 2.2, 2.3**
    #[test]
    fn prop_multiple_library_calls_ordered(
        pkg1 in pkg_name(),
        pkg2 in pkg_name(),
        pkg3 in pkg_name(),
    ) {
        // Ensure packages are distinct for clearer testing
        prop_assume!(pkg1 != pkg2 && pkg2 != pkg3 && pkg1 != pkg3);

        let uri = make_url("test_multi_pkg");

        let code = format!(
            "x <- 1\nlibrary({})\ny <- 2\nlibrary({})\nz <- 3\nlibrary({})\nw <- 4",
            pkg1, pkg2, pkg3
        );

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Extract PackageLoad events
        let package_load_events: Vec<_> = artifacts.timeline.iter()
            .filter_map(|e| {
                if let ScopeEvent::PackageLoad { line, package, .. } = e {
                    Some((*line, package.clone()))
                } else {
                    None
                }
            })
            .collect();

        // Should have exactly 3 PackageLoad events
        prop_assert_eq!(
            package_load_events.len(), 3,
            "Expected 3 PackageLoad events, got {}. Code:\n{}",
            package_load_events.len(), code
        );

        // Events should be in document order with correct packages
        prop_assert_eq!(&package_load_events[0], &(1, pkg1.clone()),
            "First PackageLoad should be {} on line 1", pkg1);
        prop_assert_eq!(&package_load_events[1], &(3, pkg2.clone()),
            "Second PackageLoad should be {} on line 3", pkg2);
        prop_assert_eq!(&package_load_events[2], &(5, pkg3.clone()),
            "Third PackageLoad should be {} on line 5", pkg3);

        // Verify strict ordering: each PackageLoad should be after the previous
        for i in 1..package_load_events.len() {
            let (prev_line, _) = &package_load_events[i - 1];
            let (curr_line, _) = &package_load_events[i];
            prop_assert!(
                curr_line > prev_line,
                "PackageLoad events not in strict order: line {} not > line {}",
                curr_line, prev_line
            );
        }
    }

    /// Property 3 extended: PackageLoad position should be at the END of the library() call
    /// **Validates: Requirements 2.2, 2.3**
    ///
    /// This ensures that symbols from the package are only available AFTER the call completes,
    /// not during the call itself.
    #[test]
    fn prop_package_load_position_at_call_end(
        package in pkg_name(),
        func in library_func(),
    ) {
        let uri = make_url("test_pkg_pos");

        let code = format!("{}({})", func, package);
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        let package_load_events: Vec<_> = artifacts.timeline.iter()
            .filter_map(|e| {
                if let ScopeEvent::PackageLoad { line, column, package: pkg, .. } = e {
                    Some((*line, *column, pkg.clone()))
                } else {
                    None
                }
            })
            .collect();

        prop_assert_eq!(package_load_events.len(), 1);
        let (line, column, pkg) = &package_load_events[0];

        // Should be on line 0
        prop_assert_eq!(*line, 0);

        // Package name should match
        prop_assert_eq!(pkg, &package);

        // Column should be at or after the end of the call (after the closing paren)
        // The call is: func(package) or func("package") or func('package')
        // Minimum length is func.len() + 1 (open paren) + package.len() + 1 (close paren)
        let min_end_column = (func.len() + 1 + package.len() + 1) as u32;
        prop_assert!(
            *column >= min_end_column - 1, // Allow for 0-based indexing variations
            "PackageLoad column {} should be at or near end of call (min expected: {}). Code: {}",
            column, min_end_column, code
        );
    }
}

// ============================================================================
// Property 4: Function-Scoped Package Loading
// Feature: package-function-awareness
// **Validates: Requirements 2.4, 2.5**
//
// For any R source file with a library() call inside a function body, the package
// exports SHALL only be available within that function's scope, not at the global
// level or in other functions.
//
// This test verifies that:
// - PackageLoad events inside functions have the correct function_scope set (not None)
// - The function_scope interval matches the containing function
// - library() calls at global scope have function_scope=None
// - Nested functions capture the innermost function scope
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 4: Function-Scoped Package Loading
    /// **Validates: Requirements 2.4, 2.5**
    ///
    /// For any R source file with a library() call inside a function body:
    /// - The PackageLoad event SHALL have function_scope set to the containing function
    /// - The function_scope interval SHALL match the containing function's boundaries
    #[test]
    fn prop_function_scoped_package_loading(
        package in pkg_name(),
        func_name in r_identifier(),
        lines_before_lib in 0..3usize,
        lines_after_lib in 0..3usize,
    ) {
        let uri = make_url("test_func_pkg_scope");

        // Build code with library call inside a function
        let mut func_body_lines = Vec::new();

        // Add filler lines before library call inside function
        for i in 0..lines_before_lib {
            func_body_lines.push(format!("    x{} <- {}", i, i));
        }

        // Add library call inside function
        func_body_lines.push(format!("    library({})", package));

        // Add filler lines after library call inside function
        for i in 0..lines_after_lib {
            func_body_lines.push(format!("    y{} <- {}", i, i));
        }

        let func_body = func_body_lines.join("\n");
        let code = format!("{} <- function() {{\n{}\n}}", func_name, func_body);

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Extract PackageLoad events from timeline
        let package_load_events: Vec<_> = artifacts.timeline.iter()
            .filter_map(|e| {
                if let ScopeEvent::PackageLoad { line, column, package: pkg, function_scope, .. } = e {
                    Some((*line, *column, pkg.clone(), *function_scope))
                } else {
                    None
                }
            })
            .collect();

        // 1. Should have exactly one PackageLoad event
        prop_assert_eq!(
            package_load_events.len(), 1,
            "Expected exactly one PackageLoad event, got {}. Code:\n{}",
            package_load_events.len(), code
        );

        let (event_line, _event_column, event_package, event_function_scope) = &package_load_events[0];

        // 2. Package name should be correctly captured
        prop_assert_eq!(
            event_package, &package,
            "Package name mismatch. Expected '{}', got '{}'. Code:\n{}",
            package, event_package, code
        );

        // 3. Library call inside function should have function_scope=Some(...)
        prop_assert!(
            event_function_scope.is_some(),
            "Library call inside function should have function_scope=Some(...), got None. Code:\n{}",
            code
        );

        let function_scope = event_function_scope.as_ref().unwrap();

        // 4. Function scope should start at line 0 (where the function definition starts)
        prop_assert_eq!(
            function_scope.start.line, 0,
            "Function scope should start at line 0. Got start line {}. Code:\n{}",
            function_scope.start.line, code
        );

        // 5. Function scope should end at the last line (where the closing brace is)
        let last_line = code.lines().count() as u32 - 1;
        prop_assert_eq!(
            function_scope.end.line, last_line,
            "Function scope should end at line {}. Got end line {}. Code:\n{}",
            last_line, function_scope.end.line, code
        );

        // 6. The library call line should be within the function scope
        prop_assert!(
            function_scope.contains(super::scope::Position::new(*event_line, 0)),
            "Library call at line {} should be within function scope ({}, {}) to ({}, {}). Code:\n{}",
            event_line,
            function_scope.start.line, function_scope.start.column,
            function_scope.end.line, function_scope.end.column,
            code
        );
    }

    /// Property 4 extended: Global library() calls should have function_scope=None
    /// **Validates: Requirements 2.4, 2.5**
    #[test]
    fn prop_global_library_call_no_function_scope(
        package in pkg_name(),
        func in library_func(),
        quote_style in pkg_quote_style(),
    ) {
        let uri = make_url("test_global_pkg");

        // Global library call (not inside any function)
        let code = generate_library_call(func, &package, quote_style);

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Extract PackageLoad events
        let package_load_events: Vec<_> = artifacts.timeline.iter()
            .filter_map(|e| {
                if let ScopeEvent::PackageLoad { function_scope, package: pkg, .. } = e {
                    Some((pkg.clone(), *function_scope))
                } else {
                    None
                }
            })
            .collect();

        prop_assert_eq!(package_load_events.len(), 1);
        let (pkg, function_scope) = &package_load_events[0];

        prop_assert_eq!(pkg, &package);
        prop_assert!(
            function_scope.is_none(),
            "Global library() call should have function_scope=None, got {:?}. Code:\n{}",
            function_scope, code
        );
    }

    /// Property 4 extended: Nested functions should capture innermost function scope
    /// **Validates: Requirements 2.4, 2.5**
    #[test]
    fn prop_nested_function_innermost_scope(
        package in pkg_name(),
        outer_func in r_identifier(),
        inner_func in r_identifier(),
    ) {
        // Ensure function names are distinct
        prop_assume!(outer_func != inner_func);

        let uri = make_url("test_nested_pkg");

        // Code with library() call inside nested function
        let code = format!(
            "{} <- function() {{\n    {} <- function() {{\n        library({})\n    }}\n}}",
            outer_func, inner_func, package
        );

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Extract PackageLoad events
        let package_load_events: Vec<_> = artifacts.timeline.iter()
            .filter_map(|e| {
                if let ScopeEvent::PackageLoad { line, function_scope, package: pkg, .. } = e {
                    Some((*line, pkg.clone(), *function_scope))
                } else {
                    None
                }
            })
            .collect();

        prop_assert_eq!(
            package_load_events.len(), 1,
            "Expected exactly one PackageLoad event. Code:\n{}", code
        );

        let (event_line, event_package, event_function_scope) = &package_load_events[0];

        prop_assert_eq!(event_package, &package);

        // Should have function_scope (inside nested function)
        prop_assert!(
            event_function_scope.is_some(),
            "Library call in nested function should have function_scope. Code:\n{}",
            code
        );

        let function_scope = event_function_scope.as_ref().unwrap();

        // The function scope should be the INNER function (line 1 to line 3)
        // Outer function: lines 0-4
        // Inner function: lines 1-3
        prop_assert_eq!(
            function_scope.start.line, 1,
            "Function scope should start at inner function (line 1). Got {}. Code:\n{}",
            function_scope.start.line, code
        );

        prop_assert_eq!(
            function_scope.end.line, 3,
            "Function scope should end at inner function closing brace (line 3). Got {}. Code:\n{}",
            function_scope.end.line, code
        );

        // Library call is on line 2, which should be within the inner function scope
        prop_assert_eq!(
            *event_line, 2,
            "Library call should be on line 2. Got {}. Code:\n{}",
            event_line, code
        );

        prop_assert!(
            function_scope.contains(super::scope::Position::new(*event_line, 0)),
            "Library call should be within inner function scope. Code:\n{}",
            code
        );
    }

    /// Property 4 extended: Multiple library calls in different scopes
    /// **Validates: Requirements 2.4, 2.5**
    #[test]
    fn prop_multiple_library_calls_different_scopes(
        pkg_global in pkg_name(),
        pkg_func in pkg_name(),
        func_name in r_identifier(),
    ) {
        // Ensure packages are distinct
        prop_assume!(pkg_global != pkg_func);

        let uri = make_url("test_multi_scope_pkg");

        // Code with library() at global scope and inside a function
        let code = format!(
            "library({})\n{} <- function() {{\n    library({})\n}}",
            pkg_global, func_name, pkg_func
        );

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Extract PackageLoad events
        let package_load_events: Vec<_> = artifacts.timeline.iter()
            .filter_map(|e| {
                if let ScopeEvent::PackageLoad { line, package, function_scope, .. } = e {
                    Some((*line, package.clone(), *function_scope))
                } else {
                    None
                }
            })
            .collect();

        prop_assert_eq!(
            package_load_events.len(), 2,
            "Expected 2 PackageLoad events. Code:\n{}", code
        );

        // First event: global library call (line 0, no function scope)
        let (line0, pkg0, scope0) = &package_load_events[0];
        prop_assert_eq!(*line0, 0, "First library call should be on line 0");
        prop_assert_eq!(pkg0, &pkg_global, "First package should be {}", pkg_global);
        prop_assert!(
            scope0.is_none(),
            "Global library call should have function_scope=None. Code:\n{}",
            code
        );

        // Second event: function-scoped library call (line 2, with function scope)
        let (line2, pkg2, scope2) = &package_load_events[1];
        prop_assert_eq!(*line2, 2, "Second library call should be on line 2");
        prop_assert_eq!(pkg2, &pkg_func, "Second package should be {}", pkg_func);
        prop_assert!(
            scope2.is_some(),
            "Function library call should have function_scope=Some(...). Code:\n{}",
            code
        );

        // Verify the function scope boundaries
        let func_scope = scope2.as_ref().unwrap();
        prop_assert_eq!(
            func_scope.start.line, 1,
            "Function scope should start at line 1. Code:\n{}",
            code
        );
        prop_assert_eq!(
            func_scope.end.line, 3,
            "Function scope should end at line 3. Code:\n{}",
            code
        );
    }
}

// ============================================================================
// Property: Point Query Correctness (Interval Tree)
// Validates: Requirements 1.3, 1.4
// Feature: interval-tree-scope-lookup, Property 1: Point Query Correctness
// ============================================================================

use super::scope::{FunctionScopeInterval, FunctionScopeTree, Position};

/// Test helper: flatten an interval to a `(start_line, start_col, end_line, end_col)` tuple
/// for order-independent comparison in interval-tree property tests.
fn iv_tuple(i: &FunctionScopeInterval) -> (u32, u32, u32, u32) {
    (i.start.line, i.start.column, i.end.line, i.end.column)
}

/// Produces a strategy yielding valid intervals as (start_line, start_col, end_line, end_col)
/// where the end position is lexicographically greater than or equal to the start position.
///
/// # Examples
///
/// ```
/// use proptest::prelude::*;
///
/// proptest! {
///     |(iv in valid_interval())| {
///         let (sl, sc, el, ec) = iv;
///         assert!((el, ec) >= (sl, sc));
///     }
/// }
/// ```
fn valid_interval() -> impl Strategy<Value = (u32, u32, u32, u32)> {
    // Generate start position, then end position >= start
    (0..1000u32, 0..100u32).prop_flat_map(|(start_line, start_col)| {
        let end_line_range = start_line..1000u32;
        let end_col_range = if start_line == 1000u32 - 1 {
            start_col..100u32
        } else {
            0..100u32
        };
        (end_line_range, end_col_range).prop_map(move |(end_line, end_col)| {
            let end_col = if end_line == start_line {
                end_col.max(start_col)
            } else {
                end_col
            };
            (start_line, start_col, end_line, end_col)
        })
    })
}

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: interval-tree-scope-lookup, Property 1: Point Query Correctness
    /// **Validates: Requirements 1.3, 1.4**
    ///
    /// For any set of function scope intervals and for any query position,
    /// the point query SHALL return exactly those intervals that contain the position—
    /// no false positives (intervals that don't contain the point) and no false negatives
    /// (missing intervals that do contain the point).
    #[test]
    fn prop_point_query_correctness(
        intervals in prop::collection::vec(valid_interval(), 0..50),
        query_line in 0..1000u32,
        query_col in 0..100u32,
    ) {
        // Build tree from generated intervals
        let tree = FunctionScopeTree::from_scopes(&intervals);
        let query_pos = Position::new(query_line, query_col);

        // Query tree for all intervals containing the point
        let tree_results = tree.query_point(query_pos);

        // Brute force: find all intervals containing the point
        let brute_force: Vec<FunctionScopeInterval> = intervals
            .iter()
            .filter_map(|&(sl, sc, el, ec)| {
                let interval = FunctionScopeInterval::from_tuple((sl, sc, el, ec));
                // Only include valid intervals (start <= end)
                if interval.start <= interval.end && interval.contains(query_pos) {
                    Some(interval)
                } else {
                    None
                }
            })
            .collect();

        // Verify no false positives: all returned intervals must contain the point
        for interval in &tree_results {
            prop_assert!(
                interval.contains(query_pos),
                "False positive: interval ({}, {}) - ({}, {}) does not contain point ({}, {})",
                interval.start.line,
                interval.start.column,
                interval.end.line,
                interval.end.column,
                query_line,
                query_col
            );
        }

        // Verify no false negatives: same count as brute force
        prop_assert_eq!(
            tree_results.len(),
            brute_force.len(),
            "Missing intervals: tree returned {} but brute force found {}",
            tree_results.len(),
            brute_force.len()
        );

        // Verify the actual intervals match (not just count)
        // Sort both for comparison since order may differ
        let mut tree_sorted: Vec<_> = tree_results.iter().map(iv_tuple).collect();
        let mut brute_sorted: Vec<_> = brute_force.iter().map(iv_tuple).collect();
        tree_sorted.sort();
        brute_sorted.sort();
        prop_assert_eq!(
            tree_sorted,
            brute_sorted,
            "Interval sets differ between tree and brute force"
        );
    }

    /// Feature: interval-tree-scope-lookup, Property 1: Point Query Correctness (Empty Tree)
    /// **Validates: Requirements 1.6**
    ///
    /// An empty tree should return an empty result for any query.
    #[test]
    fn prop_point_query_empty_tree(
        query_line in 0..1000u32,
        query_col in 0..100u32,
    ) {
        let tree = FunctionScopeTree::new();
        let query_pos = Position::new(query_line, query_col);

        let results = tree.query_point(query_pos);

        prop_assert!(
            results.is_empty(),
            "Empty tree should return empty results, got {} intervals",
            results.len()
        );
    }

    /// Feature: interval-tree-scope-lookup, Property 1: Point Query Correctness (Boundary Positions)
    /// **Validates: Requirements 1.3, 4.2**
    ///
    /// Positions exactly at interval boundaries should be included (inclusive boundaries).
    #[test]
    fn prop_point_query_boundary_positions(
        intervals in prop::collection::vec(valid_interval(), 1..20),
    ) {
        let tree = FunctionScopeTree::from_scopes(&intervals);

        // For each valid interval, test that start and end positions are included
        for &(sl, sc, el, ec) in &intervals {
            let interval = FunctionScopeInterval::from_tuple((sl, sc, el, ec));
            // Skip invalid intervals
            if interval.start > interval.end {
                continue;
            }

            // Query at start position
            let start_results = tree.query_point(interval.start);
            prop_assert!(
                start_results.contains(&interval),
                "Interval ({}, {}) - ({}, {}) should contain its start position ({}, {})",
                sl, sc, el, ec, sl, sc
            );

            // Query at end position
            let end_results = tree.query_point(interval.end);
            prop_assert!(
                end_results.contains(&interval),
                "Interval ({}, {}) - ({}, {}) should contain its end position ({}, {})",
                sl, sc, el, ec, el, ec
            );
        }
    }
}

// ============================================================================
// Property 2: Innermost Selection Correctness (Interval Tree)
// Validates: Requirements 2.1, 2.2
// Feature: interval-tree-scope-lookup, Property 2: Innermost Selection Correctness
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: interval-tree-scope-lookup, Property 2: Innermost Selection Correctness
    /// **Validates: Requirements 2.1, 2.2**
    ///
    /// For any set of function scope intervals and for any query position,
    /// the innermost query SHALL return the interval with the lexicographically largest
    /// start position among all intervals containing the query point, or None if no
    /// intervals contain the point.
    #[test]
    fn prop_innermost_selection_correctness(
        intervals in prop::collection::vec(valid_interval(), 0..50),
        query_line in 0..1000u32,
        query_col in 0..100u32,
    ) {
        let tree = FunctionScopeTree::from_scopes(&intervals);
        let query_pos = Position::new(query_line, query_col);

        // Query tree for innermost
        let tree_result = tree.query_innermost(query_pos);

        // Brute force: find all containing intervals, then select max by start
        let containing: Vec<_> = intervals.iter()
            .filter_map(|&(sl, sc, el, ec)| {
                let interval = FunctionScopeInterval::from_tuple((sl, sc, el, ec));
                if interval.start <= interval.end && interval.contains(query_pos) {
                    Some(interval)
                } else {
                    None
                }
            })
            .collect();

        let brute_force_result = containing.into_iter()
            .max_by_key(|interval| interval.start);

        // Verify results match
        match (tree_result, brute_force_result) {
            (None, None) => { /* Both found nothing - correct */ }
            (Some(tree_interval), Some(brute_interval)) => {
                prop_assert_eq!(
                    (tree_interval.start.line, tree_interval.start.column),
                    (brute_interval.start.line, brute_interval.start.column),
                    "Innermost mismatch: tree start ({}, {}) vs brute start ({}, {})",
                    tree_interval.start.line, tree_interval.start.column,
                    brute_interval.start.line, brute_interval.start.column
                );
            }
            (Some(tree_interval), None) => {
                prop_assert!(
                    false,
                    "Tree returned interval ({}, {}) - ({}, {}) but brute force found nothing",
                    tree_interval.start.line, tree_interval.start.column,
                    tree_interval.end.line, tree_interval.end.column
                );
            }
            (None, Some(brute_interval)) => {
                prop_assert!(
                    false,
                    "Tree returned nothing but brute force found ({}, {}) - ({}, {})",
                    brute_interval.start.line, brute_interval.start.column,
                    brute_interval.end.line, brute_interval.end.column
                );
            }
        }
    }

    /// Feature: interval-tree-scope-lookup, Property 2: Innermost Selection Correctness (Empty Tree)
    /// **Validates: Requirements 2.2**
    ///
    /// An empty tree should return None for any innermost query.
    #[test]
    fn prop_innermost_selection_empty_tree(
        query_line in 0..1000u32,
        query_col in 0..100u32,
    ) {
        let tree = FunctionScopeTree::new();
        let query_pos = Position::new(query_line, query_col);

        let result = tree.query_innermost(query_pos);

        prop_assert!(
            result.is_none(),
            "Empty tree should return None for innermost query, got {:?}",
            result
        );
    }

    /// Feature: interval-tree-scope-lookup, Property 2: Innermost Selection Correctness (Nested Intervals)
    /// **Validates: Requirements 2.1**
    ///
    /// For nested intervals, the innermost (latest start) should be selected.
    #[test]
    fn prop_innermost_selection_nested(
        // Generate a base interval
        base_start_line in 0..500u32,
        base_start_col in 0..50u32,
        base_end_line in 500..1000u32,
        base_end_col in 50..100u32,
        // Generate a nested interval inside the base
        nest_offset_start_line in 1..100u32,
        nest_offset_start_col in 1..20u32,
        nest_offset_end_line in 1..100u32,
        nest_offset_end_col in 1..20u32,
    ) {
        // Create base interval
        let base = (base_start_line, base_start_col, base_end_line, base_end_col);

        // Create nested interval strictly inside base
        let nested_start_line = base_start_line + nest_offset_start_line;
        let nested_start_col = base_start_col + nest_offset_start_col;
        let nested_end_line = base_end_line.saturating_sub(nest_offset_end_line);
        let nested_end_col = base_end_col.saturating_sub(nest_offset_end_col);

        // Ensure nested is valid (start <= end)
        prop_assume!(
            (nested_start_line, nested_start_col) <= (nested_end_line, nested_end_col)
        );

        let nested = (nested_start_line, nested_start_col, nested_end_line, nested_end_col);

        let intervals = vec![base, nested];
        let tree = FunctionScopeTree::from_scopes(&intervals);

        // Query at a point guaranteed to be inside the nested interval.
        // Using the start position avoids cases where the midpoint is outside
        // the interval (e.g., when start/end are on different lines and end_col < start_col).
        let query_pos = Position::new(nested_start_line, nested_start_col);

        let result = tree.query_innermost(query_pos);

        // The nested interval has a later start, so it should be selected
        prop_assert!(result.is_some(), "Should find an interval containing the query point");
        let result = result.unwrap();

        // The result should be the nested interval (later start)
        prop_assert_eq!(
            iv_tuple(&result),
            nested,
            "Should select nested interval (later start) as innermost"
        );
    }

    /// Feature: interval-tree-scope-lookup, Property 2: Innermost Selection Correctness (Point Outside)
    /// **Validates: Requirements 2.2**
    ///
    /// When the query point is outside all intervals, None should be returned.
    #[test]
    fn prop_innermost_selection_point_outside(
        intervals in prop::collection::vec(valid_interval(), 1..20),
    ) {
        let tree = FunctionScopeTree::from_scopes(&intervals);

        // Find a point guaranteed to be outside all intervals
        // Use a line beyond all interval end lines
        let max_end_line = intervals.iter()
            .map(|&(_, _, el, _)| el)
            .max()
            .unwrap_or(0);

        let query_pos = Position::new(max_end_line + 100, 0);

        let result = tree.query_innermost(query_pos);

        prop_assert!(
            result.is_none(),
            "Point outside all intervals should return None, got {:?}",
            result
        );
    }
}

// ============================================================================
// Property 3: Backward Compatibility (Model-Based)
// Validates: Requirements 3.4
// Feature: interval-tree-scope-lookup, Property 3: Backward Compatibility
// ============================================================================

/// Return all intervals that contain a given position using a linear scan.
///
/// Scopes are tuples of the form `(start_line, start_col, end_line, end_col)`.
/// Only intervals where the start is less than or equal to the end are considered,
/// and an interval is included only if `start <= (line, column) <= end`.
///
/// # Returns
///
/// A `Vec` of the intervals from `scopes` that contain the specified position,
/// preserving their original order.
///
/// # Examples
///
/// ```
/// let scopes = vec![ (1, 0, 3, 10), (2, 0, 2, 5), (4, 0, 5, 0) ];
/// let containing = linear_scan_containing(&scopes, 2, 3);
/// assert_eq!(containing, vec![ (1, 0, 3, 10), (2, 0, 2, 5) ]);
/// ```
fn linear_scan_containing(
    scopes: &[(u32, u32, u32, u32)],
    line: u32,
    column: u32,
) -> Vec<(u32, u32, u32, u32)> {
    scopes
        .iter()
        .filter(|(sl, sc, el, ec)| {
            // Only include valid intervals (start <= end)
            (*sl, *sc) <= (*el, *ec)
                // Check containment: start <= point <= end
                && (*sl, *sc) <= (line, column)
                && (line, column) <= (*el, *ec)
        })
        .copied()
        .collect()
}

/// Finds the start position (line, column) of the containing interval with the greatest start.
///
/// Scans `scopes` for intervals that contain the point `(line, column)` and returns the start
/// `(line, column)` pair of the interval whose start is maximal (lexicographic by line then column).
///
/// # Returns
///
/// `Some((start_line, start_column))` if at least one interval contains the point, `None` otherwise.
///
/// # Examples
///
/// ```
/// let scopes = vec![
///     (1, 0, 3, 5), // start (1,0) .. end (3,5)
///     (2, 0, 2, 10), // start (2,0) .. end (2,10)
/// ];
/// assert_eq!(find_max_start_position(&scopes, 2, 3), Some((2, 0)));
/// assert_eq!(find_max_start_position(&scopes, 4, 0), None);
/// ```
fn find_max_start_position(
    scopes: &[(u32, u32, u32, u32)],
    line: u32,
    column: u32,
) -> Option<(u32, u32)> {
    scopes
        .iter()
        .filter(|(sl, sc, el, ec)| {
            // Only include valid intervals (start <= end)
            (*sl, *sc) <= (*el, *ec)
                // Check containment: start <= point <= end
                && (*sl, *sc) <= (line, column)
                && (line, column) <= (*el, *ec)
        })
        .map(|(sl, sc, _, _)| (*sl, *sc))
        .max()
}

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: interval-tree-scope-lookup, Property 3: Backward Compatibility
    /// **Validates: Requirements 3.4**
    ///
    /// For any valid function scopes and any position, the interval tree SHALL produce
    /// identical results to the original linear scan implementation.
    ///
    /// This is a model-based property test where the "model" is the simple linear scan
    /// implementation that was replaced by the interval tree.
    #[test]
    fn prop_backward_compatibility(
        scopes in prop::collection::vec(valid_interval(), 0..100),
        queries in prop::collection::vec((0..1000u32, 0..100u32), 1..20),
    ) {
        let tree = FunctionScopeTree::from_scopes(&scopes);

        for (line, column) in queries {
            // Compare query_point results
            let tree_containing: Vec<_> = tree
                .query_point(Position::new(line, column))
                .into_iter()
                .map(|i| iv_tuple(&i))
                .collect();
            let linear_containing = linear_scan_containing(&scopes, line, column);

            // Sort both for comparison since order may differ
            let mut tree_sorted = tree_containing.clone();
            let mut linear_sorted = linear_containing.clone();
            tree_sorted.sort();
            linear_sorted.sort();

            prop_assert_eq!(
                &tree_sorted,
                &linear_sorted,
                "query_point mismatch at ({}, {}): tree returned {:?}, linear scan returned {:?}",
                line,
                column,
                &tree_sorted,
                &linear_sorted
            );

            // Compare query_innermost results
            // When multiple intervals have the same maximum start position, either one is valid.
            // We verify that the tree returns an interval with the correct maximum start position.
            let tree_innermost = tree
                .query_innermost(Position::new(line, column))
                .map(|i| iv_tuple(&i));
            let max_start = find_max_start_position(&scopes, line, column);

            match (tree_innermost, max_start) {
                (None, None) => { /* Both found nothing - correct */ }
                (Some((sl, sc, _, _)), Some((expected_sl, expected_sc))) => {
                    prop_assert_eq!(
                        (sl, sc),
                        (expected_sl, expected_sc),
                        "query_innermost returned interval with wrong start position at ({}, {}): got ({}, {}), expected ({}, {})",
                        line,
                        column,
                        sl,
                        sc,
                        expected_sl,
                        expected_sc
                    );
                }
                (Some(interval), None) => {
                    prop_assert!(
                        false,
                        "Tree returned interval {:?} but no intervals contain point ({}, {})",
                        interval,
                        line,
                        column
                    );
                }
                (None, Some(start)) => {
                    prop_assert!(
                        false,
                        "Tree returned nothing but intervals with start {:?} contain point ({}, {})",
                        start,
                        line,
                        column
                    );
                }
            }
        }
    }

    /// Feature: interval-tree-scope-lookup, Property 3: Backward Compatibility (Edge Cases)
    /// **Validates: Requirements 3.4**
    ///
    /// Test backward compatibility with edge case scenarios:
    /// - Empty scopes
    /// - Single scope
    /// - Deeply nested scopes
    /// - Overlapping but non-nested scopes
    #[test]
    fn prop_backward_compatibility_edge_cases(
        // Generate a mix of nested and non-nested intervals
        base_intervals in prop::collection::vec(valid_interval(), 0..20),
        // Generate additional nested intervals
        nested_count in 0..10usize,
        query_line in 0..1000u32,
        query_col in 0..100u32,
    ) {
        // Create some nested intervals by shrinking existing ones
        let mut all_scopes = base_intervals.clone();
        for &(sl, sc, el, ec) in base_intervals
            .iter()
            .take(nested_count.min(base_intervals.len()))
        {
            // Create a nested interval if possible
            if sl + 1 < el || (sl + 1 == el && sc + 1 < ec) {
                let nested = (
                    sl + 1,
                    sc.saturating_add(1).min(99),
                    el.saturating_sub(1).max(sl + 1),
                    ec.saturating_sub(1),
                );
                // Only add if valid
                if (nested.0, nested.1) <= (nested.2, nested.3) {
                    all_scopes.push(nested);
                }
            }
        }

        let tree = FunctionScopeTree::from_scopes(&all_scopes);

        // Compare query_point results
        let tree_containing: Vec<_> = tree
            .query_point(Position::new(query_line, query_col))
            .into_iter()
            .map(|i| iv_tuple(&i))
            .collect();
        let linear_containing = linear_scan_containing(&all_scopes, query_line, query_col);

        let mut tree_sorted = tree_containing.clone();
        let mut linear_sorted = linear_containing.clone();
        tree_sorted.sort();
        linear_sorted.sort();

        prop_assert_eq!(
            tree_sorted,
            linear_sorted,
            "query_point mismatch with nested intervals at ({}, {})",
            query_line,
            query_col
        );

        // Compare query_innermost results
        // When multiple intervals have the same maximum start position, either one is valid.
        let tree_innermost = tree
            .query_innermost(Position::new(query_line, query_col))
            .map(|i| iv_tuple(&i));
        let max_start = find_max_start_position(&all_scopes, query_line, query_col);

        match (tree_innermost, max_start) {
            (None, None) => { /* Both found nothing - correct */ }
            (Some((tsl, tsc, _, _)), Some((expected_sl, expected_sc))) => {
                prop_assert_eq!(
                    (tsl, tsc),
                    (expected_sl, expected_sc),
                    "query_innermost returned interval with wrong start position at ({}, {})",
                    query_line,
                    query_col
                );
            }
            (Some(interval), None) => {
                prop_assert!(
                    false,
                    "Tree returned interval {:?} but no intervals contain point ({}, {})",
                    interval,
                    query_line,
                    query_col
                );
            }
            (None, Some(start)) => {
                prop_assert!(
                    false,
                    "Tree returned nothing but intervals with start {:?} contain point ({}, {})",
                    start,
                    query_line,
                    query_col
                );
            }
        }
    }

    /// Feature: interval-tree-scope-lookup, Property 3: Backward Compatibility (Boundary Queries)
    /// **Validates: Requirements 3.4**
    ///
    /// Test backward compatibility specifically at interval boundaries.
    #[test]
    fn prop_backward_compatibility_boundaries(
        scopes in prop::collection::vec(valid_interval(), 1..50),
    ) {
        let tree = FunctionScopeTree::from_scopes(&scopes);

        // Test at each interval's start and end positions
        for &(sl, sc, el, ec) in &scopes {
            // Skip invalid intervals
            if (sl, sc) > (el, ec) {
                continue;
            }

            // Test at start position
            let tree_at_start: Vec<_> = tree
                .query_point(Position::new(sl, sc))
                .into_iter()
                .map(|i| iv_tuple(&i))
                .collect();
            let linear_at_start = linear_scan_containing(&scopes, sl, sc);

            let mut tree_sorted = tree_at_start.clone();
            let mut linear_sorted = linear_at_start.clone();
            tree_sorted.sort();
            linear_sorted.sort();

            prop_assert_eq!(
                tree_sorted,
                linear_sorted,
                "query_point mismatch at start boundary ({}, {})",
                sl,
                sc
            );

            // Test at end position
            let tree_at_end: Vec<_> = tree
                .query_point(Position::new(el, ec))
                .into_iter()
                .map(|i| iv_tuple(&i))
                .collect();
            let linear_at_end = linear_scan_containing(&scopes, el, ec);

            let mut tree_sorted = tree_at_end.clone();
            let mut linear_sorted = linear_at_end.clone();
            tree_sorted.sort();
            linear_sorted.sort();

            prop_assert_eq!(
                tree_sorted,
                linear_sorted,
                "query_point mismatch at end boundary ({}, {})",
                el,
                ec
            );

            // Test innermost at start
            // When multiple intervals have the same maximum start position, either one is valid.
            let tree_innermost_start = tree
                .query_innermost(Position::new(sl, sc))
                .map(|i| iv_tuple(&i));
            let max_start_at_start = find_max_start_position(&scopes, sl, sc);

            match (tree_innermost_start, max_start_at_start) {
                (None, None) => { /* Both found nothing - correct */ }
                (Some((tsl, tsc, _, _)), Some((expected_sl, expected_sc))) => {
                    prop_assert_eq!(
                        (tsl, tsc),
                        (expected_sl, expected_sc),
                        "query_innermost returned interval with wrong start position at start boundary ({}, {})",
                        sl,
                        sc
                    );
                }
                (Some(interval), None) => {
                    prop_assert!(
                        false,
                        "Tree returned interval {:?} but no intervals contain start boundary ({}, {})",
                        interval,
                        sl,
                        sc
                    );
                }
                (None, Some(start)) => {
                    prop_assert!(
                        false,
                        "Tree returned nothing but intervals with start {:?} contain start boundary ({}, {})",
                        start,
                        sl,
                        sc
                    );
                }
            }

            // Test innermost at end
            let tree_innermost_end = tree
                .query_innermost(Position::new(el, ec))
                .map(|i| iv_tuple(&i));
            let max_start_at_end = find_max_start_position(&scopes, el, ec);

            match (tree_innermost_end, max_start_at_end) {
                (None, None) => { /* Both found nothing - correct */ }
                (Some((tsl, tsc, _, _)), Some((expected_sl, expected_sc))) => {
                    prop_assert_eq!(
                        (tsl, tsc),
                        (expected_sl, expected_sc),
                        "query_innermost returned interval with wrong start position at end boundary ({}, {})",
                        el,
                        ec
                    );
                }
                (Some(interval), None) => {
                    prop_assert!(
                        false,
                        "Tree returned interval {:?} but no intervals contain end boundary ({}, {})",
                        interval,
                        el,
                        ec
                    );
                }
                (None, Some(start)) => {
                    prop_assert!(
                        false,
                        "Tree returned nothing but intervals with start {:?} contain end boundary ({}, {})",
                        start,
                        el,
                        ec
                    );
                }
            }
        }
    }
}

// ============================================================================
// Property 4: Position Lexicographic Ordering
// Validates: Requirements 4.1
// Feature: interval-tree-scope-lookup, Property 4: Position Lexicographic Ordering
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: interval-tree-scope-lookup, Property 4: Position Lexicographic Ordering
    /// **Validates: Requirements 4.1**
    ///
    /// For any two positions (line1, col1) and (line2, col2), the Position comparison
    /// SHALL follow lexicographic ordering: (line1, col1) < (line2, col2) if and only if
    /// line1 < line2, or (line1 == line2 and col1 < col2).
    #[test]
    fn prop_position_lexicographic_ordering(
        line1 in 0..u32::MAX,
        col1 in 0..u32::MAX,
        line2 in 0..u32::MAX,
        col2 in 0..u32::MAX,
    ) {
        let pos1 = Position::new(line1, col1);
        let pos2 = Position::new(line2, col2);

        // Expected lexicographic comparison
        let expected_less = line1 < line2 || (line1 == line2 && col1 < col2);
        let expected_equal = line1 == line2 && col1 == col2;
        let expected_greater = line1 > line2 || (line1 == line2 && col1 > col2);

        // Verify Ord implementation matches
        prop_assert_eq!(pos1 < pos2, expected_less,
            "Less-than mismatch: ({}, {}) < ({}, {}) should be {}",
            line1, col1, line2, col2, expected_less);
        prop_assert_eq!(pos1 == pos2, expected_equal,
            "Equality mismatch: ({}, {}) == ({}, {}) should be {}",
            line1, col1, line2, col2, expected_equal);
        prop_assert_eq!(pos1 > pos2, expected_greater,
            "Greater-than mismatch: ({}, {}) > ({}, {}) should be {}",
            line1, col1, line2, col2, expected_greater);

        // Verify totality: exactly one of <, ==, > is true
        prop_assert!(
            (pos1 < pos2) as u8 + (pos1 == pos2) as u8 + (pos1 > pos2) as u8 == 1,
            "Totality violated for ({}, {}) vs ({}, {})",
            line1, col1, line2, col2
        );
    }

    /// Feature: interval-tree-scope-lookup, Property 4: Position Lexicographic Ordering (Transitivity)
    /// **Validates: Requirements 4.1**
    ///
    /// For any three positions a, b, c: if a < b and b < c, then a < c.
    #[test]
    fn prop_position_ordering_transitivity(
        line1 in 0..1000u32,
        col1 in 0..100u32,
        line2 in 0..1000u32,
        col2 in 0..100u32,
        line3 in 0..1000u32,
        col3 in 0..100u32,
    ) {
        let pos1 = Position::new(line1, col1);
        let pos2 = Position::new(line2, col2);
        let pos3 = Position::new(line3, col3);

        // If pos1 < pos2 and pos2 < pos3, then pos1 < pos3
        if pos1 < pos2 && pos2 < pos3 {
            prop_assert!(pos1 < pos3,
                "Transitivity violated: ({}, {}) < ({}, {}) < ({}, {}) but not ({}, {}) < ({}, {})",
                line1, col1, line2, col2, line3, col3, line1, col1, line3, col3);
        }

        // Also test transitivity for <=
        if pos1 <= pos2 && pos2 <= pos3 {
            prop_assert!(pos1 <= pos3,
                "Transitivity violated for <=: ({}, {}) <= ({}, {}) <= ({}, {}) but not ({}, {}) <= ({}, {})",
                line1, col1, line2, col2, line3, col3, line1, col1, line3, col3);
        }
    }

    /// Feature: interval-tree-scope-lookup, Property 4: Position Lexicographic Ordering (Antisymmetry)
    /// **Validates: Requirements 4.1**
    ///
    /// For any two positions a, b: if a < b, then NOT (b < a).
    /// Also: if a <= b and b <= a, then a == b.
    #[test]
    #[allow(clippy::nonminimal_bool)] // assert on the negated operator directly to exercise it
    fn prop_position_ordering_antisymmetry(
        line1 in 0..u32::MAX,
        col1 in 0..u32::MAX,
        line2 in 0..u32::MAX,
        col2 in 0..u32::MAX,
    ) {
        let pos1 = Position::new(line1, col1);
        let pos2 = Position::new(line2, col2);

        // If pos1 < pos2, then NOT (pos2 < pos1)
        if pos1 < pos2 {
            prop_assert!(!(pos2 < pos1),
                "Antisymmetry violated: ({}, {}) < ({}, {}) but also ({}, {}) < ({}, {})",
                line1, col1, line2, col2, line2, col2, line1, col1);
        }

        // If pos1 <= pos2 and pos2 <= pos1, then pos1 == pos2
        if pos1 <= pos2 && pos2 <= pos1 {
            prop_assert_eq!(pos1, pos2,
                "Antisymmetry violated for <=: ({}, {}) <= ({}, {}) and ({}, {}) <= ({}, {}) but not equal",
                line1, col1, line2, col2, line2, col2, line1, col1);
        }
    }

    /// Feature: interval-tree-scope-lookup, Property 4: Position Lexicographic Ordering (Reflexivity)
    /// **Validates: Requirements 4.1**
    ///
    /// For any position a: a == a and a <= a and NOT (a < a).
    #[test]
    #[allow(clippy::nonminimal_bool)] // assert on the negated operator directly to exercise it
    fn prop_position_ordering_reflexivity(
        line in 0..u32::MAX,
        col in 0..u32::MAX,
    ) {
        let pos = Position::new(line, col);

        // Reflexivity: a == a
        prop_assert_eq!(pos, pos,
            "Reflexivity violated: ({}, {}) != ({}, {})",
            line, col, line, col);

        // a <= a
        prop_assert!(pos <= pos,
            "Reflexivity violated for <=: ({}, {}) not <= ({}, {})",
            line, col, line, col);

        // NOT (a < a)
        prop_assert!(!(pos < pos),
            "Irreflexivity violated: ({}, {}) < ({}, {})",
            line, col, line, col);
    }

    /// Feature: interval-tree-scope-lookup, Property 4: Position Lexicographic Ordering (Consistency)
    ///
    /// The Ord implementation should be consistent with PartialOrd and Eq.
    /// Specifically: (a == b) implies (a.cmp(&b) == Ordering::Equal)
    /// and (a < b) implies (a.cmp(&b) == Ordering::Less)
    #[test]
    #[allow(clippy::nonminimal_bool)] // assert on the negated operator directly to exercise it
    fn prop_position_ordering_consistency(
        line1 in 0..u32::MAX,
        col1 in 0..u32::MAX,
        line2 in 0..u32::MAX,
        col2 in 0..u32::MAX,
    ) {
        use std::cmp::Ordering;

        let pos1 = Position::new(line1, col1);
        let pos2 = Position::new(line2, col2);

        let cmp_result = pos1.cmp(&pos2);

        // Consistency between cmp and comparison operators
        match cmp_result {
            Ordering::Less => {
                prop_assert!(pos1 < pos2,
                    "Consistency violated: cmp returned Less but ({}, {}) not < ({}, {})",
                    line1, col1, line2, col2);
                prop_assert!(!(pos1 == pos2),
                    "Consistency violated: cmp returned Less but ({}, {}) == ({}, {})",
                    line1, col1, line2, col2);
                prop_assert!(!(pos1 > pos2),
                    "Consistency violated: cmp returned Less but ({}, {}) > ({}, {})",
                    line1, col1, line2, col2);
            }
            Ordering::Equal => {
                prop_assert!(pos1 == pos2,
                    "Consistency violated: cmp returned Equal but ({}, {}) != ({}, {})",
                    line1, col1, line2, col2);
                prop_assert!(!(pos1 < pos2),
                    "Consistency violated: cmp returned Equal but ({}, {}) < ({}, {})",
                    line1, col1, line2, col2);
                prop_assert!(!(pos1 > pos2),
                    "Consistency violated: cmp returned Equal but ({}, {}) > ({}, {})",
                    line1, col1, line2, col2);
            }
            Ordering::Greater => {
                prop_assert!(pos1 > pos2,
                    "Consistency violated: cmp returned Greater but ({}, {}) not > ({}, {})",
                    line1, col1, line2, col2);
                prop_assert!(!(pos1 == pos2),
                    "Consistency violated: cmp returned Greater but ({}, {}) == ({}, {})",
                    line1, col1, line2, col2);
                prop_assert!(!(pos1 < pos2),
                    "Consistency violated: cmp returned Greater but ({}, {}) < ({}, {})",
                    line1, col1, line2, col2);
            }
        }
    }
}

// ============================================================================
// Property 10: Base Package Universal Availability
// Feature: package-function-awareness
// **Validates: Requirements 6.2, 6.3, 6.4**
//
// For any R source file and any position within that file, exports from base
// packages (base, methods, utils, grDevices, graphics, stats, datasets) SHALL
// be available in scope.
//
// This test verifies that:
// - Base exports are available at the very beginning of a file (position 0, 0)
// - Base exports are available at any random position within the file
// - Base exports are available even when no library() calls exist
// - Base exports are available before any library() calls
// - Base exports are available inside function scopes
// - Base exports are available at the end of the file
// ============================================================================

use super::scope::scope_at_position_with_packages;

/// Generate a random R code structure for testing base package availability
fn r_code_structure() -> impl Strategy<Value = RCodeStructure> {
    (
        // Number of top-level statements (0-5)
        0..6usize,
        // Whether to include a function definition
        any::<bool>(),
        // Whether to include library calls
        any::<bool>(),
        // Number of library calls (0-3)
        0..4usize,
    )
        .prop_flat_map(
            |(num_statements, include_function, include_library, num_library_calls)| {
                let statements = prop::collection::vec(r_identifier(), num_statements);
                let func_name = r_identifier();
                let func_body_statements = prop::collection::vec(r_identifier(), 0..3usize);
                let library_packages = prop::collection::vec(pkg_name(), num_library_calls);

                (
                    Just(include_function),
                    Just(include_library),
                    statements,
                    func_name,
                    func_body_statements,
                    library_packages,
                )
            },
        )
        .prop_map(
            |(
                include_function,
                include_library,
                statements,
                func_name,
                func_body_statements,
                library_packages,
            )| {
                RCodeStructure {
                    include_function,
                    include_library,
                    statements,
                    func_name,
                    func_body_statements,
                    library_packages,
                }
            },
        )
}

/// Structure representing generated R code for testing
#[derive(Debug, Clone)]
struct RCodeStructure {
    include_function: bool,
    include_library: bool,
    statements: Vec<String>,
    func_name: String,
    func_body_statements: Vec<String>,
    library_packages: Vec<String>,
}

impl RCodeStructure {
    /// Generate the R code string from this structure
    fn to_code(&self) -> String {
        let mut lines = Vec::new();

        // Add some initial statements
        for (i, stmt) in self.statements.iter().enumerate() {
            lines.push(format!("{} <- {}", stmt, i));
        }

        // Optionally add library calls
        if self.include_library {
            for pkg in &self.library_packages {
                lines.push(format!("library({})", pkg));
            }
        }

        // Optionally add a function definition
        if self.include_function {
            let mut func_lines = vec![format!("{} <- function() {{", self.func_name)];
            for (i, stmt) in self.func_body_statements.iter().enumerate() {
                func_lines.push(format!("    {} <- {}", stmt, i + 100));
            }
            func_lines.push("}".to_string());
            lines.extend(func_lines);
        }

        // Add a final statement
        lines.push("final_result <- 42".to_string());

        lines.join("\n")
    }

    /// Get the total number of lines in the generated code
    fn line_count(&self) -> u32 {
        self.to_code().lines().count() as u32
    }
}

/// Generate a set of base exports for testing
fn base_exports_set() -> HashSet<String> {
    // Representative exports from base packages
    // These are common functions from base, methods, utils, grDevices, graphics, stats, datasets
    let exports = vec![
        // base package
        "print",
        "cat",
        "sum",
        "mean",
        "length",
        "c",
        "list",
        "data.frame",
        "paste",
        "paste0",
        "sprintf",
        "format",
        "as.character",
        "as.numeric",
        "is.null",
        "is.na",
        "is.numeric",
        "is.character",
        "is.logical",
        "if",
        "for",
        "while",
        "function",
        "return",
        "stop",
        "warning",
        "message",
        "tryCatch",
        "try",
        "invisible",
        "suppressWarnings",
        "suppressMessages",
        // utils package
        "head",
        "tail",
        "str",
        "help",
        "example",
        "install.packages",
        // stats package
        "lm",
        "glm",
        "t.test",
        "cor",
        "var",
        "sd",
        "median",
        "quantile",
        // grDevices package
        "pdf",
        "png",
        "jpeg",
        "dev.off",
        "rgb",
        "col2rgb",
        // graphics package
        "plot",
        "lines",
        "points",
        "abline",
        "hist",
        "barplot",
        "boxplot",
        // methods package
        "setClass",
        "setMethod",
        "setGeneric",
        "new",
        "show",
        // datasets package (common datasets)
        "iris",
        "mtcars",
        "airquality",
        "faithful",
    ];
    exports.into_iter().map(String::from).collect()
}

/// Generate a set of base exports that are unlikely to be shadowed by generated variable names.
/// The r_identifier() generator produces names matching [a-z][a-z0-9_]{0,5}, so we use
/// exports with dots, uppercase letters, or longer names that won't match.
fn base_exports_set_unlikely_shadowed() -> HashSet<String> {
    let exports = vec![
        // Names with dots (can't be generated by r_identifier)
        "data.frame",
        "as.character",
        "as.numeric",
        "is.null",
        "is.na",
        "is.numeric",
        "is.character",
        "is.logical",
        "paste0",
        "dev.off",
        "col2rgb",
        "t.test",
        "install.packages",
        // Names with uppercase (can't be generated by r_identifier)
        "TRUE",
        "FALSE",
        "NULL",
        "NA",
        "NaN",
        "Inf",
        // Longer names (> 6 chars, unlikely to match [a-z][a-z0-9_]{0,5})
        "suppressWarnings",
        "suppressMessages",
        "tryCatch",
        "invisible",
        "setClass",
        "setMethod",
        "setGeneric",
        "quantile",
        "airquality",
        "faithful",
        "barplot",
        "boxplot",
        "abline",
        "sprintf",
        "message",
        "warning",
        "example",
        "install",
        "median",
        "format",
        "length",
        "function",
        "return",
    ];
    exports.into_iter().map(String::from).collect()
}

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: package-function-awareness, Property 10: Base Package Universal Availability
    /// **Validates: Requirements 6.2, 6.3, 6.4**
    ///
    /// For any R source file and any position within that file, exports from base
    /// packages SHALL be available in scope without requiring explicit library() calls,
    /// UNLESS they are shadowed by local definitions.
    ///
    /// This test verifies that base exports are present in scope (either from base
    /// or from a local definition that shadows them).
    #[test]
    fn prop_base_package_availability(
        code_structure in r_code_structure(),
        query_line_offset in 0..10u32,
        query_column in 0..50u32,
    ) {
        let uri = make_url("test_base_pkg_availability");
        let code = code_structure.to_code();
        let line_count = code_structure.line_count();

        // Ensure query position is within the file
        let query_line = query_line_offset % line_count.max(1);

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Create a mock package exports callback (returns empty for all packages)
        let get_exports = |_pkg: &str| -> HashSet<String> {
            HashSet::new()
        };

        // Create base exports set - use exports that are unlikely to be shadowed
        // by generated variable names (which use r_identifier() pattern [a-z][a-z0-9_]{0,5})
        let base_exports = base_exports_set_unlikely_shadowed();

        // Query scope at the generated position
        let scope = scope_at_position_with_packages(&artifacts, query_line, query_column, &get_exports, &base_exports, false);

        // Verify that base exports are available at this position
        // (either from base package or shadowed by local definition)
        for export in &base_exports {
            prop_assert!(
                scope.symbols.contains_key(export.as_str()),
                "Base export '{}' should be available at position ({}, {}) in code:\n{}",
                export, query_line, query_column, code
            );

            // Verify the symbol has the correct package:base URI
            // (since we use exports unlikely to be shadowed)
            let symbol = scope.symbols.get(export.as_str()).unwrap();
            prop_assert_eq!(
                symbol.source_uri.as_str(), "package:base",
                "Base export '{}' should have package:base URI, got '{}'. Code:\n{}",
                export, symbol.source_uri.as_str(), code
            );
        }
    }

    /// Feature: package-function-awareness, Property 10 extended: Base exports at file start
    /// **Validates: Requirements 6.3, 6.4**
    ///
    /// Base exports SHALL be available at the very beginning of any file (position 0, 0).
    #[test]
    fn prop_base_package_available_at_file_start(
        code_structure in r_code_structure(),
    ) {
        let uri = make_url("test_base_pkg_start");
        let code = code_structure.to_code();

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        let get_exports = |_pkg: &str| -> HashSet<String> {
            HashSet::new()
        };
        let base_exports = base_exports_set();

        // Query at the very start of the file
        let scope = scope_at_position_with_packages(&artifacts, 0, 0, &get_exports, &base_exports, false);

        // All base exports should be available
        for export in &base_exports {
            prop_assert!(
                scope.symbols.contains_key(export.as_str()),
                "Base export '{}' should be available at file start (0, 0). Code:\n{}",
                export, code
            );
        }
    }

    /// Feature: package-function-awareness, Property 10 extended: Base exports at file end
    /// **Validates: Requirements 6.3, 6.4**
    ///
    /// Base exports SHALL be available at the end of any file.
    #[test]
    fn prop_base_package_available_at_file_end(
        code_structure in r_code_structure(),
    ) {
        let uri = make_url("test_base_pkg_end");
        let code = code_structure.to_code();
        let last_line = code.lines().count().saturating_sub(1) as u32;
        let last_line_len = code.lines().last().map(|l| l.len()).unwrap_or(0) as u32;

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        let get_exports = |_pkg: &str| -> HashSet<String> {
            HashSet::new()
        };
        let base_exports = base_exports_set();

        // Query at the end of the file
        let scope = scope_at_position_with_packages(&artifacts, last_line, last_line_len, &get_exports, &base_exports, false);

        // All base exports should be available
        for export in &base_exports {
            prop_assert!(
                scope.symbols.contains_key(export.as_str()),
                "Base export '{}' should be available at file end ({}, {}). Code:\n{}",
                export, last_line, last_line_len, code
            );
        }
    }

    /// Feature: package-function-awareness, Property 10 extended: Base exports inside functions
    /// **Validates: Requirements 6.3, 6.4**
    ///
    /// Base exports SHALL be available inside function scopes.
    #[test]
    fn prop_base_package_available_inside_function(
        func_name in r_identifier(),
        body_statements in prop::collection::vec(r_identifier(), 1..4usize),
    ) {
        let uri = make_url("test_base_pkg_func");

        // Create code with a function
        let mut func_body = Vec::new();
        for (i, stmt) in body_statements.iter().enumerate() {
            func_body.push(format!("    {} <- {}", stmt, i));
        }
        let code = format!(
            "{} <- function() {{\n{}\n}}",
            func_name,
            func_body.join("\n")
        );

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        let get_exports = |_pkg: &str| -> HashSet<String> {
            HashSet::new()
        };
        let base_exports = base_exports_set();

        // Query inside the function body (line 1, which is inside the function)
        let scope = scope_at_position_with_packages(&artifacts, 1, 10, &get_exports, &base_exports, false);

        // All base exports should be available inside the function
        for export in &base_exports {
            prop_assert!(
                scope.symbols.contains_key(export.as_str()),
                "Base export '{}' should be available inside function. Code:\n{}",
                export, code
            );
        }
    }

    /// Feature: package-function-awareness, Property 10 extended: Base exports before library calls
    /// **Validates: Requirements 6.3, 6.4**
    ///
    /// Base exports SHALL be available even before any library() calls in the file.
    #[test]
    fn prop_base_package_available_before_library_calls(
        pkg in pkg_name(),
        statements_before in prop::collection::vec(r_identifier(), 1..4usize),
    ) {
        let uri = make_url("test_base_pkg_before_lib");

        // Create code with statements before a library call
        let mut lines = Vec::new();
        for (i, stmt) in statements_before.iter().enumerate() {
            lines.push(format!("{} <- {}", stmt, i));
        }
        lines.push(format!("library({})", pkg));
        lines.push("final <- 1".to_string());
        let code = lines.join("\n");

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        let get_exports = |_pkg: &str| -> HashSet<String> {
            HashSet::new()
        };
        let base_exports = base_exports_set();

        // Query at line 0 (before the library call)
        let scope = scope_at_position_with_packages(&artifacts, 0, 5, &get_exports, &base_exports, false);

        // All base exports should be available before library()
        for export in &base_exports {
            prop_assert!(
                scope.symbols.contains_key(export.as_str()),
                "Base export '{}' should be available before library() call. Code:\n{}",
                export, code
            );
        }
    }

    /// Feature: package-function-awareness, Property 10 extended: Base exports not overridden by empty packages
    /// **Validates: Requirements 6.3, 6.4**
    ///
    /// Base exports SHALL remain available even when library() calls load packages
    /// that don't export the same symbols.
    #[test]
    fn prop_base_package_not_overridden_by_empty_packages(
        pkg in pkg_name(),
    ) {
        let uri = make_url("test_base_pkg_not_overridden");

        let code = format!("library({})\nx <- print(1)", pkg);

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Package exports callback returns empty (package has no exports)
        let get_exports = |_pkg: &str| -> HashSet<String> {
            HashSet::new()
        };
        let base_exports = base_exports_set();

        // Query after the library call
        let scope = scope_at_position_with_packages(&artifacts, 1, 10, &get_exports, &base_exports, false);

        // Base exports should still be available
        for export in &base_exports {
            prop_assert!(
                scope.symbols.contains_key(export.as_str()),
                "Base export '{}' should still be available after loading package '{}'. Code:\n{}",
                export, pkg, code
            );
        }
    }

    /// Feature: package-function-awareness, Property 10 extended: Package exports override base exports
    /// **Validates: Requirements 6.3, 6.4**
    ///
    /// When a loaded package exports a symbol with the same name as a base export,
    /// the package export SHALL take precedence (override the base export).
    #[test]
    fn prop_package_export_overrides_base_export(
        pkg in pkg_name(),
    ) {
        let uri = make_url("test_pkg_overrides_base");

        let code = format!("library({})\nx <- print(1)", pkg);

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Package exports callback returns "print" (same as base export)
        let get_exports = |p: &str| -> HashSet<String> {
            if p == pkg {
                let mut exports = HashSet::new();
                exports.insert("print".to_string());
                exports
            } else {
                HashSet::new()
            }
        };

        let mut base_exports = HashSet::new();
        base_exports.insert("print".to_string());
        base_exports.insert("cat".to_string());

        // Query after the library call
        let scope = scope_at_position_with_packages(&artifacts, 1, 10, &get_exports, &base_exports, false);

        // "print" should be from the loaded package, not base
        let print_symbol = scope.symbols.get("print").unwrap();
        prop_assert_eq!(
            print_symbol.source_uri.as_str(), &format!("package:{}", pkg),
            "print should be from package '{}' after library() call, not base. Code:\n{}",
            pkg, code
        );

        // "cat" should still be from base (not exported by the package)
        let cat_symbol = scope.symbols.get("cat").unwrap();
        prop_assert_eq!(
            cat_symbol.source_uri.as_str(), "package:base",
            "cat should still be from base. Code:\n{}",
            code
        );
    }
}

// ============================================================================
// Feature: package-function-awareness, Property 8: Cross-File Package Propagation
// **Validates: Requirements 5.1, 5.2, 5.3**
//
// For any parent file that loads package P before a source() call to child file C,
// scope resolution in C SHALL include exports from P.
//
// This test verifies that:
// - Packages loaded BEFORE source() call are propagated to child files
// - Packages loaded AFTER source() call are NOT propagated to child files
// - Multiple packages loaded before source() are all propagated
// - Package propagation respects call-site positions
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: package-function-awareness, Property 8: Cross-File Package Propagation
    /// **Validates: Requirements 5.1, 5.2, 5.3**
    ///
    /// For any parent file that loads package P before a source() call to child file C,
    /// scope resolution in C SHALL include exports from P in inherited_packages.
    ///
    /// Test pattern:
    /// ```r
    /// # parent.R
    /// library(dplyr)      # Line 0
    /// source("child.R")   # Line 1
    /// ```
    /// Child file should have "dplyr" in inherited_packages.
    #[test]
    fn prop_cross_file_package_propagation_basic(
        package in pkg_name(),
        func in library_func(),
    ) {
        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: library call at line 0, source() at line 1
        let parent_code = format!("{}({})\nsource(\"child.R\")", func, package);
        let parent_tree = parse_r_tree(&parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, &parent_code);

        // Child code: simple assignment
        let child_code = "x <- 1";
        let child_tree = parse_r_tree(child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, child_code);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta = make_meta_with_sources(vec![("child.R", 1)]);
        graph.update_file(&parent_uri, &parent_meta, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta.clone())) }
            else { None }
        };

        // Query child's scope at position (0, 0)
        let scope = scope_at_position_with_graph(
            &child_uri, 0, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Auto,
            &|| false,
            None,
            None,
        );

        // Child should have inherited the package from parent
        prop_assert!(
            scope.inherited_packages.contains(&package),
            "Child should inherit package '{}' from parent. Got inherited_packages: {:?}. Parent code:\n{}",
            package, scope.inherited_packages, parent_code
        );
    }

    /// Feature: package-function-awareness, Property 8: Cross-File Package Propagation
    /// **Validates: Requirements 5.1, 5.2, 5.3**
    ///
    /// Packages loaded AFTER source() call should NOT be propagated to child files.
    ///
    /// Test pattern:
    /// ```r
    /// # parent.R
    /// source("child.R")   # Line 0
    /// library(dplyr)      # Line 1
    /// ```
    /// Child file should NOT have "dplyr" in inherited_packages.
    #[test]
    fn prop_cross_file_package_propagation_after_source_not_propagated(
        package in pkg_name(),
        func in library_func(),
    ) {
        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: source() at line 0, library call at line 1
        let parent_code = format!("source(\"child.R\")\n{}({})", func, package);
        let parent_tree = parse_r_tree(&parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, &parent_code);

        // Child code: simple assignment
        let child_code = "x <- 1";
        let child_tree = parse_r_tree(child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, child_code);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta = make_meta_with_sources(vec![("child.R", 0)]);
        graph.update_file(&parent_uri, &parent_meta, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta.clone())) }
            else { None }
        };

        // Query child's scope at position (0, 0)
        let scope = scope_at_position_with_graph(
            &child_uri, 0, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );

        // Child should NOT have the package (loaded after source() call)
        prop_assert!(
            !scope.inherited_packages.contains(&package),
            "Child should NOT inherit package '{}' (loaded after source() call). Got inherited_packages: {:?}. Parent code:\n{}",
            package, scope.inherited_packages, parent_code
        );
    }

    /// Feature: package-function-awareness, Property 8: Cross-File Package Propagation
    /// **Validates: Requirements 5.1, 5.2, 5.3**
    ///
    /// Multiple packages loaded before source() should all be propagated.
    ///
    /// Test pattern:
    /// ```r
    /// # parent.R
    /// library(pkg1)       # Line 0
    /// library(pkg2)       # Line 1
    /// source("child.R")   # Line 2
    /// ```
    /// Child file should have both "pkg1" and "pkg2" in inherited_packages.
    #[test]
    fn prop_cross_file_package_propagation_multiple_packages(
        pkg1 in pkg_name(),
        pkg2 in pkg_name(),
    ) {
        // Ensure packages are distinct
        prop_assume!(pkg1 != pkg2);

        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: two library calls before source()
        let parent_code = format!("library({})\nlibrary({})\nsource(\"child.R\")", pkg1, pkg2);
        let parent_tree = parse_r_tree(&parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, &parent_code);

        // Child code: simple assignment
        let child_code = "x <- 1";
        let child_tree = parse_r_tree(child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, child_code);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta = make_meta_with_sources(vec![("child.R", 2)]);
        graph.update_file(&parent_uri, &parent_meta, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta.clone())) }
            else { None }
        };

        // Query child's scope at position (0, 0)
        let scope = scope_at_position_with_graph(
            &child_uri, 0, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Auto,
            &|| false,
            None,
            None,
        );

        // Child should have inherited both packages from parent
        prop_assert!(
            scope.inherited_packages.contains(&pkg1),
            "Child should inherit package '{}' from parent. Got inherited_packages: {:?}. Parent code:\n{}",
            pkg1, scope.inherited_packages, parent_code
        );
        prop_assert!(
            scope.inherited_packages.contains(&pkg2),
            "Child should inherit package '{}' from parent. Got inherited_packages: {:?}. Parent code:\n{}",
            pkg2, scope.inherited_packages, parent_code
        );
    }

    /// Feature: package-function-awareness, Property 8: Cross-File Package Propagation
    /// **Validates: Requirements 5.1, 5.2, 5.3**
    ///
    /// Only packages loaded BEFORE source() should be propagated, not those loaded after.
    ///
    /// Test pattern:
    /// ```r
    /// # parent.R
    /// library(pkg_before) # Line 0
    /// source("child.R")   # Line 1
    /// library(pkg_after)  # Line 2
    /// ```
    /// Child file should have "pkg_before" but NOT "pkg_after" in inherited_packages.
    #[test]
    fn prop_cross_file_package_propagation_respects_call_site(
        pkg_before in pkg_name(),
        pkg_after in pkg_name(),
    ) {
        // Ensure packages are distinct
        prop_assume!(pkg_before != pkg_after);

        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: library before source(), library after source()
        let parent_code = format!(
            "library({})\nsource(\"child.R\")\nlibrary({})",
            pkg_before, pkg_after
        );
        let parent_tree = parse_r_tree(&parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, &parent_code);

        // Child code: simple assignment
        let child_code = "x <- 1";
        let child_tree = parse_r_tree(child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, child_code);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta = make_meta_with_sources(vec![("child.R", 1)]);
        graph.update_file(&parent_uri, &parent_meta, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta.clone())) }
            else { None }
        };

        // Query child's scope at position (0, 0)
        let scope = scope_at_position_with_graph(
            &child_uri, 0, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Auto,
            &|| false,
            None,
            None,
        );

        // Child should have inherited pkg_before (loaded before source())
        prop_assert!(
            scope.inherited_packages.contains(&pkg_before),
            "Child should inherit package '{}' (loaded before source()). Got inherited_packages: {:?}. Parent code:\n{}",
            pkg_before, scope.inherited_packages, parent_code
        );

        // Child should NOT have pkg_after (loaded after source())
        prop_assert!(
            !scope.inherited_packages.contains(&pkg_after),
            "Child should NOT inherit package '{}' (loaded after source()). Got inherited_packages: {:?}. Parent code:\n{}",
            pkg_after, scope.inherited_packages, parent_code
        );
    }

    /// Feature: package-function-awareness, Property 8: Cross-File Package Propagation
    /// **Validates: Requirements 5.1, 5.2, 5.3**
    ///
    /// Function-scoped package loads should NOT be propagated to child files
    /// (unless the source() call is within the same function scope).
    ///
    /// Test pattern:
    /// ```r
    /// # parent.R
    /// f <- function() {
    ///     library(dplyr)
    /// }
    /// source("child.R")
    /// ```
    /// Child file should NOT have "dplyr" in inherited_packages.
    #[test]
    fn prop_cross_file_package_propagation_function_scoped_not_propagated(
        package in pkg_name(),
        func_name in r_identifier(),
    ) {
        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: library inside function, source() outside
        let parent_code = format!(
            "{} <- function() {{\n    library({})\n}}\nsource(\"child.R\")",
            func_name, package
        );
        let parent_tree = parse_r_tree(&parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, &parent_code);

        // Child code: simple assignment
        let child_code = "x <- 1";
        let child_tree = parse_r_tree(child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, child_code);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta = make_meta_with_sources(vec![("child.R", 3)]);
        graph.update_file(&parent_uri, &parent_meta, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta.clone())) }
            else { None }
        };

        // Query child's scope at position (0, 0)
        let scope = scope_at_position_with_graph(
            &child_uri, 0, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );

        // Child should NOT have the package (it's function-scoped in parent)
        prop_assert!(
            !scope.inherited_packages.contains(&package),
            "Child should NOT inherit function-scoped package '{}'. Got inherited_packages: {:?}. Parent code:\n{}",
            package, scope.inherited_packages, parent_code
        );
    }

    /// Feature: package-function-awareness, Property 8: Cross-File Package Propagation
    /// **Validates: Requirements 5.1, 5.2, 5.3**
    ///
    /// Packages should propagate through multiple levels of source() chains.
    ///
    /// Test pattern:
    /// ```r
    /// # grandparent.R
    /// library(dplyr)
    /// source("parent.R")
    ///
    /// # parent.R
    /// source("child.R")
    ///
    /// # child.R
    /// x <- 1
    /// ```
    /// Child file should have "dplyr" in inherited_packages (propagated through parent).
    #[test]
    fn prop_cross_file_package_propagation_transitive(
        package in pkg_name(),
    ) {
        let grandparent_uri = make_url("grandparent");
        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Grandparent code: library call, then source parent
        let grandparent_code = format!("library({})\nsource(\"parent.R\")", package);
        let grandparent_tree = parse_r_tree(&grandparent_code);
        let grandparent_artifacts = compute_artifacts(&grandparent_uri, &grandparent_tree, &grandparent_code);

        // Parent code: source child
        let parent_code = "source(\"child.R\")";
        let parent_tree = parse_r_tree(parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, parent_code);

        // Child code: simple assignment
        let child_code = "x <- 1";
        let child_tree = parse_r_tree(child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, child_code);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let grandparent_meta = make_meta_with_sources(vec![("parent.R", 1)]);
        let parent_meta = make_meta_with_sources(vec![("child.R", 0)]);
        graph.update_file(&grandparent_uri, &grandparent_meta, Some(&workspace_root), |_| None);
        graph.update_file(&parent_uri, &parent_meta, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let grandparent_artifacts = Arc::new(grandparent_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &grandparent_uri { Some(Arc::clone(&grandparent_artifacts)) }
            else if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &grandparent_uri { Some(std::sync::Arc::new(grandparent_meta.clone())) }
            else if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta.clone())) }
            else { None }
        };

        // Query child's scope at position (0, 0)
        let scope = scope_at_position_with_graph(
            &child_uri, 0, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Auto,
            &|| false,
            None,
            None,
        );

        // Child should have inherited the package from grandparent (through parent)
        prop_assert!(
            scope.inherited_packages.contains(&package),
            "Child should inherit package '{}' from grandparent (transitive). Got inherited_packages: {:?}. Grandparent code:\n{}",
            package, scope.inherited_packages, grandparent_code
        );
    }

    /// Feature: package-function-awareness, Property 8: Cross-File Package Propagation
    /// **Validates: Requirements 5.1, 5.2, 5.3**
    ///
    /// Packages inherited from parent should be available at any position in child file.
    #[test]
    fn prop_cross_file_package_propagation_available_at_any_position(
        package in pkg_name(),
        query_line in 0..10u32,
    ) {
        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: library call at line 0, source() at line 1
        let parent_code = format!("library({})\nsource(\"child.R\")", package);
        let parent_tree = parse_r_tree(&parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, &parent_code);

        // Child code: multiple lines
        let child_code = "x <- 1\ny <- 2\nz <- 3\na <- 4\nb <- 5\nc <- 6\nd <- 7\ne <- 8\nf <- 9\ng <- 10";
        let child_tree = parse_r_tree(child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, child_code);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta = make_meta_with_sources(vec![("child.R", 1)]);
        graph.update_file(&parent_uri, &parent_meta, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta.clone())) }
            else { None }
        };

        // Query child's scope at various positions
        let scope = scope_at_position_with_graph(
            &child_uri, query_line, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Auto,
            &|| false,
            None,
            None,
        );

        // Child should have inherited the package at any position
        prop_assert!(
            scope.inherited_packages.contains(&package),
            "Child should inherit package '{}' at line {}. Got inherited_packages: {:?}. Parent code:\n{}",
            package, query_line, scope.inherited_packages, parent_code
        );
    }
}

// ============================================================================
// Feature: package-function-awareness, Property 9: Package Propagation via source()
//
// For any child file C that loads package P, scope resolution in the parent file
// SHALL include P after the source() call.
//
// This test verifies that:
// - Packages loaded in child files appear in parent's loaded_packages after source()
// - Packages loaded in deeply nested files propagate back through the chain
// - Symbols and packages both propagate from sourced files to parent
// - Parent's packages propagate forward to child (via inherited_packages), and child's packages propagate back (via loaded_packages)
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: package-function-awareness, Property 9: Package Propagation via source()
    ///
    /// For any child file C that loads package P, scope resolution in the parent file
    /// SHALL include exports from P in loaded_packages after source().
    ///
    /// Test pattern:
    /// ```r
    /// # parent.R
    /// source("child.R")   # Line 0
    /// x <- 1              # Line 1
    ///
    /// # child.R
    /// library(dplyr)      # Line 0
    /// ```
    /// Parent file should have "dplyr" in loaded_packages after the source() call.
    #[test]
    fn prop_package_propagation_basic(
        package in pkg_name(),
        func in library_func(),
    ) {
        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: source() at line 0, then some code
        let parent_code = "source(\"child.R\")\nx <- 1";
        let parent_tree = parse_r_tree(parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, parent_code);

        // Child code: library call
        let child_code = format!("{}({})\ny <- 2", func, package);
        let child_tree = parse_r_tree(&child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, &child_code);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta = make_meta_with_sources(vec![("child.R", 0)]);
        graph.update_file(&parent_uri, &parent_meta, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta.clone())) }
            else { None }
        };

        // Query parent's scope AFTER the source() call
        let scope = scope_at_position_with_graph(
            &parent_uri, 1, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );

        // Parent should have the package (loaded in child, available after source())
        // Packages from sourced files go into loaded_packages, not inherited_packages
        prop_assert!(
            scope.loaded_packages.contains(&package),
            "Parent should have package '{}' from child (via loaded_packages). Got loaded_packages: {:?}. Child code:\n{}",
            package, scope.loaded_packages, child_code
        );
    }

    /// Feature: package-function-awareness, Property 9: Package Propagation via source()
    ///
    /// Packages loaded in deeply nested files should propagate back through the chain.
    ///
    /// Test pattern:
    /// ```r
    /// # grandparent.R
    /// source("parent.R")
    ///
    /// # parent.R
    /// source("child.R")
    ///
    /// # child.R
    /// library(stringr)
    /// ```
    /// Both grandparent and parent should have the package in loaded_packages.
    #[test]
    fn prop_package_propagation_deep_chain(
        package in pkg_name(),
    ) {
        let grandparent_uri = make_url("grandparent");
        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Grandparent code: source parent
        let grandparent_code = "source(\"parent.R\")\nz <- 1";
        let grandparent_tree = parse_r_tree(grandparent_code);
        let grandparent_artifacts = compute_artifacts(&grandparent_uri, &grandparent_tree, grandparent_code);

        // Parent code: source child
        let parent_code = "source(\"child.R\")\ny <- 1";
        let parent_tree = parse_r_tree(parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, parent_code);

        // Child code: loads package
        let child_code = format!("library({})\nx <- 1", package);
        let child_tree = parse_r_tree(&child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, &child_code);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let grandparent_meta = make_meta_with_sources(vec![("parent.R", 0)]);
        let parent_meta = make_meta_with_sources(vec![("child.R", 0)]);
        graph.update_file(&grandparent_uri, &grandparent_meta, Some(&workspace_root), |_| None);
        graph.update_file(&parent_uri, &parent_meta, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let grandparent_artifacts = Arc::new(grandparent_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &grandparent_uri { Some(Arc::clone(&grandparent_artifacts)) }
            else if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &grandparent_uri { Some(std::sync::Arc::new(grandparent_meta.clone())) }
            else if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta.clone())) }
            else { None }
        };

        // Query grandparent's scope after source() call
        let grandparent_scope = scope_at_position_with_graph(
            &grandparent_uri, 1, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );

        // Grandparent should have the package (loaded in grandchild)
        // Packages from sourced files go into loaded_packages, not inherited_packages
        prop_assert!(
            grandparent_scope.loaded_packages.contains(&package),
            "Grandparent should have package '{}' from grandchild (via loaded_packages). Got loaded_packages: {:?}",
            package, grandparent_scope.loaded_packages
        );

        // Query parent's scope after source() call
        let parent_scope = scope_at_position_with_graph(
            &parent_uri, 1, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );

        // Parent should also have the package (loaded in child)
        // Packages from sourced files go into loaded_packages, not inherited_packages
        prop_assert!(
            parent_scope.loaded_packages.contains(&package),
            "Parent should have package '{}' from child (via loaded_packages). Got loaded_packages: {:?}",
            package, parent_scope.loaded_packages
        );
    }

    /// Feature: package-function-awareness, Property 9: Package Propagation via source()
    ///
    /// Symbols and packages from child files are merged into parent scope.
    ///
    /// Test pattern:
    /// ```r
    /// # parent.R
    /// source("child.R")
    /// y <- helper_func()
    ///
    /// # child.R
    /// library(ggplot2)
    /// helper_func <- function() { 1 }
    /// ```
    /// Parent should have "helper_func" symbol and "ggplot2" in loaded_packages.
    #[test]
    fn prop_package_propagation_symbols_and_packages(
        package in pkg_name(),
        func_name in r_identifier(),
    ) {
        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: source child, then use function from child
        let parent_code = format!("source(\"child.R\")\ny <- {}()", func_name);
        let parent_tree = parse_r_tree(&parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, &parent_code);

        // Child code: loads package and defines function
        let child_code = format!("library({})\n{} <- function() {{ 1 }}", package, func_name);
        let child_tree = parse_r_tree(&child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, &child_code);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta = make_meta_with_sources(vec![("child.R", 0)]);
        graph.update_file(&parent_uri, &parent_meta, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta.clone())) }
            else { None }
        };

        // Query parent's scope after source() call
        let scope = scope_at_position_with_graph(
            &parent_uri, 1, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );

        // Symbols from child SHOULD be available in parent
        prop_assert!(
            scope.symbols.contains_key(func_name.as_str()),
            "Parent should have '{}' symbol from child (symbols propagate). Got symbols: {:?}",
            func_name, scope.symbols.keys().collect::<Vec<_>>()
        );

        // Packages from child should be in parent's loaded_packages (not inherited_packages)
        prop_assert!(
            scope.loaded_packages.contains(&package),
            "Parent should have package '{}' from child (via loaded_packages). Got loaded_packages: {:?}",
            package, scope.loaded_packages
        );
    }

    /// Feature: package-function-awareness, Property 9: Package Propagation via source()
    ///
    /// Parent's packages propagate forward to child, and child's packages propagate back.
    ///
    /// Test pattern:
    /// ```r
    /// # parent.R
    /// library(dplyr)
    /// source("child.R")
    /// z <- 1
    ///
    /// # child.R
    /// library(ggplot2)
    /// x <- 1
    /// ```
    /// Child should have "dplyr" in inherited_packages.
    /// Parent should have "ggplot2" in loaded_packages.
    #[test]
    fn prop_package_propagation_asymmetric(
        parent_pkg in pkg_name(),
        child_pkg in pkg_name(),
    ) {
        // Ensure packages are distinct
        prop_assume!(parent_pkg != child_pkg);

        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: library call, then source child
        let parent_code = format!("library({})\nsource(\"child.R\")\nz <- 1", parent_pkg);
        let parent_tree = parse_r_tree(&parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, &parent_code);

        // Child code: loads different package
        let child_code = format!("library({})\nx <- 1", child_pkg);
        let child_tree = parse_r_tree(&child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, &child_code);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta = make_meta_with_sources(vec![("child.R", 1)]);
        graph.update_file(&parent_uri, &parent_meta, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta.clone())) }
            else { None }
        };

        // Query child's scope - should have parent's package
        let child_scope = scope_at_position_with_graph(
            &child_uri, 0, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Auto,
            &|| false,
            None,
            None,
        );

        // Child SHOULD have parent's package (forward propagation works)
        prop_assert!(
            child_scope.inherited_packages.contains(&parent_pkg),
            "Child should inherit package '{}' from parent (forward propagation). Got inherited_packages: {:?}",
            parent_pkg, child_scope.inherited_packages
        );

        // Query parent's scope after source() call
        let parent_scope = scope_at_position_with_graph(
            &parent_uri, 2, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Auto,
            &|| false,
            None,
            None,
        );

        // Parent should have child's package (propagated from child via loaded_packages)
        prop_assert!(
            parent_scope.loaded_packages.contains(&child_pkg),
            "Parent should have package '{}' from child (via loaded_packages). Got loaded_packages: {:?}",
            child_pkg, parent_scope.loaded_packages
        );
    }

    /// Feature: package-function-awareness, Property 9: Package Propagation via source()
    ///
    /// Packages loaded in child should appear in parent after the source() call.
    #[test]
    fn prop_package_propagation_any_parent_position(
        package in pkg_name(),
        query_line in 0..5u32,
    ) {
        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: source child at line 0, then multiple lines
        let parent_code = "source(\"child.R\")\na <- 1\nb <- 2\nc <- 3\nd <- 4\ne <- 5";
        let parent_tree = parse_r_tree(parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, parent_code);

        // Child code: loads package
        let child_code = format!("library({})\nx <- 1", package);
        let child_tree = parse_r_tree(&child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, &child_code);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta = make_meta_with_sources(vec![("child.R", 0)]);
        graph.update_file(&parent_uri, &parent_meta, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta.clone())) }
            else { None }
        };

        // Query parent's scope at various positions
        let scope = scope_at_position_with_graph(
            &parent_uri, query_line, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );

        // Packages from sourced files go into loaded_packages, not inherited_packages
        if query_line == 0 {
            prop_assert!(
                !scope.loaded_packages.contains(&package),
                "Parent should NOT have package '{}' at the source() line. Got loaded_packages: {:?}",
                package, scope.loaded_packages
            );
        } else {
            prop_assert!(
                scope.loaded_packages.contains(&package),
                "Parent should have package '{}' from child at line {} (via loaded_packages). Got loaded_packages: {:?}",
                package, query_line, scope.loaded_packages
            );
        }
    }

    /// Feature: package-function-awareness, Property 9: Package Propagation via source()
    ///
    /// Multiple packages loaded in child should all propagate to parent.
    #[test]
    fn prop_package_propagation_multiple_packages(
        pkg1 in pkg_name(),
        pkg2 in pkg_name(),
        pkg3 in pkg_name(),
    ) {
        // Ensure packages are distinct
        prop_assume!(pkg1 != pkg2 && pkg2 != pkg3 && pkg1 != pkg3);

        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: source child
        let parent_code = "source(\"child.R\")\nx <- 1";
        let parent_tree = parse_r_tree(parent_code);
        let parent_artifacts = compute_artifacts(&parent_uri, &parent_tree, parent_code);

        // Child code: loads multiple packages
        let child_code = format!("library({})\nlibrary({})\nlibrary({})\ny <- 1", pkg1, pkg2, pkg3);
        let child_tree = parse_r_tree(&child_code);
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, &child_code);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta = make_meta_with_sources(vec![("child.R", 0)]);
        graph.update_file(&parent_uri, &parent_meta, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta.clone())) }
            else { None }
        };

        // Query parent's scope after source() call
        let scope = scope_at_position_with_graph(
            &parent_uri, 1, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );

        // Parent should have all of the child's packages (via loaded_packages)
        prop_assert!(
            scope.loaded_packages.contains(&pkg1),
            "Parent should have package '{}' from child (via loaded_packages). Got loaded_packages: {:?}",
            pkg1, scope.loaded_packages
        );
        prop_assert!(
            scope.loaded_packages.contains(&pkg2),
            "Parent should have package '{}' from child (via loaded_packages). Got loaded_packages: {:?}",
            pkg2, scope.loaded_packages
        );
        prop_assert!(
            scope.loaded_packages.contains(&pkg3),
            "Parent should have package '{}' from child (via loaded_packages). Got loaded_packages: {:?}",
            pkg3, scope.loaded_packages
        );
    }
}

// ============================================================================
// Property 11: Package Export Diagnostic Suppression
// Feature: package-function-awareness
// **Validates: Requirements 8.1, 8.2**
//
// For any symbol S that is exported by a package P loaded before position X,
// the Diagnostic_Engine SHALL NOT emit an "undefined variable" warning for S
// at position X.
//
// This test verifies that:
// - Symbols from loaded packages are available in scope after the library() call
// - Symbols from loaded packages are NOT available before the library() call
// - The scope resolution correctly includes package exports at the usage position
// - Multiple packages can provide exports that suppress diagnostics
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: package-function-awareness, Property 11: Package Export Diagnostic Suppression
    /// **Validates: Requirements 8.1, 8.2**
    ///
    /// For any symbol S that is exported by a package P loaded before position X,
    /// the scope at position X SHALL contain S, which means the Diagnostic_Engine
    /// SHALL NOT emit an "undefined variable" warning for S at position X.
    ///
    /// This test verifies that package exports are available in scope after the
    /// library() call, which is the mechanism by which diagnostics are suppressed.
    #[test]
    fn prop_package_export_diagnostic_suppression(
        package in pkg_name(),
        func in library_func(),
        export_name in r_identifier(),
        lines_before in 0..3usize,
        lines_after in 1..4usize,
    ) {
        let uri = make_url("test_pkg_diag_suppression");

        // Build code with library call and usage of package export
        let mut code_lines = Vec::new();

        // Add filler lines before library call
        // Use prefix "filler_" to avoid collision with generated export_name
        for i in 0..lines_before {
            code_lines.push(format!("filler_{} <- {}", i, i));
        }

        // Add library call
        let library_line = lines_before;
        code_lines.push(format!("{}({})", func, package));

        // Add lines after library call, including usage of package export
        for i in 0..lines_after {
            if i == 0 {
                // Use the package export on the first line after library()
                code_lines.push(format!("result <- {}(1)", export_name));
            } else {
                code_lines.push(format!("y{} <- {}", i, i));
            }
        }

        let code = code_lines.join("\n");
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Create a package exports callback that returns the export_name for our package
        let pkg_clone = package.clone();
        let export_clone = export_name.clone();
        let get_exports = move |p: &str| -> HashSet<String> {
            if p == pkg_clone {
                let mut exports = HashSet::new();
                exports.insert(export_clone.clone());
                exports
            } else {
                HashSet::new()
            }
        };

        // Empty base exports (we're testing package exports, not base)
        let base_exports = HashSet::new();

        // Query scope at the usage position (line after library call)
        let usage_line = (library_line + 1) as u32;
        let scope = scope_at_position_with_packages(&artifacts, usage_line, 10, &get_exports, &base_exports, false);

        // Requirement 8.1, 8.2: The symbol should be in scope after the library() call
        // This means the Diagnostic_Engine would NOT emit an "undefined variable" warning
        prop_assert!(
            scope.symbols.contains_key(export_name.as_str()),
            "Package export '{}' from package '{}' should be in scope at line {} (after library() on line {}). \
             This means no 'undefined variable' warning would be emitted. Code:\n{}",
            export_name, package, usage_line, library_line, code
        );

        // Verify the symbol has the correct package URI
        let symbol = scope.symbols.get(export_name.as_str()).unwrap();
        let expected_uri = format!("package:{}", package);
        prop_assert_eq!(
            symbol.source_uri.as_str(), expected_uri.as_str(),
            "Package export '{}' should have URI '{}', got '{}'. Code:\n{}",
            export_name, expected_uri, symbol.source_uri.as_str(), code
        );
    }

    /// Feature: package-function-awareness, Property 11 extended: Multiple package exports
    /// **Validates: Requirements 8.1, 8.2**
    ///
    /// When multiple packages are loaded, exports from ALL loaded packages should
    /// be available in scope and suppress diagnostics.
    #[test]
    fn prop_package_export_diagnostic_suppression_multiple_packages(
        pkg1 in pkg_name(),
        pkg2 in pkg_name(),
        export1 in r_identifier(),
        export2 in r_identifier(),
    ) {
        // Ensure packages and exports are distinct
        prop_assume!(pkg1 != pkg2);
        prop_assume!(export1 != export2);

        let uri = make_url("test_multi_pkg_diag_suppression");

        // Code with two library calls and usage of both exports
        let code = format!(
            "library({})\nlibrary({})\nresult1 <- {}(1)\nresult2 <- {}(2)",
            pkg1, pkg2, export1, export2
        );

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Create a package exports callback
        let pkg1_clone = pkg1.clone();
        let pkg2_clone = pkg2.clone();
        let export1_clone = export1.clone();
        let export2_clone = export2.clone();
        let get_exports = move |p: &str| -> HashSet<String> {
            if p == pkg1_clone {
                let mut exports = HashSet::new();
                exports.insert(export1_clone.clone());
                exports
            } else if p == pkg2_clone {
                let mut exports = HashSet::new();
                exports.insert(export2_clone.clone());
                exports
            } else {
                HashSet::new()
            }
        };

        let base_exports = HashSet::new();

        // Query scope at line 2 (after both library calls)
        let scope = scope_at_position_with_packages(&artifacts, 2, 10, &get_exports, &base_exports, false);

        // Both exports should be in scope
        prop_assert!(
            scope.symbols.contains_key(export1.as_str()),
            "Export '{}' from package '{}' should be in scope. Code:\n{}",
            export1, pkg1, code
        );
        prop_assert!(
            scope.symbols.contains_key(export2.as_str()),
            "Export '{}' from package '{}' should be in scope. Code:\n{}",
            export2, pkg2, code
        );
    }

    /// Feature: package-function-awareness, Property 11 extended: Export NOT available before library()
    /// **Validates: Requirements 8.1, 8.2 (inverse)**
    ///
    /// Symbols from a package should NOT be in scope BEFORE the library() call.
    /// This verifies the position-aware nature of diagnostic suppression.
    #[test]
    fn prop_package_export_not_available_before_library(
        package in pkg_name(),
        export_name in r_identifier(),
        lines_before in 1..4usize,
    ) {
        let uri = make_url("test_pkg_export_before_lib");

        // Build code with usage BEFORE library call
        let mut code_lines = Vec::new();

        // Add lines before library call, including usage of package export
        for i in 0..lines_before {
            if i == 0 {
                // Use the package export on the first line (before library)
                code_lines.push(format!("result <- {}(1)", export_name));
            } else {
                code_lines.push(format!("x{} <- {}", i, i));
            }
        }

        // Add library call after the usage
        code_lines.push(format!("library({})", package));

        let code = code_lines.join("\n");
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Create a package exports callback
        let pkg_clone = package.clone();
        let export_clone = export_name.clone();
        let get_exports = move |p: &str| -> HashSet<String> {
            if p == pkg_clone {
                let mut exports = HashSet::new();
                exports.insert(export_clone.clone());
                exports
            } else {
                HashSet::new()
            }
        };

        let base_exports = HashSet::new();

        // Query scope at line 0 (before library call)
        let scope = scope_at_position_with_packages(&artifacts, 0, 10, &get_exports, &base_exports, false);

        // The export should NOT be in scope before the library() call
        // This means the Diagnostic_Engine WOULD emit an "undefined variable" warning
        prop_assert!(
            !scope.symbols.contains_key(export_name.as_str()),
            "Package export '{}' from package '{}' should NOT be in scope at line 0 (before library()). \
             This means an 'undefined variable' warning WOULD be emitted. Code:\n{}",
            export_name, package, code
        );
    }

    /// Feature: package-function-awareness, Property 11 extended: Function-scoped package exports
    /// **Validates: Requirements 8.1, 8.2, 2.4, 2.5**
    ///
    /// When a library() call is inside a function, its exports should only suppress
    /// diagnostics within that function scope, not outside.
    #[test]
    fn prop_package_export_diagnostic_suppression_function_scoped(
        package in pkg_name(),
        func_name in r_identifier(),
        export_name in r_identifier(),
    ) {
        // Ensure func_name and export_name are different to avoid shadowing
        // (the function definition would shadow the package export)
        prop_assume!(func_name != export_name);

        let uri = make_url("test_func_scoped_pkg_diag");

        // Code with library() inside a function
        let code = format!(
            "{} <- function() {{\n    library({})\n    result <- {}(1)\n}}\noutside <- {}(2)",
            func_name, package, export_name, export_name
        );

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Create a package exports callback
        let pkg_clone = package.clone();
        let export_clone = export_name.clone();
        let get_exports = move |p: &str| -> HashSet<String> {
            if p == pkg_clone {
                let mut exports = HashSet::new();
                exports.insert(export_clone.clone());
                exports
            } else {
                HashSet::new()
            }
        };

        let base_exports = HashSet::new();

        // Query scope inside the function (line 2, after library call inside function)
        let scope_inside = scope_at_position_with_packages(&artifacts, 2, 10, &get_exports, &base_exports, false);

        // Export should be in scope inside the function
        prop_assert!(
            scope_inside.symbols.contains_key(export_name.as_str()),
            "Package export '{}' should be in scope inside function after library(). Code:\n{}",
            export_name, code
        );

        // Query scope outside the function (line 4)
        let scope_outside = scope_at_position_with_packages(&artifacts, 4, 10, &get_exports, &base_exports, false);

        // Export should NOT be in scope outside the function
        // (function-scoped library() doesn't affect global scope)
        prop_assert!(
            !scope_outside.symbols.contains_key(export_name.as_str()),
            "Package export '{}' should NOT be in scope outside function (function-scoped library). Code:\n{}",
            export_name, code
        );
    }

    /// Feature: package-function-awareness, Property 11 extended: Local definition shadows package export
    /// **Validates: Requirements 8.1, 8.2**
    ///
    /// When a local definition shadows a package export, the local definition should
    /// take precedence in scope (and thus also suppress diagnostics).
    #[test]
    fn prop_package_export_shadowed_by_local_definition(
        package in pkg_name(),
        symbol_name in r_identifier(),
    ) {
        let uri = make_url("test_local_shadows_pkg");

        // Code with library() and local definition of same name
        let code = format!(
            "library({})\n{} <- function(x) x + 1\nresult <- {}(1)",
            package, symbol_name, symbol_name
        );

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Create a package exports callback
        let pkg_clone = package.clone();
        let symbol_clone = symbol_name.clone();
        let get_exports = move |p: &str| -> HashSet<String> {
            if p == pkg_clone {
                let mut exports = HashSet::new();
                exports.insert(symbol_clone.clone());
                exports
            } else {
                HashSet::new()
            }
        };

        let base_exports = HashSet::new();

        // Query scope at line 2 (after both library and local definition)
        let scope = scope_at_position_with_packages(&artifacts, 2, 10, &get_exports, &base_exports, false);

        // Symbol should be in scope (either from package or local definition)
        prop_assert!(
            scope.symbols.contains_key(symbol_name.as_str()),
            "Symbol '{}' should be in scope (from local definition or package). Code:\n{}",
            symbol_name, code
        );

        // The symbol should be from the local definition, not the package
        // (local definitions take precedence)
        let symbol = scope.symbols.get(symbol_name.as_str()).unwrap();
        prop_assert!(
            !symbol.source_uri.as_str().starts_with("package:"),
            "Symbol '{}' should be from local definition, not package. Got URI: '{}'. Code:\n{}",
            symbol_name, symbol.source_uri.as_str(), code
        );
    }

    /// Feature: package-function-awareness, Property 11 extended: Same export from multiple packages
    /// **Validates: Requirements 8.1, 8.2**
    ///
    /// When multiple packages export the same symbol, the last loaded package's
    /// export should mask earlier ones (matching R's search path behavior where
    /// later library() calls attach higher on the search path).
    #[test]
    fn prop_package_export_last_loaded_wins(
        pkg1 in pkg_name(),
        pkg2 in pkg_name(),
        export_name in r_identifier(),
    ) {
        // Ensure packages are distinct
        prop_assume!(pkg1 != pkg2);

        let uri = make_url("test_last_pkg_wins");

        // Code with two library calls, both packages export same symbol
        let code = format!(
            "library({})\nlibrary({})\nresult <- {}(1)",
            pkg1, pkg2, export_name
        );

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Create a package exports callback - both packages export the same symbol
        let pkg1_clone = pkg1.clone();
        let pkg2_clone = pkg2.clone();
        let export_clone = export_name.clone();
        let get_exports = move |p: &str| -> HashSet<String> {
            if p == pkg1_clone || p == pkg2_clone {
                let mut exports = HashSet::new();
                exports.insert(export_clone.clone());
                exports
            } else {
                HashSet::new()
            }
        };

        let base_exports = HashSet::new();

        // Query scope at line 2 (after both library calls)
        let scope = scope_at_position_with_packages(&artifacts, 2, 10, &get_exports, &base_exports, false);

        // Symbol should be in scope (diagnostics suppressed)
        prop_assert!(
            scope.symbols.contains_key(export_name.as_str()),
            "Export '{}' should be in scope (from either package). Code:\n{}",
            export_name, code
        );

        // The symbol should be from pkg2 (last loaded) since later library()
        // calls mask earlier ones, matching R's search path behavior
        let symbol = scope.symbols.get(export_name.as_str()).unwrap();
        let expected_uri = format!("package:{}", pkg2);
        prop_assert_eq!(
            symbol.source_uri.as_str(), expected_uri.as_str(),
            "Export '{}' should be from last loaded package '{}', got '{}'. Code:\n{}",
            export_name, pkg2, symbol.source_uri.as_str(), code
        );
    }
}

// ============================================================================
// Property 12: Pre-Load Diagnostic Emission
// Feature: package-function-awareness
// **Validates: Requirement 8.3**
//
// For any symbol S that is exported by a package P loaded at position X,
// the Diagnostic_Engine SHALL emit an "undefined variable" warning for S
// at any position before X.
//
// This test verifies that:
// - Symbols from packages are NOT available in scope BEFORE the library() call
// - The scope resolution correctly excludes package exports at positions before loading
// - This is the inverse of Property 11 - we verify diagnostics WOULD be emitted
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: package-function-awareness, Property 12: Pre-Load Diagnostic Emission
    /// **Validates: Requirement 8.3**
    ///
    /// For any symbol S that is exported by a package P loaded at position X,
    /// the scope at any position before X SHALL NOT contain S, which means the
    /// Diagnostic_Engine SHALL emit an "undefined variable" warning for S.
    ///
    /// This test verifies that package exports are NOT available in scope before
    /// the library() call, which means diagnostics WOULD be emitted.
    #[test]
    fn prop_pre_load_diagnostic_emission(
        package in pkg_name(),
        func in library_func(),
        export_name in r_identifier(),
        lines_before in 1..5usize,
        lines_after in 0..3usize,
    ) {
        let uri = make_url("test_pre_load_diag");

        // Build code with usage BEFORE library call
        let mut code_lines = Vec::new();

        // Add lines before library call, including usage of package export
        for i in 0..lines_before {
            if i == 0 {
                // Use the package export on the first line (before library)
                code_lines.push(format!("result <- {}(1)", export_name));
            } else {
                code_lines.push(format!("x{} <- {}", i, i));
            }
        }

        // Add library call after the usage
        let library_line = lines_before;
        code_lines.push(generate_library_call(func, &package, PkgQuoteStyle::None));

        // Add filler lines after library call
        for i in 0..lines_after {
            code_lines.push(format!("y{} <- {}", i, i));
        }

        let code = code_lines.join("\n");
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Create a package exports callback that returns the export_name for our package
        let pkg_clone = package.clone();
        let export_clone = export_name.clone();
        let get_exports = move |p: &str| -> HashSet<String> {
            if p == pkg_clone {
                let mut exports = HashSet::new();
                exports.insert(export_clone.clone());
                exports
            } else {
                HashSet::new()
            }
        };

        // Empty base exports (we're testing package exports, not base)
        let base_exports = HashSet::new();

        // Query scope at line 0 (before library call)
        let scope = scope_at_position_with_packages(&artifacts, 0, 10, &get_exports, &base_exports, false);

        // Requirement 8.3: The symbol should NOT be in scope before the library() call
        // This means the Diagnostic_Engine WOULD emit an "undefined variable" warning
        prop_assert!(
            !scope.symbols.contains_key(export_name.as_str()),
            "Package export '{}' from package '{}' should NOT be in scope at line 0 (before library() on line {}). \
             This means an 'undefined variable' warning WOULD be emitted. Code:\n{}",
            export_name, package, library_line, code
        );
    }

    /// Feature: package-function-awareness, Property 12 extended: Multiple positions before library
    /// **Validates: Requirement 8.3**
    ///
    /// Verifies that the symbol is NOT in scope at ANY position before the library() call,
    /// not just at line 0.
    #[test]
    fn prop_pre_load_diagnostic_emission_all_positions(
        package in pkg_name(),
        export_name in r_identifier(),
        lines_before in 2..6usize,
    ) {
        // Ensure export_name doesn't collide with filler variable names (x0, x1, etc.)
        // which would create local definitions that shadow the package export
        prop_assume!(!filler_names(lines_before, 0).contains(export_name.as_str()));

        let uri = make_url("test_pre_load_all_pos");

        // Build code with multiple lines before library call
        let mut code_lines = Vec::new();

        // Add lines before library call
        for i in 0..lines_before {
            code_lines.push(format!("x{} <- {}", i, i));
        }

        // Add library call
        let library_line = lines_before;
        code_lines.push(format!("library({})", package));

        // Add usage after library call
        code_lines.push(format!("result <- {}(1)", export_name));

        let code = code_lines.join("\n");
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Create a package exports callback
        let pkg_clone = package.clone();
        let export_clone = export_name.clone();
        let get_exports = move |p: &str| -> HashSet<String> {
            if p == pkg_clone {
                let mut exports = HashSet::new();
                exports.insert(export_clone.clone());
                exports
            } else {
                HashSet::new()
            }
        };

        let base_exports = HashSet::new();

        // Check ALL positions before the library call
        for check_line in 0..library_line {
            let scope = scope_at_position_with_packages(&artifacts, check_line as u32, 10, &get_exports, &base_exports, false);

            // Requirement 8.3: Symbol should NOT be in scope at any position before library()
            prop_assert!(
                !scope.symbols.contains_key(export_name.as_str()),
                "Package export '{}' should NOT be in scope at line {} (before library() on line {}). \
                 This means an 'undefined variable' warning WOULD be emitted. Code:\n{}",
                export_name, check_line, library_line, code
            );
        }

        // Verify it IS in scope after the library call (sanity check)
        let scope_after = scope_at_position_with_packages(&artifacts, (library_line + 1) as u32, 10, &get_exports, &base_exports, false);
        prop_assert!(
            scope_after.symbols.contains_key(export_name.as_str()),
            "Package export '{}' SHOULD be in scope at line {} (after library() on line {}). Code:\n{}",
            export_name, library_line + 1, library_line, code
        );
    }

    /// Feature: package-function-awareness, Property 12 extended: Same line before call position
    /// **Validates: Requirement 8.3**
    ///
    /// When a symbol usage is on the same line as the library() call but BEFORE the call,
    /// the symbol should NOT be in scope (diagnostic should be emitted).
    #[test]
    fn prop_pre_load_diagnostic_same_line_before_call(
        package in pkg_name(),
        export_name in r_identifier(),
    ) {
        let uri = make_url("test_pre_load_same_line");

        // Code with usage before library call on same line (using semicolon)
        // Note: In R, this is unusual but valid syntax
        let code = format!("result <- {}(1); library({})", export_name, package);

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Create a package exports callback
        let pkg_clone = package.clone();
        let export_clone = export_name.clone();
        let get_exports = move |p: &str| -> HashSet<String> {
            if p == pkg_clone {
                let mut exports = HashSet::new();
                exports.insert(export_clone.clone());
                exports
            } else {
                HashSet::new()
            }
        };

        let base_exports = HashSet::new();

        // Query scope at column 0 (before the library call on the same line)
        // The usage `result <- export_name(1)` starts at column 0
        let scope = scope_at_position_with_packages(&artifacts, 0, 0, &get_exports, &base_exports, false);

        // Requirement 8.3: Symbol should NOT be in scope before the library() call
        // even on the same line
        prop_assert!(
            !scope.symbols.contains_key(export_name.as_str()),
            "Package export '{}' should NOT be in scope at column 0 (before library() call on same line). \
             This means an 'undefined variable' warning WOULD be emitted. Code:\n{}",
            export_name, code
        );
    }

    /// Feature: package-function-awareness, Property 12 extended: Function-scoped pre-load
    /// **Validates: Requirement 8.3, 2.4**
    ///
    /// When a library() call is inside a function, symbols should NOT be in scope
    /// before the library() call within that function.
    #[test]
    fn prop_pre_load_diagnostic_function_scoped(
        package in pkg_name(),
        func_name in r_identifier(),
        export_name in r_identifier(),
    ) {
        // Ensure func_name and export_name are different to avoid shadowing
        // (the function definition would shadow the package export)
        prop_assume!(func_name != export_name);

        let uri = make_url("test_pre_load_func_scoped");

        // Code with usage before library() inside a function
        let code = format!(
            "{} <- function() {{\n    result <- {}(1)\n    library({})\n    result2 <- {}(2)\n}}",
            func_name, export_name, package, export_name
        );

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Create a package exports callback
        let pkg_clone = package.clone();
        let export_clone = export_name.clone();
        let get_exports = move |p: &str| -> HashSet<String> {
            if p == pkg_clone {
                let mut exports = HashSet::new();
                exports.insert(export_clone.clone());
                exports
            } else {
                HashSet::new()
            }
        };

        let base_exports = HashSet::new();

        // Query scope at line 1 (before library() inside function)
        let scope_before = scope_at_position_with_packages(&artifacts, 1, 10, &get_exports, &base_exports, false);

        // Requirement 8.3: Symbol should NOT be in scope before library() inside function
        prop_assert!(
            !scope_before.symbols.contains_key(export_name.as_str()),
            "Package export '{}' should NOT be in scope at line 1 (before library() inside function). \
             This means an 'undefined variable' warning WOULD be emitted. Code:\n{}",
            export_name, code
        );

        // Query scope at line 3 (after library() inside function)
        let scope_after = scope_at_position_with_packages(&artifacts, 3, 10, &get_exports, &base_exports, false);

        // Sanity check: Symbol SHOULD be in scope after library() inside function
        prop_assert!(
            scope_after.symbols.contains_key(export_name.as_str()),
            "Package export '{}' SHOULD be in scope at line 3 (after library() inside function). Code:\n{}",
            export_name, code
        );
    }

    /// Feature: package-function-awareness, Property 12 extended: Multiple packages pre-load
    /// **Validates: Requirement 8.3**
    ///
    /// When multiple packages are loaded at different positions, symbols from each
    /// package should NOT be in scope before their respective library() calls.
    #[test]
    fn prop_pre_load_diagnostic_multiple_packages(
        pkg1 in pkg_name(),
        pkg2 in pkg_name(),
        export1 in r_identifier(),
        export2 in r_identifier(),
    ) {
        // Ensure packages and exports are distinct
        prop_assume!(pkg1 != pkg2);
        prop_assume!(export1 != export2);

        let uri = make_url("test_pre_load_multi_pkg");

        // Code with two library calls at different positions
        let code = format!(
            "# Line 0: before both\nlibrary({})\n# Line 2: after pkg1, before pkg2\nlibrary({})\n# Line 4: after both",
            pkg1, pkg2
        );

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Create a package exports callback
        let pkg1_clone = pkg1.clone();
        let pkg2_clone = pkg2.clone();
        let export1_clone = export1.clone();
        let export2_clone = export2.clone();
        let get_exports = move |p: &str| -> HashSet<String> {
            if p == pkg1_clone {
                let mut exports = HashSet::new();
                exports.insert(export1_clone.clone());
                exports
            } else if p == pkg2_clone {
                let mut exports = HashSet::new();
                exports.insert(export2_clone.clone());
                exports
            } else {
                HashSet::new()
            }
        };

        let base_exports = HashSet::new();

        // Line 0: Before both library calls - neither export should be in scope
        let scope_0 = scope_at_position_with_packages(&artifacts, 0, 0, &get_exports, &base_exports, false);
        prop_assert!(
            !scope_0.symbols.contains_key(export1.as_str()),
            "Export '{}' from pkg1 should NOT be in scope at line 0 (before library(pkg1)). Code:\n{}",
            export1, code
        );
        prop_assert!(
            !scope_0.symbols.contains_key(export2.as_str()),
            "Export '{}' from pkg2 should NOT be in scope at line 0 (before library(pkg2)). Code:\n{}",
            export2, code
        );

        // Line 2: After pkg1, before pkg2 - only export1 should be in scope
        let scope_2 = scope_at_position_with_packages(&artifacts, 2, 0, &get_exports, &base_exports, false);
        prop_assert!(
            scope_2.symbols.contains_key(export1.as_str()),
            "Export '{}' from pkg1 SHOULD be in scope at line 2 (after library(pkg1)). Code:\n{}",
            export1, code
        );
        prop_assert!(
            !scope_2.symbols.contains_key(export2.as_str()),
            "Export '{}' from pkg2 should NOT be in scope at line 2 (before library(pkg2)). Code:\n{}",
            export2, code
        );

        // Line 4: After both library calls - both exports should be in scope
        let scope_4 = scope_at_position_with_packages(&artifacts, 4, 0, &get_exports, &base_exports, false);
        prop_assert!(
            scope_4.symbols.contains_key(export1.as_str()),
            "Export '{}' from pkg1 SHOULD be in scope at line 4 (after both library calls). Code:\n{}",
            export1, code
        );
        prop_assert!(
            scope_4.symbols.contains_key(export2.as_str()),
            "Export '{}' from pkg2 SHOULD be in scope at line 4 (after both library calls). Code:\n{}",
            export2, code
        );
    }
}

// ============================================================================
// Property 13: Non-Export Diagnostic Emission
// Feature: package-function-awareness
// **Validates: Requirement 8.4**
//
// For any symbol S that is NOT exported by any loaded package at position X,
// the Diagnostic_Engine SHALL emit an "undefined variable" warning for S at
// position X.
//
// This test verifies that:
// - Symbols NOT in a package's exports are NOT available in scope
// - Loading a package does NOT make non-exported symbols available
// - The scope resolution correctly excludes non-exported symbols
// - Multiple packages being loaded does not affect non-exported symbols
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: package-function-awareness, Property 13: Non-Export Diagnostic Emission
    /// **Validates: Requirement 8.4**
    ///
    /// For any symbol S that is NOT exported by any loaded package at position X,
    /// the scope at position X SHALL NOT contain S, which means the Diagnostic_Engine
    /// SHALL emit an "undefined variable" warning for S at position X.
    ///
    /// This test verifies that symbols NOT in a package's exports are NOT available
    /// in scope, even after the library() call.
    #[test]
    fn prop_non_export_diagnostic_emission(
        package in pkg_name(),
        func in library_func(),
        exported_name in r_identifier(),
        non_exported_name in r_identifier(),
        lines_before in 0..3usize,
        lines_after in 1..4usize,
    ) {
        // Ensure the exported and non-exported names are different
        prop_assume!(exported_name != non_exported_name);

        // Ensure non_exported_name doesn't conflict with generated variable names
        for i in 0..lines_before {
            prop_assume!(non_exported_name != format!("x{}", i));
        }
        for i in 0..lines_after {
            prop_assume!(non_exported_name != format!("y{}", i));
        }
        prop_assume!(non_exported_name != "result");

        let uri = make_url("test_non_export_diag");

        // Build code with library call and usage of a NON-exported symbol
        let mut code_lines = Vec::new();

        // Add filler lines before library call
        for i in 0..lines_before {
            code_lines.push(format!("x{} <- {}", i, i));
        }

        // Add library call
        let library_line = lines_before;
        code_lines.push(format!("{}({})", func, package));

        // Add lines after library call, including usage of NON-exported symbol
        for i in 0..lines_after {
            if i == 0 {
                // Use the NON-exported symbol on the first line after library()
                code_lines.push(format!("result <- {}(1)", non_exported_name));
            } else {
                code_lines.push(format!("y{} <- {}", i, i));
            }
        }

        let code = code_lines.join("\n");
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Create a package exports callback that returns ONLY the exported_name
        // (NOT the non_exported_name)
        let pkg_clone = package.clone();
        let export_clone = exported_name.clone();
        let get_exports = move |p: &str| -> HashSet<String> {
            if p == pkg_clone {
                let mut exports = HashSet::new();
                exports.insert(export_clone.clone());
                exports
            } else {
                HashSet::new()
            }
        };

        // Empty base exports (we're testing package exports, not base)
        let base_exports = HashSet::new();

        // Query scope at the usage position (line after library call)
        let usage_line = (library_line + 1) as u32;
        let scope = scope_at_position_with_packages(&artifacts, usage_line, 10, &get_exports, &base_exports, false);

        // Requirement 8.4: The NON-exported symbol should NOT be in scope
        // This means the Diagnostic_Engine WOULD emit an "undefined variable" warning
        prop_assert!(
            !scope.symbols.contains_key(non_exported_name.as_str()),
            "Non-exported symbol '{}' should NOT be in scope at line {} (after library({}) on line {}). \
             Package '{}' only exports '{}'. \
             This means an 'undefined variable' warning WOULD be emitted. Code:\n{}",
            non_exported_name, usage_line, package, library_line, package, exported_name, code
        );

        // Sanity check: The exported symbol SHOULD be in scope
        prop_assert!(
            scope.symbols.contains_key(exported_name.as_str()),
            "Exported symbol '{}' SHOULD be in scope at line {} (after library({}) on line {}). Code:\n{}",
            exported_name, usage_line, package, library_line, code
        );
    }

    /// Feature: package-function-awareness, Property 13 extended: Multiple packages, symbol not in any
    /// **Validates: Requirement 8.4**
    ///
    /// When multiple packages are loaded, a symbol that is NOT exported by ANY of them
    /// should NOT be in scope.
    #[test]
    fn prop_non_export_diagnostic_multiple_packages(
        pkg1 in pkg_name(),
        pkg2 in pkg_name(),
        export1 in r_identifier(),
        export2 in r_identifier(),
        non_exported in r_identifier(),
    ) {
        // Ensure all names are distinct
        prop_assume!(pkg1 != pkg2);
        prop_assume!(export1 != export2);
        prop_assume!(non_exported != export1);
        prop_assume!(non_exported != export2);

        let uri = make_url("test_non_export_multi_pkg");

        // Code with two library calls and usage of non-exported symbol
        let code = format!(
            "library({})\nlibrary({})\nresult <- {}(1)",
            pkg1, pkg2, non_exported
        );

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Create a package exports callback - neither package exports non_exported
        let pkg1_clone = pkg1.clone();
        let pkg2_clone = pkg2.clone();
        let export1_clone = export1.clone();
        let export2_clone = export2.clone();
        let get_exports = move |p: &str| -> HashSet<String> {
            if p == pkg1_clone {
                let mut exports = HashSet::new();
                exports.insert(export1_clone.clone());
                exports
            } else if p == pkg2_clone {
                let mut exports = HashSet::new();
                exports.insert(export2_clone.clone());
                exports
            } else {
                HashSet::new()
            }
        };

        let base_exports = HashSet::new();

        // Query scope at line 2 (after both library calls)
        let scope = scope_at_position_with_packages(&artifacts, 2, 10, &get_exports, &base_exports, false);

        // Requirement 8.4: Non-exported symbol should NOT be in scope
        prop_assert!(
            !scope.symbols.contains_key(non_exported.as_str()),
            "Non-exported symbol '{}' should NOT be in scope even after loading packages '{}' and '{}'. \
             Package '{}' exports '{}', package '{}' exports '{}'. \
             This means an 'undefined variable' warning WOULD be emitted. Code:\n{}",
            non_exported, pkg1, pkg2, pkg1, export1, pkg2, export2, code
        );

        // Sanity check: Both exported symbols SHOULD be in scope
        prop_assert!(
            scope.symbols.contains_key(export1.as_str()),
            "Exported symbol '{}' from package '{}' SHOULD be in scope. Code:\n{}",
            export1, pkg1, code
        );
        prop_assert!(
            scope.symbols.contains_key(export2.as_str()),
            "Exported symbol '{}' from package '{}' SHOULD be in scope. Code:\n{}",
            export2, pkg2, code
        );
    }

    /// Feature: package-function-awareness, Property 13 extended: Package with empty exports
    /// **Validates: Requirement 8.4**
    ///
    /// When a package has no exports (empty export list), no symbols from that package
    /// should be available in scope.
    #[test]
    fn prop_non_export_diagnostic_empty_exports(
        package in pkg_name(),
        symbol_name in r_identifier(),
    ) {
        let uri = make_url("test_empty_exports");

        // Code with library call and usage of a symbol
        let code = format!(
            "library({})\nresult <- {}(1)",
            package, symbol_name
        );

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Create a package exports callback that returns EMPTY exports
        let get_exports = move |_p: &str| -> HashSet<String> { HashSet::new() };

        let base_exports = HashSet::new();

        // Query scope at line 1 (after library call)
        let scope = scope_at_position_with_packages(&artifacts, 1, 10, &get_exports, &base_exports, false);

        // Requirement 8.4: Symbol should NOT be in scope (package has no exports)
        prop_assert!(
            !scope.symbols.contains_key(symbol_name.as_str()),
            "Symbol '{}' should NOT be in scope after loading package '{}' with empty exports. \
             This means an 'undefined variable' warning WOULD be emitted. Code:\n{}",
            symbol_name, package, code
        );
    }

    /// Feature: package-function-awareness, Property 13 extended: Function-scoped non-export
    /// **Validates: Requirement 8.4, 2.4**
    ///
    /// When a library() call is inside a function, non-exported symbols should NOT
    /// be in scope either inside or outside the function.
    #[test]
    fn prop_non_export_diagnostic_function_scoped(
        package in pkg_name(),
        func_name in r_identifier(),
        exported_name in r_identifier(),
        non_exported_name in r_identifier(),
    ) {
        // Ensure names are distinct
        prop_assume!(exported_name != non_exported_name);
        prop_assume!(func_name != exported_name);
        prop_assume!(func_name != non_exported_name);

        let uri = make_url("test_func_scoped_non_export");

        // Code with library() inside a function, using non-exported symbol
        let code = format!(
            "{} <- function() {{\n    library({})\n    result <- {}(1)\n}}\noutside <- {}(2)",
            func_name, package, non_exported_name, non_exported_name
        );

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Create a package exports callback - only exports exported_name
        let pkg_clone = package.clone();
        let export_clone = exported_name.clone();
        let get_exports = move |p: &str| -> HashSet<String> {
            if p == pkg_clone {
                let mut exports = HashSet::new();
                exports.insert(export_clone.clone());
                exports
            } else {
                HashSet::new()
            }
        };

        let base_exports = HashSet::new();

        // Query scope inside the function (line 2, after library call inside function)
        let scope_inside = scope_at_position_with_packages(&artifacts, 2, 10, &get_exports, &base_exports, false);

        // Requirement 8.4: Non-exported symbol should NOT be in scope inside function
        prop_assert!(
            !scope_inside.symbols.contains_key(non_exported_name.as_str()),
            "Non-exported symbol '{}' should NOT be in scope inside function after library({}). \
             Package only exports '{}'. Code:\n{}",
            non_exported_name, package, exported_name, code
        );

        // Query scope outside the function (line 4)
        let scope_outside = scope_at_position_with_packages(&artifacts, 4, 10, &get_exports, &base_exports, false);

        // Non-exported symbol should NOT be in scope outside function either
        prop_assert!(
            !scope_outside.symbols.contains_key(non_exported_name.as_str()),
            "Non-exported symbol '{}' should NOT be in scope outside function. Code:\n{}",
            non_exported_name, code
        );
    }

    /// Feature: package-function-awareness, Property 13 extended: Similar but different symbol names
    /// **Validates: Requirement 8.4**
    ///
    /// Verifies that symbols with similar names (e.g., "mutate" vs "mutate2") are
    /// correctly distinguished - only exact matches should be in scope.
    #[test]
    fn prop_non_export_diagnostic_similar_names(
        package in pkg_name(),
        base_name in r_identifier(),
    ) {
        let uri = make_url("test_similar_names");

        // Create similar but different names
        let exported_name = base_name.clone();
        let similar_name = format!("{}2", base_name);

        // Code with library call and usage of similar-but-different symbol
        let code = format!(
            "library({})\nresult <- {}(1)",
            package, similar_name
        );

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Create a package exports callback - only exports base_name, not similar_name
        let pkg_clone = package.clone();
        let export_clone = exported_name.clone();
        let get_exports = move |p: &str| -> HashSet<String> {
            if p == pkg_clone {
                let mut exports = HashSet::new();
                exports.insert(export_clone.clone());
                exports
            } else {
                HashSet::new()
            }
        };

        let base_exports = HashSet::new();

        // Query scope at line 1 (after library call)
        let scope = scope_at_position_with_packages(&artifacts, 1, 10, &get_exports, &base_exports, false);

        // Requirement 8.4: Similar-but-different symbol should NOT be in scope
        prop_assert!(
            !scope.symbols.contains_key(similar_name.as_str()),
            "Similar symbol '{}' should NOT be in scope (only '{}' is exported by '{}'). \
             This means an 'undefined variable' warning WOULD be emitted. Code:\n{}",
            similar_name, exported_name, package, code
        );

        // Sanity check: The exact exported name SHOULD be in scope
        prop_assert!(
            scope.symbols.contains_key(exported_name.as_str()),
            "Exported symbol '{}' SHOULD be in scope. Code:\n{}",
            exported_name, code
        );
    }

    /// Feature: package-function-awareness, Property 13 extended: Non-export not affected by base packages
    /// **Validates: Requirement 8.4**
    ///
    /// Verifies that non-exported symbols are NOT in scope even when base packages
    /// are available (base packages don't magically make all symbols available).
    #[test]
    fn prop_non_export_diagnostic_with_base_packages(
        package in pkg_name(),
        exported_name in r_identifier(),
        non_exported_name in r_identifier(),
        base_export in r_identifier(),
    ) {
        // Ensure all names are distinct
        prop_assume!(exported_name != non_exported_name);
        prop_assume!(non_exported_name != base_export);
        prop_assume!(exported_name != base_export);

        let uri = make_url("test_non_export_with_base");

        // Code with library call and usage of non-exported symbol
        let code = format!(
            "library({})\nresult <- {}(1)",
            package, non_exported_name
        );

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Create a package exports callback
        let pkg_clone = package.clone();
        let export_clone = exported_name.clone();
        let get_exports = move |p: &str| -> HashSet<String> {
            if p == pkg_clone {
                let mut exports = HashSet::new();
                exports.insert(export_clone.clone());
                exports
            } else {
                HashSet::new()
            }
        };

        // Add some base exports (but NOT the non_exported_name)
        let mut base_exports = HashSet::new();
        base_exports.insert(base_export.clone());

        // Query scope at line 1 (after library call)
        let scope = scope_at_position_with_packages(&artifacts, 1, 10, &get_exports, &base_exports, false);

        // Requirement 8.4: Non-exported symbol should NOT be in scope
        // (even though base packages are available)
        prop_assert!(
            !scope.symbols.contains_key(non_exported_name.as_str()),
            "Non-exported symbol '{}' should NOT be in scope (not in package '{}' exports or base). \
             This means an 'undefined variable' warning WOULD be emitted. Code:\n{}",
            non_exported_name, package, code
        );

        // Sanity checks
        prop_assert!(
            scope.symbols.contains_key(exported_name.as_str()),
            "Exported symbol '{}' from package '{}' SHOULD be in scope. Code:\n{}",
            exported_name, package, code
        );
        prop_assert!(
            scope.symbols.contains_key(base_export.as_str()),
            "Base export '{}' SHOULD be in scope. Code:\n{}",
            base_export, code
        );
    }
}

// ============================================================================
// Property 14: Package Completion Inclusion
// Validates: Requirements 9.1, 9.2
//
// For any position X after a library(P) call, completions at X SHALL include
// all exports from package P with package attribution.
//
// This test verifies that:
// - All exports from a loaded package are available in scope after the library() call
// - Each export has the correct package attribution (source_uri contains package name)
// - Multiple packages can provide exports that appear in completions
// - Package attribution is preserved for each export
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: package-function-awareness, Property 14: Package Completion Inclusion
    /// **Validates: Requirements 9.1, 9.2**
    ///
    /// For any position X after a library(P) call, completions at X SHALL include
    /// all exports from package P with package attribution.
    ///
    /// This test verifies that package exports are available in scope after the
    /// library() call with correct package attribution, which is the mechanism
    /// by which completions include package exports with package names in the detail field.
    #[test]
    fn prop_package_completion_inclusion(
        package in pkg_name(),
        func in library_func(),
        export1 in r_identifier(),
        export2 in r_identifier(),
        export3 in r_identifier(),
        lines_before in 0..3usize,
    ) {
        // Ensure exports are distinct
        prop_assume!(export1 != export2 && export2 != export3 && export1 != export3);
        // Ensure exports don't conflict with filler variable names (filler0, filler1, filler2)
        prop_assume!(!export1.starts_with("filler") && !export2.starts_with("filler") && !export3.starts_with("filler"));

        let uri = make_url("test_pkg_completion_inclusion");

        // Build code with library call
        let mut code_lines = Vec::new();

        // Add filler lines before library call (using "filler" prefix to avoid conflicts with exports)
        for i in 0..lines_before {
            code_lines.push(format!("filler{} <- {}", i, i));
        }

        // Add library call
        let library_line = lines_before;
        code_lines.push(format!("{}({})", func, package));

        // Add a line after library call
        code_lines.push("# cursor position here".to_string());

        let code = code_lines.join("\n");
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Create a package exports callback that returns multiple exports for our package
        let pkg_clone = package.clone();
        let export1_clone = export1.clone();
        let export2_clone = export2.clone();
        let export3_clone = export3.clone();
        let get_exports = move |p: &str| -> HashSet<String> {
            if p == pkg_clone {
                let mut exports = HashSet::new();
                exports.insert(export1_clone.clone());
                exports.insert(export2_clone.clone());
                exports.insert(export3_clone.clone());
                exports
            } else {
                HashSet::new()
            }
        };

        // Empty base exports (we're testing package exports, not base)
        let base_exports = HashSet::new();

        // Query scope at the position after library call (where completions would be requested)
        let query_line = (library_line + 1) as u32;
        let scope = scope_at_position_with_packages(&artifacts, query_line, 0, &get_exports, &base_exports, false);

        // Requirement 9.1: All exports from the loaded package should be in scope
        prop_assert!(
            scope.symbols.contains_key(export1.as_str()),
            "Package export '{}' from package '{}' should be in scope at line {} (after library() on line {}). \
             This means it would appear in completions. Code:\n{}",
            export1, package, query_line, library_line, code
        );
        prop_assert!(
            scope.symbols.contains_key(export2.as_str()),
            "Package export '{}' from package '{}' should be in scope at line {} (after library() on line {}). \
             This means it would appear in completions. Code:\n{}",
            export2, package, query_line, library_line, code
        );
        prop_assert!(
            scope.symbols.contains_key(export3.as_str()),
            "Package export '{}' from package '{}' should be in scope at line {} (after library() on line {}). \
             This means it would appear in completions. Code:\n{}",
            export3, package, query_line, library_line, code
        );

        // Requirement 9.2: Each export should have the correct package attribution
        let expected_uri = format!("package:{}", package);

        let symbol1 = scope.symbols.get(export1.as_str()).unwrap();
        prop_assert_eq!(
            symbol1.source_uri.as_str(), expected_uri.as_str(),
            "Package export '{}' should have URI '{}' for package attribution, got '{}'. Code:\n{}",
            export1, expected_uri, symbol1.source_uri.as_str(), code
        );

        let symbol2 = scope.symbols.get(export2.as_str()).unwrap();
        prop_assert_eq!(
            symbol2.source_uri.as_str(), expected_uri.as_str(),
            "Package export '{}' should have URI '{}' for package attribution, got '{}'. Code:\n{}",
            export2, expected_uri, symbol2.source_uri.as_str(), code
        );

        let symbol3 = scope.symbols.get(export3.as_str()).unwrap();
        prop_assert_eq!(
            symbol3.source_uri.as_str(), expected_uri.as_str(),
            "Package export '{}' should have URI '{}' for package attribution, got '{}'. Code:\n{}",
            export3, expected_uri, symbol3.source_uri.as_str(), code
        );
    }

    /// Feature: package-function-awareness, Property 14 extended: Multiple packages
    /// **Validates: Requirements 9.1, 9.2, 9.3**
    ///
    /// When multiple packages are loaded, completions should include exports from
    /// ALL loaded packages, each with correct package attribution.
    #[test]
    fn prop_package_completion_inclusion_multiple_packages(
        pkg1 in pkg_name(),
        pkg2 in pkg_name(),
        export1 in r_identifier(),
        export2 in r_identifier(),
    ) {
        // Ensure packages and exports are distinct
        prop_assume!(pkg1 != pkg2);
        prop_assume!(export1 != export2);

        let uri = make_url("test_multi_pkg_completion");

        // Code with two library calls
        let code = format!(
            "library({})\nlibrary({})\n# cursor position here",
            pkg1, pkg2
        );

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Create a package exports callback
        let pkg1_clone = pkg1.clone();
        let pkg2_clone = pkg2.clone();
        let export1_clone = export1.clone();
        let export2_clone = export2.clone();
        let get_exports = move |p: &str| -> HashSet<String> {
            if p == pkg1_clone {
                let mut exports = HashSet::new();
                exports.insert(export1_clone.clone());
                exports
            } else if p == pkg2_clone {
                let mut exports = HashSet::new();
                exports.insert(export2_clone.clone());
                exports
            } else {
                HashSet::new()
            }
        };

        let base_exports = HashSet::new();

        // Query scope at line 2 (after both library calls)
        let scope = scope_at_position_with_packages(&artifacts, 2, 0, &get_exports, &base_exports, false);

        // Requirement 9.1: Both exports should be in scope
        prop_assert!(
            scope.symbols.contains_key(export1.as_str()),
            "Export '{}' from package '{}' should be in scope. Code:\n{}",
            export1, pkg1, code
        );
        prop_assert!(
            scope.symbols.contains_key(export2.as_str()),
            "Export '{}' from package '{}' should be in scope. Code:\n{}",
            export2, pkg2, code
        );

        // Requirement 9.2: Each export should have correct package attribution
        let symbol1 = scope.symbols.get(export1.as_str()).unwrap();
        let expected_uri1 = format!("package:{}", pkg1);
        prop_assert_eq!(
            symbol1.source_uri.as_str(), expected_uri1.as_str(),
            "Export '{}' should have URI '{}', got '{}'. Code:\n{}",
            export1, expected_uri1, symbol1.source_uri.as_str(), code
        );

        let symbol2 = scope.symbols.get(export2.as_str()).unwrap();
        let expected_uri2 = format!("package:{}", pkg2);
        prop_assert_eq!(
            symbol2.source_uri.as_str(), expected_uri2.as_str(),
            "Export '{}' should have URI '{}', got '{}'. Code:\n{}",
            export2, expected_uri2, symbol2.source_uri.as_str(), code
        );
    }

    /// Feature: package-function-awareness, Property 14 extended: Duplicate exports
    /// **Validates: Requirements 9.2, 9.3**
    ///
    /// When multiple packages export the same symbol, the last loaded package's
    /// export should mask earlier ones (matching R's search path behavior).
    /// This test verifies the scope resolution behavior for duplicate exports.
    #[test]
    fn prop_package_completion_duplicate_exports(
        pkg1 in pkg_name(),
        pkg2 in pkg_name(),
        shared_export in r_identifier(),
    ) {
        // Ensure packages are distinct
        prop_assume!(pkg1 != pkg2);

        let uri = make_url("test_duplicate_export_completion");

        // Code with two library calls, both packages export the same symbol
        let code = format!(
            "library({})\nlibrary({})\n# cursor position here",
            pkg1, pkg2
        );

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Create a package exports callback where both packages export the same symbol
        let pkg1_clone = pkg1.clone();
        let pkg2_clone = pkg2.clone();
        let export_clone = shared_export.clone();
        let get_exports = move |p: &str| -> HashSet<String> {
            if p == pkg1_clone || p == pkg2_clone {
                let mut exports = HashSet::new();
                exports.insert(export_clone.clone());
                exports
            } else {
                HashSet::new()
            }
        };

        let base_exports = HashSet::new();

        // Query scope at line 2 (after both library calls)
        let scope = scope_at_position_with_packages(&artifacts, 2, 0, &get_exports, &base_exports, false);

        // The symbol should be in scope
        prop_assert!(
            scope.symbols.contains_key(shared_export.as_str()),
            "Shared export '{}' should be in scope. Code:\n{}",
            shared_export, code
        );

        // The last loaded package (pkg2) should win for the symbol attribution
        // This matches R's search path behavior where later library() calls
        // attach higher on the search path and mask earlier packages
        let symbol = scope.symbols.get(shared_export.as_str()).unwrap();
        let expected_uri = format!("package:{}", pkg2);
        prop_assert_eq!(
            symbol.source_uri.as_str(), expected_uri.as_str(),
            "Shared export '{}' should have URI '{}' (last loaded package), got '{}'. Code:\n{}",
            shared_export, expected_uri, symbol.source_uri.as_str(), code
        );
    }

    /// Feature: package-function-awareness, Property 14 extended: Position-aware completions
    /// **Validates: Requirements 9.1, 2.1, 2.2**
    ///
    /// Package exports should NOT be available in completions before the library() call.
    #[test]
    fn prop_package_completion_position_aware(
        package in pkg_name(),
        export_name in r_identifier(),
        lines_before in 1..4usize,
    ) {
        // Ensure export doesn't conflict with filler variable names
        prop_assume!(!export_name.starts_with("filler"));

        let uri = make_url("test_pkg_completion_position");

        // Build code with library call in the middle
        let mut code_lines = Vec::new();

        // Add filler lines before library call (using "filler" prefix to avoid conflicts)
        for i in 0..lines_before {
            code_lines.push(format!("filler{} <- {}", i, i));
        }

        // Add library call
        let library_line = lines_before;
        code_lines.push(format!("library({})", package));

        // Add a line after library call
        code_lines.push("# after library".to_string());

        let code = code_lines.join("\n");
        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Create a package exports callback
        let pkg_clone = package.clone();
        let export_clone = export_name.clone();
        let get_exports = move |p: &str| -> HashSet<String> {
            if p == pkg_clone {
                let mut exports = HashSet::new();
                exports.insert(export_clone.clone());
                exports
            } else {
                HashSet::new()
            }
        };

        let base_exports = HashSet::new();

        // Query scope BEFORE the library call (line 0)
        let scope_before = scope_at_position_with_packages(&artifacts, 0, 0, &get_exports, &base_exports, false);

        // Export should NOT be in scope before library() call
        prop_assert!(
            !scope_before.symbols.contains_key(export_name.as_str()),
            "Package export '{}' should NOT be in scope at line 0 (before library() on line {}). \
             This means it would NOT appear in completions before the library call. Code:\n{}",
            export_name, library_line, code
        );

        // Query scope AFTER the library call
        let scope_after = scope_at_position_with_packages(&artifacts, (library_line + 1) as u32, 0, &get_exports, &base_exports, false);

        // Export SHOULD be in scope after library() call
        prop_assert!(
            scope_after.symbols.contains_key(export_name.as_str()),
            "Package export '{}' should be in scope at line {} (after library() on line {}). \
             This means it would appear in completions after the library call. Code:\n{}",
            export_name, library_line + 1, library_line, code
        );
    }

    /// Feature: package-function-awareness, Property 14 extended: Local definitions shadow package exports
    /// **Validates: Requirements 9.4**
    ///
    /// Local definitions should take precedence over package exports in completions.
    #[test]
    fn prop_package_completion_local_precedence(
        package in pkg_name(),
        symbol_name in r_identifier(),
    ) {
        let uri = make_url("test_pkg_completion_local_precedence");

        // Code with library call followed by local definition of same symbol
        let code = format!(
            "library({})\n{} <- 42\n# cursor position here",
            package, symbol_name
        );

        let tree = parse_r_tree(&code);
        let artifacts = compute_artifacts(&uri, &tree, &code);

        // Create a package exports callback
        let pkg_clone = package.clone();
        let symbol_clone = symbol_name.clone();
        let get_exports = move |p: &str| -> HashSet<String> {
            if p == pkg_clone {
                let mut exports = HashSet::new();
                exports.insert(symbol_clone.clone());
                exports
            } else {
                HashSet::new()
            }
        };

        let base_exports = HashSet::new();

        // Query scope at line 2 (after both library call and local definition)
        let scope = scope_at_position_with_packages(&artifacts, 2, 0, &get_exports, &base_exports, false);

        // Symbol should be in scope
        prop_assert!(
            scope.symbols.contains_key(symbol_name.as_str()),
            "Symbol '{}' should be in scope. Code:\n{}",
            symbol_name, code
        );

        // Requirement 9.4: Local definition should take precedence
        // The symbol should have the file URI, not the package URI
        let symbol = scope.symbols.get(symbol_name.as_str()).unwrap();
        prop_assert_eq!(
            &symbol.source_uri, &uri,
            "Symbol '{}' should have local file URI (local definition takes precedence), got '{}'. Code:\n{}",
            symbol_name, symbol.source_uri.as_str(), code
        );
    }
}

// ============================================================================
// Feature: working-directory-inheritance
// Property 6: Metadata and PathContext Round-Trip
// Validates: Requirements 6.1, 6.2, 6.3
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: working-directory-inheritance, Property 6: Metadata and PathContext Round-Trip
    /// **Validates: Requirements 6.1, 6.2, 6.3**
    ///
    /// For any CrossFileMetadata with an inherited_working_directory field set,
    /// constructing a PathContext from that metadata and then computing the
    /// effective working directory SHALL return the inherited working directory
    /// (when no explicit working directory is set).
    #[test]
    fn prop_metadata_pathcontext_round_trip_inherited_wd(
        workspace in path_component(),
        subdir in path_component(),
        inherited_wd_dir in path_component(),
    ) {
        // Create file URI: /workspace/subdir/child.R
        let file_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, subdir)).unwrap();
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Create metadata with inherited_working_directory set as an absolute path.
        // Per design doc: "The stored path is always absolute for consistent resolution"
        // This simulates what compute_inherited_working_directory would return.
        let inherited_wd_path = format!("/{}/{}", workspace, inherited_wd_dir);
        let meta = CrossFileMetadata {
            working_directory: None, // No explicit working directory
            inherited_working_directory: Some(inherited_wd_path.clone()),
            ..Default::default()
        };

        // Construct PathContext from metadata
        let ctx = PathContext::from_metadata(&file_uri, &meta, Some(&workspace_uri));
        prop_assert!(ctx.is_some(), "PathContext::from_metadata should succeed");
        let ctx = ctx.unwrap();

        // Compute effective working directory
        let effective_wd = ctx.effective_working_directory();

        // The effective working directory should be the inherited working directory
        // (already absolute, used directly)
        let expected_wd = PathBuf::from(&inherited_wd_path);

        // Check equality first, then provide detailed error message if it fails
        prop_assert!(
            effective_wd == expected_wd,
            "Effective working directory should equal inherited working directory. \
             inherited_wd_path='{}', expected='{}', got='{}'",
            inherited_wd_path, expected_wd.display(), effective_wd.display()
        );

        // Verify that working_directory is None (no explicit WD)
        prop_assert!(
            ctx.working_directory.is_none(),
            "PathContext should have no explicit working_directory set"
        );

        // Verify that inherited_working_directory is set correctly
        prop_assert!(
            ctx.inherited_working_directory.is_some(),
            "PathContext should have inherited_working_directory set"
        );
        prop_assert!(
            ctx.inherited_working_directory.as_ref().unwrap() == &expected_wd,
            "PathContext inherited_working_directory should match expected. got='{}', expected='{}'",
            ctx.inherited_working_directory.as_ref().unwrap().display(), expected_wd.display()
        );
    }

    /// Feature: working-directory-inheritance, Property 6 extended: Relative inherited WD
    /// **Validates: Requirements 6.2, 6.3**
    ///
    /// Inherited working directory with relative path should resolve relative to file's directory.
    #[test]
    fn prop_metadata_pathcontext_round_trip_relative_inherited_wd(
        workspace in path_component(),
        subdir in path_component(),
        relative_wd in path_component(),
    ) {
        // Create file URI: /workspace/subdir/child.R
        let file_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, subdir)).unwrap();
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Create metadata with relative inherited_working_directory
        let inherited_wd_path = format!("../{}", relative_wd);
        let meta = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: Some(inherited_wd_path.clone()),
            ..Default::default()
        };

        // Construct PathContext from metadata
        let ctx = PathContext::from_metadata(&file_uri, &meta, Some(&workspace_uri));
        prop_assert!(ctx.is_some(), "PathContext::from_metadata should succeed");
        let ctx = ctx.unwrap();

        // Compute effective working directory
        let effective_wd = ctx.effective_working_directory();

        // The relative path "../relative_wd" from /workspace/subdir/ should resolve to /workspace/relative_wd
        let expected_wd = PathBuf::from(format!("/{}/{}", workspace, relative_wd));

        prop_assert!(
            effective_wd == expected_wd,
            "Effective working directory should equal resolved inherited working directory. \
             inherited_wd_path='{}', expected='{}', got='{}'",
            inherited_wd_path, expected_wd.display(), effective_wd.display()
        );
    }

    /// Feature: working-directory-inheritance, Property 6 extended: No inherited WD falls back to file's directory
    /// **Validates: Requirements 6.1, 6.2**
    ///
    /// When no inherited_working_directory is set, effective working directory should be file's directory.
    #[test]
    fn prop_metadata_pathcontext_no_inherited_wd_fallback(
        workspace in path_component(),
        subdir in path_component(),
    ) {
        // Create file URI: /workspace/subdir/child.R
        let file_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, subdir)).unwrap();
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Create metadata with NO inherited_working_directory
        let meta = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            ..Default::default()
        };

        // Construct PathContext from metadata
        let ctx = PathContext::from_metadata(&file_uri, &meta, Some(&workspace_uri));
        prop_assert!(ctx.is_some(), "PathContext::from_metadata should succeed");
        let ctx = ctx.unwrap();

        // Compute effective working directory
        let effective_wd = ctx.effective_working_directory();

        // Should fall back to file's directory
        let expected_wd = PathBuf::from(format!("/{}/{}", workspace, subdir));

        prop_assert!(
            effective_wd == expected_wd,
            "Effective working directory should fall back to file's directory when no inherited WD. \
             expected='{}', got='{}'",
            expected_wd.display(), effective_wd.display()
        );

        // Verify both working directories are None
        prop_assert!(ctx.working_directory.is_none());
        prop_assert!(ctx.inherited_working_directory.is_none());
    }

    /// Feature: working-directory-inheritance, Property 6 extended: Explicit WD takes precedence over inherited
    /// **Validates: Requirements 6.2, 6.3, 3.1**
    ///
    /// When both explicit and inherited working directories are present,
    /// explicit should take precedence (this validates the round-trip preserves precedence).
    #[test]
    fn prop_metadata_pathcontext_explicit_wd_precedence(
        workspace in path_component(),
        subdir in path_component(),
        explicit_wd_dir in path_component(),
        inherited_wd_dir in path_component(),
    ) {
        // Ensure explicit and inherited are different
        prop_assume!(explicit_wd_dir != inherited_wd_dir);

        // Create file URI: /workspace/subdir/child.R
        let file_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, subdir)).unwrap();
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Create metadata with BOTH explicit and inherited working directories
        let explicit_wd_path = format!("/{}", explicit_wd_dir);
        let inherited_wd_path = format!("/{}", inherited_wd_dir);
        let meta = CrossFileMetadata {
            working_directory: Some(explicit_wd_path.clone()),
            inherited_working_directory: Some(inherited_wd_path.clone()),
            ..Default::default()
        };

        // Construct PathContext from metadata
        let ctx = PathContext::from_metadata(&file_uri, &meta, Some(&workspace_uri));
        prop_assert!(ctx.is_some(), "PathContext::from_metadata should succeed");
        let ctx = ctx.unwrap();

        // Compute effective working directory
        let effective_wd = ctx.effective_working_directory();

        // The effective working directory should be the EXPLICIT working directory
        let expected_wd = PathBuf::from(format!("/{}/{}", workspace, explicit_wd_dir));

        prop_assert!(
            effective_wd == expected_wd,
            "Effective working directory should equal explicit working directory (takes precedence). \
             explicit='{}', inherited='{}', expected='{}', got='{}'",
            explicit_wd_path, inherited_wd_path, expected_wd.display(), effective_wd.display()
        );

        // Verify that explicit working_directory is set
        prop_assert!(
            ctx.working_directory.is_some(),
            "PathContext should have explicit working_directory set"
        );

        // Verify that inherited_working_directory is NOT set (because explicit takes precedence)
        // This is the behavior in from_metadata: if explicit is set, inherited is not populated
        prop_assert!(
            ctx.inherited_working_directory.is_none(),
            "PathContext should NOT have inherited_working_directory when explicit is set"
        );
    }

    /// Feature: working-directory-inheritance, Property 6 extended: Metadata serialization round-trip
    /// **Validates: Requirements 6.1**
    ///
    /// CrossFileMetadata with inherited_working_directory should serialize and deserialize correctly.
    #[test]
    fn prop_metadata_inherited_wd_serialization_round_trip(
        inherited_wd_path in relative_path_with_parents(),
    ) {
        // Create metadata with inherited_working_directory
        let meta = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: Some(inherited_wd_path.clone()),
            ..Default::default()
        };

        // Serialize to JSON
        let json = serde_json::to_string(&meta);
        prop_assert!(json.is_ok(), "Serialization should succeed");
        let json = json.unwrap();

        // Deserialize back
        let meta2: Result<CrossFileMetadata, _> = serde_json::from_str(&json);
        prop_assert!(meta2.is_ok(), "Deserialization should succeed");
        let meta2 = meta2.unwrap();

        // Verify inherited_working_directory is preserved
        prop_assert_eq!(
            meta.inherited_working_directory, meta2.inherited_working_directory,
            "inherited_working_directory should be preserved through serialization round-trip"
        );

        // Verify other fields are also preserved
        prop_assert_eq!(meta.working_directory, meta2.working_directory);
        prop_assert_eq!(meta.sourced_by.len(), meta2.sourced_by.len());
        prop_assert_eq!(meta.sources.len(), meta2.sources.len());
    }
}

// ============================================================================
// Feature: working-directory-inheritance
// Property 3: Explicit Working Directory Precedence
// Validates: Requirements 3.1, 3.2
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: working-directory-inheritance, Property 3: Explicit Working Directory Precedence
    /// **Validates: Requirements 3.1, 3.2**
    ///
    /// For any child file that has both a backward directive AND its own explicit @lsp-cd directive,
    /// the effective working directory for path resolution SHALL equal the child's explicit working
    /// directory, ignoring any inherited working directory from the parent.
    #[test]
    fn prop_explicit_wd_precedence_over_inherited(
        workspace in path_component(),
        child_subdir in path_component(),
        child_explicit_wd in path_component(),
        parent_wd in path_component(),
    ) {
        // Ensure child's explicit WD and parent's WD are different
        prop_assume!(child_explicit_wd != parent_wd);

        // Create file URI: /workspace/child_subdir/child.R
        let file_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, child_subdir)).unwrap();
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Simulate a child file with:
        // - A backward directive (represented by inherited_working_directory from parent)
        // - Its own explicit @lsp-cd directive
        let child_explicit_wd_path = format!("/{}", child_explicit_wd);
        let parent_wd_path = format!("/{}", parent_wd);

        // Create metadata with BOTH explicit and inherited working directories
        let meta = CrossFileMetadata {
            working_directory: Some(child_explicit_wd_path.clone()),
            inherited_working_directory: Some(parent_wd_path.clone()),
            ..Default::default()
        };

        // Construct PathContext from metadata
        let ctx = PathContext::from_metadata(&file_uri, &meta, Some(&workspace_uri));
        prop_assert!(ctx.is_some(), "PathContext::from_metadata should succeed");
        let ctx = ctx.unwrap();

        // Compute effective working directory
        let effective_wd = ctx.effective_working_directory();

        // The effective working directory should be the CHILD'S EXPLICIT working directory
        // (workspace-relative path /child_explicit_wd resolves to /workspace/child_explicit_wd)
        let expected_wd = PathBuf::from(format!("/{}/{}", workspace, child_explicit_wd));

        // Requirement 3.1: Child's explicit @lsp-cd is used for path resolution
        prop_assert!(
            effective_wd == expected_wd,
            "Effective working directory should equal child's explicit working directory. \
             child_explicit='{}', parent_wd='{}', expected='{}', got='{}'",
            child_explicit_wd_path, parent_wd_path, expected_wd.display(), effective_wd.display()
        );

        // Requirement 3.2: Parent's working directory is NOT used
        let parent_resolved_wd = PathBuf::from(format!("/{}/{}", workspace, parent_wd));
        prop_assert!(
            effective_wd != parent_resolved_wd,
            "Effective working directory should NOT equal parent's working directory. \
             child_explicit='{}', parent_wd='{}', effective='{}'",
            child_explicit_wd_path, parent_wd_path, effective_wd.display()
        );
    }

    /// Feature: working-directory-inheritance, Property 3 extended: Path resolution uses child's explicit WD
    /// **Validates: Requirements 3.1, 3.2**
    ///
    /// When resolving source() paths in a child file with explicit @lsp-cd,
    /// the path should resolve relative to the child's explicit WD, not the parent's.
    #[test]
    fn prop_path_resolution_uses_child_explicit_wd(
        workspace in path_component(),
        child_subdir in path_component(),
        child_explicit_wd in path_component(),
        parent_wd in path_component(),
        source_file in path_component(),
    ) {
        // Ensure child's explicit WD and parent's WD are different
        prop_assume!(child_explicit_wd != parent_wd);

        // Create file URI: /workspace/child_subdir/child.R
        let file_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, child_subdir)).unwrap();
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Child has explicit @lsp-cd and inherited WD from parent
        let child_explicit_wd_path = format!("/{}", child_explicit_wd);
        let parent_wd_path = format!("/{}", parent_wd);

        let meta = CrossFileMetadata {
            working_directory: Some(child_explicit_wd_path.clone()),
            inherited_working_directory: Some(parent_wd_path.clone()),
            ..Default::default()
        };

        // Construct PathContext from metadata
        let ctx = PathContext::from_metadata(&file_uri, &meta, Some(&workspace_uri));
        prop_assert!(ctx.is_some(), "PathContext::from_metadata should succeed");
        let ctx = ctx.unwrap();

        // Resolve a relative path (simulating source("file.R"))
        let source_path = format!("{}.R", source_file);
        let resolved = resolve_path(&source_path, &ctx);

        prop_assert!(resolved.is_some(), "Path resolution should succeed");
        let resolved = resolved.unwrap();

        // The path should resolve relative to child's explicit WD
        // (workspace-relative /child_explicit_wd resolves to /workspace/child_explicit_wd)
        let expected_resolved = PathBuf::from(format!("/{}/{}/{}.R", workspace, child_explicit_wd, source_file));

        prop_assert!(
            resolved == expected_resolved,
            "Path should resolve relative to child's explicit WD, not parent's. \
             source_path='{}', child_explicit_wd='{}', parent_wd='{}', expected='{}', got='{}'",
            source_path, child_explicit_wd_path, parent_wd_path, expected_resolved.display(), resolved.display()
        );

        // Verify it's NOT resolved relative to parent's WD
        let parent_resolved = PathBuf::from(format!("/{}/{}/{}.R", workspace, parent_wd, source_file));
        prop_assert!(
            resolved != parent_resolved,
            "Path should NOT resolve relative to parent's WD. \
             source_path='{}', resolved='{}', parent_would_be='{}'",
            source_path, resolved.display(), parent_resolved.display()
        );
    }

    /// Feature: working-directory-inheritance, Property 3 extended: Absolute explicit WD takes precedence
    /// **Validates: Requirements 3.1, 3.2**
    ///
    /// When child has an absolute path @lsp-cd, it should take precedence over inherited WD.
    #[test]
    fn prop_absolute_explicit_wd_precedence(
        workspace in path_component(),
        child_subdir in path_component(),
        absolute_wd_dir in path_component(),
        parent_wd in path_component(),
    ) {
        // Ensure absolute WD and parent's WD are different
        prop_assume!(absolute_wd_dir != parent_wd);

        // Create file URI: /workspace/child_subdir/child.R
        let file_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, child_subdir)).unwrap();
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Child has absolute @lsp-cd (workspace-relative starting with /)
        let child_explicit_wd_path = format!("/{}", absolute_wd_dir);
        let parent_wd_path = format!("/{}", parent_wd);

        let meta = CrossFileMetadata {
            working_directory: Some(child_explicit_wd_path.clone()),
            inherited_working_directory: Some(parent_wd_path.clone()),
            ..Default::default()
        };

        // Construct PathContext from metadata
        let ctx = PathContext::from_metadata(&file_uri, &meta, Some(&workspace_uri));
        prop_assert!(ctx.is_some(), "PathContext::from_metadata should succeed");
        let ctx = ctx.unwrap();

        // Compute effective working directory
        let effective_wd = ctx.effective_working_directory();

        // The effective working directory should be the child's explicit WD
        // (workspace-relative /absolute_wd_dir resolves to /workspace/absolute_wd_dir)
        let expected_wd = PathBuf::from(format!("/{}/{}", workspace, absolute_wd_dir));

        prop_assert!(
            effective_wd == expected_wd,
            "Absolute explicit WD should take precedence over inherited WD. \
             child_explicit='{}', parent_wd='{}', expected='{}', got='{}'",
            child_explicit_wd_path, parent_wd_path, expected_wd.display(), effective_wd.display()
        );
    }

    /// Feature: working-directory-inheritance, Property 3 extended: Relative explicit WD takes precedence
    /// **Validates: Requirements 3.1, 3.2**
    ///
    /// When child has a relative path @lsp-cd, it should take precedence over inherited WD.
    #[test]
    fn prop_relative_explicit_wd_precedence(
        workspace in path_component(),
        child_subdir in path_component(),
        relative_wd_dir in path_component(),
        parent_wd in path_component(),
    ) {
        // Ensure relative WD and parent's WD are different
        prop_assume!(relative_wd_dir != parent_wd);

        // Create file URI: /workspace/child_subdir/child.R
        let file_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, child_subdir)).unwrap();
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Child has relative @lsp-cd (relative to file's directory)
        let child_explicit_wd_path = format!("../{}", relative_wd_dir);
        let parent_wd_path = format!("/{}", parent_wd);

        let meta = CrossFileMetadata {
            working_directory: Some(child_explicit_wd_path.clone()),
            inherited_working_directory: Some(parent_wd_path.clone()),
            ..Default::default()
        };

        // Construct PathContext from metadata
        let ctx = PathContext::from_metadata(&file_uri, &meta, Some(&workspace_uri));
        prop_assert!(ctx.is_some(), "PathContext::from_metadata should succeed");
        let ctx = ctx.unwrap();

        // Compute effective working directory
        let effective_wd = ctx.effective_working_directory();

        // The relative path "../relative_wd_dir" from /workspace/child_subdir/
        // should resolve to /workspace/relative_wd_dir
        let expected_wd = PathBuf::from(format!("/{}/{}", workspace, relative_wd_dir));

        prop_assert!(
            effective_wd == expected_wd,
            "Relative explicit WD should take precedence over inherited WD. \
             child_explicit='{}', parent_wd='{}', expected='{}', got='{}'",
            child_explicit_wd_path, parent_wd_path, expected_wd.display(), effective_wd.display()
        );

        // Verify it's NOT the parent's WD
        let parent_resolved_wd = PathBuf::from(format!("/{}/{}", workspace, parent_wd));
        prop_assert!(
            effective_wd != parent_resolved_wd,
            "Effective WD should NOT equal parent's WD. \
             child_explicit='{}', parent_wd='{}', effective='{}'",
            child_explicit_wd_path, parent_wd_path, effective_wd.display()
        );
    }

    /// Feature: working-directory-inheritance, Property 3 extended: Empty explicit WD still takes precedence
    /// **Validates: Requirements 3.1, 3.2**
    ///
    /// When child has @lsp-cd: . (current directory), it should still take precedence over inherited WD.
    #[test]
    fn prop_current_dir_explicit_wd_precedence(
        workspace in path_component(),
        child_subdir in path_component(),
        parent_wd in path_component(),
    ) {
        // Ensure child's directory and parent's WD are different
        prop_assume!(child_subdir != parent_wd);

        // Create file URI: /workspace/child_subdir/child.R
        let file_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, child_subdir)).unwrap();
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Child has @lsp-cd: . (current directory)
        let child_explicit_wd_path = ".".to_string();
        let parent_wd_path = format!("/{}", parent_wd);

        let meta = CrossFileMetadata {
            working_directory: Some(child_explicit_wd_path.clone()),
            inherited_working_directory: Some(parent_wd_path.clone()),
            ..Default::default()
        };

        // Construct PathContext from metadata
        let ctx = PathContext::from_metadata(&file_uri, &meta, Some(&workspace_uri));
        prop_assert!(ctx.is_some(), "PathContext::from_metadata should succeed");
        let ctx = ctx.unwrap();

        // Compute effective working directory
        let effective_wd = ctx.effective_working_directory();

        // The "." path should resolve to the file's directory: /workspace/child_subdir
        let expected_wd = PathBuf::from(format!("/{}/{}", workspace, child_subdir));

        prop_assert!(
            effective_wd == expected_wd,
            "Explicit @lsp-cd: . should resolve to file's directory and take precedence. \
             child_explicit='{}', parent_wd='{}', expected='{}', got='{}'",
            child_explicit_wd_path, parent_wd_path, expected_wd.display(), effective_wd.display()
        );

        // Verify it's NOT the parent's WD
        let parent_resolved_wd = PathBuf::from(format!("/{}/{}", workspace, parent_wd));
        prop_assert!(
            effective_wd != parent_resolved_wd,
            "Effective WD should NOT equal parent's WD even with @lsp-cd: . \
             child_explicit='{}', parent_wd='{}', effective='{}'",
            child_explicit_wd_path, parent_wd_path, effective_wd.display()
        );
    }
}

// ============================================================================
// Feature: working-directory-inheritance
// Property 1: Parent Effective Working Directory Inheritance
// Validates: Requirements 1.1, 2.1, 2.2
// ============================================================================

use super::dependency::compute_inherited_working_directory;

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: working-directory-inheritance, Property 1: Parent Effective Working Directory Inheritance
    /// **Validates: Requirements 1.1, 2.1, 2.2**
    ///
    /// For any child file with a backward directive pointing to a parent file, when the child
    /// has no explicit @lsp-cd directive, the child's inherited working directory SHALL equal
    /// the parent's effective working directory (whether the parent has an explicit @lsp-cd
    /// or uses its own directory as default).
    #[test]
    fn prop_parent_effective_wd_inheritance_explicit_parent_wd(
        workspace in path_component(),
        parent_subdir in path_component(),
        child_subdir in path_component(),
        parent_explicit_wd in path_component(),
    ) {
        // Ensure parent and child are in different directories
        prop_assume!(parent_subdir != child_subdir);

        // Create workspace root URI
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Create parent file URI: /workspace/parent_subdir/parent.R
        let parent_uri = Url::parse(&format!("file:///{}/{}/parent.R", workspace, parent_subdir)).unwrap();

        // Create child file URI: /workspace/child_subdir/child.R
        let child_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, child_subdir)).unwrap();

        // Parent has explicit @lsp-cd directive (workspace-relative path)
        let parent_explicit_wd_path = format!("/{}", parent_explicit_wd);
        let parent_meta = CrossFileMetadata {
            working_directory: Some(parent_explicit_wd_path.clone()),
            inherited_working_directory: None,
            ..Default::default()
        };

        // Child has backward directive pointing to parent, no explicit @lsp-cd
        // The backward directive path is relative to child's directory
        let backward_path = format!("../{}/parent.R", parent_subdir);
        let child_meta = CrossFileMetadata {
            sourced_by: vec![BackwardDirective {
                path: backward_path.clone(),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            working_directory: None, // No explicit @lsp-cd
            inherited_working_directory: None, // Will be computed
            ..Default::default()
        };

        // Create a metadata getter that returns parent's metadata
        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri {
                Some(std::sync::Arc::new(parent_meta.clone()))
            } else {
                None
            }
        };

        // Compute inherited working directory for child
        let inherited_wd = compute_inherited_working_directory(
            &child_uri,
            &child_meta,
            Some(&workspace_uri),
            get_metadata,
        );

        // The inherited WD should be the parent's effective working directory
        // Parent's explicit @lsp-cd is workspace-relative, so it resolves to /workspace/parent_explicit_wd
        let expected_inherited_wd = format!("/{}/{}", workspace, parent_explicit_wd);

        prop_assert!(
            inherited_wd.is_some(),
            "Inherited working directory should be computed. \
             parent_explicit_wd='{}', backward_path='{}'",
            parent_explicit_wd_path, backward_path
        );

        prop_assert_eq!(
            inherited_wd.as_ref().unwrap(),
            &expected_inherited_wd,
            "Inherited WD should equal parent's effective WD. \
             parent_explicit_wd='{}', expected='{}', got='{}'",
            parent_explicit_wd_path, expected_inherited_wd, inherited_wd.as_ref().unwrap()
        );
    }

    /// Feature: working-directory-inheritance, Property 1 extended: Parent with implicit WD (no @lsp-cd)
    /// **Validates: Requirements 2.1, 2.2**
    ///
    /// When the parent has no explicit @lsp-cd, the child should inherit the parent's directory
    /// as the working directory.
    #[test]
    fn prop_parent_effective_wd_inheritance_implicit_parent_wd(
        workspace in path_component(),
        parent_subdir in path_component(),
        child_subdir in path_component(),
    ) {
        // Ensure parent and child are in different directories
        prop_assume!(parent_subdir != child_subdir);

        // Create workspace root URI
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Create parent file URI: /workspace/parent_subdir/parent.R
        let parent_uri = Url::parse(&format!("file:///{}/{}/parent.R", workspace, parent_subdir)).unwrap();

        // Create child file URI: /workspace/child_subdir/child.R
        let child_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, child_subdir)).unwrap();

        // Parent has NO explicit @lsp-cd directive
        let parent_meta = CrossFileMetadata {
            working_directory: None, // No explicit @lsp-cd
            inherited_working_directory: None,
            ..Default::default()
        };

        // Child has backward directive pointing to parent, no explicit @lsp-cd
        let backward_path = format!("../{}/parent.R", parent_subdir);
        let child_meta = CrossFileMetadata {
            sourced_by: vec![BackwardDirective {
                path: backward_path.clone(),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            ..Default::default()
        };

        // Create a metadata getter that returns parent's metadata
        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri {
                Some(std::sync::Arc::new(parent_meta.clone()))
            } else {
                None
            }
        };

        // Compute inherited working directory for child
        let inherited_wd = compute_inherited_working_directory(
            &child_uri,
            &child_meta,
            Some(&workspace_uri),
            get_metadata,
        );

        // The inherited WD should be the parent's directory (since parent has no explicit @lsp-cd)
        // Parent's directory is /workspace/parent_subdir
        let expected_inherited_wd = format!("/{}/{}", workspace, parent_subdir);

        prop_assert!(
            inherited_wd.is_some(),
            "Inherited working directory should be computed even when parent has no explicit @lsp-cd. \
             backward_path='{}'",
            backward_path
        );

        prop_assert_eq!(
            inherited_wd.as_ref().unwrap(),
            &expected_inherited_wd,
            "Inherited WD should equal parent's directory when parent has no explicit @lsp-cd. \
             expected='{}', got='{}'",
            expected_inherited_wd, inherited_wd.as_ref().unwrap()
        );
    }

    /// Feature: working-directory-inheritance, Property 1 extended: Child with explicit @lsp-cd skips inheritance
    /// **Validates: Requirements 1.1 (negative case)**
    ///
    /// When the child has its own explicit @lsp-cd, inheritance should be skipped.
    #[test]
    fn prop_parent_wd_inheritance_skipped_when_child_has_explicit_wd(
        workspace in path_component(),
        parent_subdir in path_component(),
        child_subdir in path_component(),
        parent_explicit_wd in path_component(),
        child_explicit_wd in path_component(),
    ) {
        // Ensure parent and child are in different directories
        prop_assume!(parent_subdir != child_subdir);

        // Create workspace root URI
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Create parent file URI: /workspace/parent_subdir/parent.R
        let parent_uri = Url::parse(&format!("file:///{}/{}/parent.R", workspace, parent_subdir)).unwrap();

        // Create child file URI: /workspace/child_subdir/child.R
        let child_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, child_subdir)).unwrap();

        // Parent has explicit @lsp-cd directive
        let parent_explicit_wd_path = format!("/{}", parent_explicit_wd);
        let parent_meta = CrossFileMetadata {
            working_directory: Some(parent_explicit_wd_path.clone()),
            inherited_working_directory: None,
            ..Default::default()
        };

        // Child has backward directive AND its own explicit @lsp-cd
        let backward_path = format!("../{}/parent.R", parent_subdir);
        let child_explicit_wd_path = format!("/{}", child_explicit_wd);
        let child_meta = CrossFileMetadata {
            sourced_by: vec![BackwardDirective {
                path: backward_path.clone(),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            working_directory: Some(child_explicit_wd_path.clone()), // Child has explicit @lsp-cd
            inherited_working_directory: None,
            ..Default::default()
        };

        // Create a metadata getter that returns parent's metadata
        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri {
                Some(std::sync::Arc::new(parent_meta.clone()))
            } else {
                None
            }
        };

        // Compute inherited working directory for child
        let inherited_wd = compute_inherited_working_directory(
            &child_uri,
            &child_meta,
            Some(&workspace_uri),
            get_metadata,
        );

        // Inheritance should be skipped because child has explicit @lsp-cd
        prop_assert!(
            inherited_wd.is_none(),
            "Inherited WD should be None when child has explicit @lsp-cd. \
             child_explicit_wd='{}', parent_explicit_wd='{}', got='{:?}'",
            child_explicit_wd_path, parent_explicit_wd_path, inherited_wd
        );
    }

    /// Feature: working-directory-inheritance, Property 1 extended: No backward directive means no inheritance
    /// **Validates: Requirements 1.1 (negative case)**
    ///
    /// When the child has no backward directive, there's nothing to inherit from.
    #[test]
    fn prop_no_inheritance_without_backward_directive(
        workspace in path_component(),
        child_subdir in path_component(),
    ) {
        // Create workspace root URI
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Create child file URI: /workspace/child_subdir/child.R
        let child_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, child_subdir)).unwrap();

        // Child has NO backward directive
        let child_meta = CrossFileMetadata {
            sourced_by: vec![], // No backward directives
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            ..Default::default()
        };

        // Create a metadata getter (won't be called since there's no backward directive)
        let get_metadata = |_uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            None
        };

        // Compute inherited working directory for child
        let inherited_wd = compute_inherited_working_directory(
            &child_uri,
            &child_meta,
            Some(&workspace_uri),
            get_metadata,
        );

        // No inheritance should occur
        prop_assert!(
            inherited_wd.is_none(),
            "Inherited WD should be None when child has no backward directive. got='{:?}'",
            inherited_wd
        );
    }



    /// Feature: working-directory-inheritance, Property 1 extended: Parent with relative @lsp-cd
    /// **Validates: Requirements 1.1, 2.2**
    ///
    /// When parent has a relative @lsp-cd path, it should resolve relative to parent's directory.
    #[test]
    fn prop_parent_effective_wd_inheritance_relative_parent_wd(
        workspace in path_component(),
        parent_subdir in path_component(),
        child_subdir in path_component(),
        relative_wd_target in path_component(),
    ) {
        // Ensure parent and child are in different directories
        prop_assume!(parent_subdir != child_subdir);
        // Ensure relative WD target is different from parent's subdir
        prop_assume!(relative_wd_target != parent_subdir);

        // Create workspace root URI
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Create parent file URI: /workspace/parent_subdir/parent.R
        let parent_uri = Url::parse(&format!("file:///{}/{}/parent.R", workspace, parent_subdir)).unwrap();

        // Create child file URI: /workspace/child_subdir/child.R
        let child_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, child_subdir)).unwrap();

        // Parent has relative @lsp-cd directive (relative to parent's directory)
        // "../relative_wd_target" from /workspace/parent_subdir/ resolves to /workspace/relative_wd_target
        let parent_relative_wd_path = format!("../{}", relative_wd_target);
        let parent_meta = CrossFileMetadata {
            working_directory: Some(parent_relative_wd_path.clone()),
            inherited_working_directory: None,
            ..Default::default()
        };

        // Child has backward directive pointing to parent, no explicit @lsp-cd
        let backward_path = format!("../{}/parent.R", parent_subdir);
        let child_meta = CrossFileMetadata {
            sourced_by: vec![BackwardDirective {
                path: backward_path.clone(),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            ..Default::default()
        };

        // Create a metadata getter that returns parent's metadata
        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri {
                Some(std::sync::Arc::new(parent_meta.clone()))
            } else {
                None
            }
        };

        // Compute inherited working directory for child
        let inherited_wd = compute_inherited_working_directory(
            &child_uri,
            &child_meta,
            Some(&workspace_uri),
            get_metadata,
        );

        // The inherited WD should be the parent's effective working directory
        // Parent's relative @lsp-cd "../relative_wd_target" from /workspace/parent_subdir/
        // resolves to /workspace/relative_wd_target
        let expected_inherited_wd = format!("/{}/{}", workspace, relative_wd_target);

        prop_assert!(
            inherited_wd.is_some(),
            "Inherited working directory should be computed. \
             parent_relative_wd='{}', backward_path='{}'",
            parent_relative_wd_path, backward_path
        );

        prop_assert_eq!(
            inherited_wd.as_ref().unwrap(),
            &expected_inherited_wd,
            "Inherited WD should equal parent's effective WD (resolved relative path). \
             parent_relative_wd='{}', expected='{}', got='{}'",
            parent_relative_wd_path, expected_inherited_wd, inherited_wd.as_ref().unwrap()
        );
    }
}

// ============================================================================
// Feature: working-directory-inheritance
// Property 5: Fallback When Parent Metadata Unavailable
// Validates: Requirements 5.3
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: working-directory-inheritance, Property 5: Fallback When Parent Metadata Unavailable
    /// **Validates: Requirements 5.3**
    ///
    /// For any child file with a backward directive where the parent file's metadata cannot
    /// be retrieved, the system SHALL use the parent file's directory as the inherited
    /// working directory.
    #[test]
    fn prop_fallback_when_parent_metadata_unavailable(
        workspace in path_component(),
        parent_subdir in path_component(),
        child_subdir in path_component(),
    ) {
        // Ensure parent and child are in different directories
        prop_assume!(parent_subdir != child_subdir);

        // Create workspace root URI
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Parent file URI: /workspace/parent_subdir/parent.R
        // (Not used directly, but the backward directive path resolves to this)
        let _parent_uri = Url::parse(&format!("file:///{}/{}/parent.R", workspace, parent_subdir)).unwrap();

        // Create child file URI: /workspace/child_subdir/child.R
        let child_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, child_subdir)).unwrap();

        // Child has backward directive pointing to parent, no explicit @lsp-cd
        let backward_path = format!("../{}/parent.R", parent_subdir);
        let child_meta = CrossFileMetadata {
            sourced_by: vec![BackwardDirective {
                path: backward_path.clone(),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            ..Default::default()
        };

        // Create a metadata getter that ALWAYS returns None (simulating unavailable metadata)
        let get_metadata = |_uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            None // Parent metadata is unavailable
        };

        // Compute inherited working directory for child
        let inherited_wd = compute_inherited_working_directory(
            &child_uri,
            &child_meta,
            Some(&workspace_uri),
            get_metadata,
        );

        // The inherited WD should fall back to the parent's directory
        // Parent's directory is /workspace/parent_subdir
        let expected_inherited_wd = format!("/{}/{}", workspace, parent_subdir);

        prop_assert!(
            inherited_wd.is_some(),
            "Inherited working directory should be computed even when parent metadata is unavailable. \
             backward_path='{}', expected fallback to parent's directory='{}'",
            backward_path, expected_inherited_wd
        );

        prop_assert_eq!(
            inherited_wd.as_ref().unwrap(),
            &expected_inherited_wd,
            "When parent metadata is unavailable, inherited WD should fall back to parent's directory. \
             expected='{}', got='{}'",
            expected_inherited_wd, inherited_wd.as_ref().unwrap()
        );
    }


    /// Feature: working-directory-inheritance, Property 5 extended: Fallback with nested parent directory
    /// **Validates: Requirements 5.3**
    ///
    /// Test fallback behavior when parent is in a deeply nested directory structure.
    #[test]
    fn prop_fallback_with_nested_parent_directory(
        workspace in path_component(),
        parent_dir1 in path_component(),
        parent_dir2 in path_component(),
        child_subdir in path_component(),
    ) {
        // Ensure directories are different
        prop_assume!(parent_dir1 != child_subdir);
        prop_assume!(parent_dir2 != child_subdir);

        // Create workspace root URI
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Parent file URI in nested directory: /workspace/parent_dir1/parent_dir2/parent.R
        // (Not used directly, but the backward directive path resolves to this)
        let _parent_uri = Url::parse(&format!(
            "file:///{}/{}/{}/parent.R",
            workspace, parent_dir1, parent_dir2
        )).unwrap();

        // Create child file URI: /workspace/child_subdir/child.R
        let child_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, child_subdir)).unwrap();

        // Child has backward directive pointing to nested parent
        let backward_path = format!("../{}/{}/parent.R", parent_dir1, parent_dir2);
        let child_meta = CrossFileMetadata {
            sourced_by: vec![BackwardDirective {
                path: backward_path.clone(),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            ..Default::default()
        };

        // Create a metadata getter that ALWAYS returns None
        let get_metadata = |_uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            None // Parent metadata is unavailable
        };

        // Compute inherited working directory for child
        let inherited_wd = compute_inherited_working_directory(
            &child_uri,
            &child_meta,
            Some(&workspace_uri),
            get_metadata,
        );

        // The inherited WD should fall back to the parent's directory (nested)
        let expected_inherited_wd = format!("/{}/{}/{}", workspace, parent_dir1, parent_dir2);

        prop_assert!(
            inherited_wd.is_some(),
            "Inherited working directory should be computed for nested parent directory. \
             backward_path='{}', expected fallback='{}'",
            backward_path, expected_inherited_wd
        );

        prop_assert_eq!(
            inherited_wd.as_ref().unwrap(),
            &expected_inherited_wd,
            "Fallback should use nested parent's directory. \
             expected='{}', got='{}'",
            expected_inherited_wd, inherited_wd.as_ref().unwrap()
        );
    }

}

// ============================================================================
// Feature: working-directory-inheritance
// Property 7: First Backward Directive Wins
// Validates: Requirements 7.1, 7.2
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: working-directory-inheritance, Property 7: First Backward Directive Wins
    /// **Validates: Requirements 7.1, 7.2**
    ///
    /// For any child file with multiple backward directives pointing to different parent files
    /// with different effective working directories, the inherited working directory SHALL equal
    /// the first parent's (in document order) effective working directory.
    #[test]
    fn prop_first_backward_directive_wins(
        workspace in path_component(),
        parent1_subdir in path_component(),
        parent2_subdir in path_component(),
        child_subdir in path_component(),
        parent1_explicit_wd in path_component(),
        parent2_explicit_wd in path_component(),
    ) {
        // Ensure all directories are different
        prop_assume!(parent1_subdir != parent2_subdir);
        prop_assume!(parent1_subdir != child_subdir);
        prop_assume!(parent2_subdir != child_subdir);
        // Ensure the two parents have different working directories
        prop_assume!(parent1_explicit_wd != parent2_explicit_wd);

        // Create workspace root URI
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Create parent1 file URI: /workspace/parent1_subdir/parent1.R
        let parent1_uri = Url::parse(&format!(
            "file:///{}/{}/parent1.R",
            workspace, parent1_subdir
        )).unwrap();

        // Create parent2 file URI: /workspace/parent2_subdir/parent2.R
        let parent2_uri = Url::parse(&format!(
            "file:///{}/{}/parent2.R",
            workspace, parent2_subdir
        )).unwrap();

        // Create child file URI: /workspace/child_subdir/child.R
        let child_uri = Url::parse(&format!(
            "file:///{}/{}/child.R",
            workspace, child_subdir
        )).unwrap();

        // Parent1 has explicit @lsp-cd directive (workspace-relative path)
        let parent1_explicit_wd_path = format!("/{}", parent1_explicit_wd);
        let parent1_meta = CrossFileMetadata {
            working_directory: Some(parent1_explicit_wd_path.clone()),
            inherited_working_directory: None,
            ..Default::default()
        };

        // Parent2 has a DIFFERENT explicit @lsp-cd directive
        let parent2_explicit_wd_path = format!("/{}", parent2_explicit_wd);
        let parent2_meta = CrossFileMetadata {
            working_directory: Some(parent2_explicit_wd_path.clone()),
            inherited_working_directory: None,
            ..Default::default()
        };

        // Child has TWO backward directives pointing to different parents
        // The first directive (document order) points to parent1
        // The second directive points to parent2
        let backward_path1 = format!("../{}/parent1.R", parent1_subdir);
        let backward_path2 = format!("../{}/parent2.R", parent2_subdir);
        let child_meta = CrossFileMetadata {
            sourced_by: vec![
                BackwardDirective {
                    path: backward_path1.clone(),
                    call_site: CallSiteSpec::Default,
                    directive_line: 0, // First in document order
                },
                BackwardDirective {
                    path: backward_path2.clone(),
                    call_site: CallSiteSpec::Default,
                    directive_line: 1, // Second in document order
                },
            ],
            working_directory: None, // No explicit @lsp-cd
            inherited_working_directory: None,
            ..Default::default()
        };

        // Create a metadata getter that returns the appropriate parent's metadata
        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent1_uri {
                Some(std::sync::Arc::new(parent1_meta.clone()))
            } else if uri == &parent2_uri {
                Some(std::sync::Arc::new(parent2_meta.clone()))
            } else {
                None
            }
        };

        // Compute inherited working directory for child
        let inherited_wd = compute_inherited_working_directory(
            &child_uri,
            &child_meta,
            Some(&workspace_uri),
            get_metadata,
        );

        // The inherited WD should be the FIRST parent's effective working directory
        // NOT the second parent's
        let expected_inherited_wd = format!("/{}/{}", workspace, parent1_explicit_wd);
        let unexpected_inherited_wd = format!("/{}/{}", workspace, parent2_explicit_wd);

        prop_assert!(
            inherited_wd.is_some(),
            "Inherited working directory should be computed from first backward directive. \
             backward_path1='{}', backward_path2='{}'",
            backward_path1, backward_path2
        );

        prop_assert_eq!(
            inherited_wd.as_ref().unwrap(),
            &expected_inherited_wd,
            "Inherited WD should equal FIRST parent's effective WD (document order). \
             parent1_wd='{}', parent2_wd='{}', expected='{}', got='{}'",
            parent1_explicit_wd_path, parent2_explicit_wd_path,
            expected_inherited_wd, inherited_wd.as_ref().unwrap()
        );

        prop_assert_ne!(
            inherited_wd.as_ref().unwrap(),
            &unexpected_inherited_wd,
            "Inherited WD should NOT equal second parent's WD. \
             parent1_wd='{}', parent2_wd='{}', got='{}'",
            parent1_explicit_wd_path, parent2_explicit_wd_path,
            inherited_wd.as_ref().unwrap()
        );
    }

    /// Feature: working-directory-inheritance, Property 7 extended: First directive wins with implicit WDs
    /// **Validates: Requirements 7.1, 7.2**
    ///
    /// When multiple backward directives exist and parents have implicit working directories
    /// (no @lsp-cd), the first parent's directory should be used.
    #[test]
    fn prop_first_backward_directive_wins_implicit_wds(
        workspace in path_component(),
        parent1_subdir in path_component(),
        parent2_subdir in path_component(),
        child_subdir in path_component(),
    ) {
        // Ensure all directories are different
        prop_assume!(parent1_subdir != parent2_subdir);
        prop_assume!(parent1_subdir != child_subdir);
        prop_assume!(parent2_subdir != child_subdir);

        // Create workspace root URI
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Create parent1 file URI: /workspace/parent1_subdir/parent1.R
        let parent1_uri = Url::parse(&format!(
            "file:///{}/{}/parent1.R",
            workspace, parent1_subdir
        )).unwrap();

        // Create parent2 file URI: /workspace/parent2_subdir/parent2.R
        let parent2_uri = Url::parse(&format!(
            "file:///{}/{}/parent2.R",
            workspace, parent2_subdir
        )).unwrap();

        // Create child file URI: /workspace/child_subdir/child.R
        let child_uri = Url::parse(&format!(
            "file:///{}/{}/child.R",
            workspace, child_subdir
        )).unwrap();

        // Both parents have NO explicit @lsp-cd (implicit WD = their directory)
        let parent1_meta = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            ..Default::default()
        };

        let parent2_meta = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            ..Default::default()
        };

        // Child has TWO backward directives pointing to different parents
        let backward_path1 = format!("../{}/parent1.R", parent1_subdir);
        let backward_path2 = format!("../{}/parent2.R", parent2_subdir);
        let child_meta = CrossFileMetadata {
            sourced_by: vec![
                BackwardDirective {
                    path: backward_path1.clone(),
                    call_site: CallSiteSpec::Default,
                    directive_line: 0, // First in document order
                },
                BackwardDirective {
                    path: backward_path2.clone(),
                    call_site: CallSiteSpec::Default,
                    directive_line: 1, // Second in document order
                },
            ],
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            ..Default::default()
        };

        // Create a metadata getter that returns the appropriate parent's metadata
        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent1_uri {
                Some(std::sync::Arc::new(parent1_meta.clone()))
            } else if uri == &parent2_uri {
                Some(std::sync::Arc::new(parent2_meta.clone()))
            } else {
                None
            }
        };

        // Compute inherited working directory for child
        let inherited_wd = compute_inherited_working_directory(
            &child_uri,
            &child_meta,
            Some(&workspace_uri),
            get_metadata,
        );

        // The inherited WD should be the FIRST parent's directory (implicit WD)
        let expected_inherited_wd = format!("/{}/{}", workspace, parent1_subdir);
        let unexpected_inherited_wd = format!("/{}/{}", workspace, parent2_subdir);

        prop_assert!(
            inherited_wd.is_some(),
            "Inherited working directory should be computed from first backward directive. \
             backward_path1='{}', backward_path2='{}'",
            backward_path1, backward_path2
        );

        prop_assert_eq!(
            inherited_wd.as_ref().unwrap(),
            &expected_inherited_wd,
            "Inherited WD should equal FIRST parent's directory (implicit WD). \
             parent1_dir='{}', parent2_dir='{}', expected='{}', got='{}'",
            parent1_subdir, parent2_subdir,
            expected_inherited_wd, inherited_wd.as_ref().unwrap()
        );

        prop_assert_ne!(
            inherited_wd.as_ref().unwrap(),
            &unexpected_inherited_wd,
            "Inherited WD should NOT equal second parent's directory. \
             parent1_dir='{}', parent2_dir='{}', got='{}'",
            parent1_subdir, parent2_subdir,
            inherited_wd.as_ref().unwrap()
        );
    }

    /// Feature: working-directory-inheritance, Property 7 extended: First directive wins with mixed WDs
    /// **Validates: Requirements 7.1, 7.2**
    ///
    /// When the first parent has implicit WD and second has explicit WD,
    /// the first parent's implicit WD should still be used.
    #[test]
    fn prop_first_backward_directive_wins_mixed_wds(
        workspace in path_component(),
        parent1_subdir in path_component(),
        parent2_subdir in path_component(),
        child_subdir in path_component(),
        parent2_explicit_wd in path_component(),
    ) {
        // Ensure all directories are different
        prop_assume!(parent1_subdir != parent2_subdir);
        prop_assume!(parent1_subdir != child_subdir);
        prop_assume!(parent2_subdir != child_subdir);
        // Ensure parent2's explicit WD is different from parent1's directory
        prop_assume!(parent2_explicit_wd != parent1_subdir);

        // Create workspace root URI
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Create parent1 file URI: /workspace/parent1_subdir/parent1.R
        let parent1_uri = Url::parse(&format!(
            "file:///{}/{}/parent1.R",
            workspace, parent1_subdir
        )).unwrap();

        // Create parent2 file URI: /workspace/parent2_subdir/parent2.R
        let parent2_uri = Url::parse(&format!(
            "file:///{}/{}/parent2.R",
            workspace, parent2_subdir
        )).unwrap();

        // Create child file URI: /workspace/child_subdir/child.R
        let child_uri = Url::parse(&format!(
            "file:///{}/{}/child.R",
            workspace, child_subdir
        )).unwrap();

        // Parent1 has NO explicit @lsp-cd (implicit WD = its directory)
        let parent1_meta = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            ..Default::default()
        };

        // Parent2 HAS explicit @lsp-cd
        let parent2_explicit_wd_path = format!("/{}", parent2_explicit_wd);
        let parent2_meta = CrossFileMetadata {
            working_directory: Some(parent2_explicit_wd_path.clone()),
            inherited_working_directory: None,
            ..Default::default()
        };

        // Child has TWO backward directives - first to parent1 (implicit WD), second to parent2 (explicit WD)
        let backward_path1 = format!("../{}/parent1.R", parent1_subdir);
        let backward_path2 = format!("../{}/parent2.R", parent2_subdir);
        let child_meta = CrossFileMetadata {
            sourced_by: vec![
                BackwardDirective {
                    path: backward_path1.clone(),
                    call_site: CallSiteSpec::Default,
                    directive_line: 0, // First in document order
                },
                BackwardDirective {
                    path: backward_path2.clone(),
                    call_site: CallSiteSpec::Default,
                    directive_line: 1, // Second in document order
                },
            ],
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            ..Default::default()
        };

        // Create a metadata getter that returns the appropriate parent's metadata
        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent1_uri {
                Some(std::sync::Arc::new(parent1_meta.clone()))
            } else if uri == &parent2_uri {
                Some(std::sync::Arc::new(parent2_meta.clone()))
            } else {
                None
            }
        };

        // Compute inherited working directory for child
        let inherited_wd = compute_inherited_working_directory(
            &child_uri,
            &child_meta,
            Some(&workspace_uri),
            get_metadata,
        );

        // The inherited WD should be the FIRST parent's directory (implicit WD)
        // NOT the second parent's explicit WD
        let expected_inherited_wd = format!("/{}/{}", workspace, parent1_subdir);
        let unexpected_inherited_wd = format!("/{}/{}", workspace, parent2_explicit_wd);

        prop_assert!(
            inherited_wd.is_some(),
            "Inherited working directory should be computed from first backward directive. \
             backward_path1='{}', backward_path2='{}'",
            backward_path1, backward_path2
        );

        prop_assert_eq!(
            inherited_wd.as_ref().unwrap(),
            &expected_inherited_wd,
            "Inherited WD should equal FIRST parent's directory (implicit WD), \
             even when second parent has explicit WD. \
             parent1_dir='{}', parent2_explicit_wd='{}', expected='{}', got='{}'",
            parent1_subdir, parent2_explicit_wd_path,
            expected_inherited_wd, inherited_wd.as_ref().unwrap()
        );

        prop_assert_ne!(
            inherited_wd.as_ref().unwrap(),
            &unexpected_inherited_wd,
            "Inherited WD should NOT equal second parent's explicit WD. \
             parent1_dir='{}', parent2_explicit_wd='{}', got='{}'",
            parent1_subdir, parent2_explicit_wd_path,
            inherited_wd.as_ref().unwrap()
        );
    }

    /// Feature: working-directory-inheritance, Property 7 extended: Three backward directives
    /// **Validates: Requirements 7.1, 7.2**
    ///
    /// When three backward directives exist, only the first one should be used.
    #[test]
    fn prop_first_backward_directive_wins_three_directives(
        workspace in path_component(),
        parent1_subdir in path_component(),
        parent2_subdir in path_component(),
        parent3_subdir in path_component(),
        child_subdir in path_component(),
        parent1_explicit_wd in path_component(),
        parent2_explicit_wd in path_component(),
        parent3_explicit_wd in path_component(),
    ) {
        // Ensure all directories are different
        prop_assume!(parent1_subdir != parent2_subdir);
        prop_assume!(parent1_subdir != parent3_subdir);
        prop_assume!(parent2_subdir != parent3_subdir);
        prop_assume!(parent1_subdir != child_subdir);
        prop_assume!(parent2_subdir != child_subdir);
        prop_assume!(parent3_subdir != child_subdir);
        // Ensure all explicit WDs are different
        prop_assume!(parent1_explicit_wd != parent2_explicit_wd);
        prop_assume!(parent1_explicit_wd != parent3_explicit_wd);
        prop_assume!(parent2_explicit_wd != parent3_explicit_wd);

        // Create workspace root URI
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Create parent file URIs
        let parent1_uri = Url::parse(&format!(
            "file:///{}/{}/parent1.R",
            workspace, parent1_subdir
        )).unwrap();

        let parent2_uri = Url::parse(&format!(
            "file:///{}/{}/parent2.R",
            workspace, parent2_subdir
        )).unwrap();

        let parent3_uri = Url::parse(&format!(
            "file:///{}/{}/parent3.R",
            workspace, parent3_subdir
        )).unwrap();

        // Create child file URI
        let child_uri = Url::parse(&format!(
            "file:///{}/{}/child.R",
            workspace, child_subdir
        )).unwrap();

        // All parents have different explicit @lsp-cd directives
        let parent1_explicit_wd_path = format!("/{}", parent1_explicit_wd);
        let parent1_meta = CrossFileMetadata {
            working_directory: Some(parent1_explicit_wd_path.clone()),
            inherited_working_directory: None,
            ..Default::default()
        };

        let parent2_explicit_wd_path = format!("/{}", parent2_explicit_wd);
        let parent2_meta = CrossFileMetadata {
            working_directory: Some(parent2_explicit_wd_path.clone()),
            inherited_working_directory: None,
            ..Default::default()
        };

        let parent3_explicit_wd_path = format!("/{}", parent3_explicit_wd);
        let parent3_meta = CrossFileMetadata {
            working_directory: Some(parent3_explicit_wd_path.clone()),
            inherited_working_directory: None,
            ..Default::default()
        };

        // Child has THREE backward directives
        let backward_path1 = format!("../{}/parent1.R", parent1_subdir);
        let backward_path2 = format!("../{}/parent2.R", parent2_subdir);
        let backward_path3 = format!("../{}/parent3.R", parent3_subdir);
        let child_meta = CrossFileMetadata {
            sourced_by: vec![
                BackwardDirective {
                    path: backward_path1.clone(),
                    call_site: CallSiteSpec::Default,
                    directive_line: 0, // First in document order
                },
                BackwardDirective {
                    path: backward_path2.clone(),
                    call_site: CallSiteSpec::Default,
                    directive_line: 1, // Second in document order
                },
                BackwardDirective {
                    path: backward_path3.clone(),
                    call_site: CallSiteSpec::Default,
                    directive_line: 2, // Third in document order
                },
            ],
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            ..Default::default()
        };

        // Create a metadata getter that returns the appropriate parent's metadata
        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent1_uri {
                Some(std::sync::Arc::new(parent1_meta.clone()))
            } else if uri == &parent2_uri {
                Some(std::sync::Arc::new(parent2_meta.clone()))
            } else if uri == &parent3_uri {
                Some(std::sync::Arc::new(parent3_meta.clone()))
            } else {
                None
            }
        };

        // Compute inherited working directory for child
        let inherited_wd = compute_inherited_working_directory(
            &child_uri,
            &child_meta,
            Some(&workspace_uri),
            get_metadata,
        );

        // The inherited WD should be the FIRST parent's effective working directory
        let expected_inherited_wd = format!("/{}/{}", workspace, parent1_explicit_wd);

        prop_assert!(
            inherited_wd.is_some(),
            "Inherited working directory should be computed from first backward directive."
        );

        prop_assert_eq!(
            inherited_wd.as_ref().unwrap(),
            &expected_inherited_wd,
            "Inherited WD should equal FIRST parent's effective WD, ignoring second and third. \
             parent1_wd='{}', parent2_wd='{}', parent3_wd='{}', expected='{}', got='{}'",
            parent1_explicit_wd_path, parent2_explicit_wd_path, parent3_explicit_wd_path,
            expected_inherited_wd, inherited_wd.as_ref().unwrap()
        );
    }
}

// ============================================================================
// Feature: working-directory-inheritance
// Property 2: Path Resolution Uses Inherited Working Directory
// Validates: Requirements 1.2, 1.3
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: working-directory-inheritance, Property 2: Path Resolution Uses Inherited Working Directory
    /// **Validates: Requirements 1.2, 1.3**
    ///
    /// For any source() call path in a child file that has inherited a working directory
    /// from a parent, resolving that path SHALL produce the same result as if the path
    /// were resolved from the parent's effective working directory.
    #[test]
    fn prop_path_resolution_uses_inherited_wd(
        workspace in path_component(),
        parent_subdir in path_component(),
        child_subdir in path_component(),
        parent_explicit_wd in path_component(),
        source_file in path_component(),
    ) {
        // Ensure parent and child are in different directories
        prop_assume!(parent_subdir != child_subdir);
        // Ensure parent's WD is different from child's directory
        prop_assume!(parent_explicit_wd != child_subdir);

        // Create workspace root URI
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Create parent file URI: /workspace/parent_subdir/parent.R
        let parent_uri = Url::parse(&format!("file:///{}/{}/parent.R", workspace, parent_subdir)).unwrap();

        // Create child file URI: /workspace/child_subdir/child.R
        let child_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, child_subdir)).unwrap();

        // Parent has explicit @lsp-cd (workspace-relative path)
        let parent_explicit_wd_path = format!("/{}", parent_explicit_wd);
        let parent_meta = CrossFileMetadata {
            working_directory: Some(parent_explicit_wd_path.clone()),
            inherited_working_directory: None,
            ..Default::default()
        };

        // Build parent's PathContext to get its effective working directory
        let parent_ctx = PathContext::from_metadata(&parent_uri, &parent_meta, Some(&workspace_uri));
        prop_assert!(parent_ctx.is_some(), "Parent PathContext should be created");
        let parent_ctx = parent_ctx.unwrap();
        let parent_effective_wd = parent_ctx.effective_working_directory();

        // Child inherits parent's working directory.
        // Per design doc: "The stored path is always absolute for consistent resolution"
        // So we store the parent's effective WD (already resolved to absolute).
        let child_meta = CrossFileMetadata {
            working_directory: None, // No explicit @lsp-cd
            // Store as absolute path (what compute_inherited_working_directory returns)
            inherited_working_directory: Some(parent_effective_wd.to_string_lossy().to_string()),
            ..Default::default()
        };

        // Build child's PathContext from metadata
        let child_ctx = PathContext::from_metadata(&child_uri, &child_meta, Some(&workspace_uri));
        prop_assert!(child_ctx.is_some(), "Child PathContext should be created");
        let child_ctx = child_ctx.unwrap();

        // Verify child's effective WD equals parent's effective WD
        let child_effective_wd = child_ctx.effective_working_directory();
        prop_assert_eq!(
            &child_effective_wd, &parent_effective_wd,
            "Child's effective WD should equal parent's effective WD"
        );

        // Resolve a relative path (simulating source("file.R") in child)
        let source_path = format!("{}.R", source_file);
        let resolved_from_child = resolve_path(&source_path, &child_ctx);

        // Also resolve the same path from parent's context (as reference)
        let resolved_from_parent = resolve_path(&source_path, &parent_ctx);

        // Both should succeed
        prop_assert!(resolved_from_child.is_some(), "Path resolution from child should succeed");
        prop_assert!(resolved_from_parent.is_some(), "Path resolution from parent should succeed");

        // Requirement 1.2: The path resolved from child (using inherited WD) should equal
        // the path resolved from parent (using its effective WD)
        prop_assert_eq!(
            resolved_from_child.as_ref().unwrap(),
            resolved_from_parent.as_ref().unwrap(),
            "Path resolved from child with inherited WD should equal path resolved from parent. \
             source_path='{}', parent_wd='{}', child_inherited_wd='{}', \
             resolved_from_child='{}', resolved_from_parent='{}'",
            source_path,
            parent_effective_wd.display(),
            child_effective_wd.display(),
            resolved_from_child.as_ref().unwrap().display(),
            resolved_from_parent.as_ref().unwrap().display()
        );
    }

    /// Feature: working-directory-inheritance, Property 2 extended: Workspace-relative path in parent WD
    /// **Validates: Requirements 1.2, 1.3**
    ///
    /// When the parent's @lsp-cd specifies a workspace-relative path (starting with /),
    /// the child should inherit the resolved absolute path and use it for source() resolution.
    #[test]
    fn prop_path_resolution_inherited_workspace_relative_wd(
        workspace in path_component(),
        parent_subdir in path_component(),
        child_subdir in path_component(),
        parent_wd_subdir in path_component(),
        source_file in path_component(),
    ) {
        // Ensure directories are different
        prop_assume!(parent_subdir != child_subdir);
        prop_assume!(parent_wd_subdir != child_subdir);

        // Create workspace root URI
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Create parent file URI: /workspace/parent_subdir/parent.R
        let parent_uri = Url::parse(&format!("file:///{}/{}/parent.R", workspace, parent_subdir)).unwrap();

        // Create child file URI: /workspace/child_subdir/child.R
        let child_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, child_subdir)).unwrap();

        // Parent has workspace-relative @lsp-cd (starts with /)
        let parent_explicit_wd_path = format!("/{}", parent_wd_subdir);
        let parent_meta = CrossFileMetadata {
            working_directory: Some(parent_explicit_wd_path.clone()),
            inherited_working_directory: None,
            ..Default::default()
        };

        // Build parent's PathContext
        let parent_ctx = PathContext::from_metadata(&parent_uri, &parent_meta, Some(&workspace_uri));
        prop_assert!(parent_ctx.is_some(), "Parent PathContext should be created");
        let parent_ctx = parent_ctx.unwrap();
        let parent_effective_wd = parent_ctx.effective_working_directory();

        // Verify parent's effective WD is workspace-relative resolved
        let expected_parent_wd = PathBuf::from(format!("/{}/{}", workspace, parent_wd_subdir));
        prop_assert_eq!(
            &parent_effective_wd, &expected_parent_wd,
            "Parent's effective WD should be workspace-relative resolved"
        );

        // Child inherits parent's working directory.
        // Per design doc: "The stored path is always absolute for consistent resolution"
        // So we store the parent's effective WD (already resolved to absolute).
        let child_meta = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: Some(parent_effective_wd.to_string_lossy().to_string()),
            ..Default::default()
        };

        // Build child's PathContext
        let child_ctx = PathContext::from_metadata(&child_uri, &child_meta, Some(&workspace_uri));
        prop_assert!(child_ctx.is_some(), "Child PathContext should be created");
        let child_ctx = child_ctx.unwrap();

        // Resolve a relative path from child
        let source_path = format!("{}.R", source_file);
        let resolved = resolve_path(&source_path, &child_ctx);

        prop_assert!(resolved.is_some(), "Path resolution should succeed");

        // The resolved path should be relative to parent's effective WD
        let expected_resolved = PathBuf::from(format!("/{}/{}/{}.R", workspace, parent_wd_subdir, source_file));
        prop_assert_eq!(
            resolved.as_ref().unwrap(),
            &expected_resolved,
            "Path should resolve relative to inherited (workspace-relative) WD. \
             source_path='{}', inherited_wd='{}', expected='{}', got='{}'",
            source_path,
            child_ctx.effective_working_directory().display(),
            expected_resolved.display(),
            resolved.as_ref().unwrap().display()
        );
    }

    /// Feature: working-directory-inheritance, Property 2 extended: Parent directory navigation in source path
    /// **Validates: Requirements 1.2, 1.3**
    ///
    /// When resolving source("../file.R") in a child with inherited WD, the path should
    /// resolve relative to the inherited WD, not the child's file directory.
    #[test]
    fn prop_path_resolution_inherited_wd_with_parent_nav(
        workspace in path_component(),
        parent_subdir in path_component(),
        child_subdir in path_component(),
        parent_wd_subdir in path_component(),
        target_subdir in path_component(),
        source_file in path_component(),
    ) {
        // Ensure directories are different
        prop_assume!(parent_subdir != child_subdir);
        prop_assume!(parent_wd_subdir != child_subdir);
        prop_assume!(parent_wd_subdir != target_subdir);

        // Create workspace root URI
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Create parent file URI: /workspace/parent_subdir/parent.R
        let parent_uri = Url::parse(&format!("file:///{}/{}/parent.R", workspace, parent_subdir)).unwrap();

        // Create child file URI: /workspace/child_subdir/child.R
        let child_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, child_subdir)).unwrap();

        // Parent has @lsp-cd pointing to a subdirectory: /workspace/parent_wd_subdir
        let parent_explicit_wd_path = format!("/{}", parent_wd_subdir);
        let parent_meta = CrossFileMetadata {
            working_directory: Some(parent_explicit_wd_path.clone()),
            inherited_working_directory: None,
            ..Default::default()
        };

        // Build parent's PathContext
        let parent_ctx = PathContext::from_metadata(&parent_uri, &parent_meta, Some(&workspace_uri));
        prop_assert!(parent_ctx.is_some(), "Parent PathContext should be created");
        let parent_ctx = parent_ctx.unwrap();
        let parent_effective_wd = parent_ctx.effective_working_directory();

        // Child inherits parent's working directory.
        // Per design doc: "The stored path is always absolute for consistent resolution"
        // So we store the parent's effective WD (already resolved to absolute).
        let child_meta = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: Some(parent_effective_wd.to_string_lossy().to_string()),
            ..Default::default()
        };

        // Build child's PathContext
        let child_ctx = PathContext::from_metadata(&child_uri, &child_meta, Some(&workspace_uri));
        prop_assert!(child_ctx.is_some(), "Child PathContext should be created");
        let child_ctx = child_ctx.unwrap();

        // Resolve a path with parent directory navigation: source("../target_subdir/file.R")
        let source_path = format!("../{}/{}.R", target_subdir, source_file);
        let resolved = resolve_path(&source_path, &child_ctx);

        prop_assert!(resolved.is_some(), "Path resolution should succeed");

        // The path "../target_subdir/file.R" from /workspace/parent_wd_subdir
        // should resolve to /workspace/target_subdir/file.R
        let expected_resolved = PathBuf::from(format!("/{}/{}/{}.R", workspace, target_subdir, source_file));
        prop_assert_eq!(
            resolved.as_ref().unwrap(),
            &expected_resolved,
            "Path with parent navigation should resolve relative to inherited WD. \
             source_path='{}', inherited_wd='{}', expected='{}', got='{}'",
            source_path,
            child_ctx.effective_working_directory().display(),
            expected_resolved.display(),
            resolved.as_ref().unwrap().display()
        );
    }

    /// Feature: working-directory-inheritance, Property 2 extended: Implicit parent WD inheritance
    /// **Validates: Requirements 1.2, 2.1**
    ///
    /// When the parent has no explicit @lsp-cd (uses its own directory as WD),
    /// the child should inherit the parent's directory as its working directory.
    #[test]
    fn prop_path_resolution_inherited_implicit_parent_wd(
        workspace in path_component(),
        parent_subdir in path_component(),
        child_subdir in path_component(),
        source_file in path_component(),
    ) {
        // Ensure parent and child are in different directories
        prop_assume!(parent_subdir != child_subdir);

        // Create workspace root URI
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Create parent file URI: /workspace/parent_subdir/parent.R
        let parent_uri = Url::parse(&format!("file:///{}/{}/parent.R", workspace, parent_subdir)).unwrap();

        // Create child file URI: /workspace/child_subdir/child.R
        let child_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, child_subdir)).unwrap();

        // Parent has NO explicit @lsp-cd (uses its own directory)
        let parent_meta = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            ..Default::default()
        };

        // Build parent's PathContext
        let parent_ctx = PathContext::from_metadata(&parent_uri, &parent_meta, Some(&workspace_uri));
        prop_assert!(parent_ctx.is_some(), "Parent PathContext should be created");
        let parent_ctx = parent_ctx.unwrap();
        let parent_effective_wd = parent_ctx.effective_working_directory();

        // Parent's effective WD should be its own directory
        let expected_parent_wd = PathBuf::from(format!("/{}/{}", workspace, parent_subdir));
        prop_assert_eq!(
            &parent_effective_wd, &expected_parent_wd,
            "Parent's effective WD should be its own directory when no @lsp-cd"
        );

        // Child inherits parent's directory as working directory.
        // Per design doc: "The stored path is always absolute for consistent resolution"
        // So we store the parent's effective WD (already resolved to absolute).
        let child_meta = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: Some(parent_effective_wd.to_string_lossy().to_string()),
            ..Default::default()
        };

        // Build child's PathContext
        let child_ctx = PathContext::from_metadata(&child_uri, &child_meta, Some(&workspace_uri));
        prop_assert!(child_ctx.is_some(), "Child PathContext should be created");
        let child_ctx = child_ctx.unwrap();

        // Resolve a relative path from child
        let source_path = format!("{}.R", source_file);
        let resolved_from_child = resolve_path(&source_path, &child_ctx);
        let resolved_from_parent = resolve_path(&source_path, &parent_ctx);

        prop_assert!(resolved_from_child.is_some(), "Path resolution from child should succeed");
        prop_assert!(resolved_from_parent.is_some(), "Path resolution from parent should succeed");

        // Both should resolve to the same path (relative to parent's directory)
        prop_assert_eq!(
            resolved_from_child.as_ref().unwrap(),
            resolved_from_parent.as_ref().unwrap(),
            "Path resolved from child with inherited implicit WD should equal path from parent. \
             source_path='{}', parent_dir='{}', child_inherited_wd='{}', \
             resolved_from_child='{}', resolved_from_parent='{}'",
            source_path,
            parent_effective_wd.display(),
            child_ctx.effective_working_directory().display(),
            resolved_from_child.as_ref().unwrap().display(),
            resolved_from_parent.as_ref().unwrap().display()
        );

        // Verify the resolved path is in parent's directory, not child's
        let expected_resolved = PathBuf::from(format!("/{}/{}/{}.R", workspace, parent_subdir, source_file));
        prop_assert_eq!(
            resolved_from_child.as_ref().unwrap(),
            &expected_resolved,
            "Path should resolve relative to parent's directory (inherited WD)"
        );
    }

    /// Feature: working-directory-inheritance, Property 2 extended: Child without inherited WD uses own directory
    /// **Validates: Requirements 1.2**
    ///
    /// When a child has no inherited working directory, source() paths should resolve
    /// relative to the child's own directory (baseline behavior).
    #[test]
    fn prop_path_resolution_no_inherited_wd_uses_child_dir(
        workspace in path_component(),
        child_subdir in path_component(),
        source_file in path_component(),
    ) {
        // Create workspace root URI
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Create child file URI: /workspace/child_subdir/child.R
        let child_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, child_subdir)).unwrap();

        // Child has NO inherited working directory
        let child_meta = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            ..Default::default()
        };

        // Build child's PathContext
        let child_ctx = PathContext::from_metadata(&child_uri, &child_meta, Some(&workspace_uri));
        prop_assert!(child_ctx.is_some(), "Child PathContext should be created");
        let child_ctx = child_ctx.unwrap();

        // Resolve a relative path from child
        let source_path = format!("{}.R", source_file);
        let resolved = resolve_path(&source_path, &child_ctx);

        prop_assert!(resolved.is_some(), "Path resolution should succeed");

        // The path should resolve relative to child's own directory
        let expected_resolved = PathBuf::from(format!("/{}/{}/{}.R", workspace, child_subdir, source_file));
        prop_assert_eq!(
            resolved.as_ref().unwrap(),
            &expected_resolved,
            "Without inherited WD, path should resolve relative to child's directory. \
             source_path='{}', child_dir='{}', expected='{}', got='{}'",
            source_path,
            child_ctx.effective_working_directory().display(),
            expected_resolved.display(),
            resolved.as_ref().unwrap().display()
        );
    }
}

// ============================================================================
// Feature: working-directory-inheritance
// Property 4: Backward Directive Paths Ignore Working Directory
// Validates: Requirements 4.1, 4.2, 4.3
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: working-directory-inheritance, Property 4: Backward Directive Paths Ignore Working Directory
    /// **Validates: Requirements 4.1, 4.2, 4.3**
    ///
    /// For any backward directive path (e.g., `@lsp-sourced-by: ../parent.R`), resolving
    /// that path SHALL always be relative to the child file's directory, regardless of
    /// any explicit `@lsp-cd` or inherited working directory settings.
    #[test]
    fn prop_backward_directive_paths_ignore_working_directory(
        workspace in path_component(),
        child_subdir in path_component(),
        explicit_wd in path_component(),
        inherited_wd in path_component(),
        parent_file in path_component(),
    ) {
        // Ensure directories are different to make the test meaningful
        prop_assume!(child_subdir != explicit_wd);
        prop_assume!(child_subdir != inherited_wd);

        // Create workspace root URI
        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Create child file URI: /workspace/child_subdir/child.R
        let child_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, child_subdir)).unwrap();

        // Backward directive path: ../parent.R (should resolve to /workspace/parent.R)
        let backward_directive_path = format!("../{}.R", parent_file);

        // Case 1: PathContext::new (correct for backward directives - no WD at all)
        let ctx_new = PathContext::new(&child_uri, Some(&workspace_uri)).unwrap();

        // Case 2: Metadata with explicit @lsp-cd (workspace-root-relative path starting with /)
        // Note: Paths starting with / are workspace-root-relative, so /explicit_wd resolves to workspace/explicit_wd
        let meta_with_explicit_wd = CrossFileMetadata {
            working_directory: Some(format!("/{}", explicit_wd)),
            inherited_working_directory: None,
            ..Default::default()
        };
        let ctx_with_explicit_wd = PathContext::from_metadata(
            &child_uri,
            &meta_with_explicit_wd,
            Some(&workspace_uri)
        ).unwrap();

        // Case 3: Metadata with inherited working directory (stored as absolute path per design doc)
        let inherited_wd_absolute = format!("/{}/{}", workspace, inherited_wd);
        let meta_with_inherited_wd = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: Some(inherited_wd_absolute.clone()),
            ..Default::default()
        };
        let ctx_with_inherited_wd = PathContext::from_metadata(
            &child_uri,
            &meta_with_inherited_wd,
            Some(&workspace_uri)
        ).unwrap();

        // Case 4: Metadata with both explicit and inherited WD
        let meta_with_both_wd = CrossFileMetadata {
            working_directory: Some(format!("/{}", explicit_wd)),
            inherited_working_directory: Some(inherited_wd_absolute.clone()),
            ..Default::default()
        };
        let ctx_with_both_wd = PathContext::from_metadata(
            &child_uri,
            &meta_with_both_wd,
            Some(&workspace_uri)
        ).unwrap();

        // Resolve backward directive path using PathContext::new (correct behavior)
        let resolved_with_new = resolve_path(&backward_directive_path, &ctx_new);

        // Property 4.1: Backward directive path SHALL resolve relative to child file's directory
        prop_assert!(
            resolved_with_new.is_some(),
            "Backward directive path should resolve successfully"
        );

        let expected_resolved = PathBuf::from(format!("/{}/{}.R", workspace, parent_file));
        prop_assert_eq!(
            resolved_with_new.as_ref().unwrap(),
            &expected_resolved,
            "Backward directive path '../{}.R' should resolve to '{}' (relative to child's directory)",
            parent_file, expected_resolved.display()
        );

        // Property 4.2: Backward directive path SHALL NOT use inherited working directory
        // Verify that PathContext::new has no inherited_working_directory
        prop_assert!(
            ctx_new.inherited_working_directory.is_none(),
            "PathContext::new should have no inherited_working_directory"
        );

        // Property 4.3: Backward directive path SHALL NOT use explicit working directory
        // Verify that PathContext::new has no working_directory
        prop_assert!(
            ctx_new.working_directory.is_none(),
            "PathContext::new should have no working_directory"
        );

        // Verify that from_metadata contexts have different effective working directories
        // (confirming that WD settings are being applied, just not for backward directives)
        let wd_new = ctx_new.effective_working_directory();
        let wd_explicit = ctx_with_explicit_wd.effective_working_directory();
        let wd_inherited = ctx_with_inherited_wd.effective_working_directory();
        let wd_both = ctx_with_both_wd.effective_working_directory();

        // PathContext::new should use child's directory
        let expected_child_dir = PathBuf::from(format!("/{}/{}", workspace, child_subdir));
        prop_assert_eq!(
            wd_new, expected_child_dir,
            "PathContext::new should use child's directory as effective WD"
        );

        // from_metadata with explicit WD should use explicit WD
        // Note: /explicit_wd is workspace-root-relative, so it resolves to /workspace/explicit_wd
        let expected_explicit_wd = PathBuf::from(format!("/{}/{}", workspace, explicit_wd));
        prop_assert_eq!(
            wd_explicit, expected_explicit_wd.clone(),
            "from_metadata with explicit WD should use explicit WD"
        );

        // from_metadata with inherited WD should use inherited WD (stored as absolute)
        let expected_inherited_wd = PathBuf::from(&inherited_wd_absolute);
        prop_assert_eq!(
            wd_inherited, expected_inherited_wd,
            "from_metadata with inherited WD should use inherited WD"
        );

        // from_metadata with both should use explicit WD (precedence)
        prop_assert_eq!(
            wd_both, expected_explicit_wd,
            "from_metadata with both WDs should use explicit WD (precedence)"
        );
    }

    /// Feature: working-directory-inheritance, Property 4 extended: All backward directive synonyms ignore WD
    /// **Validates: Requirements 4.1, 4.2, 4.3**
    ///
    /// All backward directive synonyms (@lsp-sourced-by, @lsp-run-by, @lsp-included-by)
    /// should resolve paths relative to the file's directory, ignoring any WD settings.
    #[test]
    fn prop_all_backward_directive_synonyms_ignore_wd(
        workspace in path_component(),
        child_subdir in path_component(),
        explicit_wd in path_component(),
        inherited_wd in path_component(),
        parent_file in path_component(),
    ) {
        prop_assume!(child_subdir != explicit_wd);
        prop_assume!(child_subdir != inherited_wd);

        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();
        let child_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, child_subdir)).unwrap();

        // PathContext::new (correct for backward directives)
        let ctx_new = PathContext::new(&child_uri, Some(&workspace_uri)).unwrap();

        // Test with parent directory navigation (common pattern for backward directives)
        let parent_path = format!("../{}.R", parent_file);

        // Parse all backward directive synonyms
        let sourced_by = format!("# @lsp-sourced-by {}", parent_path);
        let run_by = format!("# @lsp-run-by {}", parent_path);
        let included_by = format!("# @lsp-included-by {}", parent_path);

        let meta_sourced = parse_directives(&sourced_by);
        let meta_run = parse_directives(&run_by);
        let meta_included = parse_directives(&included_by);

        // All synonyms should parse to the same path
        prop_assert_eq!(meta_sourced.sourced_by.len(), 1);
        prop_assert_eq!(meta_run.sourced_by.len(), 1);
        prop_assert_eq!(meta_included.sourced_by.len(), 1);

        prop_assert_eq!(&meta_sourced.sourced_by[0].path, &parent_path);
        prop_assert_eq!(&meta_run.sourced_by[0].path, &parent_path);
        prop_assert_eq!(&meta_included.sourced_by[0].path, &parent_path);

        // Resolve using PathContext::new (correct for backward directives)
        let resolved = resolve_path(&parent_path, &ctx_new);

        prop_assert!(
            resolved.is_some(),
            "Backward directive path should resolve successfully"
        );

        // All should resolve to the same path (relative to child's directory)
        let expected = PathBuf::from(format!("/{}/{}.R", workspace, parent_file));
        prop_assert_eq!(
            resolved.as_ref().unwrap(),
            &expected,
            "All backward directive synonyms should resolve to '{}' (relative to child's directory)",
            expected.display()
        );
    }

    /// Feature: working-directory-inheritance, Property 4 extended: Backward directive with nested path ignores WD
    /// **Validates: Requirements 4.1, 4.2, 4.3**
    ///
    /// Backward directive paths with multiple parent directory navigations (../../parent.R)
    /// should still resolve relative to the file's directory, ignoring WD settings.
    #[test]
    fn prop_backward_directive_nested_path_ignores_wd(
        workspace in path_component(),
        subdir1 in path_component(),
        subdir2 in path_component(),
        explicit_wd in path_component(),
        parent_file in path_component(),
    ) {
        prop_assume!(subdir1 != explicit_wd);
        prop_assume!(subdir2 != explicit_wd);

        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();
        // Child file is nested: /workspace/subdir1/subdir2/child.R
        let child_uri = Url::parse(&format!("file:///{}/{}/{}/child.R", workspace, subdir1, subdir2)).unwrap();

        // PathContext::new (correct for backward directives)
        let ctx_new = PathContext::new(&child_uri, Some(&workspace_uri)).unwrap();

        // Backward directive path with double parent navigation: ../../parent.R
        let backward_path = format!("../../{}.R", parent_file);

        let resolved = resolve_path(&backward_path, &ctx_new);

        prop_assert!(
            resolved.is_some(),
            "Nested backward directive path should resolve successfully"
        );

        // Should resolve to /workspace/parent.R (two levels up from child's directory)
        let expected = PathBuf::from(format!("/{}/{}.R", workspace, parent_file));
        prop_assert_eq!(
            resolved.as_ref().unwrap(),
            &expected,
            "Backward directive '../../{}.R' should resolve to '{}' (relative to child's directory)",
            parent_file, expected.display()
        );
    }

    /// Feature: working-directory-inheritance, Property 4 extended: Backward directive with sibling path ignores WD
    /// **Validates: Requirements 4.1, 4.2, 4.3**
    ///
    /// Backward directive paths pointing to sibling directories (../sibling/parent.R)
    /// should resolve relative to the file's directory, ignoring WD settings.
    #[test]
    fn prop_backward_directive_sibling_path_ignores_wd(
        workspace in path_component(),
        child_subdir in path_component(),
        sibling_subdir in path_component(),
        explicit_wd in path_component(),
        parent_file in path_component(),
    ) {
        prop_assume!(child_subdir != explicit_wd);
        prop_assume!(sibling_subdir != explicit_wd);
        prop_assume!(child_subdir != sibling_subdir);

        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();
        let child_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, child_subdir)).unwrap();

        // PathContext::new (correct for backward directives)
        let ctx_new = PathContext::new(&child_uri, Some(&workspace_uri)).unwrap();

        // Backward directive path to sibling directory: ../sibling/parent.R
        let backward_path = format!("../{}/{}.R", sibling_subdir, parent_file);

        let resolved = resolve_path(&backward_path, &ctx_new);

        prop_assert!(
            resolved.is_some(),
            "Sibling backward directive path should resolve successfully"
        );

        // Should resolve to /workspace/sibling_subdir/parent.R
        let expected = PathBuf::from(format!("/{}/{}/{}.R", workspace, sibling_subdir, parent_file));
        prop_assert_eq!(
            resolved.as_ref().unwrap(),
            &expected,
            "Backward directive '../{}/{}.R' should resolve to '{}' (relative to child's directory)",
            sibling_subdir, parent_file, expected.display()
        );
    }

    /// Feature: working-directory-inheritance, Property 4 extended: Backward directive same-directory path ignores WD
    /// **Validates: Requirements 4.1, 4.2, 4.3**
    ///
    /// Backward directive paths in the same directory (./parent.R or parent.R)
    /// should resolve relative to the file's directory, ignoring WD settings.
    #[test]
    fn prop_backward_directive_same_dir_path_ignores_wd(
        workspace in path_component(),
        child_subdir in path_component(),
        explicit_wd in path_component(),
        parent_file in path_component(),
    ) {
        prop_assume!(child_subdir != explicit_wd);

        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();
        let child_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, child_subdir)).unwrap();

        // PathContext::new (correct for backward directives)
        let ctx_new = PathContext::new(&child_uri, Some(&workspace_uri)).unwrap();

        // Test both ./parent.R and parent.R forms
        let backward_path_dot = format!("./{}.R", parent_file);
        let backward_path_plain = format!("{}.R", parent_file);

        let resolved_dot = resolve_path(&backward_path_dot, &ctx_new);
        let resolved_plain = resolve_path(&backward_path_plain, &ctx_new);

        prop_assert!(
            resolved_dot.is_some(),
            "Same-directory backward directive path (./form) should resolve successfully"
        );
        prop_assert!(
            resolved_plain.is_some(),
            "Same-directory backward directive path (plain form) should resolve successfully"
        );

        // Both should resolve to /workspace/child_subdir/parent.R
        let expected = PathBuf::from(format!("/{}/{}/{}.R", workspace, child_subdir, parent_file));
        prop_assert_eq!(
            resolved_dot.as_ref().unwrap(),
            &expected,
            "Backward directive './{}.R' should resolve to '{}' (relative to child's directory)",
            parent_file, expected.display()
        );
        prop_assert_eq!(
            resolved_plain.as_ref().unwrap(),
            &expected,
            "Backward directive '{}.R' should resolve to '{}' (relative to child's directory)",
            parent_file, expected.display()
        );
    }

    /// Feature: working-directory-inheritance, Property 4 extended: Backward directive vs source() path resolution
    /// **Validates: Requirements 4.1, 4.2, 4.3**
    ///
    /// This test demonstrates the key difference: backward directive paths resolve
    /// relative to the file's directory (using PathContext::new), while source() paths
    /// resolve using the effective working directory (using PathContext::from_metadata).
    #[test]
    fn prop_backward_directive_vs_source_path_resolution(
        workspace in path_component(),
        child_subdir in path_component(),
        inherited_wd_subdir in path_component(),
        target_file in path_component(),
    ) {
        // Ensure directories are different to make the test meaningful
        prop_assume!(child_subdir != inherited_wd_subdir);

        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();
        let child_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, child_subdir)).unwrap();

        // Child has inherited working directory from parent.
        // Per design doc: "The stored path is always absolute for consistent resolution"
        let inherited_wd_absolute = format!("/{}/{}", workspace, inherited_wd_subdir);
        let meta_with_inherited_wd = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: Some(inherited_wd_absolute.clone()),
            ..Default::default()
        };

        // PathContext::new (for backward directives - ignores WD)
        let ctx_backward = PathContext::new(&child_uri, Some(&workspace_uri)).unwrap();

        // PathContext::from_metadata (for source() calls - uses inherited WD)
        let ctx_source = PathContext::from_metadata(
            &child_uri,
            &meta_with_inherited_wd,
            Some(&workspace_uri)
        ).unwrap();

        // Same relative path used for both
        let relative_path = format!("{}.R", target_file);

        // Resolve using backward directive context (file-relative)
        let resolved_backward = resolve_path(&relative_path, &ctx_backward);

        // Resolve using source() context (uses inherited WD)
        let resolved_source = resolve_path(&relative_path, &ctx_source);

        prop_assert!(resolved_backward.is_some());
        prop_assert!(resolved_source.is_some());

        // Key assertion: the two resolutions should be DIFFERENT
        // because backward directives ignore WD while source() uses it
        let expected_backward = PathBuf::from(format!("/{}/{}/{}.R", workspace, child_subdir, target_file));
        let expected_source = PathBuf::from(format!("/{}/{}/{}.R", workspace, inherited_wd_subdir, target_file));

        prop_assert_eq!(
            resolved_backward.as_ref().unwrap(),
            &expected_backward,
            "Backward directive path should resolve relative to child's directory"
        );

        prop_assert_eq!(
            resolved_source.as_ref().unwrap(),
            &expected_source,
            "source() path should resolve relative to inherited working directory"
        );

        prop_assert_ne!(
            resolved_backward.as_ref().unwrap(),
            resolved_source.as_ref().unwrap(),
            "Backward directive and source() should resolve to different paths when WD differs from file's directory"
        );
    }
}

// ============================================================================
// Feature: working-directory-inheritance
// Property 8: Transitive Inheritance
// Validates: Requirements 9.1
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: working-directory-inheritance, Property 8: Transitive Inheritance
    /// **Validates: Requirements 9.1**
    ///
    /// For any chain of files A → B → C connected by backward directives
    /// (where → means "is sourced by"), if only A has an explicit `@lsp-cd`
    /// and B and C have none, then C's inherited working directory SHALL
    /// equal A's explicit working directory.
    ///
    /// This test validates that working directory inheritance works transitively
    /// through chains of backward directives. When A has @lsp-cd, B inherits from A,
    /// and C inherits from B (getting A's WD).
    #[test]
    fn prop_transitive_inheritance_three_file_chain(
        workspace in path_component(),
        dir_a in path_component(),
        dir_b in path_component(),
        dir_c in path_component(),
        wd_dir in path_component(),
    ) {
        // Ensure directories are different to make the test meaningful
        prop_assume!(dir_a != dir_b);
        prop_assume!(dir_b != dir_c);
        prop_assume!(dir_a != dir_c);
        prop_assume!(wd_dir != dir_a);
        prop_assume!(wd_dir != dir_b);
        prop_assume!(wd_dir != dir_c);

        use super::dependency::compute_inherited_working_directory;
        use super::types::{BackwardDirective, CrossFileMetadata};

        // Setup: A → B → C chain where only A has explicit @lsp-cd
        // A is in /workspace/dir_a/a.R with @lsp-cd: /wd_dir
        // B is in /workspace/dir_b/b.R with @lsp-sourced-by: ../dir_a/a.R
        // C is in /workspace/dir_c/c.R with @lsp-sourced-by: ../dir_b/b.R

        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();
        let a_uri = Url::parse(&format!("file:///{}/{}/a.R", workspace, dir_a)).unwrap();
        let b_uri = Url::parse(&format!("file:///{}/{}/b.R", workspace, dir_b)).unwrap();
        let c_uri = Url::parse(&format!("file:///{}/{}/c.R", workspace, dir_c)).unwrap();

        // A's explicit working directory (workspace-relative)
        let a_explicit_wd = format!("/{}", wd_dir);

        // File A: has explicit @lsp-cd, no backward directive
        let meta_a = CrossFileMetadata {
            working_directory: Some(a_explicit_wd.clone()),
            inherited_working_directory: None,
            sourced_by: vec![],
            ..Default::default()
        };

        // File B: has backward directive to A, no explicit @lsp-cd
        // B's inherited_working_directory will be computed from A
        let meta_b_initial = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/a.R", dir_a),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // File C: has backward directive to B, no explicit @lsp-cd
        let meta_c = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/b.R", dir_b),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // Create metadata getter that returns appropriate metadata for each URI
        // First, compute B's inherited WD from A
        let get_metadata_for_b = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &a_uri {
                Some(std::sync::Arc::new(meta_a.clone()))
            } else {
                None
            }
        };

        // Compute B's inherited working directory
        let b_inherited_wd = compute_inherited_working_directory(
            &b_uri,
            &meta_b_initial,
            Some(&workspace_uri),
            get_metadata_for_b,
        );

        // B should inherit A's explicit working directory
        prop_assert!(
            b_inherited_wd.is_some(),
            "B should inherit working directory from A"
        );

        // Create B's metadata with the computed inherited WD
        let meta_b_with_inherited = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: b_inherited_wd.clone(),
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/a.R", dir_a),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // Now compute C's inherited WD from B (which has A's WD)
        let get_metadata_for_c = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &b_uri {
                Some(std::sync::Arc::new(meta_b_with_inherited.clone()))
            } else if uri == &a_uri {
                Some(std::sync::Arc::new(meta_a.clone()))
            } else {
                None
            }
        };

        let c_inherited_wd = compute_inherited_working_directory(
            &c_uri,
            &meta_c,
            Some(&workspace_uri),
            get_metadata_for_c,
        );

        // C should inherit A's working directory through B
        prop_assert!(
            c_inherited_wd.is_some(),
            "C should inherit working directory transitively from A through B"
        );

        // The expected resolved path for A's working directory
        let expected_wd = PathBuf::from(format!("/{}/{}", workspace, wd_dir));

        // Verify C's inherited WD equals A's explicit WD
        let c_inherited_path = PathBuf::from(c_inherited_wd.as_ref().unwrap());
        prop_assert_eq!(
            c_inherited_path,
            expected_wd,
            "C's inherited working directory should equal A's explicit working directory. \
             A's @lsp-cd: '{}', B inherited: {:?}, C inherited: {:?}",
            a_explicit_wd,
            b_inherited_wd,
            c_inherited_wd
        );
    }

    /// Feature: working-directory-inheritance, Property 8 extended: Transitive inheritance with relative WD
    /// **Validates: Requirements 9.1**
    ///
    /// Tests transitive inheritance when A's @lsp-cd is a relative path.
    /// The relative path should be resolved relative to A's directory,
    /// and that resolved path should propagate through B to C.
    #[test]
    fn prop_transitive_inheritance_relative_wd(
        workspace in path_component(),
        dir_a in path_component(),
        dir_b in path_component(),
        dir_c in path_component(),
        relative_wd in path_component(),
    ) {
        // Ensure directories are different
        prop_assume!(dir_a != dir_b);
        prop_assume!(dir_b != dir_c);
        prop_assume!(dir_a != dir_c);

        use super::dependency::compute_inherited_working_directory;
        use super::types::{BackwardDirective, CrossFileMetadata};

        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();
        let a_uri = Url::parse(&format!("file:///{}/{}/a.R", workspace, dir_a)).unwrap();
        let b_uri = Url::parse(&format!("file:///{}/{}/b.R", workspace, dir_b)).unwrap();
        let c_uri = Url::parse(&format!("file:///{}/{}/c.R", workspace, dir_c)).unwrap();

        // A's relative working directory (relative to A's directory)
        let a_relative_wd = format!("../{}", relative_wd);

        // File A: has relative @lsp-cd
        let meta_a = CrossFileMetadata {
            working_directory: Some(a_relative_wd.clone()),
            inherited_working_directory: None,
            sourced_by: vec![],
            ..Default::default()
        };

        // File B: backward directive to A
        let meta_b_initial = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/a.R", dir_a),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // File C: backward directive to B
        let meta_c = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/b.R", dir_b),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // Compute B's inherited WD
        let get_metadata_for_b = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &a_uri {
                Some(std::sync::Arc::new(meta_a.clone()))
            } else {
                None
            }
        };

        let b_inherited_wd = compute_inherited_working_directory(
            &b_uri,
            &meta_b_initial,
            Some(&workspace_uri),
            get_metadata_for_b,
        );

        prop_assert!(
            b_inherited_wd.is_some(),
            "B should inherit working directory from A"
        );

        // Create B's metadata with inherited WD
        let meta_b_with_inherited = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: b_inherited_wd.clone(),
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/a.R", dir_a),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // Compute C's inherited WD
        let get_metadata_for_c = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &b_uri {
                Some(std::sync::Arc::new(meta_b_with_inherited.clone()))
            } else if uri == &a_uri {
                Some(std::sync::Arc::new(meta_a.clone()))
            } else {
                None
            }
        };

        let c_inherited_wd = compute_inherited_working_directory(
            &c_uri,
            &meta_c,
            Some(&workspace_uri),
            get_metadata_for_c,
        );

        prop_assert!(
            c_inherited_wd.is_some(),
            "C should inherit working directory transitively"
        );

        // A's relative WD "../{relative_wd}" from /workspace/dir_a/ resolves to /workspace/{relative_wd}
        let expected_wd = PathBuf::from(format!("/{}/{}", workspace, relative_wd));

        let c_inherited_path = PathBuf::from(c_inherited_wd.as_ref().unwrap());
        prop_assert_eq!(
            c_inherited_path,
            expected_wd,
            "C's inherited WD should equal A's resolved relative WD"
        );
    }

    /// Feature: working-directory-inheritance, Property 8 extended: Four-file chain
    /// **Validates: Requirements 9.1**
    ///
    /// Tests transitive inheritance through a longer chain: A → B → C → D
    /// where only A has @lsp-cd. D should inherit A's working directory.
    #[test]
    fn prop_transitive_inheritance_four_file_chain(
        workspace in path_component(),
        dir_a in path_component(),
        dir_b in path_component(),
        dir_c in path_component(),
        dir_d in path_component(),
        wd_dir in path_component(),
    ) {
        // Ensure all directories are different
        prop_assume!(dir_a != dir_b && dir_a != dir_c && dir_a != dir_d);
        prop_assume!(dir_b != dir_c && dir_b != dir_d);
        prop_assume!(dir_c != dir_d);
        prop_assume!(wd_dir != dir_a && wd_dir != dir_b && wd_dir != dir_c && wd_dir != dir_d);

        use super::dependency::compute_inherited_working_directory;
        use super::types::{BackwardDirective, CrossFileMetadata};

        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();
        let a_uri = Url::parse(&format!("file:///{}/{}/a.R", workspace, dir_a)).unwrap();
        let b_uri = Url::parse(&format!("file:///{}/{}/b.R", workspace, dir_b)).unwrap();
        let c_uri = Url::parse(&format!("file:///{}/{}/c.R", workspace, dir_c)).unwrap();
        let d_uri = Url::parse(&format!("file:///{}/{}/d.R", workspace, dir_d)).unwrap();

        let a_explicit_wd = format!("/{}", wd_dir);

        // File A: has explicit @lsp-cd
        let meta_a = CrossFileMetadata {
            working_directory: Some(a_explicit_wd.clone()),
            inherited_working_directory: None,
            sourced_by: vec![],
            ..Default::default()
        };

        // File B: backward directive to A
        let meta_b_initial = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/a.R", dir_a),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // Compute B's inherited WD
        let get_meta_a = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &a_uri { Some(std::sync::Arc::new(meta_a.clone())) } else { None }
        };
        let b_inherited_wd = compute_inherited_working_directory(
            &b_uri, &meta_b_initial, Some(&workspace_uri), get_meta_a,
        );
        prop_assert!(b_inherited_wd.is_some(), "B should inherit from A");

        let meta_b = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: b_inherited_wd.clone(),
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/a.R", dir_a),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // File C: backward directive to B
        let meta_c_initial = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/b.R", dir_b),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // Compute C's inherited WD
        let meta_a_clone = meta_a.clone();
        let meta_b_clone = meta_b.clone();
        let a_uri_clone = a_uri.clone();
        let b_uri_clone = b_uri.clone();
        let get_meta_ab = move |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &a_uri_clone { Some(std::sync::Arc::new(meta_a_clone.clone())) }
            else if uri == &b_uri_clone { Some(std::sync::Arc::new(meta_b_clone.clone())) }
            else { None }
        };
        let c_inherited_wd = compute_inherited_working_directory(
            &c_uri, &meta_c_initial, Some(&workspace_uri), get_meta_ab,
        );
        prop_assert!(c_inherited_wd.is_some(), "C should inherit from B");

        let meta_c = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: c_inherited_wd.clone(),
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/b.R", dir_b),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // File D: backward directive to C
        let meta_d = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/c.R", dir_c),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // Compute D's inherited WD
        let get_meta_all = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &a_uri { Some(std::sync::Arc::new(meta_a.clone())) }
            else if uri == &b_uri { Some(std::sync::Arc::new(meta_b.clone())) }
            else if uri == &c_uri { Some(std::sync::Arc::new(meta_c.clone())) }
            else { None }
        };
        let d_inherited_wd = compute_inherited_working_directory(
            &d_uri, &meta_d, Some(&workspace_uri), get_meta_all,
        );

        prop_assert!(
            d_inherited_wd.is_some(),
            "D should inherit working directory transitively through A → B → C → D"
        );

        let expected_wd = PathBuf::from(format!("/{}/{}", workspace, wd_dir));
        let d_inherited_path = PathBuf::from(d_inherited_wd.as_ref().unwrap());
        prop_assert_eq!(
            d_inherited_path,
            expected_wd,
            "D's inherited WD should equal A's explicit WD through transitive inheritance"
        );
    }

    /// Feature: working-directory-inheritance, Property 8 extended: Middle file with explicit WD breaks chain
    /// **Validates: Requirements 9.1, 3.1**
    ///
    /// Tests that when B has its own explicit @lsp-cd, C inherits B's WD, not A's.
    /// This validates that explicit WD takes precedence and "breaks" the transitive chain.
    #[test]
    fn prop_transitive_inheritance_middle_explicit_wd_breaks_chain(
        workspace in path_component(),
        dir_a in path_component(),
        dir_b in path_component(),
        dir_c in path_component(),
        wd_a in path_component(),
        wd_b in path_component(),
    ) {
        // Ensure directories are different
        prop_assume!(dir_a != dir_b && dir_b != dir_c && dir_a != dir_c);
        prop_assume!(wd_a != wd_b);
        prop_assume!(wd_a != dir_a && wd_a != dir_b && wd_a != dir_c);
        prop_assume!(wd_b != dir_a && wd_b != dir_b && wd_b != dir_c);

        use super::dependency::compute_inherited_working_directory;
        use super::types::{BackwardDirective, CrossFileMetadata};

        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();
        let a_uri = Url::parse(&format!("file:///{}/{}/a.R", workspace, dir_a)).unwrap();
        let b_uri = Url::parse(&format!("file:///{}/{}/b.R", workspace, dir_b)).unwrap();
        let c_uri = Url::parse(&format!("file:///{}/{}/c.R", workspace, dir_c)).unwrap();

        // File A: has explicit @lsp-cd: /wd_a
        let meta_a = CrossFileMetadata {
            working_directory: Some(format!("/{}", wd_a)),
            inherited_working_directory: None,
            sourced_by: vec![],
            ..Default::default()
        };

        // File B: has BOTH backward directive to A AND its own explicit @lsp-cd: /wd_b
        // B's explicit WD should take precedence over inheritance from A
        let meta_b = CrossFileMetadata {
            working_directory: Some(format!("/{}", wd_b)),
            inherited_working_directory: None, // Not computed because explicit WD exists
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/a.R", dir_a),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // File C: backward directive to B
        let meta_c = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/b.R", dir_b),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // Compute C's inherited WD
        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &a_uri { Some(std::sync::Arc::new(meta_a.clone())) }
            else if uri == &b_uri { Some(std::sync::Arc::new(meta_b.clone())) }
            else { None }
        };

        let c_inherited_wd = compute_inherited_working_directory(
            &c_uri, &meta_c, Some(&workspace_uri), get_metadata,
        );

        prop_assert!(
            c_inherited_wd.is_some(),
            "C should inherit working directory from B"
        );

        // C should inherit B's explicit WD, NOT A's
        let expected_wd = PathBuf::from(format!("/{}/{}", workspace, wd_b));
        let c_inherited_path = PathBuf::from(c_inherited_wd.as_ref().unwrap());
        prop_assert_eq!(
            c_inherited_path.clone(),
            expected_wd,
            "C should inherit B's explicit WD ({}), not A's WD ({})",
            wd_b, wd_a
        );

        // Verify it's NOT A's WD
        let a_wd = PathBuf::from(format!("/{}/{}", workspace, wd_a));
        prop_assert_ne!(
            c_inherited_path,
            a_wd,
            "C should NOT inherit A's WD when B has explicit WD"
        );
    }

    /// Feature: working-directory-inheritance, Property 8 extended: Implicit WD transitive inheritance
    /// **Validates: Requirements 9.1, 2.1**
    ///
    /// Tests transitive inheritance when A has no explicit @lsp-cd (uses its directory).
    /// B and C should inherit A's directory as the working directory.
    #[test]
    fn prop_transitive_inheritance_implicit_wd(
        workspace in path_component(),
        dir_a in path_component(),
        dir_b in path_component(),
        dir_c in path_component(),
    ) {
        // Ensure directories are different
        prop_assume!(dir_a != dir_b && dir_b != dir_c && dir_a != dir_c);

        use super::dependency::compute_inherited_working_directory;
        use super::types::{BackwardDirective, CrossFileMetadata};

        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();
        let a_uri = Url::parse(&format!("file:///{}/{}/a.R", workspace, dir_a)).unwrap();
        let b_uri = Url::parse(&format!("file:///{}/{}/b.R", workspace, dir_b)).unwrap();
        let c_uri = Url::parse(&format!("file:///{}/{}/c.R", workspace, dir_c)).unwrap();

        // File A: NO explicit @lsp-cd (uses its directory as effective WD)
        let meta_a = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![],
            ..Default::default()
        };

        // File B: backward directive to A
        let meta_b_initial = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/a.R", dir_a),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // Compute B's inherited WD (should be A's directory)
        let get_meta_a = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &a_uri { Some(std::sync::Arc::new(meta_a.clone())) } else { None }
        };
        let b_inherited_wd = compute_inherited_working_directory(
            &b_uri, &meta_b_initial, Some(&workspace_uri), get_meta_a,
        );

        prop_assert!(
            b_inherited_wd.is_some(),
            "B should inherit A's directory as working directory"
        );

        // A's effective WD is its directory: /workspace/dir_a
        let expected_a_wd = PathBuf::from(format!("/{}/{}", workspace, dir_a));
        let b_inherited_path = PathBuf::from(b_inherited_wd.as_ref().unwrap());
        prop_assert_eq!(
            b_inherited_path,
            expected_a_wd.clone(),
            "B should inherit A's directory as WD"
        );

        // Create B's metadata with inherited WD
        let meta_b = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: b_inherited_wd.clone(),
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/a.R", dir_a),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // File C: backward directive to B
        let meta_c = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/b.R", dir_b),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // Compute C's inherited WD
        let get_meta_ab = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &a_uri { Some(std::sync::Arc::new(meta_a.clone())) }
            else if uri == &b_uri { Some(std::sync::Arc::new(meta_b.clone())) }
            else { None }
        };
        let c_inherited_wd = compute_inherited_working_directory(
            &c_uri, &meta_c, Some(&workspace_uri), get_meta_ab,
        );

        prop_assert!(
            c_inherited_wd.is_some(),
            "C should inherit working directory transitively"
        );

        // C should also inherit A's directory through B
        let c_inherited_path = PathBuf::from(c_inherited_wd.as_ref().unwrap());
        prop_assert_eq!(
            c_inherited_path,
            expected_a_wd,
            "C should inherit A's directory transitively through B"
        );
    }
}

// ============================================================================
// Feature: working-directory-inheritance
// Property 9: Depth Limiting
// Validates: Requirements 9.2
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: working-directory-inheritance, Property 9: Depth Limiting
    /// **Validates: Requirements 9.2**
    ///
    /// For any chain of backward directives exceeding `max_chain_depth`, the system
    /// SHALL stop inheritance at the depth limit and use the file's own directory
    /// for files beyond the limit.
    ///
    /// This test verifies that when max_depth is reached, the system stops traversing
    /// the inheritance chain and falls back to the file's directory.
    #[test]
    fn prop_depth_limiting_stops_at_max_depth(
        workspace in path_component(),
        dir_child in path_component(),
        dir_parent in path_component(),
        wd_parent in path_component(),
    ) {
        // Ensure all directory names are unique and different from workspace
        prop_assume!(dir_child != dir_parent);
        prop_assume!(dir_child != workspace && dir_parent != workspace);
        prop_assume!(wd_parent != dir_child && wd_parent != dir_parent && wd_parent != workspace);

        use super::dependency::compute_inherited_working_directory_with_depth;
        use super::types::{BackwardDirective, CrossFileMetadata};

        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();
        let parent_uri = Url::parse(&format!("file:///{}/{}/parent.R", workspace, dir_parent)).unwrap();
        let child_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, dir_child)).unwrap();

        // Parent has explicit @lsp-cd (file-relative path)
        let parent_meta = CrossFileMetadata {
            working_directory: Some(wd_parent.clone()),
            inherited_working_directory: None,
            sourced_by: vec![],
            ..Default::default()
        };

        // Child has backward directive to parent
        let child_meta = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/parent.R", dir_parent),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta.clone())) }
            else { None }
        };

        // Test with max_depth = 0: should return None (depth limit reached immediately)
        let result_depth_0 = compute_inherited_working_directory_with_depth(
            &child_uri, &child_meta, Some(&workspace_uri), get_metadata, 0,
        );
        prop_assert!(
            result_depth_0.is_none(),
            "With max_depth=0, inheritance should stop immediately and return None"
        );

        // Test with max_depth = 1: should resolve parent's effective WD
        let result_depth_1 = compute_inherited_working_directory_with_depth(
            &child_uri, &child_meta, Some(&workspace_uri), get_metadata, 1,
        );
        prop_assert!(
            result_depth_1.is_some(),
            "With max_depth=1, should get parent's effective WD"
        );
        let expected_parent_wd = PathBuf::from(format!("/{}/{}/{}", workspace, dir_parent, wd_parent));
        let result_path_1 = PathBuf::from(result_depth_1.as_ref().unwrap());
        prop_assert_eq!(
            result_path_1.clone(),
            expected_parent_wd,
            "With max_depth=1, should inherit parent's explicit WD"
        );

        // Test with sufficient depth (2+): should get parent's explicit WD
        let result_sufficient = compute_inherited_working_directory_with_depth(
            &child_uri, &child_meta, Some(&workspace_uri), get_metadata, 2,
        );
        prop_assert!(
            result_sufficient.is_some(),
            "With sufficient depth, should inherit parent's WD"
        );
        // Parent's file-relative WD resolves from parent's directory
        let expected_parent_wd = PathBuf::from(format!("/{}/{}/{}", workspace, dir_parent, wd_parent));
        let result_path_sufficient = PathBuf::from(result_sufficient.as_ref().unwrap());
        prop_assert_eq!(
            result_path_sufficient.clone(),
            expected_parent_wd,
            "With sufficient depth, should inherit parent's explicit WD"
        );

        // With explicit parent WD and max_depth >= 1, depth should match sufficient depth
        prop_assert_eq!(
            result_path_1,
            result_path_sufficient,
            "With max_depth >= 1, should resolve parent's explicit WD"
        );
    }

    /// Feature: working-directory-inheritance, Property 9 extended: Depth limiting with longer chains
    /// **Validates: Requirements 9.2**
    ///
    /// Tests that depth limiting works correctly with chains of varying lengths.
    /// For a chain where the root has an explicit WD, we need sufficient depth to
    /// reach the root's WD. With insufficient depth, we get an intermediate directory.
    ///
    /// Note: This test simulates proper metadata propagation where each file's
    /// inherited_working_directory is computed and stored before the next file
    /// in the chain is processed.
    #[test]
    fn prop_depth_limiting_chain_length(
        workspace in path_component(),
        chain_length in 1..4usize,
        wd_root in path_component(),
    ) {
        use super::dependency::compute_inherited_working_directory_with_depth;
        use super::types::{BackwardDirective, CrossFileMetadata};

        // Generate unique directory names for each file in the chain
        let dirs: Vec<String> = (0..=chain_length)
            .map(|i| format!("dir{}", i))
            .collect();

        // Ensure wd_root is different from all directory names and workspace
        prop_assume!(!dirs.contains(&wd_root));
        prop_assume!(wd_root != workspace);

        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Create URIs for all files in the chain
        let uris: Vec<Url> = dirs.iter()
            .enumerate()
            .map(|(i, dir)| {
                Url::parse(&format!("file:///{}/{}/file{}.R", workspace, dir, i)).unwrap()
            })
            .collect();

        // Create metadata for all files, simulating proper metadata propagation
        // File 0 (root): has explicit @lsp-cd (file-relative)
        // Files 1..n: have backward directive to previous file AND inherited WD from previous
        let mut metadatas: Vec<CrossFileMetadata> = Vec::new();

        for i in 0..=chain_length {
            if i == 0 {
                // Root file has explicit WD (file-relative path)
                metadatas.push(CrossFileMetadata {
                    working_directory: Some(wd_root.clone()),
                    inherited_working_directory: None,
                    sourced_by: vec![],
                    ..Default::default()
                });
            } else {
                // Compute inherited WD from previous file
                // This simulates what happens during metadata extraction
                let prev_meta = &metadatas[i - 1];

                // Get previous file's effective WD
                let prev_effective_wd = if let Some(ref wd) = prev_meta.working_directory {
                    // Previous has explicit WD - resolve it from previous file's directory
                    Some(format!("/{}/{}/{}", workspace, dirs[i - 1], wd))
                } else if let Some(ref inherited) = prev_meta.inherited_working_directory {
                    // Previous has inherited WD
                    Some(inherited.clone())
                } else {
                    // Previous has no WD - use its directory
                    Some(format!("/{}/{}", workspace, dirs[i - 1]))
                };

                metadatas.push(CrossFileMetadata {
                    working_directory: None,
                    inherited_working_directory: prev_effective_wd,
                    sourced_by: vec![BackwardDirective {
                        path: format!("../{}/file{}.R", dirs[i - 1], i - 1),
                        call_site: CallSiteSpec::Default,
                        directive_line: 0,
                    }],
                    ..Default::default()
                });
            }
        }

        // Pre-build a `Url -> Arc<CrossFileMetadata>` map so the recursive
        // working-directory walk does O(1) HashMap lookups + Arc-clone on
        // every call instead of an O(n) linear scan + deep-clone per call.
        // proptest runs 256 cases × up-to-`max_depth` recursive lookups, so
        // this matters for test latency.
        let metadata_map: std::collections::HashMap<Url, std::sync::Arc<CrossFileMetadata>> = uris
            .iter()
            .zip(metadatas.iter())
            .map(|(u, m)| (u.clone(), std::sync::Arc::new(m.clone())))
            .collect();
        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            metadata_map.get(uri).cloned()
        };

        // Test inheritance from the last file in the chain
        let last_idx = chain_length;

        // Test with depth 0: should return None
        let result_depth_0 = compute_inherited_working_directory_with_depth(
            &uris[last_idx],
            &metadatas[last_idx],
            Some(&workspace_uri),
            get_metadata,
            0,
        );
        prop_assert!(
            result_depth_0.is_none(),
            "With max_depth=0, should return None"
        );

        // Test with depth 1: should get immediate parent's effective WD
        let result_depth_1 = compute_inherited_working_directory_with_depth(
            &uris[last_idx],
            &metadatas[last_idx],
            Some(&workspace_uri),
            get_metadata,
            1,
        );
        prop_assert!(
            result_depth_1.is_some(),
            "With max_depth=1, should get immediate parent's effective WD"
        );
        let parent_idx = last_idx - 1;
        let parent_meta = &metadatas[parent_idx];
        let expected_parent_wd = if let Some(ref wd) = parent_meta.working_directory {
            PathBuf::from(format!("/{}/{}/{}", workspace, dirs[parent_idx], wd))
        } else if let Some(ref inherited) = parent_meta.inherited_working_directory {
            PathBuf::from(inherited)
        } else {
            PathBuf::from(format!("/{}/{}", workspace, dirs[parent_idx]))
        };
        let result_path_1 = PathBuf::from(result_depth_1.as_ref().unwrap());
        prop_assert_eq!(
            result_path_1.clone(),
            expected_parent_wd,
            "With max_depth=1, should match immediate parent's effective WD"
        );

        // Test with large depth: should get root's explicit WD (through metadata propagation)
        let result_large_depth = compute_inherited_working_directory_with_depth(
            &uris[last_idx],
            &metadatas[last_idx],
            Some(&workspace_uri),
            get_metadata,
            100, // Large enough for any chain
        );
        prop_assert!(
            result_large_depth.is_some(),
            "With large depth, should inherit root's WD"
        );
        // Root's file-relative WD resolves from root's directory: /{workspace}/dir0/{wd_root}
        let expected_root_wd = PathBuf::from(format!("/{}/dir0/{}", workspace, wd_root));
        let result_path_large = PathBuf::from(result_large_depth.as_ref().unwrap());
        prop_assert_eq!(
            result_path_large.clone(),
            expected_root_wd,
            "With large depth, should inherit root's explicit WD"
        );

        // With propagated inherited WDs, depth=1 should already match the root WD.
        prop_assert_eq!(
            result_path_1,
            result_path_large,
            "With propagated inherited WDs, depth=1 should match large depth result"
        );
    }

    /// Feature: working-directory-inheritance, Property 9 extended: Depth zero always stops
    /// **Validates: Requirements 9.2**
    ///
    /// Tests that max_depth=0 always stops inheritance regardless of chain structure.
    #[test]
    fn prop_depth_zero_always_stops(
        workspace in path_component(),
        dir_child in path_component(),
        dir_parent in path_component(),
        wd_parent in path_component(),
    ) {
        prop_assume!(dir_child != dir_parent);

        use super::dependency::compute_inherited_working_directory_with_depth;
        use super::types::{BackwardDirective, CrossFileMetadata};

        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();
        let child_uri = Url::parse(&format!("file:///{}/{}/child.R", workspace, dir_child)).unwrap();
        let parent_uri = Url::parse(&format!("file:///{}/{}/parent.R", workspace, dir_parent)).unwrap();

        // Parent has explicit WD
        let parent_meta = CrossFileMetadata {
            working_directory: Some(wd_parent.clone()),
            inherited_working_directory: None,
            sourced_by: vec![],
            ..Default::default()
        };

        // Child has backward directive to parent
        let child_meta = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/parent.R", dir_parent),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta.clone())) }
            else { None }
        };

        // With max_depth=0, should always return None
        let result = compute_inherited_working_directory_with_depth(
            &child_uri, &child_meta, Some(&workspace_uri), get_metadata, 0,
        );

        prop_assert!(
            result.is_none(),
            "With max_depth=0, inheritance should always stop and return None"
        );
    }

    /// Feature: working-directory-inheritance, Property 9 extended: Default depth is sufficient for reasonable chains
    /// **Validates: Requirements 9.2**
    ///
    /// Tests that the DEFAULT_MAX_INHERITANCE_DEPTH (10) is sufficient for typical use cases.
    /// This test simulates proper metadata propagation where each file's inherited_working_directory
    /// is computed and stored before the next file in the chain is processed.
    #[test]
    fn prop_default_depth_sufficient_for_typical_chains(
        workspace in path_component(),
        chain_length in 1..8usize,  // Typical chains are < 10 levels deep
        wd_root in path_component(),
    ) {
        use super::dependency::{compute_inherited_working_directory, DEFAULT_MAX_INHERITANCE_DEPTH};
        use super::types::{BackwardDirective, CrossFileMetadata};

        // Verify the default depth is what we expect
        prop_assert_eq!(DEFAULT_MAX_INHERITANCE_DEPTH, 10);

        // Generate unique directory names for each file in the chain
        let dirs: Vec<String> = (0..=chain_length)
            .map(|i| format!("dir{}", i))
            .collect();

        // Ensure wd_root is different from all directory names and workspace
        prop_assume!(!dirs.contains(&wd_root));
        prop_assume!(wd_root != workspace);

        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();

        // Create URIs for all files in the chain
        let uris: Vec<Url> = dirs.iter()
            .enumerate()
            .map(|(i, dir)| {
                Url::parse(&format!("file:///{}/{}/file{}.R", workspace, dir, i)).unwrap()
            })
            .collect();

        // Create metadata for all files, simulating proper metadata propagation
        let mut metadatas: Vec<CrossFileMetadata> = Vec::new();

        for i in 0..=chain_length {
            if i == 0 {
                metadatas.push(CrossFileMetadata {
                    working_directory: Some(wd_root.clone()),
                    inherited_working_directory: None,
                    sourced_by: vec![],
                    ..Default::default()
                });
            } else {
                // Compute inherited WD from previous file
                let prev_meta = &metadatas[i - 1];

                // Get previous file's effective WD
                let prev_effective_wd = if let Some(ref wd) = prev_meta.working_directory {
                    Some(format!("/{}/{}/{}", workspace, dirs[i - 1], wd))
                } else if let Some(ref inherited) = prev_meta.inherited_working_directory {
                    Some(inherited.clone())
                } else {
                    Some(format!("/{}/{}", workspace, dirs[i - 1]))
                };

                metadatas.push(CrossFileMetadata {
                    working_directory: None,
                    inherited_working_directory: prev_effective_wd,
                    sourced_by: vec![BackwardDirective {
                        path: format!("../{}/file{}.R", dirs[i - 1], i - 1),
                        call_site: CallSiteSpec::Default,
                        directive_line: 0,
                    }],
                    ..Default::default()
                });
            }
        }

        // Same O(1) lookup map as the depth-tracking case above.
        let metadata_map: std::collections::HashMap<Url, std::sync::Arc<CrossFileMetadata>> = uris
            .iter()
            .zip(metadatas.iter())
            .map(|(u, m)| (u.clone(), std::sync::Arc::new(m.clone())))
            .collect();
        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            metadata_map.get(uri).cloned()
        };

        // With default depth, typical chains should work
        let last_idx = chain_length;
        let result = compute_inherited_working_directory(
            &uris[last_idx],
            &metadatas[last_idx],
            Some(&workspace_uri),
            get_metadata,
        );

        // For chains shorter than DEFAULT_MAX_INHERITANCE_DEPTH, should succeed
        prop_assert!(
            result.is_some(),
            "Default depth ({}) should be sufficient for chain length {}",
            DEFAULT_MAX_INHERITANCE_DEPTH, chain_length
        );

        // Root's file-relative WD resolves from root's directory: /{workspace}/dir0/{wd_root}
        let expected_root_wd = PathBuf::from(format!("/{}/dir0/{}", workspace, wd_root));
        let result_path = PathBuf::from(result.as_ref().unwrap());
        prop_assert_eq!(
            result_path,
            expected_root_wd,
            "Should inherit root's explicit WD with default depth"
        );
    }
}

// ============================================================================
// Feature: working-directory-inheritance
// Property 10: Cycle Handling
// Validates: Requirements 9.3
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: working-directory-inheritance, Property 10: Cycle Handling
    /// **Validates: Requirements 9.3**
    ///
    /// For any cycle in backward directive relationships (e.g., A → B → A),
    /// the system SHALL detect the cycle, stop inheritance at the cycle point,
    /// and use the file's own directory as the effective working directory.
    ///
    /// This test validates the simple two-file cycle: A → B → A
    /// where A has @lsp-sourced-by pointing to B, and B has @lsp-sourced-by pointing to A.
    #[test]
    fn prop_cycle_handling_two_file_cycle(
        workspace in path_component(),
        dir_a in path_component(),
        dir_b in path_component(),
        wd_a in path_component(),
    ) {
        // Ensure directories are different
        prop_assume!(dir_a != dir_b);
        prop_assume!(wd_a != dir_a && wd_a != dir_b && wd_a != workspace);

        use super::dependency::compute_inherited_working_directory;
        use super::types::{BackwardDirective, CrossFileMetadata};

        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();
        let a_uri = Url::parse(&format!("file:///{}/{}/a.R", workspace, dir_a)).unwrap();
        let b_uri = Url::parse(&format!("file:///{}/{}/b.R", workspace, dir_b)).unwrap();

        // File A: has backward directive to B AND explicit @lsp-cd
        // (explicit WD means A won't try to inherit, but B will try to inherit from A)
        let meta_a = CrossFileMetadata {
            working_directory: Some(format!("/{}", wd_a)),
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/b.R", dir_b),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // File B: has backward directive to A (creates cycle A → B → A)
        let meta_b = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/a.R", dir_a),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // Create metadata getter
        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &a_uri { Some(std::sync::Arc::new(meta_a.clone())) }
            else if uri == &b_uri { Some(std::sync::Arc::new(meta_b.clone())) }
            else { None }
        };

        // Compute B's inherited WD - should succeed because A has explicit WD
        // (A doesn't need to inherit, so no cycle is triggered)
        let b_inherited_wd = compute_inherited_working_directory(
            &b_uri,
            &meta_b,
            Some(&workspace_uri),
            get_metadata,
        );

        // B should inherit A's explicit working directory
        prop_assert!(
            b_inherited_wd.is_some(),
            "B should inherit A's explicit WD (no cycle triggered because A has explicit WD)"
        );

        let expected_wd = PathBuf::from(format!("/{}/{}", workspace, wd_a));
        let b_inherited_path = PathBuf::from(b_inherited_wd.as_ref().unwrap());
        prop_assert_eq!(
            b_inherited_path,
            expected_wd,
            "B should inherit A's explicit working directory"
        );
    }

    /// Feature: working-directory-inheritance, Property 10 extended: Self-reference cycle (A → A)
    /// **Validates: Requirements 9.3**
    ///
    /// Tests that a file with a backward directive pointing to itself (self-reference)
    /// is handled correctly. The system should detect the cycle and not inherit.
    #[test]
    fn prop_cycle_handling_self_reference(
        workspace in path_component(),
        dir_a in path_component(),
    ) {
        use super::dependency::compute_inherited_working_directory;
        use super::types::{BackwardDirective, CrossFileMetadata};

        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();
        let a_uri = Url::parse(&format!("file:///{}/{}/a.R", workspace, dir_a)).unwrap();

        // File A: has backward directive pointing to itself (self-reference)
        let meta_a = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: "a.R".to_string(), // Points to itself
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // Create metadata getter
        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &a_uri { Some(std::sync::Arc::new(meta_a.clone())) }
            else { None }
        };

        // Compute A's inherited WD - should detect cycle and fall back to A's directory
        let a_inherited_wd = compute_inherited_working_directory(
            &a_uri,
            &meta_a,
            Some(&workspace_uri),
            get_metadata,
        );

        // When cycle is detected, the system falls back to the file's directory
        // In this case, A tries to inherit from itself, cycle is detected,
        // and it falls back to A's directory
        prop_assert!(
            a_inherited_wd.is_some(),
            "Self-reference should fall back to file's directory"
        );

        let expected_dir = PathBuf::from(format!("/{}/{}", workspace, dir_a));
        let a_inherited_path = PathBuf::from(a_inherited_wd.as_ref().unwrap());
        prop_assert_eq!(
            a_inherited_path,
            expected_dir,
            "Self-reference should fall back to file's own directory"
        );
    }

    /// Feature: working-directory-inheritance, Property 10 extended: Three-file cycle (A → B → C → A)
    /// **Validates: Requirements 9.3**
    ///
    /// Tests cycle detection in a longer chain: A → B → C → A
    /// where each file has a backward directive to the next, forming a cycle.
    #[test]
    fn prop_cycle_handling_three_file_cycle(
        workspace in path_component(),
        dir_a in path_component(),
        dir_b in path_component(),
        dir_c in path_component(),
    ) {
        // Ensure directories are different
        prop_assume!(dir_a != dir_b && dir_b != dir_c && dir_a != dir_c);

        use super::dependency::compute_inherited_working_directory;
        use super::types::{BackwardDirective, CrossFileMetadata};

        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();
        let a_uri = Url::parse(&format!("file:///{}/{}/a.R", workspace, dir_a)).unwrap();
        let b_uri = Url::parse(&format!("file:///{}/{}/b.R", workspace, dir_b)).unwrap();
        let c_uri = Url::parse(&format!("file:///{}/{}/c.R", workspace, dir_c)).unwrap();

        // File A: backward directive to C (completing the cycle)
        let meta_a = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/c.R", dir_c),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // File B: backward directive to A
        let meta_b = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/a.R", dir_a),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // File C: backward directive to B
        let meta_c = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/b.R", dir_b),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // Create metadata getter
        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &a_uri { Some(std::sync::Arc::new(meta_a.clone())) }
            else if uri == &b_uri { Some(std::sync::Arc::new(meta_b.clone())) }
            else if uri == &c_uri { Some(std::sync::Arc::new(meta_c.clone())) }
            else { None }
        };

        // Compute A's inherited WD - should detect cycle and fall back
        // Chain: A tries to inherit from C, C tries to inherit from B, B tries to inherit from A
        // When B tries to inherit from A, A is already visited → cycle detected
        let a_inherited_wd = compute_inherited_working_directory(
            &a_uri,
            &meta_a,
            Some(&workspace_uri),
            get_metadata,
        );

        // When cycle is detected, the system falls back to the file's directory
        prop_assert!(
            a_inherited_wd.is_some(),
            "Three-file cycle should fall back to file's directory"
        );

        // The fallback should be the directory of the file where cycle was detected
        // In this case, when resolving A's WD, we traverse C → B → A (cycle)
        // The cycle is detected when trying to resolve A again, so we fall back to A's directory
        // But actually, the fallback happens at the point where cycle is detected in the chain
        let a_inherited_path = PathBuf::from(a_inherited_wd.as_ref().unwrap());

        // The result should be some directory in the workspace (either A's, B's, or C's directory
        // depending on where the cycle detection kicks in)
        prop_assert!(
            a_inherited_path.starts_with(format!("/{}", workspace)),
            "Cycle fallback should be within workspace"
        );
    }

    /// Feature: working-directory-inheritance, Property 10 extended: Cycle with explicit WD breaks cycle
    /// **Validates: Requirements 9.3, 3.1**
    ///
    /// Tests that when one file in a potential cycle has an explicit @lsp-cd,
    /// the cycle is effectively broken because that file doesn't need to inherit.
    #[test]
    fn prop_cycle_handling_explicit_wd_breaks_cycle(
        workspace in path_component(),
        dir_a in path_component(),
        dir_b in path_component(),
        wd_b in path_component(),
    ) {
        // Ensure directories are different
        prop_assume!(dir_a != dir_b);
        prop_assume!(wd_b != dir_a && wd_b != dir_b && wd_b != workspace);

        use super::dependency::compute_inherited_working_directory;
        use super::types::{BackwardDirective, CrossFileMetadata};

        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();
        let a_uri = Url::parse(&format!("file:///{}/{}/a.R", workspace, dir_a)).unwrap();
        let b_uri = Url::parse(&format!("file:///{}/{}/b.R", workspace, dir_b)).unwrap();

        // File A: backward directive to B (no explicit WD)
        let meta_a = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/b.R", dir_b),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // File B: backward directive to A AND explicit @lsp-cd
        // B's explicit WD means B doesn't need to inherit, breaking the cycle
        let meta_b = CrossFileMetadata {
            working_directory: Some(format!("/{}", wd_b)),
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/a.R", dir_a),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // Create metadata getter
        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &a_uri { Some(std::sync::Arc::new(meta_a.clone())) }
            else if uri == &b_uri { Some(std::sync::Arc::new(meta_b.clone())) }
            else { None }
        };

        // Compute A's inherited WD - should succeed because B has explicit WD
        // A tries to inherit from B, B has explicit WD, so A gets B's WD
        let a_inherited_wd = compute_inherited_working_directory(
            &a_uri,
            &meta_a,
            Some(&workspace_uri),
            get_metadata,
        );

        // A should inherit B's explicit working directory
        prop_assert!(
            a_inherited_wd.is_some(),
            "A should inherit B's explicit WD (cycle broken by B's explicit WD)"
        );

        let expected_wd = PathBuf::from(format!("/{}/{}", workspace, wd_b));
        let a_inherited_path = PathBuf::from(a_inherited_wd.as_ref().unwrap());
        prop_assert_eq!(
            a_inherited_path,
            expected_wd,
            "A should inherit B's explicit working directory"
        );
    }

    /// Feature: working-directory-inheritance, Property 10 extended: Cycle detection with visited set
    /// **Validates: Requirements 9.3**
    ///
    /// Tests the low-level cycle detection using compute_inherited_working_directory_with_visited
    /// directly, verifying that the visited set correctly tracks URIs.
    #[test]
    fn prop_cycle_handling_visited_set_tracking(
        workspace in path_component(),
        dir_a in path_component(),
        dir_b in path_component(),
    ) {
        // Ensure directories are different
        prop_assume!(dir_a != dir_b);

        use super::dependency::compute_inherited_working_directory_with_visited;
        use super::types::{BackwardDirective, CrossFileMetadata};
        use std::collections::HashSet;

        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();
        let a_uri = Url::parse(&format!("file:///{}/{}/a.R", workspace, dir_a)).unwrap();
        let b_uri = Url::parse(&format!("file:///{}/{}/b.R", workspace, dir_b)).unwrap();

        // File A: backward directive to B
        let meta_a = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/b.R", dir_b),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // File B: backward directive to A (creates cycle)
        let meta_b = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/a.R", dir_a),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // Create metadata getter
        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &a_uri { Some(std::sync::Arc::new(meta_a.clone())) }
            else if uri == &b_uri { Some(std::sync::Arc::new(meta_b.clone())) }
            else { None }
        };

        // Pre-populate visited set with A's URI to simulate cycle detection
        let mut visited = HashSet::new();
        visited.insert(a_uri.clone());

        // Now try to compute A's inherited WD with A already in visited set
        // This should immediately detect the cycle and return None
        let result = compute_inherited_working_directory_with_visited(
            &a_uri,
            &meta_a,
            Some(&workspace_uri),
            &get_metadata,
            10, // Sufficient depth
            &mut visited,
        );

        // Should return None because A is already in visited set (cycle detected)
        prop_assert!(
            result.is_none(),
            "Should return None when URI is already in visited set (cycle detected)"
        );
    }

    /// Feature: working-directory-inheritance, Property 10 extended: Cycle in middle of chain
    /// **Validates: Requirements 9.3**
    ///
    /// Tests cycle detection when the cycle occurs in the middle of a longer chain.
    /// Chain: D → C → B → A (where A has explicit WD)
    /// Even though A has a backward directive to B (potential cycle), A's explicit WD
    /// means it doesn't need to inherit, so the cycle is effectively broken.
    /// D should inherit A's explicit WD through the chain.
    ///
    /// Note: This test simulates proper metadata propagation where each file's
    /// inherited_working_directory is computed and stored before the next file
    /// in the chain is processed.
    #[test]
    fn prop_cycle_handling_cycle_in_middle_of_chain(
        workspace in path_component(),
        dir_a in path_component(),
        dir_b in path_component(),
        dir_c in path_component(),
        dir_d in path_component(),
        wd_a in path_component(),
    ) {
        // Ensure all directories are different from each other AND from workspace
        prop_assume!(dir_a != dir_b && dir_a != dir_c && dir_a != dir_d);
        prop_assume!(dir_b != dir_c && dir_b != dir_d);
        prop_assume!(dir_c != dir_d);
        prop_assume!(dir_a != workspace && dir_b != workspace && dir_c != workspace && dir_d != workspace);
        prop_assume!(wd_a != dir_a && wd_a != dir_b && wd_a != dir_c && wd_a != dir_d && wd_a != workspace);

        use super::dependency::compute_inherited_working_directory;
        use super::types::{BackwardDirective, CrossFileMetadata};

        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();
        let a_uri = Url::parse(&format!("file:///{}/{}/a.R", workspace, dir_a)).unwrap();
        let b_uri = Url::parse(&format!("file:///{}/{}/b.R", workspace, dir_b)).unwrap();
        let c_uri = Url::parse(&format!("file:///{}/{}/c.R", workspace, dir_c)).unwrap();
        let d_uri = Url::parse(&format!("file:///{}/{}/d.R", workspace, dir_d)).unwrap();

        // File A: has explicit @lsp-cd AND backward directive to B (creates potential cycle A → B → A)
        // But A's explicit WD means A doesn't need to inherit, breaking the cycle
        let meta_a = CrossFileMetadata {
            working_directory: Some(format!("/{}", wd_a)),
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/b.R", dir_b),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // File B: backward directive to A (part of potential cycle)
        let meta_b_initial = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/a.R", dir_a),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // Step 1: Compute B's inherited WD from A
        let get_meta_a = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &a_uri { Some(std::sync::Arc::new(meta_a.clone())) } else { None }
        };
        let b_inherited_wd = compute_inherited_working_directory(
            &b_uri, &meta_b_initial, Some(&workspace_uri), get_meta_a,
        );
        prop_assert!(b_inherited_wd.is_some(), "B should inherit A's explicit WD");

        // Create B's metadata with inherited WD
        let meta_b = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: b_inherited_wd.clone(),
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/a.R", dir_a),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // File C: backward directive to B
        let meta_c_initial = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/b.R", dir_b),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // Step 2: Compute C's inherited WD from B
        let meta_a_clone = meta_a.clone();
        let meta_b_clone = meta_b.clone();
        let a_uri_clone = a_uri.clone();
        let b_uri_clone = b_uri.clone();
        let get_meta_ab = move |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &a_uri_clone { Some(std::sync::Arc::new(meta_a_clone.clone())) }
            else if uri == &b_uri_clone { Some(std::sync::Arc::new(meta_b_clone.clone())) }
            else { None }
        };
        let c_inherited_wd = compute_inherited_working_directory(
            &c_uri, &meta_c_initial, Some(&workspace_uri), get_meta_ab,
        );
        prop_assert!(c_inherited_wd.is_some(), "C should inherit from B");

        // Create C's metadata with inherited WD
        let meta_c = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: c_inherited_wd.clone(),
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/b.R", dir_b),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // File D: backward directive to C
        let meta_d = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/c.R", dir_c),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // Step 3: Compute D's inherited WD from C
        let get_meta_all = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &a_uri { Some(std::sync::Arc::new(meta_a.clone())) }
            else if uri == &b_uri { Some(std::sync::Arc::new(meta_b.clone())) }
            else if uri == &c_uri { Some(std::sync::Arc::new(meta_c.clone())) }
            else { None }
        };
        let d_inherited_wd = compute_inherited_working_directory(
            &d_uri,
            &meta_d,
            Some(&workspace_uri),
            get_meta_all,
        );

        // D should eventually inherit A's explicit WD through the chain
        // (A has explicit WD, so it doesn't try to inherit from B, avoiding the cycle)
        prop_assert!(
            d_inherited_wd.is_some(),
            "D should inherit WD through chain D → C → B → A"
        );

        // The inherited WD should be A's explicit WD
        let expected_wd = PathBuf::from(format!("/{}/{}", workspace, wd_a));
        let d_inherited_path = PathBuf::from(d_inherited_wd.as_ref().unwrap());
        prop_assert_eq!(
            d_inherited_path,
            expected_wd,
            "D should inherit A's explicit WD through the chain"
        );
    }

    /// Feature: working-directory-inheritance, Property 10 extended: All files in cycle have no explicit WD
    /// **Validates: Requirements 9.3**
    ///
    /// Tests the worst-case scenario where all files in a cycle have no explicit WD.
    /// The system should detect the cycle and fall back to file directories.
    #[test]
    fn prop_cycle_handling_all_implicit_wd(
        workspace in path_component(),
        dir_a in path_component(),
        dir_b in path_component(),
    ) {
        // Ensure directories are different
        prop_assume!(dir_a != dir_b);

        use super::dependency::compute_inherited_working_directory;
        use super::types::{BackwardDirective, CrossFileMetadata};

        let workspace_uri = Url::parse(&format!("file:///{}", workspace)).unwrap();
        let a_uri = Url::parse(&format!("file:///{}/{}/a.R", workspace, dir_a)).unwrap();
        let b_uri = Url::parse(&format!("file:///{}/{}/b.R", workspace, dir_b)).unwrap();

        // File A: backward directive to B, no explicit WD
        let meta_a = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/b.R", dir_b),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // File B: backward directive to A, no explicit WD (creates cycle)
        let meta_b = CrossFileMetadata {
            working_directory: None,
            application_working_directory: None,
            inherited_working_directory: None,
            sourced_by: vec![BackwardDirective {
                path: format!("../{}/a.R", dir_a),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            ..Default::default()
        };

        // Create metadata getter
        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &a_uri { Some(std::sync::Arc::new(meta_a.clone())) }
            else if uri == &b_uri { Some(std::sync::Arc::new(meta_b.clone())) }
            else { None }
        };

        // Compute A's inherited WD
        // Chain: A → B → A (cycle detected)
        // When cycle is detected, falls back to file's directory
        let a_inherited_wd = compute_inherited_working_directory(
            &a_uri,
            &meta_a,
            Some(&workspace_uri),
            get_metadata,
        );

        // Should get some result (fallback to directory when cycle detected)
        prop_assert!(
            a_inherited_wd.is_some(),
            "Should fall back to directory when cycle detected with all implicit WDs"
        );

        // The result should be within the workspace
        let a_inherited_path = PathBuf::from(a_inherited_wd.as_ref().unwrap());
        prop_assert!(
            a_inherited_path.starts_with(format!("/{}", workspace)),
            "Fallback directory should be within workspace"
        );
    }
}

// ============================================================================
// Feature: lsp-source-directive, Property 1: Forward Directive Parsing Completeness
// Validates: Requirements 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9
// ============================================================================

/// Generate a forward directive synonym
fn forward_directive_synonym() -> impl Strategy<Value = &'static str> {
    prop_oneof![Just("lsp-source"), Just("lsp-run"), Just("lsp-include"),]
}

/// Generate optional colon separator
fn optional_colon() -> impl Strategy<Value = &'static str> {
    prop_oneof![Just(":"), Just(""),]
}

/// Quote style for paths
#[derive(Debug, Clone, Copy)]
enum QuoteStyle {
    None,
    Double,
    Single,
}

fn quote_style() -> impl Strategy<Value = QuoteStyle> {
    prop_oneof![
        Just(QuoteStyle::None),
        Just(QuoteStyle::Double),
        Just(QuoteStyle::Single),
    ]
}

/// Format a path with the given quote style
fn format_path_with_quotes(path: &str, style: QuoteStyle) -> String {
    match style {
        QuoteStyle::None => path.to_string(),
        QuoteStyle::Double => format!("\"{}\"", path),
        QuoteStyle::Single => format!("'{}'", path),
    }
}

/// Generate optional line=N parameter
fn optional_line_param() -> impl Strategy<Value = Option<u32>> {
    prop_oneof![Just(None), (1..1000u32).prop_map(Some),]
}

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: lsp-source-directive, Property 1: Forward Directive Parsing Completeness
    ///
    /// For any valid forward directive syntax variation (with/without colon,
    /// with single/double/no quotes, with/without line= parameter), the Directive_Parser
    /// SHALL produce a ForwardSource entry with the correct path and `is_directive=true`.
    ///
    /// **Validates: Requirements 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9**
    #[test]
    fn prop_forward_directive_parsing_completeness(
        synonym in forward_directive_synonym(),
        colon in optional_colon(),
        path in relative_path(),  // Use simple path for unquoted case
        quotes in quote_style(),
        line_param in optional_line_param(),
        prefix_lines in 0..5u32,
    ) {
        // Skip unquoted paths with spaces (invalid syntax)
        let formatted_path = format_path_with_quotes(&path, quotes);

        // Build the directive line
        let line_suffix = match line_param {
            Some(n) => format!(" line={}", n),
            None => String::new(),
        };

        // Build prefix lines to test directive line position
        let mut lines = Vec::new();
        for i in 0..prefix_lines {
            lines.push(format!("x{} <- {}", i, i));
        }
        lines.push(format!("# @{}{} {}{}", synonym, colon, formatted_path, line_suffix));
        let content = lines.join("\n");

        let meta = parse_directives(&content);

        // Requirement 1.1-1.3: Should produce exactly one ForwardSource
        prop_assert_eq!(
            meta.sources.len(),
            1,
            "Expected 1 ForwardSource for directive: # @{}{} {}{}",
            synonym, colon, formatted_path, line_suffix
        );

        let source = &meta.sources[0];

        // Requirement 1.6, 1.7, 1.9: Path should be extracted correctly (without quotes)
        prop_assert_eq!(
            &source.path,
            &path,
            "Path should be extracted without quotes"
        );

        // Requirement: is_directive should be true
        prop_assert!(
            source.is_directive,
            "is_directive should be true for @lsp-source directive"
        );

        // Requirement 2.1, 2.2: Line should be correct
        let expected_line = match line_param {
            Some(n) => n.saturating_sub(1), // Convert 1-based to 0-based
            None => prefix_lines,           // Use directive's own line
        };
        prop_assert_eq!(
            source.line,
            expected_line,
            "Line should be {} (line_param={:?}, prefix_lines={})",
            expected_line, line_param, prefix_lines
        );

        // Requirement 2.4: Column should always be 0 for directives
        prop_assert_eq!(
            source.column,
            0,
            "Column should always be 0 for directive-based sources"
        );

        // Directive-specific flags
        prop_assert_eq!(
            source.locality,
            SourceLocality::Global,
            "directives should source into the global environment"
        );
        prop_assert!(!source.chdir, "chdir should be false for directives");
        prop_assert!(!source.is_sys_source, "is_sys_source should be false for directives");
    }

    /// Feature: lsp-source-directive, Property 1 Extended: Paths with spaces require quotes
    ///
    /// For any path containing spaces, the directive MUST use quotes (single or double)
    /// for the path to be correctly extracted.
    ///
    /// **Validates: Requirements 1.6, 1.7, 1.8**
    #[test]
    fn prop_forward_directive_paths_with_spaces(
        synonym in forward_directive_synonym(),
        colon in optional_colon(),
        dir in path_component(),
        file in path_component(),
        use_double_quotes in proptest::bool::ANY,
    ) {
        let path_with_spaces = format!("{} folder/{}.R", dir, file);

        let formatted_path = if use_double_quotes {
            format!("\"{}\"", path_with_spaces)
        } else {
            format!("'{}'", path_with_spaces)
        };

        let content = format!("# @{}{} {}", synonym, colon, formatted_path);
        let meta = parse_directives(&content);

        // Should produce exactly one ForwardSource
        prop_assert_eq!(meta.sources.len(), 1);

        // Requirement 1.8: Path with spaces should be preserved
        prop_assert_eq!(
            &meta.sources[0].path,
            &path_with_spaces,
            "Path with spaces should be preserved"
        );

        prop_assert!(meta.sources[0].is_directive);
    }

    /// Feature: lsp-source-directive, Property 1 Extended: All syntax combinations
    ///
    /// Exhaustively test all combinations of @ prefix, colon, and quote styles
    /// to ensure complete coverage of the directive syntax.
    ///
    /// **Validates: Requirements 1.4, 1.5, 1.6, 1.7, 1.9**
    #[test]
    fn prop_forward_directive_all_syntax_combinations(
        path in relative_path(),
    ) {
        let synonyms = ["lsp-source", "lsp-run", "lsp-include"];
        let colons = [":", ""];
        let quote_styles = [QuoteStyle::None, QuoteStyle::Double, QuoteStyle::Single];

        for synonym in &synonyms {
            for colon in &colons {
                for quotes in &quote_styles {
                    let formatted_path = format_path_with_quotes(&path, *quotes);
                    let content = format!("# @{}{} {}", synonym, colon, formatted_path);
                    let meta = parse_directives(&content);

                    prop_assert_eq!(
                        meta.sources.len(),
                        1,
                        "Failed for: {}",
                        content
                    );
                    prop_assert_eq!(
                        &meta.sources[0].path,
                        &path,
                        "Path mismatch for: {}",
                        content
                    );
                    prop_assert!(
                        meta.sources[0].is_directive,
                        "is_directive should be true for: {}",
                        content
                    );
                }
            }
        }
    }

    /// Feature: lsp-source-directive, Property 2: Synonym Equivalence
    ///
    /// For any path string, parsing `@lsp-source <path>`, `@lsp-run <path>`, and
    /// `@lsp-include <path>` SHALL produce identical ForwardSource entries
    /// (same path, same flags).
    ///
    /// **Validates: Requirements 1.2, 1.3**
    #[test]
    fn prop_forward_directive_synonym_equivalence(
        path in relative_path_with_parents(),
    ) {
        let source_content = format!("# @lsp-source {}", path);
        let run_content = format!("# @lsp-run {}", path);
        let include_content = format!("# @lsp-include {}", path);

        let meta_source = parse_directives(&source_content);
        let meta_run = parse_directives(&run_content);
        let meta_include = parse_directives(&include_content);

        // All should produce exactly one ForwardSource
        prop_assert_eq!(meta_source.sources.len(), 1, "@lsp-source should produce 1 ForwardSource");
        prop_assert_eq!(meta_run.sources.len(), 1, "@lsp-run should produce 1 ForwardSource");
        prop_assert_eq!(meta_include.sources.len(), 1, "@lsp-include should produce 1 ForwardSource");

        let source = &meta_source.sources[0];
        let run = &meta_run.sources[0];
        let include = &meta_include.sources[0];

        // All should have the same path
        prop_assert_eq!(&source.path, &path, "@lsp-source path mismatch");
        prop_assert_eq!(&run.path, &path, "@lsp-run path mismatch");
        prop_assert_eq!(&include.path, &path, "@lsp-include path mismatch");

        // All should have identical flags
        prop_assert_eq!(source.is_directive, run.is_directive, "is_directive mismatch between @lsp-source and @lsp-run");
        prop_assert_eq!(source.is_directive, include.is_directive, "is_directive mismatch between @lsp-source and @lsp-include");
        prop_assert!(source.is_directive, "is_directive should be true for all synonyms");

        prop_assert_eq!(source.locality, run.locality, "locality mismatch between @lsp-source and @lsp-run");
        prop_assert_eq!(source.locality, include.locality, "locality mismatch between @lsp-source and @lsp-include");

        prop_assert_eq!(source.chdir, run.chdir, "chdir mismatch between @lsp-source and @lsp-run");
        prop_assert_eq!(source.chdir, include.chdir, "chdir mismatch between @lsp-source and @lsp-include");

        prop_assert_eq!(source.is_sys_source, run.is_sys_source, "is_sys_source mismatch between @lsp-source and @lsp-run");
        prop_assert_eq!(source.is_sys_source, include.is_sys_source, "is_sys_source mismatch between @lsp-source and @lsp-include");

        // All should have the same line (0, since directive is on first line)
        prop_assert_eq!(source.line, run.line, "line mismatch between @lsp-source and @lsp-run");
        prop_assert_eq!(source.line, include.line, "line mismatch between @lsp-source and @lsp-include");

        // All should have column = 0 for directives
        prop_assert_eq!(source.column, run.column, "column mismatch between @lsp-source and @lsp-run");
        prop_assert_eq!(source.column, include.column, "column mismatch between @lsp-source and @lsp-include");
        prop_assert_eq!(source.column, 0, "column should be 0 for all directive synonyms");
    }

    /// Feature: lsp-source-directive, Property 2 Extended: Synonym equivalence with colon
    ///
    /// Synonyms with colon separator should also produce identical ForwardSource entries.
    ///
    /// **Validates: Requirements 1.2, 1.3, 1.5**
    #[test]
    fn prop_forward_directive_synonym_equivalence_with_colon(
        path in relative_path_with_parents(),
    ) {
        let source_content = format!("# @lsp-source: {}", path);
        let run_content = format!("# @lsp-run: {}", path);
        let include_content = format!("# @lsp-include: {}", path);

        let meta_source = parse_directives(&source_content);
        let meta_run = parse_directives(&run_content);
        let meta_include = parse_directives(&include_content);

        // All should produce exactly one ForwardSource
        prop_assert_eq!(meta_source.sources.len(), 1);
        prop_assert_eq!(meta_run.sources.len(), 1);
        prop_assert_eq!(meta_include.sources.len(), 1);

        // All should have the same path
        prop_assert_eq!(&meta_source.sources[0].path, &path);
        prop_assert_eq!(&meta_run.sources[0].path, &path);
        prop_assert_eq!(&meta_include.sources[0].path, &path);

        // All should have identical ForwardSource structures
        prop_assert_eq!(&meta_source.sources[0], &meta_run.sources[0], "@lsp-source: and @lsp-run: should produce identical ForwardSource");
        prop_assert_eq!(&meta_source.sources[0], &meta_include.sources[0], "@lsp-source: and @lsp-include: should produce identical ForwardSource");
    }

    /// Feature: lsp-source-directive, Property 2 Extended: Synonym equivalence with quotes
    ///
    /// Synonyms with quoted paths should also produce identical ForwardSource entries.
    ///
    /// **Validates: Requirements 1.2, 1.3, 1.6, 1.7**
    #[test]
    fn prop_forward_directive_synonym_equivalence_with_quotes(
        path in relative_path_with_parents(),
    ) {
        // Test with double quotes
        let source_double = format!("# @lsp-source \"{}\"", path);
        let run_double = format!("# @lsp-run \"{}\"", path);
        let include_double = format!("# @lsp-include \"{}\"", path);

        let meta_source_double = parse_directives(&source_double);
        let meta_run_double = parse_directives(&run_double);
        let meta_include_double = parse_directives(&include_double);

        prop_assert_eq!(meta_source_double.sources.len(), 1);
        prop_assert_eq!(meta_run_double.sources.len(), 1);
        prop_assert_eq!(meta_include_double.sources.len(), 1);

        prop_assert_eq!(&meta_source_double.sources[0], &meta_run_double.sources[0], "@lsp-source and @lsp-run with double quotes should produce identical ForwardSource");
        prop_assert_eq!(&meta_source_double.sources[0], &meta_include_double.sources[0], "@lsp-source and @lsp-include with double quotes should produce identical ForwardSource");

        // Test with single quotes
        let source_single = format!("# @lsp-source '{}'", path);
        let run_single = format!("# @lsp-run '{}'", path);
        let include_single = format!("# @lsp-include '{}'", path);

        let meta_source_single = parse_directives(&source_single);
        let meta_run_single = parse_directives(&run_single);
        let meta_include_single = parse_directives(&include_single);

        prop_assert_eq!(meta_source_single.sources.len(), 1);
        prop_assert_eq!(meta_run_single.sources.len(), 1);
        prop_assert_eq!(meta_include_single.sources.len(), 1);

        prop_assert_eq!(&meta_source_single.sources[0], &meta_run_single.sources[0], "@lsp-source and @lsp-run with single quotes should produce identical ForwardSource");
        prop_assert_eq!(&meta_source_single.sources[0], &meta_include_single.sources[0], "@lsp-source and @lsp-include with single quotes should produce identical ForwardSource");

        // Double and single quotes should also produce identical results
        prop_assert_eq!(&meta_source_double.sources[0], &meta_source_single.sources[0], "Double and single quotes should produce identical ForwardSource");
    }

    /// Feature: lsp-source-directive, Property 2 Extended: Synonym equivalence without @ prefix
    ///
    /// Synonyms without @ prefix should NOT be recognized as directives.
    ///
    /// **Validates: All directives require @ prefix**
    #[test]
    fn prop_forward_directive_synonym_no_at_prefix_not_recognized(
        path in relative_path_with_parents(),
    ) {
        let source_content = format!("# lsp-source {}", path);
        let run_content = format!("# lsp-run {}", path);
        let include_content = format!("# lsp-include {}", path);

        let meta_source = parse_directives(&source_content);
        let meta_run = parse_directives(&run_content);
        let meta_include = parse_directives(&include_content);

        // None should produce any ForwardSource entries
        prop_assert_eq!(meta_source.sources.len(), 0, "lsp-source without @ should not be recognized");
        prop_assert_eq!(meta_run.sources.len(), 0, "lsp-run without @ should not be recognized");
        prop_assert_eq!(meta_include.sources.len(), 0, "lsp-include without @ should not be recognized");
    }
}

// ============================================================================
// Feature: lsp-source-directive, Property 3: Call-Site Line Conversion
// Validates: Requirements 2.1
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: lsp-source-directive, Property 3: Call-Site Line Conversion
    ///
    /// *For any* forward directive with `line=N` parameter where N is a positive integer,
    /// the resulting ForwardSource SHALL have `line = N - 1` (converting from 1-based
    /// user input to 0-based internal representation).
    ///
    /// **Validates: Requirements 2.1**
    #[test]
    fn prop_forward_directive_call_site_line_conversion(
        path in relative_path(),
        user_line in 1..10000u32,  // 1-based line numbers (user input)
    ) {
        // Create directive with line=N parameter
        let content = format!("# @lsp-source {} line={}", path, user_line);
        let meta = parse_directives(&content);

        // Should produce exactly one ForwardSource
        prop_assert_eq!(
            meta.sources.len(),
            1,
            "Expected 1 ForwardSource for directive with line={}", user_line
        );

        let source = &meta.sources[0];

        // Core property: line should be N-1 (0-based internal representation)
        let expected_line = user_line.saturating_sub(1);
        prop_assert_eq!(
            source.line,
            expected_line,
            "For line={} (1-based), internal line should be {} (0-based), but got {}",
            user_line, expected_line, source.line
        );

        // Verify path is correct
        prop_assert_eq!(&source.path, &path);

        // Verify is_directive flag
        prop_assert!(source.is_directive, "is_directive should be true");

        // Verify column is always 0 for directives
        prop_assert_eq!(source.column, 0, "column should always be 0 for directives");
    }

    /// Feature: lsp-source-directive, Property 3 Extended: Line conversion with all synonyms
    ///
    /// The line=N to N-1 conversion should work identically for all forward directive
    /// synonyms (@lsp-source, @lsp-run, @lsp-include).
    ///
    /// **Validates: Requirements 2.1**
    #[test]
    fn prop_forward_directive_call_site_line_conversion_all_synonyms(
        path in relative_path(),
        user_line in 1..1000u32,
    ) {
        let synonyms = ["@lsp-source", "@lsp-run", "@lsp-include"];
        let expected_line = user_line.saturating_sub(1);

        for synonym in &synonyms {
            let content = format!("# {} {} line={}", synonym, path, user_line);
            let meta = parse_directives(&content);

            prop_assert_eq!(
                meta.sources.len(),
                1,
                "Expected 1 ForwardSource for {} with line={}", synonym, user_line
            );

            prop_assert_eq!(
                meta.sources[0].line,
                expected_line,
                "For {} line={}, internal line should be {}, but got {}",
                synonym, user_line, expected_line, meta.sources[0].line
            );
        }
    }

    /// Feature: lsp-source-directive, Property 3 Extended: Line conversion with various syntax
    ///
    /// The line=N to N-1 conversion should work with all syntax variations
    /// (with/without colon, with/without quotes).
    ///
    /// **Validates: Requirements 2.1**
    #[test]
    fn prop_forward_directive_call_site_line_conversion_syntax_variations(
        path in relative_path(),
        user_line in 1..500u32,
        colon in optional_colon(),
        quotes in quote_style(),
    ) {
        let formatted_path = format_path_with_quotes(&path, quotes);
        let content = format!("# @lsp-source{} {} line={}", colon, formatted_path, user_line);
        let meta = parse_directives(&content);

        let expected_line = user_line.saturating_sub(1);

        prop_assert_eq!(
            meta.sources.len(),
            1,
            "Expected 1 ForwardSource for directive: {}", content
        );

        prop_assert_eq!(
            meta.sources[0].line,
            expected_line,
            "For '{}', internal line should be {} (0-based), but got {}",
            content, expected_line, meta.sources[0].line
        );
    }

    /// Feature: lsp-source-directive, Property 3 Extended: Edge case line=1
    ///
    /// The minimum valid line number (line=1) should convert to 0.
    ///
    /// **Validates: Requirements 2.1**
    #[test]
    fn prop_forward_directive_call_site_line_one_converts_to_zero(
        path in relative_path(),
    ) {
        let content = format!("# @lsp-source {} line=1", path);
        let meta = parse_directives(&content);

        prop_assert_eq!(meta.sources.len(), 1);
        prop_assert_eq!(
            meta.sources[0].line,
            0,
            "line=1 (1-based) should convert to 0 (0-based)"
        );
    }

    /// Feature: lsp-source-directive, Property 3 Extended: Large line numbers
    ///
    /// Large line numbers should also be correctly converted.
    ///
    /// **Validates: Requirements 2.1**
    #[test]
    fn prop_forward_directive_call_site_large_line_numbers(
        path in relative_path(),
        user_line in 10000..100000u32,
    ) {
        let content = format!("# @lsp-source {} line={}", path, user_line);
        let meta = parse_directives(&content);

        let expected_line = user_line.saturating_sub(1);

        prop_assert_eq!(meta.sources.len(), 1);
        prop_assert_eq!(
            meta.sources[0].line,
            expected_line,
            "For line={}, internal line should be {}", user_line, expected_line
        );
    }
}

// ============================================================================
// Feature: lsp-source-directive, Property 4: Default Call-Site Assignment
// Validates: Requirements 2.2
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: lsp-source-directive, Property 4: Default Call-Site Assignment
    ///
    /// *For any* forward directive without a `line=` parameter appearing at line L (0-based),
    /// the resulting ForwardSource SHALL have `line = L`.
    ///
    /// **Validates: Requirements 2.2**
    #[test]
    fn prop_forward_directive_default_call_site_assignment(
        path in relative_path(),
        prefix_lines in 0..50u32,  // Number of lines before the directive
    ) {
        // Build content with prefix_lines lines before the directive
        let mut lines = Vec::new();
        for i in 0..prefix_lines {
            lines.push(format!("x{} <- {}", i, i));
        }
        // Add the directive WITHOUT line= parameter
        lines.push(format!("# @lsp-source {}", path));
        let content = lines.join("\n");

        let meta = parse_directives(&content);

        // Should produce exactly one ForwardSource
        prop_assert_eq!(
            meta.sources.len(),
            1,
            "Expected 1 ForwardSource for directive at line {}", prefix_lines
        );

        let source = &meta.sources[0];

        // Core property: line should equal the directive's own line position (0-based)
        prop_assert_eq!(
            source.line,
            prefix_lines,
            "For directive at line {} (0-based), ForwardSource.line should be {}, but got {}",
            prefix_lines, prefix_lines, source.line
        );

        // Verify path is correct
        prop_assert_eq!(&source.path, &path);

        // Verify is_directive flag
        prop_assert!(source.is_directive, "is_directive should be true");

        // Verify column is always 0 for directives
        prop_assert_eq!(source.column, 0, "column should always be 0 for directives");
    }

    /// Feature: lsp-source-directive, Property 4 Extended: Default call-site with all synonyms
    ///
    /// The default call-site assignment (using directive's own line) should work
    /// identically for all forward directive synonyms.
    ///
    /// **Validates: Requirements 2.2**
    #[test]
    fn prop_forward_directive_default_call_site_all_synonyms(
        path in relative_path(),
        prefix_lines in 0..20u32,
    ) {
        let synonyms = ["@lsp-source", "@lsp-run", "@lsp-include"];

        for synonym in &synonyms {
            let mut lines = Vec::new();
            for i in 0..prefix_lines {
                lines.push(format!("y{} <- {}", i, i));
            }
            lines.push(format!("# {} {}", synonym, path));
            let content = lines.join("\n");

            let meta = parse_directives(&content);

            prop_assert_eq!(
                meta.sources.len(),
                1,
                "Expected 1 ForwardSource for {} at line {}", synonym, prefix_lines
            );

            prop_assert_eq!(
                meta.sources[0].line,
                prefix_lines,
                "For {} at line {}, ForwardSource.line should be {}, but got {}",
                synonym, prefix_lines, prefix_lines, meta.sources[0].line
            );
        }
    }

    /// Feature: lsp-source-directive, Property 4 Extended: Default call-site with syntax variations
    ///
    /// The default call-site assignment should work with all syntax variations
    /// (with/without colon, with/without quotes).
    ///
    /// **Validates: Requirements 2.2**
    #[test]
    fn prop_forward_directive_default_call_site_syntax_variations(
        path in relative_path(),
        prefix_lines in 0..15u32,
        colon in optional_colon(),
        quotes in quote_style(),
    ) {
        let formatted_path = format_path_with_quotes(&path, quotes);

        let mut lines = Vec::new();
        for i in 0..prefix_lines {
            lines.push(format!("z{} <- {}", i, i));
        }
        // Directive WITHOUT line= parameter
        lines.push(format!("# @lsp-source{} {}", colon, formatted_path));
        let content = lines.join("\n");

        let meta = parse_directives(&content);

        prop_assert_eq!(
            meta.sources.len(),
            1,
            "Expected 1 ForwardSource for directive at line {}", prefix_lines
        );

        prop_assert_eq!(
            meta.sources[0].line,
            prefix_lines,
            "For directive at line {}, ForwardSource.line should be {}, but got {}",
            prefix_lines, prefix_lines, meta.sources[0].line
        );
    }

    /// Feature: lsp-source-directive, Property 4 Extended: Default call-site at line 0
    ///
    /// When the directive is on the first line (line 0), the ForwardSource.line should be 0.
    ///
    /// **Validates: Requirements 2.2**
    #[test]
    fn prop_forward_directive_default_call_site_line_zero(
        path in relative_path(),
    ) {
        // Directive on the very first line (no prefix lines)
        let content = format!("# @lsp-source {}", path);
        let meta = parse_directives(&content);

        prop_assert_eq!(meta.sources.len(), 1);
        prop_assert_eq!(
            meta.sources[0].line,
            0,
            "Directive on first line should have ForwardSource.line = 0"
        );
    }

    /// Feature: lsp-source-directive, Property 4 Extended: Default call-site vs explicit line=
    ///
    /// Verify that default call-site (no line=) differs from explicit line= parameter.
    /// When directive is at line L and has line=N, the ForwardSource.line should be N-1, not L.
    ///
    /// **Validates: Requirements 2.2 (by contrast with 2.1)**
    #[test]
    fn prop_forward_directive_default_vs_explicit_call_site(
        path in relative_path(),
        prefix_lines in 1..20u32,  // At least 1 prefix line so directive is not at line 0
        explicit_line in 1..100u32,
    ) {
        // Directive WITHOUT line= parameter
        let mut lines_default = Vec::new();
        for i in 0..prefix_lines {
            lines_default.push(format!("a{} <- {}", i, i));
        }
        lines_default.push(format!("# @lsp-source {}", path));
        let content_default = lines_default.join("\n");

        // Directive WITH line= parameter
        let mut lines_explicit = Vec::new();
        for i in 0..prefix_lines {
            lines_explicit.push(format!("b{} <- {}", i, i));
        }
        lines_explicit.push(format!("# @lsp-source {} line={}", path, explicit_line));
        let content_explicit = lines_explicit.join("\n");

        let meta_default = parse_directives(&content_default);
        let meta_explicit = parse_directives(&content_explicit);

        prop_assert_eq!(meta_default.sources.len(), 1);
        prop_assert_eq!(meta_explicit.sources.len(), 1);

        // Default should use directive's own line
        prop_assert_eq!(
            meta_default.sources[0].line,
            prefix_lines,
            "Default call-site should be directive's line ({})", prefix_lines
        );

        // Explicit should use line=N converted to 0-based
        let expected_explicit = explicit_line.saturating_sub(1);
        prop_assert_eq!(
            meta_explicit.sources[0].line,
            expected_explicit,
            "Explicit line={} should convert to {}", explicit_line, expected_explicit
        );

        // They should differ (unless by coincidence prefix_lines == explicit_line - 1)
        // This is just a sanity check, not a strict property
    }

    /// Feature: lsp-source-directive, Property 4 Extended: Multiple directives at different lines
    ///
    /// When multiple directives without line= appear at different lines, each should
    /// have its ForwardSource.line set to its own line position.
    ///
    /// **Validates: Requirements 2.2, 2.3**
    #[test]
    fn prop_forward_directive_multiple_default_call_sites(
        path1 in relative_path(),
        path2 in relative_path(),
        path3 in relative_path(),
        gap1 in 0..5u32,  // Lines between start and first directive
        gap2 in 1..5u32,  // Lines between first and second directive
        gap3 in 1..5u32,  // Lines between second and third directive
    ) {
        let mut lines = Vec::new();

        // Add gap1 lines before first directive
        for i in 0..gap1 {
            lines.push(format!("pre1_{} <- {}", i, i));
        }
        let line1 = lines.len() as u32;
        lines.push(format!("# @lsp-source {}", path1));

        // Add gap2 lines before second directive
        for i in 0..gap2 {
            lines.push(format!("pre2_{} <- {}", i, i));
        }
        let line2 = lines.len() as u32;
        lines.push(format!("# @lsp-run {}", path2));

        // Add gap3 lines before third directive
        for i in 0..gap3 {
            lines.push(format!("pre3_{} <- {}", i, i));
        }
        let line3 = lines.len() as u32;
        lines.push(format!("# @lsp-include {}", path3));

        let content = lines.join("\n");
        let meta = parse_directives(&content);

        // Should produce exactly 3 ForwardSource entries
        prop_assert_eq!(
            meta.sources.len(),
            3,
            "Expected 3 ForwardSource entries"
        );

        // Each should have its line set to its own position
        prop_assert_eq!(
            meta.sources[0].line,
            line1,
            "First directive at line {} should have ForwardSource.line = {}", line1, line1
        );
        prop_assert_eq!(
            meta.sources[1].line,
            line2,
            "Second directive at line {} should have ForwardSource.line = {}", line2, line2
        );
        prop_assert_eq!(
            meta.sources[2].line,
            line3,
            "Third directive at line {} should have ForwardSource.line = {}", line3, line3
        );

        // Verify paths are correct
        prop_assert_eq!(&meta.sources[0].path, &path1);
        prop_assert_eq!(&meta.sources[1].path, &path2);
        prop_assert_eq!(&meta.sources[2].path, &path3);
    }
}

// ============================================================================
// Feature: lsp-source-directive, Property 5: Multiple Directive Independence
// Validates: Requirements 2.3
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: lsp-source-directive, Property 5: Multiple Directive Independence
    ///
    /// *For any* file containing N forward directives, the Directive_Parser SHALL produce
    /// exactly N ForwardSource entries, each with the correct path and line.
    ///
    /// This property verifies that:
    /// 1. Each directive is parsed independently
    /// 2. No directives are lost or duplicated
    /// 3. Each ForwardSource has the correct path
    /// 4. Each ForwardSource has the correct line (either from line= param or directive position)
    ///
    /// **Validates: Requirements 2.3**
    #[test]
    fn prop_forward_directive_multiple_independence(
        num_directives in 1..=10usize,
    ) {
        // Generate unique paths for each directive
        let paths: Vec<String> = (0..num_directives)
            .map(|i| format!("file_{}.R", i))
            .collect();

        // Build file content with N directives, each on its own line
        // Use different synonyms to also verify synonym handling
        let synonyms = ["@lsp-source", "@lsp-run", "@lsp-include"];
        let mut lines = Vec::new();
        let mut expected_entries: Vec<(String, u32)> = Vec::new();

        for (i, path) in paths.iter().enumerate() {
            let synonym = synonyms[i % synonyms.len()];
            let line_num = lines.len() as u32;
            lines.push(format!("# {} {}", synonym, path));
            expected_entries.push((path.clone(), line_num));
        }

        let content = lines.join("\n");
        let meta = parse_directives(&content);

        // Property: Exactly N ForwardSource entries
        prop_assert_eq!(
            meta.sources.len(),
            num_directives,
            "Expected {} ForwardSource entries, got {}",
            num_directives,
            meta.sources.len()
        );

        // Property: Each entry has correct path and line
        for (i, (expected_path, expected_line)) in expected_entries.iter().enumerate() {
            prop_assert_eq!(
                &meta.sources[i].path,
                expected_path,
                "Entry {} should have path '{}', got '{}'",
                i,
                expected_path,
                meta.sources[i].path
            );
            prop_assert_eq!(
                meta.sources[i].line,
                *expected_line,
                "Entry {} should have line {}, got {}",
                i,
                expected_line,
                meta.sources[i].line
            );
            // All directive-based sources should have is_directive=true
            prop_assert!(
                meta.sources[i].is_directive,
                "Entry {} should have is_directive=true",
                i
            );
            // All directive-based sources should have column=0
            prop_assert_eq!(
                meta.sources[i].column,
                0,
                "Entry {} should have column=0",
                i
            );
        }
    }

    /// Feature: lsp-source-directive, Property 5 Extended: Multiple directives with explicit line= params
    ///
    /// When multiple directives have explicit line= parameters, each should independently
    /// convert its line number from 1-based to 0-based.
    ///
    /// **Validates: Requirements 2.1, 2.3**
    #[test]
    fn prop_forward_directive_multiple_with_explicit_lines(
        num_directives in 1..=10usize,
    ) {
        // Generate unique paths and line numbers for each directive
        let mut lines = Vec::new();
        let mut expected_entries: Vec<(String, u32)> = Vec::new();

        for i in 0..num_directives {
            let path = format!("module_{}.R", i);
            // Use different explicit line numbers (1-based user input)
            let explicit_line = (i as u32 + 1) * 10; // 10, 20, 30, ...
            let expected_line = explicit_line - 1; // Convert to 0-based

            lines.push(format!("# @lsp-source {} line={}", path, explicit_line));
            expected_entries.push((path, expected_line));
        }

        let content = lines.join("\n");
        let meta = parse_directives(&content);

        // Property: Exactly N ForwardSource entries
        prop_assert_eq!(
            meta.sources.len(),
            num_directives,
            "Expected {} ForwardSource entries, got {}",
            num_directives,
            meta.sources.len()
        );

        // Property: Each entry has correct path and converted line
        for (i, (expected_path, expected_line)) in expected_entries.iter().enumerate() {
            prop_assert_eq!(
                &meta.sources[i].path,
                expected_path,
                "Entry {} should have path '{}', got '{}'",
                i,
                expected_path,
                meta.sources[i].path
            );
            prop_assert_eq!(
                meta.sources[i].line,
                *expected_line,
                "Entry {} should have line {} (converted from {}), got {}",
                i,
                expected_line,
                expected_line + 1,
                meta.sources[i].line
            );
        }
    }

    /// Feature: lsp-source-directive, Property 5 Extended: Multiple directives with mixed line= usage
    ///
    /// When some directives have explicit line= and others don't, each should be
    /// processed independently according to its own parameters.
    ///
    /// **Validates: Requirements 2.1, 2.2, 2.3**
    #[test]
    fn prop_forward_directive_multiple_mixed_line_params(
        num_directives in 2..=10usize,
    ) {
        let mut lines = Vec::new();
        let mut expected_entries: Vec<(String, u32)> = Vec::new();

        for i in 0..num_directives {
            let path = format!("script_{}.R", i);
            let directive_line = lines.len() as u32;

            // Alternate between explicit line= and default (directive's own line)
            if i % 2 == 0 {
                // Even indices: use explicit line=
                let explicit_line = (i as u32 + 1) * 5; // 5, 15, 25, ...
                let expected_line = explicit_line - 1; // Convert to 0-based
                lines.push(format!("# @lsp-source {} line={}", path, explicit_line));
                expected_entries.push((path, expected_line));
            } else {
                // Odd indices: use default (directive's own line)
                lines.push(format!("# @lsp-source {}", path));
                expected_entries.push((path, directive_line));
            }
        }

        let content = lines.join("\n");
        let meta = parse_directives(&content);

        // Property: Exactly N ForwardSource entries
        prop_assert_eq!(
            meta.sources.len(),
            num_directives,
            "Expected {} ForwardSource entries, got {}",
            num_directives,
            meta.sources.len()
        );

        // Property: Each entry has correct path and line (explicit or default)
        for (i, (expected_path, expected_line)) in expected_entries.iter().enumerate() {
            prop_assert_eq!(
                &meta.sources[i].path,
                expected_path,
                "Entry {} should have path '{}', got '{}'",
                i,
                expected_path,
                meta.sources[i].path
            );
            prop_assert_eq!(
                meta.sources[i].line,
                *expected_line,
                "Entry {} should have line {}, got {}",
                i,
                expected_line,
                meta.sources[i].line
            );
        }
    }

    /// Feature: lsp-source-directive, Property 5 Extended: Multiple directives with interleaved code
    ///
    /// When directives are interleaved with regular R code, each directive should
    /// still be parsed correctly with the right line number.
    ///
    /// **Validates: Requirements 2.2, 2.3**
    #[test]
    fn prop_forward_directive_multiple_interleaved_with_code(
        num_directives in 1..=10usize,
        code_lines_between in 0..5usize,
    ) {
        let mut lines = Vec::new();
        let mut expected_entries: Vec<(String, u32)> = Vec::new();

        for i in 0..num_directives {
            // Add some R code lines before each directive
            for j in 0..code_lines_between {
                lines.push(format!("var_{}_{} <- {}", i, j, i * 10 + j));
            }

            let path = format!("helper_{}.R", i);
            let directive_line = lines.len() as u32;
            lines.push(format!("# @lsp-source {}", path));
            expected_entries.push((path, directive_line));
        }

        let content = lines.join("\n");
        let meta = parse_directives(&content);

        // Property: Exactly N ForwardSource entries (code lines should not affect count)
        prop_assert_eq!(
            meta.sources.len(),
            num_directives,
            "Expected {} ForwardSource entries, got {}",
            num_directives,
            meta.sources.len()
        );

        // Property: Each entry has correct path and line
        for (i, (expected_path, expected_line)) in expected_entries.iter().enumerate() {
            prop_assert_eq!(
                &meta.sources[i].path,
                expected_path,
                "Entry {} should have path '{}', got '{}'",
                i,
                expected_path,
                meta.sources[i].path
            );
            prop_assert_eq!(
                meta.sources[i].line,
                *expected_line,
                "Entry {} should have line {}, got {}",
                i,
                expected_line,
                meta.sources[i].line
            );
        }
    }

    /// Feature: lsp-source-directive, Property 5 Extended: Multiple directives preserve order
    ///
    /// The order of ForwardSource entries should match the order of directives in the file.
    ///
    /// **Validates: Requirements 2.3**
    #[test]
    fn prop_forward_directive_multiple_preserve_order(
        num_directives in 2..=10usize,
    ) {
        // Generate paths in a specific order
        let paths: Vec<String> = (0..num_directives)
            .map(|i| format!("ordered_{}.R", i))
            .collect();

        let content = paths
            .iter()
            .map(|p| format!("# @lsp-source {}", p))
            .collect::<Vec<_>>()
            .join("\n");

        let meta = parse_directives(&content);

        // Property: Exactly N ForwardSource entries
        prop_assert_eq!(
            meta.sources.len(),
            num_directives,
            "Expected {} ForwardSource entries, got {}",
            num_directives,
            meta.sources.len()
        );

        // Property: Order is preserved
        for (i, expected_path) in paths.iter().enumerate() {
            prop_assert_eq!(
                &meta.sources[i].path,
                expected_path,
                "Entry {} should have path '{}' (order preserved), got '{}'",
                i,
                expected_path,
                meta.sources[i].path
            );
        }
    }
}

// ============================================================================
// Feature: lsp-source-directive, Property 6: Forward Directive Uses Working Directory
// Validates: Requirements 3.4
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: lsp-source-directive, Property 6: Forward Directive Uses Working Directory
    ///
    /// *For any* file with both `@lsp-cd <wd>` and `@lsp-source <path>` directives,
    /// the path resolution for the forward directive SHALL use the working directory
    /// `<wd>` as the base for relative path resolution.
    ///
    /// This property verifies that:
    /// 1. When @lsp-cd is present, forward directive paths resolve relative to the working directory
    /// 2. The working directory takes precedence over the file's directory for path resolution
    /// 3. PathContext::from_metadata() correctly includes the working directory
    ///
    /// **Validates: Requirements 3.4**
    #[test]
    fn prop_forward_directive_uses_working_directory(
        wd_subdir in path_component(),
        source_file in path_component(),
    ) {
        // Setup: File at /workspace/src/main.R with @lsp-cd pointing to /workspace/data
        // and @lsp-source pointing to utils.R
        //
        // Expected: The path utils.R should resolve to /workspace/data/utils.R
        // (using the working directory), NOT /workspace/src/utils.R (file's directory)

        let workspace_root = PathBuf::from("/workspace");
        let file_path = PathBuf::from("/workspace/src/main.R");
        let working_dir_path = format!("../{}", wd_subdir); // e.g., "../data"
        let source_path = format!("{}.R", source_file); // e.g., "utils.R"

        // Build file content with @lsp-cd and @lsp-source
        let content = format!(
            "# @lsp-cd {}\n# @lsp-source {}",
            working_dir_path, source_path
        );

        // Parse directives to get metadata
        let meta = parse_directives(&content);

        // Verify @lsp-cd was parsed
        prop_assert!(
            meta.working_directory.is_some(),
            "Working directory should be parsed from @lsp-cd directive"
        );
        prop_assert_eq!(
            meta.working_directory.as_ref().unwrap(),
            &working_dir_path,
            "Working directory should match the @lsp-cd path"
        );

        // Verify @lsp-source was parsed
        prop_assert_eq!(
            meta.sources.len(),
            1,
            "Should have exactly one forward source"
        );
        prop_assert_eq!(
            &meta.sources[0].path,
            &source_path,
            "Forward source path should match"
        );
        prop_assert!(
            meta.sources[0].is_directive,
            "Forward source should be marked as directive"
        );

        // Create PathContext from metadata (this is what dependency.rs does)
        let file_uri = Url::from_file_path(&file_path).unwrap();
        let workspace_uri = Url::from_file_path(&workspace_root).unwrap();
        let path_ctx = PathContext::from_metadata(&file_uri, &meta, Some(&workspace_uri)).unwrap();

        // Verify the effective working directory is the @lsp-cd path, not the file's directory
        let effective_wd = path_ctx.effective_working_directory();

        // The working directory should be /workspace/{wd_subdir} (resolved from ../wd_subdir)
        let expected_wd = PathBuf::from(format!("/workspace/{}", wd_subdir));
        prop_assert_eq!(
            effective_wd,
            expected_wd,
            "Effective working directory should be the @lsp-cd path, not file's directory"
        );

        // Verify that path resolution uses the working directory
        let resolved = resolve_path(&source_path, &path_ctx);
        prop_assert!(
            resolved.is_some(),
            "Path should resolve successfully"
        );

        // The resolved path should be /workspace/{wd_subdir}/{source_file}.R
        let expected_resolved = PathBuf::from(format!("/workspace/{}/{}.R", wd_subdir, source_file));
        prop_assert_eq!(
            resolved.unwrap(),
            expected_resolved,
            "Forward directive path should resolve relative to working directory, not file's directory"
        );
    }

    /// Feature: lsp-source-directive, Property 6 Extended: Working directory with absolute path
    ///
    /// When @lsp-cd uses a workspace-root-relative path (starting with /), the forward
    /// directive should still resolve relative to that working directory.
    ///
    /// **Validates: Requirements 3.4**
    #[test]
    fn prop_forward_directive_uses_absolute_working_directory(
        wd_subdir in path_component(),
        source_file in path_component(),
    ) {
        let workspace_root = PathBuf::from("/workspace");
        let file_path = PathBuf::from("/workspace/src/main.R");
        // Use workspace-root-relative path for @lsp-cd
        let working_dir_path = format!("/{}", wd_subdir); // e.g., "/data"
        let source_path = format!("{}.R", source_file);

        let content = format!(
            "# @lsp-cd {}\n# @lsp-source {}",
            working_dir_path, source_path
        );

        let meta = parse_directives(&content);

        // Verify @lsp-cd was parsed
        prop_assert!(meta.working_directory.is_some());
        prop_assert_eq!(
            meta.working_directory.as_ref().unwrap(),
            &working_dir_path
        );

        // Create PathContext from metadata
        let file_uri = Url::from_file_path(&file_path).unwrap();
        let workspace_uri = Url::from_file_path(&workspace_root).unwrap();
        let path_ctx = PathContext::from_metadata(&file_uri, &meta, Some(&workspace_uri)).unwrap();

        // The effective working directory should be /workspace/{wd_subdir}
        let effective_wd = path_ctx.effective_working_directory();
        let expected_wd = PathBuf::from(format!("/workspace/{}", wd_subdir));
        prop_assert_eq!(
            effective_wd,
            expected_wd,
            "Effective working directory should be the workspace-root-relative @lsp-cd path"
        );

        // Verify path resolution uses the working directory
        let resolved = resolve_path(&source_path, &path_ctx);
        prop_assert!(resolved.is_some());

        let expected_resolved = PathBuf::from(format!("/workspace/{}/{}.R", wd_subdir, source_file));
        prop_assert_eq!(
            resolved.unwrap(),
            expected_resolved,
            "Forward directive path should resolve relative to workspace-root-relative working directory"
        );
    }

    /// Feature: lsp-source-directive, Property 6 Extended: Without @lsp-cd, uses file's directory
    ///
    /// When no @lsp-cd directive is present, forward directive paths should resolve
    /// relative to the file's directory (default behavior).
    ///
    /// **Validates: Requirements 3.1, 3.4**
    #[test]
    fn prop_forward_directive_without_working_directory(
        source_file in path_component(),
    ) {
        let workspace_root = PathBuf::from("/workspace");
        let file_path = PathBuf::from("/workspace/src/main.R");
        let source_path = format!("{}.R", source_file);

        // Only @lsp-source, no @lsp-cd
        let content = format!("# @lsp-source {}", source_path);

        let meta = parse_directives(&content);

        // Verify no working directory
        prop_assert!(
            meta.working_directory.is_none(),
            "No working directory should be set without @lsp-cd"
        );

        // Create PathContext from metadata
        let file_uri = Url::from_file_path(&file_path).unwrap();
        let workspace_uri = Url::from_file_path(&workspace_root).unwrap();
        let path_ctx = PathContext::from_metadata(&file_uri, &meta, Some(&workspace_uri)).unwrap();

        // The effective working directory should be the file's directory
        let effective_wd = path_ctx.effective_working_directory();
        let expected_wd = PathBuf::from("/workspace/src");
        prop_assert_eq!(
            effective_wd,
            expected_wd,
            "Without @lsp-cd, effective working directory should be file's directory"
        );

        // Verify path resolution uses the file's directory
        let resolved = resolve_path(&source_path, &path_ctx);
        prop_assert!(resolved.is_some());

        let expected_resolved = PathBuf::from(format!("/workspace/src/{}.R", source_file));
        prop_assert_eq!(
            resolved.unwrap(),
            expected_resolved,
            "Without @lsp-cd, forward directive path should resolve relative to file's directory"
        );
    }

    /// Feature: lsp-source-directive, Property 6 Extended: Working directory with nested path
    ///
    /// When @lsp-source uses a nested relative path (e.g., "subdir/file.R"), it should
    /// resolve relative to the working directory.
    ///
    /// **Validates: Requirements 3.4**
    #[test]
    fn prop_forward_directive_nested_path_with_working_directory(
        wd_subdir in path_component(),
        source_subdir in path_component(),
        source_file in path_component(),
    ) {
        let workspace_root = PathBuf::from("/workspace");
        let file_path = PathBuf::from("/workspace/src/main.R");
        let working_dir_path = format!("../{}", wd_subdir);
        let source_path = format!("{}/{}.R", source_subdir, source_file);

        let content = format!(
            "# @lsp-cd {}\n# @lsp-source {}",
            working_dir_path, source_path
        );

        let meta = parse_directives(&content);

        // Create PathContext from metadata
        let file_uri = Url::from_file_path(&file_path).unwrap();
        let workspace_uri = Url::from_file_path(&workspace_root).unwrap();
        let path_ctx = PathContext::from_metadata(&file_uri, &meta, Some(&workspace_uri)).unwrap();

        // Verify path resolution uses the working directory
        let resolved = resolve_path(&source_path, &path_ctx);
        prop_assert!(resolved.is_some());

        // Expected: /workspace/{wd_subdir}/{source_subdir}/{source_file}.R
        let expected_resolved = PathBuf::from(format!(
            "/workspace/{}/{}/{}.R",
            wd_subdir, source_subdir, source_file
        ));
        prop_assert_eq!(
            resolved.unwrap(),
            expected_resolved,
            "Nested forward directive path should resolve relative to working directory"
        );
    }

    /// Feature: lsp-source-directive, Property 6 Extended: Working directory with parent navigation
    ///
    /// When @lsp-source uses parent directory navigation (e.g., "../file.R"), it should
    /// navigate relative to the working directory, not the file's directory.
    ///
    /// **Validates: Requirements 3.4**
    #[test]
    fn prop_forward_directive_parent_nav_with_working_directory(
        wd_subdir1 in path_component(),
        wd_subdir2 in path_component(),
        source_file in path_component(),
    ) {
        let workspace_root = PathBuf::from("/workspace");
        let file_path = PathBuf::from("/workspace/src/main.R");
        // Working directory is /workspace/{wd_subdir1}/{wd_subdir2}
        let working_dir_path = format!("../{}/{}", wd_subdir1, wd_subdir2);
        // Source path navigates up one level from working directory
        let source_path = format!("../{}.R", source_file);

        let content = format!(
            "# @lsp-cd {}\n# @lsp-source {}",
            working_dir_path, source_path
        );

        let meta = parse_directives(&content);

        // Create PathContext from metadata
        let file_uri = Url::from_file_path(&file_path).unwrap();
        let workspace_uri = Url::from_file_path(&workspace_root).unwrap();
        let path_ctx = PathContext::from_metadata(&file_uri, &meta, Some(&workspace_uri)).unwrap();

        // Verify the effective working directory
        let effective_wd = path_ctx.effective_working_directory();
        let expected_wd = PathBuf::from(format!("/workspace/{}/{}", wd_subdir1, wd_subdir2));
        prop_assert_eq!(
            effective_wd,
            expected_wd,
            "Effective working directory should be the nested @lsp-cd path"
        );

        // Verify path resolution navigates from working directory
        let resolved = resolve_path(&source_path, &path_ctx);
        prop_assert!(resolved.is_some());

        // Expected: /workspace/{wd_subdir1}/{source_file}.R (one level up from working dir)
        let expected_resolved = PathBuf::from(format!(
            "/workspace/{}/{}.R",
            wd_subdir1, source_file
        ));
        prop_assert_eq!(
            resolved.unwrap(),
            expected_resolved,
            "Parent navigation in forward directive should be relative to working directory"
        );
    }

    /// Feature: lsp-source-directive, Property 6 Extended: Contrast with backward directive behavior
    ///
    /// This test verifies the key distinction: forward directives (@lsp-source) use @lsp-cd
    /// for path resolution, while backward directives (@lsp-sourced-by) ignore @lsp-cd.
    ///
    /// **Validates: Requirements 3.4**
    #[test]
    fn prop_forward_vs_backward_directive_working_directory(
        wd_subdir in path_component(),
        path_file in path_component(),
    ) {
        let workspace_root = PathBuf::from("/workspace");
        let file_path = PathBuf::from("/workspace/src/main.R");
        let working_dir_path = format!("../{}", wd_subdir);
        let target_path = format!("{}.R", path_file);

        // File with both @lsp-cd, @lsp-source, and @lsp-sourced-by
        let content = format!(
            "# @lsp-cd {}\n# @lsp-source {}\n# @lsp-sourced-by {}",
            working_dir_path, target_path, target_path
        );

        let meta = parse_directives(&content);

        // Verify both directives were parsed
        prop_assert_eq!(meta.sources.len(), 1, "Should have one forward source");
        prop_assert_eq!(meta.sourced_by.len(), 1, "Should have one backward directive");

        // Create PathContext WITH working directory (for forward directives)
        let file_uri = Url::from_file_path(&file_path).unwrap();
        let workspace_uri = Url::from_file_path(&workspace_root).unwrap();
        let forward_ctx = PathContext::from_metadata(&file_uri, &meta, Some(&workspace_uri)).unwrap();

        // Create PathContext WITHOUT working directory (for backward directives)
        let backward_ctx = PathContext::new(&file_uri, Some(&workspace_uri)).unwrap();

        // Forward directive path resolution (uses working directory)
        let forward_resolved = resolve_path(&target_path, &forward_ctx);
        prop_assert!(forward_resolved.is_some());
        let forward_expected = PathBuf::from(format!("/workspace/{}/{}.R", wd_subdir, path_file));
        prop_assert_eq!(
            forward_resolved.clone().unwrap(),
            forward_expected.clone(),
            "Forward directive should resolve relative to working directory"
        );

        // Backward directive path resolution (ignores working directory)
        let backward_resolved = resolve_path(&target_path, &backward_ctx);
        prop_assert!(backward_resolved.is_some());
        let backward_expected = PathBuf::from(format!("/workspace/src/{}.R", path_file));
        prop_assert_eq!(
            backward_resolved.clone().unwrap(),
            backward_expected.clone(),
            "Backward directive should resolve relative to file's directory (ignoring @lsp-cd)"
        );

        // The two resolutions should be different (unless wd_subdir == "src")
        if wd_subdir != "src" {
            prop_assert_ne!(
                forward_expected,
                backward_expected,
                "Forward and backward directive resolutions should differ when @lsp-cd is not file's directory"
            );
        }
    }
}

// ============================================================================
// Feature: lsp-source-directive, Property 7: Directive Edge Creation
// Validates: Requirements 4.1, 4.2
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: lsp-source-directive, Property 7: Directive Edge Creation
    ///
    /// *For any* forward directive pointing to an existing file, the Dependency_Graph
    /// SHALL contain an edge with `is_directive=true` and `is_backward_directive=false`.
    ///
    /// This property verifies that:
    /// 1. When a forward directive (@lsp-source) is processed, an edge is created
    /// 2. The edge has is_directive=true (indicating it came from a directive)
    /// 3. The edge has is_backward_directive=false (indicating it's a forward directive, not backward)
    ///
    /// **Validates: Requirements 4.1, 4.2**
    #[test]
    fn prop_forward_directive_edge_creation(
        source_file in path_component(),
        directive_line in 0..100u32,
    ) {
        use super::dependency::DependencyGraph;
        use super::types::ForwardSource;
        use tempfile::TempDir;
        use std::fs::File;

        // Helper to create temp workspace
        fn create_temp_workspace(files: &[&str]) -> (TempDir, Url) {
            let temp_dir = TempDir::new().unwrap();
            for file in files {
                let path = temp_dir.path().join(file);
                if let Some(parent) = path.parent() {
                    std::fs::create_dir_all(parent).unwrap();
                }
                File::create(&path).unwrap();
            }
            let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
            (temp_dir, workspace_url)
        }

        // Helper to create URL for file in temp workspace
        fn temp_url(temp_dir: &TempDir, file: &str) -> Url {
            Url::from_file_path(temp_dir.path().join(file)).unwrap()
        }

        // Setup: Create a temp workspace with main.R and a target file
        let target_filename = format!("{}.R", source_file);
        let (temp_dir, workspace_url) = create_temp_workspace(&["main.R", &target_filename]);
        let main_uri = temp_url(&temp_dir, "main.R");
        let target_uri = temp_url(&temp_dir, &target_filename);

        // Create metadata with a forward directive (@lsp-source)
        let meta = CrossFileMetadata {
            sources: vec![ForwardSource {
                path: target_filename.clone(),
                line: directive_line,
                column: 0,
                is_directive: true, // This is a directive, not an AST-detected source()
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            }],
            ..Default::default()
        };

        // Create dependency graph and update with the metadata
        let mut graph = DependencyGraph::new();
        let _result = graph.update_file(&main_uri, &meta, Some(&workspace_url), |_| None);

        // Get the dependencies from main.R
        let deps = graph.get_dependencies(&main_uri);

        // Property: Exactly one edge should be created
        prop_assert_eq!(
            deps.len(),
            1,
            "Forward directive should create exactly one edge, got {}",
            deps.len()
        );

        // Property: Edge should point to the correct target
        prop_assert_eq!(
            &deps[0].to,
            &target_uri,
            "Edge should point to the target file"
        );

        // Property: Edge should have is_directive=true (Requirement 4.2)
        prop_assert!(
            deps[0].is_directive,
            "Forward directive edge should have is_directive=true"
        );

        // Property: Edge should have is_backward_directive=false (Requirement 4.2)
        prop_assert!(
            !deps[0].is_backward_directive,
            "Forward directive edge should have is_backward_directive=false"
        );

        // Property: Edge should have the correct call site line
        prop_assert_eq!(
            deps[0].call_site_line,
            Some(directive_line),
            "Edge should have the correct call site line"
        );

        // Property: Edge should have column=0 (directives always have column 0)
        prop_assert_eq!(
            deps[0].call_site_column,
            Some(0),
            "Directive edge should have column=0"
        );
    }

    /// Feature: lsp-source-directive, Property 7 Extended: Multiple forward directives
    ///
    /// When multiple forward directives exist, each should create an edge with the
    /// correct flags.
    ///
    /// **Validates: Requirements 4.1, 4.2**
    #[test]
    fn prop_forward_directive_edge_creation_multiple(
        num_directives in 1..=5usize,
    ) {
        use super::dependency::DependencyGraph;
        use super::types::ForwardSource;
        use tempfile::TempDir;
        use std::fs::File;

        // Helper to create temp workspace
        fn create_temp_workspace(files: &[&str]) -> (TempDir, Url) {
            let temp_dir = TempDir::new().unwrap();
            for file in files {
                let path = temp_dir.path().join(file);
                if let Some(parent) = path.parent() {
                    std::fs::create_dir_all(parent).unwrap();
                }
                File::create(&path).unwrap();
            }
            let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
            (temp_dir, workspace_url)
        }

        // Helper to create URL for file in temp workspace
        fn temp_url(temp_dir: &TempDir, file: &str) -> Url {
            Url::from_file_path(temp_dir.path().join(file)).unwrap()
        }

        // Generate unique file names for each directive
        let file_names: Vec<String> = (0..num_directives)
            .map(|i| format!("file{}.R", i))
            .collect();

        // Create temp workspace with main.R and all target files
        let mut all_files: Vec<&str> = vec!["main.R"];
        all_files.extend(file_names.iter().map(|s| s.as_str()));
        let (temp_dir, workspace_url) = create_temp_workspace(&all_files);
        let main_uri = temp_url(&temp_dir, "main.R");

        // Create metadata with multiple forward directives
        let sources: Vec<ForwardSource> = file_names
            .iter()
            .enumerate()
            .map(|(i, name)| ForwardSource {
                path: name.clone(),
                line: i as u32 * 10, // Different lines for each directive
                column: 0,
                is_directive: true,
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            })
            .collect();

        let meta = CrossFileMetadata {
            sources,
            ..Default::default()
        };

        // Create dependency graph and update with the metadata
        let mut graph = DependencyGraph::new();
        let _result = graph.update_file(&main_uri, &meta, Some(&workspace_url), |_| None);

        // Get the dependencies from main.R
        let deps = graph.get_dependencies(&main_uri);

        // Property: Should have exactly num_directives edges
        prop_assert_eq!(
            deps.len(),
            num_directives,
            "Should have {} edges, got {}",
            num_directives,
            deps.len()
        );

        // Property: All edges should have is_directive=true and is_backward_directive=false
        for (i, edge) in deps.iter().enumerate() {
            prop_assert!(
                edge.is_directive,
                "Edge {} should have is_directive=true",
                i
            );
            prop_assert!(
                !edge.is_backward_directive,
                "Edge {} should have is_backward_directive=false",
                i
            );
        }
    }

    /// Feature: lsp-source-directive, Property 7 Extended: Forward directive with all synonyms
    ///
    /// Verifies that forward directives created from any synonym (@lsp-source, @lsp-run,
    /// @lsp-include) all result in edges with the same flags.
    ///
    /// **Validates: Requirements 4.1, 4.2**
    #[test]
    fn prop_forward_directive_edge_creation_all_synonyms(
        source_file in path_component(),
    ) {
        use super::dependency::DependencyGraph;
        use tempfile::TempDir;
        use std::fs::File;

        // Helper to create temp workspace
        fn create_temp_workspace(files: &[&str]) -> (TempDir, Url) {
            let temp_dir = TempDir::new().unwrap();
            for file in files {
                let path = temp_dir.path().join(file);
                if let Some(parent) = path.parent() {
                    std::fs::create_dir_all(parent).unwrap();
                }
                File::create(&path).unwrap();
            }
            let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
            (temp_dir, workspace_url)
        }

        // Helper to create URL for file in temp workspace
        fn temp_url(temp_dir: &TempDir, file: &str) -> Url {
            Url::from_file_path(temp_dir.path().join(file)).unwrap()
        }

        let target_filename = format!("{}.R", source_file);

        // Test each synonym
        let synonyms = ["@lsp-source", "@lsp-run", "@lsp-include"];

        for synonym in synonyms {
            // Create temp workspace
            let (temp_dir, workspace_url) = create_temp_workspace(&["main.R", &target_filename]);
            let main_uri = temp_url(&temp_dir, "main.R");

            // Parse the directive to get metadata
            let content = format!("# {} {}", synonym, target_filename);
            let meta = parse_directives(&content);

            // Verify the directive was parsed
            prop_assert_eq!(
                meta.sources.len(),
                1,
                "Synonym {} should produce one ForwardSource",
                synonym
            );
            prop_assert!(
                meta.sources[0].is_directive,
                "Synonym {} should have is_directive=true in ForwardSource",
                synonym
            );

            // Create dependency graph and update with the metadata
            let mut graph = DependencyGraph::new();
            let _result = graph.update_file(&main_uri, &meta, Some(&workspace_url), |_| None);

            // Get the dependencies
            let deps = graph.get_dependencies(&main_uri);

            // Property: Should have exactly one edge
            prop_assert_eq!(
                deps.len(),
                1,
                "Synonym {} should create exactly one edge",
                synonym
            );

            // Property: Edge should have correct flags
            prop_assert!(
                deps[0].is_directive,
                "Synonym {} edge should have is_directive=true",
                synonym
            );
            prop_assert!(
                !deps[0].is_backward_directive,
                "Synonym {} edge should have is_backward_directive=false",
                synonym
            );
        }
    }

    /// Feature: lsp-source-directive, Property 7 Extended: Forward directive with line= parameter
    ///
    /// Verifies that forward directives with explicit line= parameter create edges
    /// with the correct call site and flags.
    ///
    /// **Validates: Requirements 4.1, 4.2**
    #[test]
    fn prop_forward_directive_edge_creation_with_line_param(
        source_file in path_component(),
        user_line in 1..100u32,  // 1-based line number (user input)
    ) {
        use super::dependency::DependencyGraph;
        use tempfile::TempDir;
        use std::fs::File;

        // Helper to create temp workspace
        fn create_temp_workspace(files: &[&str]) -> (TempDir, Url) {
            let temp_dir = TempDir::new().unwrap();
            for file in files {
                let path = temp_dir.path().join(file);
                if let Some(parent) = path.parent() {
                    std::fs::create_dir_all(parent).unwrap();
                }
                File::create(&path).unwrap();
            }
            let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
            (temp_dir, workspace_url)
        }

        // Helper to create URL for file in temp workspace
        fn temp_url(temp_dir: &TempDir, file: &str) -> Url {
            Url::from_file_path(temp_dir.path().join(file)).unwrap()
        }

        let target_filename = format!("{}.R", source_file);

        // Create temp workspace
        let (temp_dir, workspace_url) = create_temp_workspace(&["main.R", &target_filename]);
        let main_uri = temp_url(&temp_dir, "main.R");

        // Parse the directive with line= parameter
        let content = format!("# @lsp-source {} line={}", target_filename, user_line);
        let meta = parse_directives(&content);

        // Verify the directive was parsed with correct line (converted to 0-based)
        prop_assert_eq!(meta.sources.len(), 1);
        prop_assert_eq!(
            meta.sources[0].line,
            user_line - 1,
            "Line should be converted from 1-based ({}) to 0-based ({})",
            user_line,
            user_line - 1
        );

        // Create dependency graph and update with the metadata
        let mut graph = DependencyGraph::new();
        let _result = graph.update_file(&main_uri, &meta, Some(&workspace_url), |_| None);

        // Get the dependencies
        let deps = graph.get_dependencies(&main_uri);

        // Property: Should have exactly one edge
        prop_assert_eq!(deps.len(), 1);

        // Property: Edge should have correct flags
        prop_assert!(
            deps[0].is_directive,
            "Edge should have is_directive=true"
        );
        prop_assert!(
            !deps[0].is_backward_directive,
            "Edge should have is_backward_directive=false"
        );

        // Property: Edge should have the correct call site line (0-based)
        prop_assert_eq!(
            deps[0].call_site_line,
            Some(user_line - 1),
            "Edge should have call_site_line={} (0-based)",
            user_line - 1
        );
    }
}

// ============================================================================
// Feature: lsp-source-directive, Property 8: Same Call-Site Conflict Resolution
// Validates: Requirements 4.3
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: lsp-source-directive, Property 8: Same Call-Site Conflict Resolution
    ///
    /// *For any* file containing both a forward directive and a `source()` call pointing
    /// to the same target file at the same line, the Dependency_Graph SHALL contain
    /// exactly one edge (the directive edge).
    ///
    /// This property verifies that:
    /// 1. When both a directive and source() call point to the same file at the same call site
    /// 2. The directive wins (directive edge is kept)
    /// 3. The AST-detected source() edge is suppressed
    /// 4. The resulting edge has is_directive=true
    ///
    /// **Validates: Requirements 4.3**
    #[test]
    fn prop_same_call_site_conflict_resolution(
        source_file in path_component(),
        call_site_line in 0..100u32,  // 0-based line number
    ) {
        use super::dependency::DependencyGraph;
        use super::types::ForwardSource;
        use tempfile::TempDir;
        use std::fs::File;

        // Helper to create temp workspace
        fn create_temp_workspace(files: &[&str]) -> (TempDir, Url) {
            let temp_dir = TempDir::new().unwrap();
            for file in files {
                let path = temp_dir.path().join(file);
                if let Some(parent) = path.parent() {
                    std::fs::create_dir_all(parent).unwrap();
                }
                File::create(&path).unwrap();
            }
            let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
            (temp_dir, workspace_url)
        }

        // Helper to create URL for file in temp workspace
        fn temp_url(temp_dir: &TempDir, file: &str) -> Url {
            Url::from_file_path(temp_dir.path().join(file)).unwrap()
        }

        let target_filename = format!("{}.R", source_file);

        // Create temp workspace with main.R and target file
        let (temp_dir, workspace_url) = create_temp_workspace(&["main.R", &target_filename]);
        let main_uri = temp_url(&temp_dir, "main.R");
        let target_uri = temp_url(&temp_dir, &target_filename);

        // Create metadata with BOTH:
        // 1. A forward directive (@lsp-source) at call_site_line
        // 2. An AST-detected source() call at the SAME call_site_line
        //
        // This simulates a file like:
        //   # @lsp-source target.R line=5
        //   source("target.R")  # at line 5
        //
        // The directive and source() call point to the same file at the same line.
        let meta = CrossFileMetadata {
            sources: vec![
                // Forward directive (is_directive=true)
                ForwardSource {
                    path: target_filename.clone(),
                    line: call_site_line,
                    column: 0,  // Directives always have column 0
                    is_directive: true,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
                // AST-detected source() call (is_directive=false)
                ForwardSource {
                    path: target_filename.clone(),
                    line: call_site_line,
                    column: 0,  // Same column for same call site
                    is_directive: false,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
            ],
            ..Default::default()
        };

        // Create dependency graph and update with the metadata
        let mut graph = DependencyGraph::new();
        let _result = graph.update_file(&main_uri, &meta, Some(&workspace_url), |_| None);

        // Get the dependencies from main.R
        let deps = graph.get_dependencies(&main_uri);

        // Property: Exactly ONE edge should exist (directive wins, AST edge suppressed)
        // (Requirement 4.3: When both directive and source() point to same file at same call site,
        // keep only the directive edge)
        prop_assert_eq!(
            deps.len(),
            1,
            "When directive and source() point to same file at same call site, \
             should have exactly 1 edge (directive wins), but got {} edges",
            deps.len()
        );

        // Property: The edge should point to the correct target
        prop_assert_eq!(
            &deps[0].to,
            &target_uri,
            "Edge should point to the target file"
        );

        // Property: The edge should be the directive edge (is_directive=true)
        // (Requirement 4.3: The directive edge is kept, not the AST edge)
        prop_assert!(
            deps[0].is_directive,
            "The surviving edge should be the directive edge (is_directive=true), \
             but got is_directive=false"
        );

        // Property: The edge should have is_backward_directive=false (it's a forward directive)
        prop_assert!(
            !deps[0].is_backward_directive,
            "Forward directive edge should have is_backward_directive=false"
        );

        // Property: The edge should have the correct call site
        prop_assert_eq!(
            deps[0].call_site_line,
            Some(call_site_line),
            "Edge should have the correct call site line"
        );
    }

    /// Feature: lsp-source-directive, Property 8 Extended: Same call-site with different columns
    ///
    /// When directive and source() are at the same line but different columns,
    /// they are still considered the same call site (directive wins).
    ///
    /// Note: Directives always have column=0, so if source() is at a different column
    /// on the same line, the call sites are technically different. However, the conflict
    /// resolution logic compares both line AND column, so this tests that behavior.
    ///
    /// **Validates: Requirements 4.3**
    #[test]
    fn prop_same_call_site_conflict_same_line_different_column(
        source_file in path_component(),
        call_site_line in 0..100u32,
        source_column in 1..50u32,  // Non-zero column for source() call
    ) {
        use super::dependency::DependencyGraph;
        use super::types::ForwardSource;
        use tempfile::TempDir;
        use std::fs::File;

        // Helper to create temp workspace
        fn create_temp_workspace(files: &[&str]) -> (TempDir, Url) {
            let temp_dir = TempDir::new().unwrap();
            for file in files {
                let path = temp_dir.path().join(file);
                if let Some(parent) = path.parent() {
                    std::fs::create_dir_all(parent).unwrap();
                }
                File::create(&path).unwrap();
            }
            let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
            (temp_dir, workspace_url)
        }

        // Helper to create URL for file in temp workspace
        fn temp_url(temp_dir: &TempDir, file: &str) -> Url {
            Url::from_file_path(temp_dir.path().join(file)).unwrap()
        }

        let target_filename = format!("{}.R", source_file);

        // Create temp workspace
        let (temp_dir, workspace_url) = create_temp_workspace(&["main.R", &target_filename]);
        let main_uri = temp_url(&temp_dir, "main.R");

        // Create metadata with directive at column 0 and source() at different column
        // Same line, different columns
        let meta = CrossFileMetadata {
            sources: vec![
                // Forward directive at column 0
                ForwardSource {
                    path: target_filename.clone(),
                    line: call_site_line,
                    column: 0,
                    is_directive: true,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
                // AST-detected source() at different column
                ForwardSource {
                    path: target_filename.clone(),
                    line: call_site_line,
                    column: source_column,  // Different column
                    is_directive: false,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
            ],
            ..Default::default()
        };

        // Create dependency graph and update with the metadata
        let mut graph = DependencyGraph::new();
        let _result = graph.update_file(&main_uri, &meta, Some(&workspace_url), |_| None);

        // Get the dependencies
        let deps = graph.get_dependencies(&main_uri);

        // When columns differ, the call sites are considered different, so both edges are kept
        // (Requirement 4.4: Different call sites - keep both edges)
        // This is the expected behavior per the conflict resolution logic
        prop_assert_eq!(
            deps.len(),
            2,
            "When directive and source() are at same line but different columns, \
             both edges should be kept (different call sites), but got {} edges",
            deps.len()
        );

        // Verify one edge is directive and one is not
        let directive_edges: Vec<_> = deps.iter().filter(|e| e.is_directive).collect();
        let ast_edges: Vec<_> = deps.iter().filter(|e| !e.is_directive).collect();

        prop_assert_eq!(
            directive_edges.len(),
            1,
            "Should have exactly one directive edge"
        );
        prop_assert_eq!(
            ast_edges.len(),
            1,
            "Should have exactly one AST edge"
        );
    }

    /// Feature: lsp-source-directive, Property 8 Extended: Same call-site with exact match
    ///
    /// When directive and source() have exactly the same line AND column,
    /// only the directive edge should be kept.
    ///
    /// **Validates: Requirements 4.3**
    #[test]
    fn prop_same_call_site_conflict_exact_match(
        source_file in path_component(),
        call_site_line in 0..100u32,
    ) {
        use super::dependency::DependencyGraph;
        use super::types::ForwardSource;
        use tempfile::TempDir;
        use std::fs::File;

        // Helper to create temp workspace
        fn create_temp_workspace(files: &[&str]) -> (TempDir, Url) {
            let temp_dir = TempDir::new().unwrap();
            for file in files {
                let path = temp_dir.path().join(file);
                if let Some(parent) = path.parent() {
                    std::fs::create_dir_all(parent).unwrap();
                }
                File::create(&path).unwrap();
            }
            let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
            (temp_dir, workspace_url)
        }

        // Helper to create URL for file in temp workspace
        fn temp_url(temp_dir: &TempDir, file: &str) -> Url {
            Url::from_file_path(temp_dir.path().join(file)).unwrap()
        }

        let target_filename = format!("{}.R", source_file);

        // Create temp workspace
        let (temp_dir, workspace_url) = create_temp_workspace(&["main.R", &target_filename]);
        let main_uri = temp_url(&temp_dir, "main.R");
        let target_uri = temp_url(&temp_dir, &target_filename);

        // Create metadata with EXACT same call site (same line AND column)
        let meta = CrossFileMetadata {
            sources: vec![
                // Forward directive
                ForwardSource {
                    path: target_filename.clone(),
                    line: call_site_line,
                    column: 0,  // Same column
                    is_directive: true,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
                // AST-detected source() at EXACT same position
                ForwardSource {
                    path: target_filename.clone(),
                    line: call_site_line,
                    column: 0,  // Same column
                    is_directive: false,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
            ],
            ..Default::default()
        };

        // Create dependency graph and update with the metadata
        let mut graph = DependencyGraph::new();
        let _result = graph.update_file(&main_uri, &meta, Some(&workspace_url), |_| None);

        // Get the dependencies
        let deps = graph.get_dependencies(&main_uri);

        // Property: Exactly ONE edge (directive wins at exact same call site)
        prop_assert_eq!(
            deps.len(),
            1,
            "When directive and source() have exact same call site (line AND column), \
             should have exactly 1 edge, but got {} edges",
            deps.len()
        );

        // Property: The edge should be the directive edge
        prop_assert!(
            deps[0].is_directive,
            "The surviving edge should be the directive edge"
        );

        // Property: Edge points to correct target
        prop_assert_eq!(
            &deps[0].to,
            &target_uri,
            "Edge should point to the target file"
        );
    }

    /// Feature: lsp-source-directive, Property 8 Extended: Multiple targets, same call-site conflict
    ///
    /// When there are multiple targets, and one target has both directive and source()
    /// at the same call site, only that target's directive edge should win.
    /// Other targets should be unaffected.
    ///
    /// **Validates: Requirements 4.3**
    #[test]
    fn prop_same_call_site_conflict_multiple_targets(
        file1 in path_component(),
        file2 in path_component(),
        conflict_line in 0..50u32,
        other_line in 50..100u32,
    ) {
        use super::dependency::DependencyGraph;
        use super::types::ForwardSource;
        use tempfile::TempDir;
        use std::fs::File;

        // Ensure file names are different
        prop_assume!(file1 != file2);

        // Helper to create temp workspace
        fn create_temp_workspace(files: &[&str]) -> (TempDir, Url) {
            let temp_dir = TempDir::new().unwrap();
            for file in files {
                let path = temp_dir.path().join(file);
                if let Some(parent) = path.parent() {
                    std::fs::create_dir_all(parent).unwrap();
                }
                File::create(&path).unwrap();
            }
            let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
            (temp_dir, workspace_url)
        }

        // Helper to create URL for file in temp workspace
        fn temp_url(temp_dir: &TempDir, file: &str) -> Url {
            Url::from_file_path(temp_dir.path().join(file)).unwrap()
        }

        let target1 = format!("{}.R", file1);
        let target2 = format!("{}.R", file2);

        // Create temp workspace
        let (temp_dir, workspace_url) = create_temp_workspace(&["main.R", &target1, &target2]);
        let main_uri = temp_url(&temp_dir, "main.R");
        let target1_uri = temp_url(&temp_dir, &target1);
        let target2_uri = temp_url(&temp_dir, &target2);

        // Create metadata:
        // - target1: has BOTH directive and source() at same call site (conflict)
        // - target2: has only source() (no conflict)
        let meta = CrossFileMetadata {
            sources: vec![
                // target1: directive
                ForwardSource {
                    path: target1.clone(),
                    line: conflict_line,
                    column: 0,
                    is_directive: true,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
                // target1: source() at same call site
                ForwardSource {
                    path: target1.clone(),
                    line: conflict_line,
                    column: 0,
                    is_directive: false,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
                // target2: only source() (no conflict)
                ForwardSource {
                    path: target2.clone(),
                    line: other_line,
                    column: 0,
                    is_directive: false,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
            ],
            ..Default::default()
        };

        // Create dependency graph and update with the metadata
        let mut graph = DependencyGraph::new();
        let _result = graph.update_file(&main_uri, &meta, Some(&workspace_url), |_| None);

        // Get the dependencies
        let deps = graph.get_dependencies(&main_uri);

        // Property: Should have exactly 2 edges (one for each target)
        // - target1: directive edge (source() suppressed due to conflict)
        // - target2: source() edge (no conflict)
        prop_assert_eq!(
            deps.len(),
            2,
            "Should have 2 edges (one per target), but got {} edges",
            deps.len()
        );

        // Find edges by target
        let target1_edges: Vec<_> = deps.iter().filter(|e| e.to == target1_uri).collect();
        let target2_edges: Vec<_> = deps.iter().filter(|e| e.to == target2_uri).collect();

        // Property: target1 should have exactly one edge (directive)
        prop_assert_eq!(
            target1_edges.len(),
            1,
            "target1 should have exactly 1 edge (directive wins)"
        );
        prop_assert!(
            target1_edges[0].is_directive,
            "target1 edge should be the directive edge"
        );

        // Property: target2 should have exactly one edge (source())
        prop_assert_eq!(
            target2_edges.len(),
            1,
            "target2 should have exactly 1 edge"
        );
        prop_assert!(
            !target2_edges[0].is_directive,
            "target2 edge should be the source() edge (no directive for this target)"
        );
    }

    /// Feature: lsp-source-directive, Property 8 Extended: Order independence
    ///
    /// The conflict resolution should work regardless of whether the directive
    /// or source() appears first in the sources list.
    ///
    /// **Validates: Requirements 4.3**
    #[test]
    fn prop_same_call_site_conflict_order_independence(
        source_file in path_component(),
        call_site_line in 0..100u32,
        directive_first in proptest::bool::ANY,
    ) {
        use super::dependency::DependencyGraph;
        use super::types::ForwardSource;
        use tempfile::TempDir;
        use std::fs::File;

        // Helper to create temp workspace
        fn create_temp_workspace(files: &[&str]) -> (TempDir, Url) {
            let temp_dir = TempDir::new().unwrap();
            for file in files {
                let path = temp_dir.path().join(file);
                if let Some(parent) = path.parent() {
                    std::fs::create_dir_all(parent).unwrap();
                }
                File::create(&path).unwrap();
            }
            let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
            (temp_dir, workspace_url)
        }

        // Helper to create URL for file in temp workspace
        fn temp_url(temp_dir: &TempDir, file: &str) -> Url {
            Url::from_file_path(temp_dir.path().join(file)).unwrap()
        }

        let target_filename = format!("{}.R", source_file);

        // Create temp workspace
        let (temp_dir, workspace_url) = create_temp_workspace(&["main.R", &target_filename]);
        let main_uri = temp_url(&temp_dir, "main.R");
        let target_uri = temp_url(&temp_dir, &target_filename);

        // Create the two ForwardSource entries
        let directive_source = ForwardSource {
            path: target_filename.clone(),
            line: call_site_line,
            column: 0,
            is_directive: true,
            chdir: false,
            is_sys_source: false,
            ..Default::default()
        };

        let ast_source = ForwardSource {
            path: target_filename.clone(),
            line: call_site_line,
            column: 0,
            is_directive: false,
            chdir: false,
            is_sys_source: false,
            ..Default::default()
        };

        // Create metadata with sources in different orders based on directive_first
        let sources = if directive_first {
            vec![directive_source, ast_source]
        } else {
            vec![ast_source, directive_source]
        };

        let meta = CrossFileMetadata {
            sources,
            ..Default::default()
        };

        // Create dependency graph and update with the metadata
        let mut graph = DependencyGraph::new();
        let _result = graph.update_file(&main_uri, &meta, Some(&workspace_url), |_| None);

        // Get the dependencies
        let deps = graph.get_dependencies(&main_uri);

        // Property: Regardless of order, should have exactly 1 edge (directive wins)
        prop_assert_eq!(
            deps.len(),
            1,
            "Regardless of source order (directive_first={}), should have exactly 1 edge, but got {}",
            directive_first,
            deps.len()
        );

        // Property: The edge should be the directive edge
        prop_assert!(
            deps[0].is_directive,
            "Regardless of source order (directive_first={}), the surviving edge should be the directive edge",
            directive_first
        );

        // Property: Edge points to correct target
        prop_assert_eq!(
            &deps[0].to,
            &target_uri,
            "Edge should point to the target file"
        );
    }
}

// ============================================================================
// Feature: lsp-source-directive, Property 9: Different Call-Site Preservation
// Validates: Requirements 4.4
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: lsp-source-directive, Property 9: Different Call-Site Preservation
    ///
    /// *For any* file containing both a forward directive at line A and a `source()` call
    /// at line B (where A ≠ B) pointing to the same target file, the Dependency_Graph
    /// SHALL contain edges for both call sites.
    ///
    /// This property verifies that:
    /// 1. When directive and source() point to the same file at DIFFERENT call sites
    /// 2. Both edges are preserved (neither is suppressed)
    /// 3. One edge has is_directive=true, the other has is_directive=false
    /// 4. Symbols become available at the earliest call site
    ///
    /// **Validates: Requirements 4.4**
    #[test]
    fn prop_different_call_site_preservation(
        source_file in path_component(),
        directive_line in 0..50u32,
        source_line in 50..100u32,  // Ensure different from directive_line
    ) {
        use super::dependency::DependencyGraph;
        use super::types::ForwardSource;
        use tempfile::TempDir;
        use std::fs::File;

        // Helper to create temp workspace
        fn create_temp_workspace(files: &[&str]) -> (TempDir, Url) {
            let temp_dir = TempDir::new().unwrap();
            for file in files {
                let path = temp_dir.path().join(file);
                if let Some(parent) = path.parent() {
                    std::fs::create_dir_all(parent).unwrap();
                }
                File::create(&path).unwrap();
            }
            let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
            (temp_dir, workspace_url)
        }

        // Helper to create URL for file in temp workspace
        fn temp_url(temp_dir: &TempDir, file: &str) -> Url {
            Url::from_file_path(temp_dir.path().join(file)).unwrap()
        }

        let target_filename = format!("{}.R", source_file);

        // Create temp workspace with main.R and target file
        let (temp_dir, workspace_url) = create_temp_workspace(&["main.R", &target_filename]);
        let main_uri = temp_url(&temp_dir, "main.R");
        let target_uri = temp_url(&temp_dir, &target_filename);

        // Create metadata with BOTH:
        // 1. A forward directive (@lsp-source) at directive_line
        // 2. An AST-detected source() call at source_line (different line)
        //
        // This simulates a file like:
        //   # @lsp-source target.R line=10
        //   ...
        //   source("target.R")  # at line 60
        //
        // The directive and source() call point to the same file at DIFFERENT lines.
        let meta = CrossFileMetadata {
            sources: vec![
                // Forward directive (is_directive=true) at directive_line
                ForwardSource {
                    path: target_filename.clone(),
                    line: directive_line,
                    column: 0,  // Directives always have column 0
                    is_directive: true,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
                // AST-detected source() call (is_directive=false) at source_line
                ForwardSource {
                    path: target_filename.clone(),
                    line: source_line,
                    column: 0,
                    is_directive: false,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
            ],
            ..Default::default()
        };

        // Create dependency graph and update with the metadata
        let mut graph = DependencyGraph::new();
        let _result = graph.update_file(&main_uri, &meta, Some(&workspace_url), |_| None);

        // Get the dependencies from main.R
        let deps = graph.get_dependencies(&main_uri);

        // Property: BOTH edges should exist (different call sites are preserved)
        // (Requirement 4.4: When directive and source() point to same file at different call sites,
        // keep both edges)
        prop_assert_eq!(
            deps.len(),
            2,
            "When directive and source() point to same file at different call sites, \
             should have 2 edges (both preserved), but got {} edges",
            deps.len()
        );

        // Property: Both edges should point to the same target
        for dep in &deps {
            prop_assert_eq!(
                &dep.to,
                &target_uri,
                "All edges should point to the target file"
            );
        }

        // Property: One edge should be directive (is_directive=true), one should be AST (is_directive=false)
        let directive_edges: Vec<_> = deps.iter().filter(|e| e.is_directive).collect();
        let ast_edges: Vec<_> = deps.iter().filter(|e| !e.is_directive).collect();

        prop_assert_eq!(
            directive_edges.len(),
            1,
            "Should have exactly one directive edge, but got {}",
            directive_edges.len()
        );
        prop_assert_eq!(
            ast_edges.len(),
            1,
            "Should have exactly one AST edge, but got {}",
            ast_edges.len()
        );

        // Property: Directive edge should have the directive_line as call site
        prop_assert_eq!(
            directive_edges[0].call_site_line,
            Some(directive_line),
            "Directive edge should have call_site_line = {}",
            directive_line
        );

        // Property: AST edge should have the source_line as call site
        prop_assert_eq!(
            ast_edges[0].call_site_line,
            Some(source_line),
            "AST edge should have call_site_line = {}",
            source_line
        );

        // Property: Directive edge should have is_backward_directive=false (it's a forward directive)
        prop_assert!(
            !directive_edges[0].is_backward_directive,
            "Forward directive edge should have is_backward_directive=false"
        );
    }

    /// Feature: lsp-source-directive, Property 9 Extended: Directive before source()
    ///
    /// When directive is at an earlier line than source(), both edges should be preserved.
    /// Symbols become available at the directive line (the earlier call site).
    ///
    /// **Validates: Requirements 4.4**
    #[test]
    fn prop_different_call_site_directive_before_source(
        source_file in path_component(),
        directive_line in 0..50u32,
        source_line in 51..100u32,  // source() is after directive
    ) {
        use super::dependency::DependencyGraph;
        use super::types::ForwardSource;
        use tempfile::TempDir;
        use std::fs::File;

        // Helper to create temp workspace
        fn create_temp_workspace(files: &[&str]) -> (TempDir, Url) {
            let temp_dir = TempDir::new().unwrap();
            for file in files {
                let path = temp_dir.path().join(file);
                if let Some(parent) = path.parent() {
                    std::fs::create_dir_all(parent).unwrap();
                }
                File::create(&path).unwrap();
            }
            let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
            (temp_dir, workspace_url)
        }

        // Helper to create URL for file in temp workspace
        fn temp_url(temp_dir: &TempDir, file: &str) -> Url {
            Url::from_file_path(temp_dir.path().join(file)).unwrap()
        }

        let target_filename = format!("{}.R", source_file);

        // Create temp workspace
        let (temp_dir, workspace_url) = create_temp_workspace(&["main.R", &target_filename]);
        let main_uri = temp_url(&temp_dir, "main.R");
        let target_uri = temp_url(&temp_dir, &target_filename);

        // Directive at earlier line, source() at later line
        let meta = CrossFileMetadata {
            sources: vec![
                ForwardSource {
                    path: target_filename.clone(),
                    line: directive_line,
                    column: 0,
                    is_directive: true,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
                ForwardSource {
                    path: target_filename.clone(),
                    line: source_line,
                    column: 0,
                    is_directive: false,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
            ],
            ..Default::default()
        };

        let mut graph = DependencyGraph::new();
        let _result = graph.update_file(&main_uri, &meta, Some(&workspace_url), |_| None);

        let deps = graph.get_dependencies(&main_uri);

        // Both edges should be preserved
        prop_assert_eq!(
            deps.len(),
            2,
            "Both edges should be preserved when directive is before source()"
        );

        // Verify both point to target
        for dep in &deps {
            prop_assert_eq!(&dep.to, &target_uri);
        }

        // Find the earliest call site (should be directive_line)
        let earliest_line = deps.iter()
            .filter_map(|e| e.call_site_line)
            .min()
            .unwrap_or(u32::MAX);

        prop_assert_eq!(
            earliest_line,
            directive_line,
            "Earliest call site should be the directive line"
        );
    }

    /// Feature: lsp-source-directive, Property 9 Extended: Source() before directive
    ///
    /// When source() is at an earlier line than directive, both edges should be preserved.
    /// Symbols become available at the source() line (the earlier call site).
    ///
    /// **Validates: Requirements 4.4**
    #[test]
    fn prop_different_call_site_source_before_directive(
        source_file in path_component(),
        source_line in 0..50u32,
        directive_line in 51..100u32,  // directive is after source()
    ) {
        use super::dependency::DependencyGraph;
        use super::types::ForwardSource;
        use tempfile::TempDir;
        use std::fs::File;

        // Helper to create temp workspace
        fn create_temp_workspace(files: &[&str]) -> (TempDir, Url) {
            let temp_dir = TempDir::new().unwrap();
            for file in files {
                let path = temp_dir.path().join(file);
                if let Some(parent) = path.parent() {
                    std::fs::create_dir_all(parent).unwrap();
                }
                File::create(&path).unwrap();
            }
            let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
            (temp_dir, workspace_url)
        }

        // Helper to create URL for file in temp workspace
        fn temp_url(temp_dir: &TempDir, file: &str) -> Url {
            Url::from_file_path(temp_dir.path().join(file)).unwrap()
        }

        let target_filename = format!("{}.R", source_file);

        // Create temp workspace
        let (temp_dir, workspace_url) = create_temp_workspace(&["main.R", &target_filename]);
        let main_uri = temp_url(&temp_dir, "main.R");
        let target_uri = temp_url(&temp_dir, &target_filename);

        // Source() at earlier line, directive at later line
        let meta = CrossFileMetadata {
            sources: vec![
                ForwardSource {
                    path: target_filename.clone(),
                    line: source_line,
                    column: 0,
                    is_directive: false,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
                ForwardSource {
                    path: target_filename.clone(),
                    line: directive_line,
                    column: 0,
                    is_directive: true,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
            ],
            ..Default::default()
        };

        let mut graph = DependencyGraph::new();
        let _result = graph.update_file(&main_uri, &meta, Some(&workspace_url), |_| None);

        let deps = graph.get_dependencies(&main_uri);

        // Both edges should be preserved
        prop_assert_eq!(
            deps.len(),
            2,
            "Both edges should be preserved when source() is before directive"
        );

        // Verify both point to target
        for dep in &deps {
            prop_assert_eq!(&dep.to, &target_uri);
        }

        // Find the earliest call site (should be source_line)
        let earliest_line = deps.iter()
            .filter_map(|e| e.call_site_line)
            .min()
            .unwrap_or(u32::MAX);

        prop_assert_eq!(
            earliest_line,
            source_line,
            "Earliest call site should be the source() line"
        );
    }

    /// Feature: lsp-source-directive, Property 9 Extended: Multiple targets with different call sites
    ///
    /// When there are multiple targets, and one target has both directive and source()
    /// at different call sites, both edges for that target should be preserved.
    /// Other targets should be unaffected.
    ///
    /// **Validates: Requirements 4.4**
    #[test]
    fn prop_different_call_site_multiple_targets(
        file1 in path_component(),
        file2 in path_component(),
        directive_line in 0..50u32,
        source_line in 51..100u32,
        other_line in 0..100u32,
    ) {
        use super::dependency::DependencyGraph;
        use super::types::ForwardSource;
        use tempfile::TempDir;
        use std::fs::File;

        // Skip if file names are the same
        prop_assume!(file1 != file2);

        // Helper to create temp workspace
        fn create_temp_workspace(files: &[&str]) -> (TempDir, Url) {
            let temp_dir = TempDir::new().unwrap();
            for file in files {
                let path = temp_dir.path().join(file);
                if let Some(parent) = path.parent() {
                    std::fs::create_dir_all(parent).unwrap();
                }
                File::create(&path).unwrap();
            }
            let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
            (temp_dir, workspace_url)
        }

        // Helper to create URL for file in temp workspace
        fn temp_url(temp_dir: &TempDir, file: &str) -> Url {
            Url::from_file_path(temp_dir.path().join(file)).unwrap()
        }

        let target1_filename = format!("{}.R", file1);
        let target2_filename = format!("{}.R", file2);

        // Create temp workspace with main.R and both target files
        let (temp_dir, workspace_url) = create_temp_workspace(&[
            "main.R",
            &target1_filename,
            &target2_filename,
        ]);
        let main_uri = temp_url(&temp_dir, "main.R");
        let target1_uri = temp_url(&temp_dir, &target1_filename);
        let target2_uri = temp_url(&temp_dir, &target2_filename);

        // Create metadata:
        // - target1: directive at directive_line, source() at source_line (different call sites)
        // - target2: only source() at other_line
        let meta = CrossFileMetadata {
            sources: vec![
                // target1: directive
                ForwardSource {
                    path: target1_filename.clone(),
                    line: directive_line,
                    column: 0,
                    is_directive: true,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
                // target1: source()
                ForwardSource {
                    path: target1_filename.clone(),
                    line: source_line,
                    column: 0,
                    is_directive: false,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
                // target2: only source()
                ForwardSource {
                    path: target2_filename.clone(),
                    line: other_line,
                    column: 0,
                    is_directive: false,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
            ],
            ..Default::default()
        };

        let mut graph = DependencyGraph::new();
        let _result = graph.update_file(&main_uri, &meta, Some(&workspace_url), |_| None);

        let deps = graph.get_dependencies(&main_uri);

        // Should have 3 edges total: 2 for target1, 1 for target2
        prop_assert_eq!(
            deps.len(),
            3,
            "Should have 3 edges total (2 for target1, 1 for target2), but got {}",
            deps.len()
        );

        // Count edges to each target
        let target1_edges: Vec<_> = deps.iter().filter(|e| e.to == target1_uri).collect();
        let target2_edges: Vec<_> = deps.iter().filter(|e| e.to == target2_uri).collect();

        prop_assert_eq!(
            target1_edges.len(),
            2,
            "Should have 2 edges to target1 (different call sites preserved)"
        );
        prop_assert_eq!(
            target2_edges.len(),
            1,
            "Should have 1 edge to target2"
        );

        // Verify target1 has one directive edge and one AST edge
        let target1_directive_edges: Vec<_> = target1_edges.iter().filter(|e| e.is_directive).collect();
        let target1_ast_edges: Vec<_> = target1_edges.iter().filter(|e| !e.is_directive).collect();

        prop_assert_eq!(
            target1_directive_edges.len(),
            1,
            "target1 should have exactly one directive edge"
        );
        prop_assert_eq!(
            target1_ast_edges.len(),
            1,
            "target1 should have exactly one AST edge"
        );

        // Verify target2 edge is AST (not directive)
        prop_assert!(
            !target2_edges[0].is_directive,
            "target2 edge should be AST edge (is_directive=false)"
        );
    }

    /// Feature: lsp-source-directive, Property 9 Extended: Adjacent lines (A and A+1)
    ///
    /// When directive and source() are on adjacent lines (e.g., line 5 and line 6),
    /// both edges should still be preserved since they are different call sites.
    ///
    /// **Validates: Requirements 4.4**
    #[test]
    fn prop_different_call_site_adjacent_lines(
        source_file in path_component(),
        base_line in 0..99u32,
    ) {
        use super::dependency::DependencyGraph;
        use super::types::ForwardSource;
        use tempfile::TempDir;
        use std::fs::File;

        // Helper to create temp workspace
        fn create_temp_workspace(files: &[&str]) -> (TempDir, Url) {
            let temp_dir = TempDir::new().unwrap();
            for file in files {
                let path = temp_dir.path().join(file);
                if let Some(parent) = path.parent() {
                    std::fs::create_dir_all(parent).unwrap();
                }
                File::create(&path).unwrap();
            }
            let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
            (temp_dir, workspace_url)
        }

        // Helper to create URL for file in temp workspace
        fn temp_url(temp_dir: &TempDir, file: &str) -> Url {
            Url::from_file_path(temp_dir.path().join(file)).unwrap()
        }

        let target_filename = format!("{}.R", source_file);
        let directive_line = base_line;
        let source_line = base_line + 1;  // Adjacent line

        // Create temp workspace
        let (temp_dir, workspace_url) = create_temp_workspace(&["main.R", &target_filename]);
        let main_uri = temp_url(&temp_dir, "main.R");
        let target_uri = temp_url(&temp_dir, &target_filename);

        // Directive at base_line, source() at base_line + 1
        let meta = CrossFileMetadata {
            sources: vec![
                ForwardSource {
                    path: target_filename.clone(),
                    line: directive_line,
                    column: 0,
                    is_directive: true,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
                ForwardSource {
                    path: target_filename.clone(),
                    line: source_line,
                    column: 0,
                    is_directive: false,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
            ],
            ..Default::default()
        };

        let mut graph = DependencyGraph::new();
        let _result = graph.update_file(&main_uri, &meta, Some(&workspace_url), |_| None);

        let deps = graph.get_dependencies(&main_uri);

        // Both edges should be preserved even for adjacent lines
        prop_assert_eq!(
            deps.len(),
            2,
            "Both edges should be preserved for adjacent lines (line {} and {})",
            directive_line,
            source_line
        );

        // Verify both point to target
        for dep in &deps {
            prop_assert_eq!(&dep.to, &target_uri);
        }

        // Verify one is directive, one is AST
        let directive_count = deps.iter().filter(|e| e.is_directive).count();
        let ast_count = deps.iter().filter(|e| !e.is_directive).count();

        prop_assert_eq!(directive_count, 1, "Should have exactly one directive edge");
        prop_assert_eq!(ast_count, 1, "Should have exactly one AST edge");
    }
}

// ============================================================================
// Feature: lsp-source-directive, Property 10: Scope Availability After Directive
// Validates: Requirements 5.1, 5.2
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: lsp-source-directive, Property 10: Scope Availability After Directive
    ///
    /// *For any* file with `@lsp-source <path>` at line L, symbols from the sourced file
    /// SHALL be available in scope at positions after line L.
    ///
    /// This property verifies that:
    /// 1. Symbols from the sourced file are NOT available before line L
    /// 2. Symbols from the sourced file ARE available after line L
    /// 3. The scope resolution correctly uses the dependency graph
    ///
    /// **Validates: Requirements 5.1, 5.2**
    #[test]
    fn prop_scope_availability_after_directive(
        symbol_name in r_identifier(),
        directive_line in 1..20u32,  // 0-based line where directive appears
    ) {
        use super::dependency::DependencyGraph;
        use super::scope::{compute_artifacts, compute_artifacts_with_metadata, scope_at_position_with_graph};
        use super::types::{CrossFileMetadata, ForwardSource};
        use tempfile::TempDir;
        use std::fs;

        // Helper to create temp workspace with files
        fn create_temp_workspace(files: &[(&str, &str)]) -> (TempDir, Url) {
            let temp_dir = TempDir::new().unwrap();
            for (name, content) in files {
                let path = temp_dir.path().join(name);
                if let Some(parent) = path.parent() {
                    fs::create_dir_all(parent).unwrap();
                }
                fs::write(&path, content).unwrap();
            }
            let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
            (temp_dir, workspace_url)
        }

        // Helper to create URL for file in temp workspace
        fn temp_url(temp_dir: &TempDir, file: &str) -> Url {
            Url::from_file_path(temp_dir.path().join(file)).unwrap()
        }

        // Build parent file content with @lsp-source directive at directive_line
        // Lines before directive are comments, directive is at directive_line
        let mut parent_lines: Vec<String> = Vec::new();
        for i in 0..directive_line {
            parent_lines.push(format!("# Comment line {}", i));
        }
        parent_lines.push("# @lsp-source child.R".to_string());
        parent_lines.push("# Code after directive".to_string());
        parent_lines.push("x <- 1".to_string());
        let parent_content = parent_lines.join("\n");

        // Child file defines a symbol
        let child_content = format!("{} <- 42", symbol_name);

        // Create temp workspace with both files
        let (temp_dir, workspace_url) = create_temp_workspace(&[
            ("parent.R", &parent_content),
            ("child.R", &child_content),
        ]);
        let parent_uri = temp_url(&temp_dir, "parent.R");
        let child_uri = temp_url(&temp_dir, "child.R");

        // Parse and compute artifacts for both files
        let parent_tree = parse_r_tree(&parent_content);
        let child_tree = parse_r_tree(&child_content);

        // Create metadata with forward directive
        let parent_metadata = CrossFileMetadata {
            sources: vec![
                ForwardSource {
                    path: "child.R".to_string(),
                    line: directive_line,
                    column: 0,
                    is_directive: true,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
            ],
            ..Default::default()
        };

        // Compute artifacts with metadata to include directive in timeline
        let parent_artifacts = compute_artifacts_with_metadata(
            &parent_uri,
            &parent_tree,
            &parent_content,
            Some(&parent_metadata),
        );
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, &child_content);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let content_provider = |uri: &Url| -> Option<String> {
            if uri == &child_uri {
                Some(child_content.clone())
            } else if uri == &parent_uri {
                Some(parent_content.clone())
            } else {
                None
            }
        };
        graph.update_file(&parent_uri, &parent_metadata, Some(&workspace_url), content_provider);

        // Create closures for scope resolution
        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<super::scope::ScopeArtifacts>> {
            if uri == &parent_uri {
                Some(Arc::clone(&parent_artifacts))
            } else if uri == &child_uri {
                Some(Arc::clone(&child_artifacts))
            } else {
                None
            }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri {
                Some(std::sync::Arc::new(parent_metadata.clone()))
            } else {
                None
            }
        };

        // Property 1: Symbols should NOT be available BEFORE the directive line
        if directive_line > 0 {
            let scope_before = scope_at_position_with_graph(
                &parent_uri,
                directive_line - 1,  // Line before directive
                0,
                &get_artifacts,
                &get_metadata,
                &graph,
                Some(&workspace_url),
                10,
                &HashSet::new(),
                false,
                crate::cross_file::config::BackwardDependencyMode::Explicit,
                &|| false,
                None,
                None,
            );

            prop_assert!(
                !scope_before.symbols.contains_key(symbol_name.as_str()),
                "Symbol '{}' should NOT be available before @lsp-source directive at line {} \
                 (checked at line {})",
                symbol_name,
                directive_line,
                directive_line - 1
            );
        }

        // Property 2: Symbols SHOULD be available AFTER the directive line
        let scope_after = scope_at_position_with_graph(
            &parent_uri,
            directive_line + 1,  // Line after directive
            0,
            &get_artifacts,
            &get_metadata,
            &graph,
            Some(&workspace_url),
            10,
            &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );

        prop_assert!(
            scope_after.symbols.contains_key(symbol_name.as_str()),
            "Symbol '{}' should be available after @lsp-source directive at line {} \
             (checked at line {})",
            symbol_name,
            directive_line,
            directive_line + 1
        );
    }

    /// Feature: lsp-source-directive, Property 10 Extended: Scope with line= parameter
    ///
    /// When @lsp-source uses line=N parameter, symbols should be available starting
    /// at line N-1 (0-based), not at the directive's physical line.
    ///
    /// **Validates: Requirements 5.2**
    #[test]
    fn prop_scope_availability_with_line_parameter(
        symbol_name in r_identifier(),
        directive_physical_line in 0..5u32,  // Physical line of directive
        effective_line in 6..15u32,  // line=N parameter (1-based, converts to N-1)
    ) {
        use super::dependency::DependencyGraph;
        use super::scope::{compute_artifacts, compute_artifacts_with_metadata, scope_at_position_with_graph};
        use super::types::{CrossFileMetadata, ForwardSource};
        use tempfile::TempDir;
        use std::fs;

        // Helper to create temp workspace with files
        fn create_temp_workspace(files: &[(&str, &str)]) -> (TempDir, Url) {
            let temp_dir = TempDir::new().unwrap();
            for (name, content) in files {
                let path = temp_dir.path().join(name);
                if let Some(parent) = path.parent() {
                    fs::create_dir_all(parent).unwrap();
                }
                fs::write(&path, content).unwrap();
            }
            let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
            (temp_dir, workspace_url)
        }

        // Helper to create URL for file in temp workspace
        fn temp_url(temp_dir: &TempDir, file: &str) -> Url {
            Url::from_file_path(temp_dir.path().join(file)).unwrap()
        }

        // The effective 0-based line where symbols become available
        let effective_line_0based = effective_line - 1;

        // Build parent file content with enough lines
        let mut parent_lines: Vec<String> = Vec::new();
        for i in 0..20 {
            if i == directive_physical_line {
                parent_lines.push(format!("# @lsp-source child.R line={}", effective_line));
            } else {
                parent_lines.push(format!("# Line {}", i));
            }
        }
        let parent_content = parent_lines.join("\n");

        // Child file defines a symbol
        let child_content = format!("{} <- 42", symbol_name);

        // Create temp workspace with both files
        let (temp_dir, workspace_url) = create_temp_workspace(&[
            ("parent.R", &parent_content),
            ("child.R", &child_content),
        ]);
        let parent_uri = temp_url(&temp_dir, "parent.R");
        let child_uri = temp_url(&temp_dir, "child.R");

        // Parse and compute artifacts
        let parent_tree = parse_r_tree(&parent_content);
        let child_tree = parse_r_tree(&child_content);

        // Create metadata with forward directive using line= parameter
        // The line field stores the 0-based effective line (N-1)
        let parent_metadata = CrossFileMetadata {
            sources: vec![
                ForwardSource {
                    path: "child.R".to_string(),
                    line: effective_line_0based,  // 0-based effective line
                    column: 0,
                    is_directive: true,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
            ],
            ..Default::default()
        };

        // Compute artifacts with metadata
        let parent_artifacts = compute_artifacts_with_metadata(
            &parent_uri,
            &parent_tree,
            &parent_content,
            Some(&parent_metadata),
        );
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, &child_content);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let content_provider = |uri: &Url| -> Option<String> {
            if uri == &child_uri {
                Some(child_content.clone())
            } else if uri == &parent_uri {
                Some(parent_content.clone())
            } else {
                None
            }
        };
        graph.update_file(&parent_uri, &parent_metadata, Some(&workspace_url), content_provider);

        // Create closures for scope resolution
        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<super::scope::ScopeArtifacts>> {
            if uri == &parent_uri {
                Some(Arc::clone(&parent_artifacts))
            } else if uri == &child_uri {
                Some(Arc::clone(&child_artifacts))
            } else {
                None
            }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri {
                Some(std::sync::Arc::new(parent_metadata.clone()))
            } else {
                None
            }
        };

        // Property 1: Symbols should NOT be available BEFORE the effective line
        if effective_line_0based > 0 {
            let scope_before = scope_at_position_with_graph(
                &parent_uri,
                effective_line_0based - 1,  // Line before effective line
                0,
                &get_artifacts,
                &get_metadata,
                &graph,
                Some(&workspace_url),
                10,
                &HashSet::new(),
                false,
                crate::cross_file::config::BackwardDependencyMode::Explicit,
                &|| false,
                None,
                None,
            );

            prop_assert!(
                !scope_before.symbols.contains_key(symbol_name.as_str()),
                "Symbol '{}' should NOT be available before effective line {} \
                 (line={} parameter, checked at line {})",
                symbol_name,
                effective_line_0based,
                effective_line,
                effective_line_0based - 1
            );
        }

        // Property 2: Symbols SHOULD be available AFTER the effective line
        let scope_after = scope_at_position_with_graph(
            &parent_uri,
            effective_line_0based + 1,  // Line after effective line
            0,
            &get_artifacts,
            &get_metadata,
            &graph,
            Some(&workspace_url),
            10,
            &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );

        prop_assert!(
            scope_after.symbols.contains_key(symbol_name.as_str()),
            "Symbol '{}' should be available after effective line {} \
             (line={} parameter, checked at line {})",
            symbol_name,
            effective_line_0based,
            effective_line,
            effective_line_0based + 1
        );
    }

    /// Feature: lsp-source-directive, Property 10 Extended: Multiple symbols from sourced file
    ///
    /// When the sourced file defines multiple symbols, ALL of them should be available
    /// after the directive line.
    ///
    /// **Validates: Requirements 5.1, 5.3**
    #[test]
    fn prop_scope_availability_multiple_symbols(
        symbol1 in r_identifier(),
        symbol2 in r_identifier(),
        directive_line in 1..10u32,
    ) {
        use super::dependency::DependencyGraph;
        use super::scope::{compute_artifacts, compute_artifacts_with_metadata, scope_at_position_with_graph};
        use super::types::{CrossFileMetadata, ForwardSource};
        use tempfile::TempDir;
        use std::fs;

        // Skip if symbols are the same
        prop_assume!(symbol1 != symbol2);

        // Helper to create temp workspace with files
        fn create_temp_workspace(files: &[(&str, &str)]) -> (TempDir, Url) {
            let temp_dir = TempDir::new().unwrap();
            for (name, content) in files {
                let path = temp_dir.path().join(name);
                if let Some(parent) = path.parent() {
                    fs::create_dir_all(parent).unwrap();
                }
                fs::write(&path, content).unwrap();
            }
            let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
            (temp_dir, workspace_url)
        }

        // Helper to create URL for file in temp workspace
        fn temp_url(temp_dir: &TempDir, file: &str) -> Url {
            Url::from_file_path(temp_dir.path().join(file)).unwrap()
        }

        // Build parent file content
        let mut parent_lines: Vec<String> = Vec::new();
        for i in 0..directive_line {
            parent_lines.push(format!("# Comment line {}", i));
        }
        parent_lines.push("# @lsp-source child.R".to_string());
        parent_lines.push("# After directive".to_string());
        let parent_content = parent_lines.join("\n");

        // Child file defines multiple symbols
        let child_content = format!("{} <- 42\n{} <- function() {{ 1 }}", symbol1, symbol2);

        // Create temp workspace
        let (temp_dir, workspace_url) = create_temp_workspace(&[
            ("parent.R", &parent_content),
            ("child.R", &child_content),
        ]);
        let parent_uri = temp_url(&temp_dir, "parent.R");
        let child_uri = temp_url(&temp_dir, "child.R");

        // Parse and compute artifacts
        let parent_tree = parse_r_tree(&parent_content);
        let child_tree = parse_r_tree(&child_content);

        let parent_metadata = CrossFileMetadata {
            sources: vec![
                ForwardSource {
                    path: "child.R".to_string(),
                    line: directive_line,
                    column: 0,
                    is_directive: true,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
            ],
            ..Default::default()
        };

        let parent_artifacts = compute_artifacts_with_metadata(
            &parent_uri,
            &parent_tree,
            &parent_content,
            Some(&parent_metadata),
        );
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, &child_content);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let content_provider = |uri: &Url| -> Option<String> {
            if uri == &child_uri {
                Some(child_content.clone())
            } else if uri == &parent_uri {
                Some(parent_content.clone())
            } else {
                None
            }
        };
        graph.update_file(&parent_uri, &parent_metadata, Some(&workspace_url), content_provider);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<super::scope::ScopeArtifacts>> {
            if uri == &parent_uri {
                Some(Arc::clone(&parent_artifacts))
            } else if uri == &child_uri {
                Some(Arc::clone(&child_artifacts))
            } else {
                None
            }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri {
                Some(std::sync::Arc::new(parent_metadata.clone()))
            } else {
                None
            }
        };

        // Property: Both symbols should be available after directive
        let scope_after = scope_at_position_with_graph(
            &parent_uri,
            directive_line + 1,
            0,
            &get_artifacts,
            &get_metadata,
            &graph,
            Some(&workspace_url),
            10,
            &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );

        prop_assert!(
            scope_after.symbols.contains_key(symbol1.as_str()),
            "Symbol '{}' should be available after @lsp-source directive",
            symbol1
        );
        prop_assert!(
            scope_after.symbols.contains_key(symbol2.as_str()),
            "Symbol '{}' should be available after @lsp-source directive",
            symbol2
        );

        // Property: Neither symbol should be available before directive
        if directive_line > 0 {
            let scope_before = scope_at_position_with_graph(
                &parent_uri,
                directive_line - 1,
                0,
                &get_artifacts,
                &get_metadata,
                &graph,
                Some(&workspace_url),
                10,
                &HashSet::new(),
                false,
                crate::cross_file::config::BackwardDependencyMode::Explicit,
                &|| false,
                None,
                None,
            );

            prop_assert!(
                !scope_before.symbols.contains_key(symbol1.as_str()),
                "Symbol '{}' should NOT be available before @lsp-source directive",
                symbol1
            );
            prop_assert!(
                !scope_before.symbols.contains_key(symbol2.as_str()),
                "Symbol '{}' should NOT be available before @lsp-source directive",
                symbol2
            );
        }
    }

    /// Feature: lsp-source-directive, Property 10 Extended: Scope at directive line boundary
    ///
    /// Symbols should be available starting at the line AFTER the directive,
    /// not at the directive line itself.
    ///
    /// **Validates: Requirements 5.1**
    #[test]
    fn prop_scope_availability_at_directive_line(
        symbol_name in r_identifier(),
        directive_line in 1..15u32,
    ) {
        use super::dependency::DependencyGraph;
        use super::scope::{compute_artifacts, compute_artifacts_with_metadata, scope_at_position_with_graph};
        use super::types::{CrossFileMetadata, ForwardSource};
        use tempfile::TempDir;
        use std::fs;

        // Helper to create temp workspace with files
        fn create_temp_workspace(files: &[(&str, &str)]) -> (TempDir, Url) {
            let temp_dir = TempDir::new().unwrap();
            for (name, content) in files {
                let path = temp_dir.path().join(name);
                if let Some(parent) = path.parent() {
                    fs::create_dir_all(parent).unwrap();
                }
                fs::write(&path, content).unwrap();
            }
            let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
            (temp_dir, workspace_url)
        }

        // Helper to create URL for file in temp workspace
        fn temp_url(temp_dir: &TempDir, file: &str) -> Url {
            Url::from_file_path(temp_dir.path().join(file)).unwrap()
        }

        // Build parent file content
        let mut parent_lines: Vec<String> = Vec::new();
        for i in 0..directive_line {
            parent_lines.push(format!("# Comment line {}", i));
        }
        parent_lines.push("# @lsp-source child.R".to_string());
        parent_lines.push("# After directive".to_string());
        let parent_content = parent_lines.join("\n");

        // Child file defines a symbol
        let child_content = format!("{} <- 42", symbol_name);

        // Create temp workspace
        let (temp_dir, workspace_url) = create_temp_workspace(&[
            ("parent.R", &parent_content),
            ("child.R", &child_content),
        ]);
        let parent_uri = temp_url(&temp_dir, "parent.R");
        let child_uri = temp_url(&temp_dir, "child.R");

        // Parse and compute artifacts
        let parent_tree = parse_r_tree(&parent_content);
        let child_tree = parse_r_tree(&child_content);

        let parent_metadata = CrossFileMetadata {
            sources: vec![
                ForwardSource {
                    path: "child.R".to_string(),
                    line: directive_line,
                    column: 0,
                    is_directive: true,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
            ],
            ..Default::default()
        };

        let parent_artifacts = compute_artifacts_with_metadata(
            &parent_uri,
            &parent_tree,
            &parent_content,
            Some(&parent_metadata),
        );
        let child_artifacts = compute_artifacts(&child_uri, &child_tree, &child_content);

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let content_provider = |uri: &Url| -> Option<String> {
            if uri == &child_uri {
                Some(child_content.clone())
            } else if uri == &parent_uri {
                Some(parent_content.clone())
            } else {
                None
            }
        };
        graph.update_file(&parent_uri, &parent_metadata, Some(&workspace_url), content_provider);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<super::scope::ScopeArtifacts>> {
            if uri == &parent_uri {
                Some(Arc::clone(&parent_artifacts))
            } else if uri == &child_uri {
                Some(Arc::clone(&child_artifacts))
            } else {
                None
            }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri {
                Some(std::sync::Arc::new(parent_metadata.clone()))
            } else {
                None
            }
        };

        // Test at the directive line itself (column 0, start of line)
        // Symbols should NOT be available at the start of the directive line
        let scope_at_directive_start = scope_at_position_with_graph(
            &parent_uri,
            directive_line,
            0,  // Start of directive line
            &get_artifacts,
            &get_metadata,
            &graph,
            Some(&workspace_url),
            10,
            &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );

        prop_assert!(
            !scope_at_directive_start.symbols.contains_key(symbol_name.as_str()),
            "Symbol '{}' should NOT be available at start of directive line {}",
            symbol_name,
            directive_line
        );

        // Test at the line after directive
        // Symbols SHOULD be available
        let scope_after = scope_at_position_with_graph(
            &parent_uri,
            directive_line + 1,
            0,
            &get_artifacts,
            &get_metadata,
            &graph,
            Some(&workspace_url),
            10,
            &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );

        prop_assert!(
            scope_after.symbols.contains_key(symbol_name.as_str()),
            "Symbol '{}' should be available at line {} (after directive at line {})",
            symbol_name,
            directive_line + 1,
            directive_line
        );
    }
}

// ============================================================================
// Feature: lsp-source-directive, Property 11: Missing File Diagnostic
// Validates: Requirements 6.1
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: lsp-source-directive, Property 11: Missing File Diagnostic
    ///
    /// *For any* forward directive referencing a non-existent file, the system SHALL
    /// emit a diagnostic at the directive's line.
    ///
    /// This property verifies that:
    /// 1. When a forward directive (@lsp-source) references a file that doesn't exist,
    ///    a diagnostic is emitted
    /// 2. The diagnostic is positioned at the directive's line
    /// 3. The diagnostic message mentions the missing file path
    ///
    /// **Validates: Requirements 6.1**
    #[test]
    fn prop_forward_directive_missing_file_diagnostic(
        missing_file in path_component(),
        directive_line in 0..100u32,
    ) {
        use super::types::ForwardSource;
        use tempfile::TempDir;
        use std::fs::File;
        use tower_lsp::lsp_types::DiagnosticSeverity;

        // Helper to create temp workspace with only main.R (no target file)
        fn create_temp_workspace_without_target() -> (TempDir, Url) {
            let temp_dir = TempDir::new().unwrap();
            let main_path = temp_dir.path().join("main.R");
            File::create(&main_path).unwrap();
            let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
            (temp_dir, workspace_url)
        }

        // Helper to create URL for file in temp workspace
        fn temp_url(temp_dir: &TempDir, file: &str) -> Url {
            Url::from_file_path(temp_dir.path().join(file)).unwrap()
        }

        // Setup: Create a temp workspace with only main.R (target file does NOT exist)
        let missing_filename = format!("{}.R", missing_file);
        let (temp_dir, workspace_url) = create_temp_workspace_without_target();
        let main_uri = temp_url(&temp_dir, "main.R");

        // Create metadata with a forward directive pointing to non-existent file
        let meta = CrossFileMetadata {
            sources: vec![ForwardSource {
                path: missing_filename.clone(),
                line: directive_line,
                column: 0,
                is_directive: true, // This is a directive, not an AST-detected source()
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            }],
            ..Default::default()
        };

        // Collect diagnostics using the standalone async function
        // We use a blocking runtime to test the async function
        let rt = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .unwrap();

        let diagnostics = rt.block_on(async {
            crate::handlers::collect_missing_file_diagnostics_standalone_for_test(
                &main_uri,
                &meta,
                Some(&workspace_url),
                DiagnosticSeverity::WARNING,
            ).await
        });

        // Property: At least one diagnostic should be emitted for the missing file
        prop_assert!(
            !diagnostics.is_empty(),
            "Should emit at least one diagnostic for missing file '{}'",
            missing_filename
        );

        // Property: The diagnostic should be at the directive's line
        let has_diagnostic_at_line = diagnostics.iter().any(|d| d.range.start.line == directive_line);
        prop_assert!(
            has_diagnostic_at_line,
            "Diagnostic should be at directive line {}, but found diagnostics at lines: {:?}",
            directive_line,
            diagnostics.iter().map(|d| d.range.start.line).collect::<Vec<_>>()
        );

        // Property: The diagnostic message should mention the missing file
        let has_message_with_path = diagnostics.iter().any(|d| {
            d.message.contains(&missing_filename) ||
            d.message.contains("not found") ||
            d.message.contains("@lsp-source")
        });
        prop_assert!(
            has_message_with_path,
            "Diagnostic message should mention the missing file '{}', but got messages: {:?}",
            missing_filename,
            diagnostics.iter().map(|d| &d.message).collect::<Vec<_>>()
        );
    }

    /// Feature: lsp-source-directive, Property 11 Extended: Multiple missing files
    ///
    /// When multiple forward directives reference non-existent files, each should
    /// generate a diagnostic at its respective line.
    ///
    /// **Validates: Requirements 6.1**
    #[test]
    fn prop_forward_directive_missing_file_diagnostic_multiple(
        num_directives in 1..=5usize,
    ) {
        use super::types::ForwardSource;
        use tempfile::TempDir;
        use std::fs::File;
        use tower_lsp::lsp_types::DiagnosticSeverity;

        // Helper to create temp workspace with only main.R
        fn create_temp_workspace_without_target() -> (TempDir, Url) {
            let temp_dir = TempDir::new().unwrap();
            let main_path = temp_dir.path().join("main.R");
            File::create(&main_path).unwrap();
            let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
            (temp_dir, workspace_url)
        }

        // Helper to create URL for file in temp workspace
        fn temp_url(temp_dir: &TempDir, file: &str) -> Url {
            Url::from_file_path(temp_dir.path().join(file)).unwrap()
        }

        // Setup: Create a temp workspace with only main.R
        let (temp_dir, workspace_url) = create_temp_workspace_without_target();
        let main_uri = temp_url(&temp_dir, "main.R");

        // Create metadata with multiple forward directives pointing to non-existent files
        let sources: Vec<ForwardSource> = (0..num_directives)
            .map(|i| ForwardSource {
                path: format!("missing{}.R", i),
                line: (i * 10) as u32, // Different lines for each directive
                column: 0,
                is_directive: true,
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            })
            .collect();

        let expected_lines: Vec<u32> = sources.iter().map(|s| s.line).collect();

        let meta = CrossFileMetadata {
            sources,
            ..Default::default()
        };

        // Collect diagnostics
        let rt = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .unwrap();

        let diagnostics = rt.block_on(async {
            crate::handlers::collect_missing_file_diagnostics_standalone_for_test(
                &main_uri,
                &meta,
                Some(&workspace_url),
                DiagnosticSeverity::WARNING,
            ).await
        });

        // Property: Should have at least num_directives diagnostics
        prop_assert!(
            diagnostics.len() >= num_directives,
            "Should emit at least {} diagnostics for {} missing files, got {}",
            num_directives,
            num_directives,
            diagnostics.len()
        );

        // Property: Each directive line should have a diagnostic
        for expected_line in &expected_lines {
            let has_diagnostic = diagnostics.iter().any(|d| d.range.start.line == *expected_line);
            prop_assert!(
                has_diagnostic,
                "Should have diagnostic at line {}, but found diagnostics at lines: {:?}",
                expected_line,
                diagnostics.iter().map(|d| d.range.start.line).collect::<Vec<_>>()
            );
        }
    }

    /// Feature: lsp-source-directive, Property 11 Extended: All directive synonyms
    ///
    /// Missing file diagnostics should work for all forward directive synonyms
    /// (@lsp-source, @lsp-run, @lsp-include).
    ///
    /// **Validates: Requirements 6.1**
    #[test]
    fn prop_forward_directive_missing_file_diagnostic_synonyms(
        missing_file in path_component(),
        directive_line in 0..50u32,
    ) {
        use tempfile::TempDir;
        use std::fs::File;
        use tower_lsp::lsp_types::DiagnosticSeverity;

        // Helper to create temp workspace with only main.R
        fn create_temp_workspace_without_target() -> (TempDir, Url) {
            let temp_dir = TempDir::new().unwrap();
            let main_path = temp_dir.path().join("main.R");
            File::create(&main_path).unwrap();
            let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
            (temp_dir, workspace_url)
        }

        // Helper to create URL for file in temp workspace
        fn temp_url(temp_dir: &TempDir, file: &str) -> Url {
            Url::from_file_path(temp_dir.path().join(file)).unwrap()
        }

        let missing_filename = format!("{}.R", missing_file);

        // Test all three synonyms
        let synonyms = ["@lsp-source", "@lsp-run", "@lsp-include"];

        for synonym in synonyms {
            // Build content with the directive at the specified line
            let mut lines: Vec<String> = Vec::new();
            for i in 0..directive_line {
                lines.push(format!("# Comment line {}", i));
            }
            lines.push(format!("# {} {}", synonym, missing_filename));
            let content = lines.join("\n");

            // Parse directives
            let meta = parse_directives(&content);

            // Verify the directive was parsed
            prop_assert!(
                !meta.sources.is_empty(),
                "Directive '{}' should be parsed",
                synonym
            );

            // Setup temp workspace
            let (temp_dir, workspace_url) = create_temp_workspace_without_target();
            let main_uri = temp_url(&temp_dir, "main.R");

            // Collect diagnostics
            let rt = tokio::runtime::Builder::new_current_thread()
                .enable_all()
                .build()
                .unwrap();

            let diagnostics = rt.block_on(async {
                crate::handlers::collect_missing_file_diagnostics_standalone_for_test(
                    &main_uri,
                    &meta,
                    Some(&workspace_url),
                    DiagnosticSeverity::WARNING,
                ).await
            });

            // Property: Should emit diagnostic for missing file
            prop_assert!(
                !diagnostics.is_empty(),
                "Synonym '{}' should emit diagnostic for missing file '{}'",
                synonym,
                missing_filename
            );

            // Property: Diagnostic should be at directive line
            let has_diagnostic_at_line = diagnostics.iter().any(|d| d.range.start.line == directive_line);
            prop_assert!(
                has_diagnostic_at_line,
                "Synonym '{}': Diagnostic should be at line {}, found at lines: {:?}",
                synonym,
                directive_line,
                diagnostics.iter().map(|d| d.range.start.line).collect::<Vec<_>>()
            );
        }
    }

    /// Feature: lsp-source-directive, Property 11 Extended: Diagnostic message format
    ///
    /// The diagnostic message for a missing file referenced by a forward source
    /// directive should specifically mention "source directive" to distinguish it
    /// from a bare source() call (prefix-agnostic: `# raven: source` / `@lsp-source`).
    ///
    /// **Validates: Requirements 6.1**
    #[test]
    fn prop_forward_directive_missing_file_diagnostic_message_format(
        missing_file in path_component(),
    ) {
        use super::types::ForwardSource;
        use tempfile::TempDir;
        use std::fs::File;
        use tower_lsp::lsp_types::DiagnosticSeverity;

        // Helper to create temp workspace with only main.R
        fn create_temp_workspace_without_target() -> (TempDir, Url) {
            let temp_dir = TempDir::new().unwrap();
            let main_path = temp_dir.path().join("main.R");
            File::create(&main_path).unwrap();
            let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
            (temp_dir, workspace_url)
        }

        // Helper to create URL for file in temp workspace
        fn temp_url(temp_dir: &TempDir, file: &str) -> Url {
            Url::from_file_path(temp_dir.path().join(file)).unwrap()
        }

        let missing_filename = format!("{}.R", missing_file);
        let (temp_dir, workspace_url) = create_temp_workspace_without_target();
        let main_uri = temp_url(&temp_dir, "main.R");

        // Create metadata with a forward directive (is_directive=true)
        let meta = CrossFileMetadata {
            sources: vec![ForwardSource {
                path: missing_filename.clone(),
                line: 0,
                column: 0,
                is_directive: true, // This is a directive
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            }],
            ..Default::default()
        };

        // Collect diagnostics
        let rt = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .unwrap();

        let diagnostics = rt.block_on(async {
            crate::handlers::collect_missing_file_diagnostics_standalone_for_test(
                &main_uri,
                &meta,
                Some(&workspace_url),
                DiagnosticSeverity::WARNING,
            ).await
        });

        // Property: Should have at least one diagnostic
        prop_assert!(
            !diagnostics.is_empty(),
            "Should emit diagnostic for missing file"
        );

        // Property: Diagnostic message should mention "source directive" to
        // distinguish it from a bare source() call (prefix-agnostic since #421:
        // `# raven: source` and `@lsp-source` share this wording).
        let has_directive_mention = diagnostics.iter().any(|d| {
            d.message.contains("source directive")
        });
        prop_assert!(
            has_directive_mention,
            "Diagnostic message should mention 'source directive', got messages: {:?}",
            diagnostics.iter().map(|d| &d.message).collect::<Vec<_>>()
        );

        // Property: Diagnostic message should contain the file path
        let has_path = diagnostics.iter().any(|d| {
            d.message.contains(&missing_filename)
        });
        prop_assert!(
            has_path,
            "Diagnostic message should contain the file path '{}', got messages: {:?}",
            missing_filename,
            diagnostics.iter().map(|d| &d.message).collect::<Vec<_>>()
        );
    }

    /// Feature: lsp-source-directive, Property 11 Extended: No diagnostic for existing files
    ///
    /// When a forward directive references an existing file, no missing file diagnostic
    /// should be emitted.
    ///
    /// **Validates: Requirements 6.1 (inverse)**
    #[test]
    fn prop_forward_directive_no_diagnostic_for_existing_file(
        target_file in path_component(),
        directive_line in 0..100u32,
    ) {
        use super::types::ForwardSource;
        use tempfile::TempDir;
        use std::fs::File;
        use tower_lsp::lsp_types::DiagnosticSeverity;

        // Helper to create temp workspace with main.R AND target file
        fn create_temp_workspace_with_target(target: &str) -> (TempDir, Url) {
            let temp_dir = TempDir::new().unwrap();
            let main_path = temp_dir.path().join("main.R");
            File::create(&main_path).unwrap();
            let target_path = temp_dir.path().join(target);
            File::create(&target_path).unwrap();
            let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
            (temp_dir, workspace_url)
        }

        // Helper to create URL for file in temp workspace
        fn temp_url(temp_dir: &TempDir, file: &str) -> Url {
            Url::from_file_path(temp_dir.path().join(file)).unwrap()
        }

        let target_filename = format!("{}.R", target_file);
        let (temp_dir, workspace_url) = create_temp_workspace_with_target(&target_filename);
        let main_uri = temp_url(&temp_dir, "main.R");

        // Create metadata with a forward directive pointing to EXISTING file
        let meta = CrossFileMetadata {
            sources: vec![ForwardSource {
                path: target_filename.clone(),
                line: directive_line,
                column: 0,
                is_directive: true,
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            }],
            ..Default::default()
        };

        // Collect diagnostics
        let rt = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .unwrap();

        let diagnostics = rt.block_on(async {
            crate::handlers::collect_missing_file_diagnostics_standalone_for_test(
                &main_uri,
                &meta,
                Some(&workspace_url),
                DiagnosticSeverity::WARNING,
            ).await
        });

        // Property: No diagnostics should be emitted for existing file
        let missing_file_diagnostics: Vec<_> = diagnostics.iter()
            .filter(|d| d.message.contains("not found") || d.message.contains("Cannot resolve"))
            .collect();

        prop_assert!(
            missing_file_diagnostics.is_empty(),
            "Should NOT emit missing file diagnostic for existing file '{}', but got: {:?}",
            target_filename,
            missing_file_diagnostics.iter().map(|d| &d.message).collect::<Vec<_>>()
        );
    }
}

// ============================================================================
// Property 12: Revalidation on Directive Change
// Feature: lsp-source-directive
// Validates: Requirements 7.1, 7.2, 7.3
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: lsp-source-directive, Property 12: Revalidation on Directive Change
    ///
    /// For any change to a forward directive (add, remove, or modify), the dependency
    /// graph SHALL be updated to reflect the change.
    ///
    /// This test verifies that:
    /// 1. Adding an @lsp-source directive creates a new edge in the graph
    /// 2. Removing an @lsp-source directive removes the edge from the graph
    /// 3. Modifying an @lsp-source directive updates the edge in the graph
    ///
    /// **Validates: Requirements 7.1, 7.2, 7.3**
    #[test]
    fn prop_revalidation_on_directive_add(
        parent in path_component(),
        child in path_component(),
        directive_line in 0..100u32,
    ) {
        use tempfile::TempDir;
        use std::fs::File;

        // Create temp workspace with actual files (required for forward directive edge creation)
        let temp_dir = TempDir::new().unwrap();
        let parent_file = format!("{}.R", parent);
        let child_file = format!("{}.R", child);
        File::create(temp_dir.path().join(&parent_file)).unwrap();
        File::create(temp_dir.path().join(&child_file)).unwrap();

        let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
        let parent_uri = Url::from_file_path(temp_dir.path().join(&parent_file)).unwrap();
        let child_uri = Url::from_file_path(temp_dir.path().join(&child_file)).unwrap();

        let mut graph = DependencyGraph::new();

        // Initial state: no directives, no edges
        let meta_v1 = CrossFileMetadata::default();
        graph.update_file(&parent_uri, &meta_v1, Some(&workspace_url), |_| None);

        // Verify no edges exist initially
        let deps_before = graph.get_dependencies(&parent_uri);
        prop_assert!(
            deps_before.is_empty(),
            "Graph should have no edges initially"
        );

        // Add a forward directive (simulating user adding @lsp-source)
        let meta_v2 = CrossFileMetadata {
            sources: vec![ForwardSource {
                path: child_file.clone(),
                line: directive_line,
                column: 0,
                is_directive: true,
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            }],
            ..Default::default()
        };
        graph.update_file(&parent_uri, &meta_v2, Some(&workspace_url), |_| None);

        // Verify edge was created (Requirement 7.1)
        let deps_after = graph.get_dependencies(&parent_uri);
        prop_assert_eq!(
            deps_after.len(), 1,
            "Adding @lsp-source directive should create exactly one edge"
        );
        prop_assert_eq!(
            &deps_after[0].to, &child_uri,
            "Edge should point to the target file"
        );
        prop_assert!(
            deps_after[0].is_directive,
            "Edge should be marked as directive"
        );
        prop_assert_eq!(
            deps_after[0].call_site_line, Some(directive_line),
            "Edge should have correct call site line"
        );
    }

    /// Feature: lsp-source-directive, Property 12: Revalidation on Directive Remove
    ///
    /// When an @lsp-source directive is removed from a file, the corresponding edge
    /// SHALL be removed from the dependency graph.
    ///
    /// **Validates: Requirements 7.2**
    #[test]
    fn prop_revalidation_on_directive_remove(
        parent in path_component(),
        child in path_component(),
        directive_line in 0..100u32,
    ) {
        use tempfile::TempDir;
        use std::fs::File;

        // Create temp workspace with actual files
        let temp_dir = TempDir::new().unwrap();
        let parent_file = format!("{}.R", parent);
        let child_file = format!("{}.R", child);
        File::create(temp_dir.path().join(&parent_file)).unwrap();
        File::create(temp_dir.path().join(&child_file)).unwrap();

        let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
        let parent_uri = Url::from_file_path(temp_dir.path().join(&parent_file)).unwrap();
        let child_uri = Url::from_file_path(temp_dir.path().join(&child_file)).unwrap();

        let mut graph = DependencyGraph::new();

        // Initial state: file has a forward directive
        let meta_v1 = CrossFileMetadata {
            sources: vec![ForwardSource {
                path: child_file.clone(),
                line: directive_line,
                column: 0,
                is_directive: true,
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            }],
            ..Default::default()
        };
        graph.update_file(&parent_uri, &meta_v1, Some(&workspace_url), |_| None);

        // Verify edge exists
        let deps_before = graph.get_dependencies(&parent_uri);
        prop_assert_eq!(
            deps_before.len(), 1,
            "Graph should have one edge before removal"
        );
        prop_assert_eq!(
            &deps_before[0].to, &child_uri,
            "Edge should point to child file"
        );

        // Remove the directive (simulating user removing @lsp-source)
        let meta_v2 = CrossFileMetadata::default();
        graph.update_file(&parent_uri, &meta_v2, Some(&workspace_url), |_| None);

        // Verify edge was removed (Requirement 7.2)
        let deps_after = graph.get_dependencies(&parent_uri);
        prop_assert!(
            deps_after.is_empty(),
            "Removing @lsp-source directive should remove the edge"
        );

        // Also verify backward lookup is cleared
        let dependents = graph.get_dependents(&child_uri);
        prop_assert!(
            dependents.is_empty(),
            "Child file should have no dependents after directive removal"
        );
    }

    /// Feature: lsp-source-directive, Property 12: Revalidation on Directive Modify
    ///
    /// When an @lsp-source directive's target is modified, the dependency graph
    /// SHALL be updated to reflect the new target.
    ///
    /// **Validates: Requirements 7.3**
    #[test]
    fn prop_revalidation_on_directive_modify(
        parent in path_component(),
        child_a in path_component(),
        child_b in path_component(),
        directive_line in 0..100u32,
    ) {
        prop_assume!(child_a != child_b);

        use tempfile::TempDir;
        use std::fs::File;

        // Create temp workspace with actual files
        let temp_dir = TempDir::new().unwrap();
        let parent_file = format!("{}.R", parent);
        let child_a_file = format!("{}.R", child_a);
        let child_b_file = format!("{}.R", child_b);
        File::create(temp_dir.path().join(&parent_file)).unwrap();
        File::create(temp_dir.path().join(&child_a_file)).unwrap();
        File::create(temp_dir.path().join(&child_b_file)).unwrap();

        let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
        let parent_uri = Url::from_file_path(temp_dir.path().join(&parent_file)).unwrap();
        let child_a_uri = Url::from_file_path(temp_dir.path().join(&child_a_file)).unwrap();
        let child_b_uri = Url::from_file_path(temp_dir.path().join(&child_b_file)).unwrap();

        let mut graph = DependencyGraph::new();

        // Initial state: directive points to child_a
        let meta_v1 = CrossFileMetadata {
            sources: vec![ForwardSource {
                path: child_a_file.clone(),
                line: directive_line,
                column: 0,
                is_directive: true,
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            }],
            ..Default::default()
        };
        graph.update_file(&parent_uri, &meta_v1, Some(&workspace_url), |_| None);

        // Verify edge points to child_a
        let deps_before = graph.get_dependencies(&parent_uri);
        prop_assert_eq!(deps_before.len(), 1);
        prop_assert_eq!(
            &deps_before[0].to, &child_a_uri,
            "Initial edge should point to child_a"
        );

        // Modify directive to point to child_b (simulating user changing @lsp-source target)
        let meta_v2 = CrossFileMetadata {
            sources: vec![ForwardSource {
                path: child_b_file.clone(),
                line: directive_line,
                column: 0,
                is_directive: true,
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            }],
            ..Default::default()
        };
        graph.update_file(&parent_uri, &meta_v2, Some(&workspace_url), |_| None);

        // Verify edge now points to child_b (Requirement 7.3)
        let deps_after = graph.get_dependencies(&parent_uri);
        prop_assert_eq!(
            deps_after.len(), 1,
            "Should still have exactly one edge after modification"
        );
        prop_assert_eq!(
            &deps_after[0].to, &child_b_uri,
            "Edge should now point to child_b after modification"
        );

        // Verify old edge to child_a is removed
        let child_a_dependents = graph.get_dependents(&child_a_uri);
        prop_assert!(
            child_a_dependents.is_empty(),
            "child_a should have no dependents after directive modification"
        );

        // Verify new edge to child_b exists
        let child_b_dependents = graph.get_dependents(&child_b_uri);
        prop_assert_eq!(
            child_b_dependents.len(), 1,
            "child_b should have one dependent after directive modification"
        );
    }

    /// Feature: lsp-source-directive, Property 12 Extended: Multiple directive changes
    ///
    /// When multiple forward directives are added, removed, or modified in a single
    /// update, the dependency graph SHALL reflect all changes correctly.
    ///
    /// **Validates: Requirements 7.1, 7.2, 7.3**
    #[test]
    fn prop_revalidation_on_multiple_directive_changes(
        parent in path_component(),
        child_a in path_component(),
        child_b in path_component(),
        child_c in path_component(),
        line_a in 0..30u32,
        line_b in 30..60u32,
        line_c in 60..100u32,
    ) {
        prop_assume!(child_a != child_b && child_b != child_c && child_a != child_c);

        use tempfile::TempDir;
        use std::fs::File;

        // Create temp workspace with actual files
        let temp_dir = TempDir::new().unwrap();
        let parent_file = format!("{}.R", parent);
        let child_a_file = format!("{}.R", child_a);
        let child_b_file = format!("{}.R", child_b);
        let child_c_file = format!("{}.R", child_c);
        File::create(temp_dir.path().join(&parent_file)).unwrap();
        File::create(temp_dir.path().join(&child_a_file)).unwrap();
        File::create(temp_dir.path().join(&child_b_file)).unwrap();
        File::create(temp_dir.path().join(&child_c_file)).unwrap();

        let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
        let parent_uri = Url::from_file_path(temp_dir.path().join(&parent_file)).unwrap();
        let child_a_uri = Url::from_file_path(temp_dir.path().join(&child_a_file)).unwrap();
        let child_b_uri = Url::from_file_path(temp_dir.path().join(&child_b_file)).unwrap();
        let child_c_uri = Url::from_file_path(temp_dir.path().join(&child_c_file)).unwrap();

        let mut graph = DependencyGraph::new();

        // Initial state: directives to child_a and child_b
        let meta_v1 = CrossFileMetadata {
            sources: vec![
                ForwardSource {
                    path: child_a_file.clone(),
                    line: line_a,
                    column: 0,
                    is_directive: true,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
                ForwardSource {
                    path: child_b_file.clone(),
                    line: line_b,
                    column: 0,
                    is_directive: true,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
            ],
            ..Default::default()
        };
        graph.update_file(&parent_uri, &meta_v1, Some(&workspace_url), |_| None);

        // Verify initial state
        let deps_v1 = graph.get_dependencies(&parent_uri);
        prop_assert_eq!(deps_v1.len(), 2, "Should have two edges initially");

        // Change: remove child_a, keep child_b, add child_c
        let meta_v2 = CrossFileMetadata {
            sources: vec![
                ForwardSource {
                    path: child_b_file.clone(),
                    line: line_b,
                    column: 0,
                    is_directive: true,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
                ForwardSource {
                    path: child_c_file.clone(),
                    line: line_c,
                    column: 0,
                    is_directive: true,
                    chdir: false,
                    is_sys_source: false,
                    ..Default::default()
                },
            ],
            ..Default::default()
        };
        graph.update_file(&parent_uri, &meta_v2, Some(&workspace_url), |_| None);

        // Verify final state
        let deps_v2 = graph.get_dependencies(&parent_uri);
        prop_assert_eq!(
            deps_v2.len(), 2,
            "Should still have two edges after changes"
        );

        // Collect target URIs
        let targets: HashSet<_> = deps_v2.iter().map(|e| &e.to).collect();

        // child_a should be removed
        prop_assert!(
            !targets.contains(&child_a_uri),
            "child_a should be removed from graph"
        );

        // child_b should still be present
        prop_assert!(
            targets.contains(&child_b_uri),
            "child_b should still be in graph"
        );

        // child_c should be added
        prop_assert!(
            targets.contains(&child_c_uri),
            "child_c should be added to graph"
        );

        // Verify backward lookups
        prop_assert!(
            graph.get_dependents(&child_a_uri).is_empty(),
            "child_a should have no dependents"
        );
        prop_assert_eq!(
            graph.get_dependents(&child_b_uri).len(), 1,
            "child_b should have one dependent"
        );
        prop_assert_eq!(
            graph.get_dependents(&child_c_uri).len(), 1,
            "child_c should have one dependent"
        );
    }

    /// Feature: lsp-source-directive, Property 12 Extended: Line number change
    ///
    /// When a forward directive's line number changes (but target stays the same),
    /// the dependency graph SHALL update the call site information.
    ///
    /// **Validates: Requirements 7.3**
    #[test]
    fn prop_revalidation_on_directive_line_change(
        parent in path_component(),
        child in path_component(),
        line_v1 in 0..50u32,
        line_v2 in 50..100u32,
    ) {
        use tempfile::TempDir;
        use std::fs::File;

        // Create temp workspace with actual files
        let temp_dir = TempDir::new().unwrap();
        let parent_file = format!("{}.R", parent);
        let child_file = format!("{}.R", child);
        File::create(temp_dir.path().join(&parent_file)).unwrap();
        File::create(temp_dir.path().join(&child_file)).unwrap();

        let workspace_url = Url::from_file_path(temp_dir.path()).unwrap();
        let parent_uri = Url::from_file_path(temp_dir.path().join(&parent_file)).unwrap();
        let child_uri = Url::from_file_path(temp_dir.path().join(&child_file)).unwrap();

        let mut graph = DependencyGraph::new();

        // Initial state: directive at line_v1
        let meta_v1 = CrossFileMetadata {
            sources: vec![ForwardSource {
                path: child_file.clone(),
                line: line_v1,
                column: 0,
                is_directive: true,
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            }],
            ..Default::default()
        };
        graph.update_file(&parent_uri, &meta_v1, Some(&workspace_url), |_| None);

        // Verify initial call site
        let deps_v1 = graph.get_dependencies(&parent_uri);
        prop_assert_eq!(deps_v1.len(), 1);
        prop_assert_eq!(
            deps_v1[0].call_site_line, Some(line_v1),
            "Initial call site should be at line_v1"
        );

        // Change directive line (simulating user moving the directive)
        let meta_v2 = CrossFileMetadata {
            sources: vec![ForwardSource {
                path: child_file.clone(),
                line: line_v2,
                column: 0,
                is_directive: true,
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            }],
            ..Default::default()
        };
        graph.update_file(&parent_uri, &meta_v2, Some(&workspace_url), |_| None);

        // Verify call site was updated
        let deps_v2 = graph.get_dependencies(&parent_uri);
        prop_assert_eq!(deps_v2.len(), 1);
        prop_assert_eq!(
            &deps_v2[0].to, &child_uri,
            "Edge should still point to same child"
        );
        prop_assert_eq!(
            deps_v2[0].call_site_line, Some(line_v2),
            "Call site should be updated to line_v2"
        );
    }
}

// ============================================================================
// Property 3 (Declaration Directives): Metadata Serialization Round-Trip
// Feature: lsp-declaration-directives
// Validates: Requirements 3.3
// ============================================================================

use super::types::DeclaredSymbol;

/// Generate a valid R symbol name for declared symbols
fn r_symbol_name() -> impl Strategy<Value = String> {
    // R identifiers: start with letter or dot (if not followed by digit), contain letters, digits, dots, underscores
    prop_oneof![
        // Simple alphanumeric names
        "[a-zA-Z][a-zA-Z0-9_.]{0,15}",
        // Names starting with dot (valid in R)
        "\\.[a-zA-Z][a-zA-Z0-9_.]{0,10}",
    ]
    .prop_filter("not reserved and not empty", |s| {
        !s.is_empty() && is_valid_r_identifier(s) && !s.starts_with("..")
    })
}

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 3: For any CrossFileMetadata containing declared variables and functions,
    /// serializing to JSON and deserializing back SHALL produce an equivalent metadata
    /// object with all declared symbols preserved.
    ///
    /// **Feature: lsp-declaration-directives, Property 3: Metadata Serialization Round-Trip**
    /// **Validates: Requirements 3.3**
    #[test]
    fn prop_declared_symbol_serialization_round_trip(
        var_names in prop::collection::vec(r_symbol_name(), 0..5),
        func_names in prop::collection::vec(r_symbol_name(), 0..5),
        var_lines in prop::collection::vec(0..1000u32, 0..5),
        func_lines in prop::collection::vec(0..1000u32, 0..5),
    ) {
        // Build declared variables
        let declared_variables: Vec<DeclaredSymbol> = var_names
            .iter()
            .zip(var_lines.iter().cycle())
            .map(|(name, &line)| DeclaredSymbol {
                name: name.clone(),
                line,
                is_function: false,
                formals: None,
            })
            .collect();

        // Build declared functions
        let declared_functions: Vec<DeclaredSymbol> = func_names
            .iter()
            .zip(func_lines.iter().cycle())
            .map(|(name, &line)| DeclaredSymbol {
                name: name.clone(),
                line,
                is_function: true,
                formals: None,
            })
            .collect();

        let meta = CrossFileMetadata {
            declared_variables: declared_variables.clone(),
            declared_functions: declared_functions.clone(),
            ..Default::default()
        };

        // Serialize to JSON
        let json = serde_json::to_string(&meta).expect("serialization should succeed");

        // Deserialize back
        let parsed: CrossFileMetadata = serde_json::from_str(&json).expect("deserialization should succeed");

        // Verify declared_variables preserved
        prop_assert_eq!(
            parsed.declared_variables.len(),
            declared_variables.len(),
            "declared_variables count should match"
        );
        for (original, parsed) in declared_variables.iter().zip(parsed.declared_variables.iter()) {
            prop_assert_eq!(&original.name, &parsed.name, "variable name should match");
            prop_assert_eq!(original.line, parsed.line, "variable line should match");
            prop_assert_eq!(original.is_function, parsed.is_function, "variable is_function should be false");
        }

        // Verify declared_functions preserved
        prop_assert_eq!(
            parsed.declared_functions.len(),
            declared_functions.len(),
            "declared_functions count should match"
        );
        for (original, parsed) in declared_functions.iter().zip(parsed.declared_functions.iter()) {
            prop_assert_eq!(&original.name, &parsed.name, "function name should match");
            prop_assert_eq!(original.line, parsed.line, "function line should match");
            prop_assert_eq!(original.is_function, parsed.is_function, "function is_function should be true");
        }
    }

    /// Property 3 extended: Round-trip with declared symbols alongside other metadata fields
    ///
    /// **Feature: lsp-declaration-directives, Property 3: Metadata Serialization Round-Trip**
    /// **Validates: Requirements 3.3**
    #[test]
    fn prop_declared_symbol_round_trip_with_other_fields(
        var_name in r_symbol_name(),
        func_name in r_symbol_name(),
        var_line in 0..1000u32,
        func_line in 0..1000u32,
        backward_path in relative_path_with_parents(),
        forward_path in relative_path(),
        wd_path in relative_path(),
    ) {
        let meta = CrossFileMetadata {
            sourced_by: vec![super::types::BackwardDirective {
                path: backward_path.clone(),
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            sources: vec![super::types::ForwardSource {
                path: forward_path.clone(),
                line: 5,
                column: 0,
                is_directive: false,
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            }],
            working_directory: Some(wd_path.clone()),
            declared_variables: vec![DeclaredSymbol {
                name: var_name.clone(),
                line: var_line,
                is_function: false,
                formals: None,
            }],
            declared_functions: vec![DeclaredSymbol {
                name: func_name.clone(),
                line: func_line,
                is_function: true,
                formals: None,
            }],
            ..Default::default()
        };

        // Serialize and deserialize
        let json = serde_json::to_string(&meta).expect("serialization should succeed");
        let parsed: CrossFileMetadata = serde_json::from_str(&json).expect("deserialization should succeed");

        // Verify all fields preserved
        prop_assert_eq!(parsed.sourced_by.len(), 1);
        prop_assert_eq!(&parsed.sourced_by[0].path, &backward_path);
        prop_assert_eq!(parsed.sources.len(), 1);
        prop_assert_eq!(&parsed.sources[0].path, &forward_path);
        prop_assert_eq!(parsed.working_directory, Some(wd_path));

        // Verify declared symbols
        prop_assert_eq!(parsed.declared_variables.len(), 1);
        prop_assert_eq!(&parsed.declared_variables[0].name, &var_name);
        prop_assert_eq!(parsed.declared_variables[0].line, var_line);
        prop_assert!(!parsed.declared_variables[0].is_function);

        prop_assert_eq!(parsed.declared_functions.len(), 1);
        prop_assert_eq!(&parsed.declared_functions[0].name, &func_name);
        prop_assert_eq!(parsed.declared_functions[0].line, func_line);
        prop_assert!(parsed.declared_functions[0].is_function);
    }

    /// Property 3 extended: Empty declared symbols should serialize correctly
    ///
    /// **Feature: lsp-declaration-directives, Property 3: Metadata Serialization Round-Trip**
    /// **Validates: Requirements 3.3**
    #[test]
    fn prop_empty_declared_symbols_round_trip(
        backward_path in relative_path_with_parents(),
    ) {
        let meta = CrossFileMetadata {
            sourced_by: vec![super::types::BackwardDirective {
                path: backward_path,
                call_site: CallSiteSpec::Default,
                directive_line: 0,
            }],
            declared_variables: vec![],
            declared_functions: vec![],
            ..Default::default()
        };

        let json = serde_json::to_string(&meta).expect("serialization should succeed");
        let parsed: CrossFileMetadata = serde_json::from_str(&json).expect("deserialization should succeed");

        prop_assert!(parsed.declared_variables.is_empty());
        prop_assert!(parsed.declared_functions.is_empty());
    }
}

// ============================================================================
// Feature: lsp-declaration-directives, Property 1: Directive Parsing Completeness
// Validates: Requirements 1.1, 1.2, 1.3, 1.4, 1.5, 2.1, 2.2, 2.3, 2.4, 2.5
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: lsp-declaration-directives, Property 1: Directive Parsing Completeness
    ///
    /// For any valid symbol name and any directive synonym form (@lsp-var, @lsp-variable,
    /// @lsp-declare-var, @lsp-declare-variable for variables; @lsp-func, @lsp-function,
    /// @lsp-declare-func, @lsp-declare-function for functions), with or without optional
    /// colon, with or without quotes, parsing SHALL extract the exact symbol name and
    /// correct symbol kind (function or variable).
    ///
    /// **Validates: Requirements 1.1, 1.2, 1.3, 1.4, 1.5, 2.1, 2.2, 2.3, 2.4, 2.5**
    #[test]
    fn prop_declaration_directive_parsing_completeness_var(
        symbol_name in r_symbol_name(),
        synonym_idx in 0..4usize,
        use_colon in proptest::bool::ANY,
        quote_style in 0..3usize, // 0=none, 1=double, 2=single
    ) {
        let var_synonyms = ["@lsp-var", "@lsp-variable", "@lsp-declare-var", "@lsp-declare-variable"];
        let directive = var_synonyms[synonym_idx];

        let colon = if use_colon { ":" } else { "" };
        let quoted_name = match quote_style {
            1 => format!("\"{}\"", symbol_name),
            2 => format!("'{}'", symbol_name),
            _ => symbol_name.clone(),
        };

        let content = format!("# {}{} {}", directive, colon, quoted_name);
        let meta = parse_directives(&content);

        prop_assert_eq!(
            meta.declared_variables.len(),
            1,
            "Should parse exactly one variable declaration for directive '{}' with content: {}",
            directive,
            content
        );
        prop_assert_eq!(
            &meta.declared_variables[0].name,
            &symbol_name,
            "Symbol name should match for directive '{}' with content: {}",
            directive,
            content
        );
        prop_assert!(
            !meta.declared_variables[0].is_function,
            "Should be marked as variable (is_function=false) for directive '{}'",
            directive
        );
        prop_assert_eq!(
            meta.declared_variables[0].line,
            0,
            "Line number should be 0 (first line) for directive '{}'",
            directive
        );
    }

    /// Feature: lsp-declaration-directives, Property 1: Directive Parsing Completeness (functions)
    ///
    /// **Validates: Requirements 2.1, 2.2, 2.3, 2.4, 2.5**
    #[test]
    fn prop_declaration_directive_parsing_completeness_func(
        symbol_name in r_symbol_name(),
        synonym_idx in 0..4usize,
        use_colon in proptest::bool::ANY,
        quote_style in 0..3usize, // 0=none, 1=double, 2=single
    ) {
        let func_synonyms = ["@lsp-func", "@lsp-function", "@lsp-declare-func", "@lsp-declare-function"];
        let directive = func_synonyms[synonym_idx];

        let colon = if use_colon { ":" } else { "" };
        let quoted_name = match quote_style {
            1 => format!("\"{}\"", symbol_name),
            2 => format!("'{}'", symbol_name),
            _ => symbol_name.clone(),
        };

        let content = format!("# {}{} {}", directive, colon, quoted_name);
        let meta = parse_directives(&content);

        prop_assert_eq!(
            meta.declared_functions.len(),
            1,
            "Should parse exactly one function declaration for directive '{}' with content: {}",
            directive,
            content
        );
        prop_assert_eq!(
            &meta.declared_functions[0].name,
            &symbol_name,
            "Symbol name should match for directive '{}' with content: {}",
            directive,
            content
        );
        prop_assert!(
            meta.declared_functions[0].is_function,
            "Should be marked as function (is_function=true) for directive '{}'",
            directive
        );
        prop_assert_eq!(
            meta.declared_functions[0].line,
            0,
            "Line number should be 0 (first line) for directive '{}'",
            directive
        );
    }

    /// Feature: lsp-declaration-directives, Property 1 extended: Multiple declarations
    ///
    /// For any file with multiple declaration directives on separate lines, the parser
    /// SHALL extract all declared variables and functions with correct line numbers.
    ///
    /// **Validates: Requirements 1.4, 1.5, 2.4, 2.5**
    #[test]
    fn prop_declaration_directive_multiple_on_separate_lines(
        var_names in proptest::collection::vec(r_symbol_name(), 1..5),
        func_names in proptest::collection::vec(r_symbol_name(), 1..5),
    ) {
        // Build content with alternating var and func declarations
        let mut lines = Vec::new();
        let mut expected_vars = Vec::new();
        let mut expected_funcs = Vec::new();

        for name in var_names.iter() {
            let line_num = lines.len() as u32;
            lines.push(format!("# @lsp-var {}", name));
            expected_vars.push((name.clone(), line_num));
        }

        for name in func_names.iter() {
            let line_num = lines.len() as u32;
            lines.push(format!("# @lsp-func {}", name));
            expected_funcs.push((name.clone(), line_num));
        }

        let content = lines.join("\n");
        let meta = parse_directives(&content);

        prop_assert_eq!(
            meta.declared_variables.len(),
            expected_vars.len(),
            "Should parse all variable declarations"
        );
        prop_assert_eq!(
            meta.declared_functions.len(),
            expected_funcs.len(),
            "Should parse all function declarations"
        );

        for (i, (expected_name, expected_line)) in expected_vars.iter().enumerate() {
            prop_assert_eq!(
                &meta.declared_variables[i].name,
                expected_name,
                "Variable name at index {} should match",
                i
            );
            prop_assert_eq!(
                meta.declared_variables[i].line,
                *expected_line,
                "Variable line at index {} should match",
                i
            );
        }

        for (i, (expected_name, expected_line)) in expected_funcs.iter().enumerate() {
            prop_assert_eq!(
                &meta.declared_functions[i].name,
                expected_name,
                "Function name at index {} should match",
                i
            );
            prop_assert_eq!(
                meta.declared_functions[i].line,
                *expected_line,
                "Function line at index {} should match",
                i
            );
        }
    }

    /// Feature: lsp-declaration-directives, Property 1 extended: Line number recording
    ///
    /// For any declaration directive appearing at line N, the parser SHALL record
    /// the 0-based line number N.
    ///
    /// **Validates: Requirements 1.5, 2.5**
    #[test]
    fn prop_declaration_directive_line_number_recording(
        symbol_name in r_symbol_name(),
        prefix_lines in 0..10usize,
        is_function in proptest::bool::ANY,
    ) {
        // Build content with prefix lines before the directive
        let mut lines: Vec<String> = (0..prefix_lines)
            .map(|i| format!("x{} <- {}", i, i))
            .collect();

        let directive = if is_function { "@lsp-func" } else { "@lsp-var" };
        lines.push(format!("# {} {}", directive, symbol_name));

        let content = lines.join("\n");
        let meta = parse_directives(&content);

        let expected_line = prefix_lines as u32;

        if is_function {
            prop_assert_eq!(meta.declared_functions.len(), 1);
            prop_assert_eq!(
                meta.declared_functions[0].line,
                expected_line,
                "Function declaration line should be {} (0-based)",
                expected_line
            );
        } else {
            prop_assert_eq!(meta.declared_variables.len(), 1);
            prop_assert_eq!(
                meta.declared_variables[0].line,
                expected_line,
                "Variable declaration line should be {} (0-based)",
                expected_line
            );
        }
    }
}

// ============================================================================
// Feature: lsp-declaration-directives, Property 2: Required @ Prefix
// Validates: Requirements 1.6, 2.6
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: lsp-declaration-directives, Property 2: Required @ Prefix
    ///
    /// For any directive-like comment that does not start with @ (e.g., # lsp-var myvar),
    /// the parser SHALL NOT recognize it as a valid declaration directive and SHALL NOT
    /// extract any declared symbol.
    ///
    /// **Validates: Requirements 1.6, 2.6**
    #[test]
    fn prop_declaration_directive_requires_at_prefix_var(
        symbol_name in r_symbol_name(),
        synonym_idx in 0..4usize,
        use_colon in proptest::bool::ANY,
    ) {
        // Variable directive synonyms WITHOUT @ prefix
        let var_synonyms_no_at = ["lsp-var", "lsp-variable", "lsp-declare-var", "lsp-declare-variable"];
        let directive = var_synonyms_no_at[synonym_idx];

        let colon = if use_colon { ":" } else { "" };
        let content = format!("# {}{} {}", directive, colon, symbol_name);
        let meta = parse_directives(&content);

        prop_assert!(
            meta.declared_variables.is_empty(),
            "Should NOT parse variable declaration without @ prefix for directive '{}' with content: {}",
            directive,
            content
        );
    }

    /// Feature: lsp-declaration-directives, Property 2: Required @ Prefix (functions)
    ///
    /// **Validates: Requirements 2.6**
    #[test]
    fn prop_declaration_directive_requires_at_prefix_func(
        symbol_name in r_symbol_name(),
        synonym_idx in 0..4usize,
        use_colon in proptest::bool::ANY,
    ) {
        // Function directive synonyms WITHOUT @ prefix
        let func_synonyms_no_at = ["lsp-func", "lsp-function", "lsp-declare-func", "lsp-declare-function"];
        let directive = func_synonyms_no_at[synonym_idx];

        let colon = if use_colon { ":" } else { "" };
        let content = format!("# {}{} {}", directive, colon, symbol_name);
        let meta = parse_directives(&content);

        prop_assert!(
            meta.declared_functions.is_empty(),
            "Should NOT parse function declaration without @ prefix for directive '{}' with content: {}",
            directive,
            content
        );
    }

    /// Feature: lsp-declaration-directives, Property 2 extended: @ prefix is required
    ///
    /// Verify that the same content WITH @ prefix IS recognized.
    ///
    /// **Validates: Requirements 1.6, 2.6**
    #[test]
    fn prop_declaration_directive_with_at_prefix_is_recognized(
        symbol_name in r_symbol_name(),
        is_function in proptest::bool::ANY,
    ) {
        let directive = if is_function { "@lsp-func" } else { "@lsp-var" };
        let content = format!("# {} {}", directive, symbol_name);
        let meta = parse_directives(&content);

        if is_function {
            prop_assert_eq!(
                meta.declared_functions.len(),
                1,
                "Should parse function declaration WITH @ prefix"
            );
            prop_assert_eq!(&meta.declared_functions[0].name, &symbol_name);
        } else {
            prop_assert_eq!(
                meta.declared_variables.len(),
                1,
                "Should parse variable declaration WITH @ prefix"
            );
            prop_assert_eq!(&meta.declared_variables[0].name, &symbol_name);
        }
    }
}

// ============================================================================
// Feature: lsp-declaration-directives, Property 4: Position-Aware Scope Inclusion
// Validates: Requirements 4.1, 4.2, 4.3, 4.4, 4.5, 4.6
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: lsp-declaration-directives, Property 4: Position-Aware Scope Inclusion
    ///
    /// For any file with declaration directives at various line positions and any query
    /// position (line, column), a declared symbol SHALL appear in scope if and only if
    /// the query line is strictly greater than the directive line (i.e., directive_line < query_line).
    /// A symbol declared on line N is available starting from line N+1.
    ///
    /// **Validates: Requirements 4.1, 4.2, 4.3, 4.4, 4.5, 4.6**
    #[test]
    fn prop_declaration_position_aware_scope_inclusion(
        symbol_name in r_symbol_name(),
        directive_line in 0..10u32,
        is_function in proptest::bool::ANY,
    ) {
        use super::directive::parse_directives;
        use super::scope::{compute_artifacts_with_metadata, scope_at_position};
        use tree_sitter::Parser;
        use tower_lsp::lsp_types::Url;

        // Skip if the symbol name collides with filler variable names
        prop_assume!(!filler_names(directive_line as usize, 3).contains(symbol_name.as_str()));

        // Build content with the directive at the specified line
        let mut lines: Vec<String> = (0..directive_line)
            .map(|i| format!("x{} <- {}", i, i))
            .collect();

        let directive = if is_function {
            format!("# @lsp-func {}", symbol_name)
        } else {
            format!("# @lsp-var {}", symbol_name)
        };
        lines.push(directive);

        // Add some lines after the directive
        for i in 0..3 {
            lines.push(format!("y{} <- {}", i, i + 100));
        }

        let content = lines.join("\n");
        let uri = Url::parse("file:///test.R").unwrap();

        // Parse the content
        let mut parser = Parser::new();
        parser.set_language(&tree_sitter_r::LANGUAGE.into()).unwrap();
        let tree = parser.parse(&content, None).unwrap();

        // Extract metadata and compute artifacts
        let metadata = parse_directives(&content);
        let artifacts = compute_artifacts_with_metadata(&uri, &tree, &content, Some(&metadata));

        // Test 1: Symbol should NOT be in scope on the directive line itself
        let scope_on_directive_line = scope_at_position(&artifacts, directive_line, 0, false);
        prop_assert!(
            !scope_on_directive_line.symbols.contains_key(symbol_name.as_str()),
            "Symbol '{}' should NOT be in scope on directive line {}. Content:\n{}",
            symbol_name, directive_line, content
        );

        // Test 2: Symbol should NOT be in scope at end of directive line (column u32::MAX - 1)
        // This tests that the end-of-line sentinel works correctly
        let scope_at_end_of_directive_line = scope_at_position(&artifacts, directive_line, u32::MAX - 1, false);
        prop_assert!(
            !scope_at_end_of_directive_line.symbols.contains_key(symbol_name.as_str()),
            "Symbol '{}' should NOT be in scope at end of directive line {}. Content:\n{}",
            symbol_name, directive_line, content
        );

        // Test 3: Symbol SHOULD be in scope on the line after the directive
        let scope_after_directive = scope_at_position(&artifacts, directive_line + 1, 0, false);
        prop_assert!(
            scope_after_directive.symbols.contains_key(symbol_name.as_str()),
            "Symbol '{}' SHOULD be in scope on line {} (after directive on line {}). Content:\n{}",
            symbol_name, directive_line + 1, directive_line, content
        );

        // Test 4: Verify the symbol has the correct kind
        if let Some(symbol) = scope_after_directive.symbols.get(symbol_name.as_str()) {
            if is_function {
                prop_assert_eq!(
                    symbol.kind,
                    super::scope::SymbolKind::Function,
                    "Symbol '{}' should be a function",
                    symbol_name
                );
            } else {
                prop_assert_eq!(
                    symbol.kind,
                    super::scope::SymbolKind::Variable,
                    "Symbol '{}' should be a variable",
                    symbol_name
                );
            }
        }
    }

    /// Feature: lsp-declaration-directives, Property 4 extended: Multiple declarations at different lines
    ///
    /// For any file with multiple declaration directives at different lines, each symbol
    /// should become available exactly on the line after its declaration.
    ///
    /// **Validates: Requirements 4.1, 4.2, 4.3, 4.4, 4.5**
    #[test]
    fn prop_declaration_multiple_position_aware(
        symbols in proptest::collection::vec(
            (r_symbol_name(), 0..5u32, proptest::bool::ANY),
            1..4
        ),
    ) {
        use super::directive::parse_directives;
        use super::scope::{compute_artifacts_with_metadata, scope_at_position};
        use tree_sitter::Parser;
        use tower_lsp::lsp_types::Url;

        // Deduplicate symbols by name (keep first occurrence)
        let mut unique_symbols: std::collections::HashMap<String, (u32, bool)> = std::collections::HashMap::new();
        for (name, line, is_func) in &symbols {
            unique_symbols.entry(name.clone()).or_insert((*line, *is_func));
        }

        // Also deduplicate by line (only one declaration per line)
        let mut line_to_symbol: std::collections::HashMap<u32, (String, bool)> = std::collections::HashMap::new();
        for (name, (line, is_func)) in &unique_symbols {
            line_to_symbol.entry(*line).or_insert((name.clone(), *is_func));
        }

        let mut sorted_symbols: Vec<(String, u32, bool)> = line_to_symbol
            .into_iter()
            .map(|(line, (name, is_func))| (name, line, is_func))
            .collect();
        sorted_symbols.sort_by_key(|(_, line, _)| *line);

        // Build content with declarations at specified lines
        // Use prefix "placeholder_" for generated code to avoid conflicts with declared symbol names
        let max_line = sorted_symbols.iter().map(|(_, l, _)| *l).max().unwrap_or(0);
        let mut lines: Vec<String> = Vec::new();

        for line_num in 0..=max_line + 3 {
            // Check if there's a declaration for this line
            if let Some((name, _, is_func)) = sorted_symbols.iter().find(|(_, l, _)| *l == line_num) {
                let directive = if *is_func {
                    format!("# @lsp-func {}", name)
                } else {
                    format!("# @lsp-var {}", name)
                };
                lines.push(directive);
            } else {
                // Use "placeholder_" prefix to avoid conflicts with declared symbol names
                lines.push(format!("placeholder_{} <- {}", line_num, line_num));
            }
        }

        let content = lines.join("\n");
        let uri = Url::parse("file:///test.R").unwrap();

        // Parse the content
        let mut parser = Parser::new();
        parser.set_language(&tree_sitter_r::LANGUAGE.into()).unwrap();
        let tree = parser.parse(&content, None).unwrap();

        // Extract metadata and compute artifacts
        let metadata = parse_directives(&content);
        let artifacts = compute_artifacts_with_metadata(&uri, &tree, &content, Some(&metadata));

        // For each symbol, verify it's NOT available on its declaration line but IS available after
        for (name, decl_line, _is_func) in &sorted_symbols {
            // Should NOT be in scope on declaration line
            let scope_on_decl = scope_at_position(&artifacts, *decl_line, 0, false);
            prop_assert!(
                !scope_on_decl.symbols.contains_key(name.as_str()),
                "Symbol '{}' should NOT be in scope on its declaration line {}. Content:\n{}",
                name, decl_line, content
            );

            // Should be in scope on line after declaration
            let scope_after_decl = scope_at_position(&artifacts, decl_line + 1, 0, false);
            prop_assert!(
                scope_after_decl.symbols.contains_key(name.as_str()),
                "Symbol '{}' SHOULD be in scope on line {} (after declaration on line {}). Content:\n{}",
                name, decl_line + 1, decl_line, content
            );
        }
    }

    /// Feature: lsp-declaration-directives, Property 4 extended: Trailing-comment directive not recognized
    ///
    /// Declaration directives must be on their own comment line. When a directive appears
    /// as a trailing comment (e.g., `x <- 1 # @lsp-var foo`), it is NOT recognized and
    /// the symbol is not declared.
    ///
    /// **Validates: Start-of-line anchoring for declaration directives**
    #[test]
    fn prop_declaration_trailing_comment_not_recognized(
        symbol_name in r_symbol_name(),
        code_var_name in r_symbol_name(),
        directive_line in 0..5u32,
        is_function in proptest::bool::ANY,
    ) {
        use super::directive::parse_directives;
        use super::scope::{compute_artifacts_with_metadata, scope_at_position};
        use tree_sitter::Parser;
        use tower_lsp::lsp_types::Url;

        // Skip if the symbol name collides with filler variable names or the code variable
        prop_assume!(!filler_names(directive_line as usize, 3).contains(symbol_name.as_str()));
        prop_assume!(symbol_name != code_var_name);

        // Build content with code and directive on the same line (trailing comment)
        let mut lines: Vec<String> = (0..directive_line)
            .map(|i| format!("x{} <- {}", i, i))
            .collect();

        let directive = if is_function {
            format!("# @lsp-func {}", symbol_name)
        } else {
            format!("# @lsp-var {}", symbol_name)
        };
        // Code with trailing comment directive — NOT recognized
        lines.push(format!("{} <- 42 {}", code_var_name, directive));

        // Add some lines after
        for i in 0..3 {
            lines.push(format!("y{} <- {}", i, i + 100));
        }

        let content = lines.join("\n");
        let uri = Url::parse("file:///test.R").unwrap();

        // Parse the content
        let mut parser = Parser::new();
        parser.set_language(&tree_sitter_r::LANGUAGE.into()).unwrap();
        let tree = parser.parse(&content, None).unwrap();

        // Extract metadata and compute artifacts
        let metadata = parse_directives(&content);
        let artifacts = compute_artifacts_with_metadata(&uri, &tree, &content, Some(&metadata));

        // The declared symbol should NOT be in scope anywhere — directive was not recognized
        let scope_on_directive_line = scope_at_position(&artifacts, directive_line, 0, false);
        prop_assert!(
            !scope_on_directive_line.symbols.contains_key(symbol_name.as_str()),
            "Trailing-comment directive should not be recognized: '{}' should NOT be in scope on line {}. Content:\n{}",
            symbol_name, directive_line, content
        );

        let scope_after_directive = scope_at_position(&artifacts, directive_line + 1, 0, false);
        prop_assert!(
            !scope_after_directive.symbols.contains_key(symbol_name.as_str()),
            "Trailing-comment directive should not be recognized: '{}' should NOT be in scope on line {}. Content:\n{}",
            symbol_name, directive_line + 1, content
        );

        // The code variable (from the assignment) SHOULD still be in scope
        // Position past the assignment: `{code_var_name} <- 42 ...`
        let assignment_col = (code_var_name.len() + " <- 42".len()) as u32;
        let scope_after_assignment = scope_at_position(&artifacts, directive_line, assignment_col, false);
        prop_assert!(
            scope_after_assignment.symbols.contains_key(code_var_name.as_str()),
            "Code variable '{}' SHOULD be in scope on line {} after assignment. Content:\n{}",
            code_var_name, directive_line, content
        );
    }
}

// ============================================================================
// Property 8 (Declaration Directives): Interface Hash Sensitivity
// Feature: lsp-declaration-directives
// Validates: Requirements 10.1, 10.2, 10.3, 10.4
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Property 8: For any file, the interface hash SHALL change when a declaration
    /// directive is added.
    ///
    /// **Feature: lsp-declaration-directives, Property 8: Interface Hash Sensitivity**
    /// **Validates: Requirements 10.1**
    #[test]
    fn prop_interface_hash_changes_when_declaration_added(
        symbol_name in r_symbol_name(),
        directive_type in prop_oneof![
            Just("@lsp-var"),
            Just("@lsp-variable"),
            Just("@lsp-declare-var"),
            Just("@lsp-declare-variable"),
            Just("@lsp-func"),
            Just("@lsp-function"),
            Just("@lsp-declare-func"),
            Just("@lsp-declare-function"),
        ],
    ) {
        use super::directive::parse_directives;
        use super::scope::compute_artifacts_with_metadata;

        let uri = make_url("test");

        // Code without declaration directive
        let code_without = "x <- 42\ny <- 100";
        let tree_without = parse_r_tree(code_without);
        let metadata_without = parse_directives(code_without);
        let artifacts_without = compute_artifacts_with_metadata(&uri, &tree_without, code_without, Some(&metadata_without));

        // Code with declaration directive added
        let code_with = format!("# {} {}\nx <- 42\ny <- 100", directive_type, symbol_name);
        let tree_with = parse_r_tree(&code_with);
        let metadata_with = parse_directives(&code_with);
        let artifacts_with = compute_artifacts_with_metadata(&uri, &tree_with, &code_with, Some(&metadata_with));

        // Interface hash should change when declaration is added
        prop_assert_ne!(
            artifacts_without.interface_hash,
            artifacts_with.interface_hash,
            "Interface hash should change when declaration directive '{}' for '{}' is added",
            directive_type, symbol_name
        );
    }

    /// Property 8: For any file, the interface hash SHALL change when a declaration
    /// directive is removed.
    ///
    /// **Feature: lsp-declaration-directives, Property 8: Interface Hash Sensitivity**
    /// **Validates: Requirements 10.2**
    #[test]
    fn prop_interface_hash_changes_when_declaration_removed(
        symbol_name in r_symbol_name(),
        directive_type in prop_oneof![
            Just("@lsp-var"),
            Just("@lsp-func"),
        ],
    ) {
        use super::directive::parse_directives;
        use super::scope::compute_artifacts_with_metadata;

        let uri = make_url("test");

        // Code with declaration directive
        let code_with = format!("# {} {}\nx <- 42", directive_type, symbol_name);
        let tree_with = parse_r_tree(&code_with);
        let metadata_with = parse_directives(&code_with);
        let artifacts_with = compute_artifacts_with_metadata(&uri, &tree_with, &code_with, Some(&metadata_with));

        // Code without declaration directive (directive removed)
        let code_without = "# just a comment\nx <- 42";
        let tree_without = parse_r_tree(code_without);
        let metadata_without = parse_directives(code_without);
        let artifacts_without = compute_artifacts_with_metadata(&uri, &tree_without, code_without, Some(&metadata_without));

        // Interface hash should change when declaration is removed
        prop_assert_ne!(
            artifacts_with.interface_hash,
            artifacts_without.interface_hash,
            "Interface hash should change when declaration directive '{}' for '{}' is removed",
            directive_type, symbol_name
        );
    }

    /// Property 8: For any file, the interface hash SHALL change when a declared
    /// symbol's name changes.
    ///
    /// **Feature: lsp-declaration-directives, Property 8: Interface Hash Sensitivity**
    /// **Validates: Requirements 10.3**
    #[test]
    fn prop_interface_hash_changes_when_declaration_name_changes(
        symbol_name1 in r_symbol_name(),
        symbol_name2 in r_symbol_name(),
        directive_type in prop_oneof![
            Just("@lsp-var"),
            Just("@lsp-func"),
        ],
    ) {
        use super::directive::parse_directives;
        use super::scope::compute_artifacts_with_metadata;

        prop_assume!(symbol_name1 != symbol_name2);

        let uri = make_url("test");

        // Code with first symbol name
        let code1 = format!("# {} {}\nx <- 42", directive_type, symbol_name1);
        let tree1 = parse_r_tree(&code1);
        let metadata1 = parse_directives(&code1);
        let artifacts1 = compute_artifacts_with_metadata(&uri, &tree1, &code1, Some(&metadata1));

        // Code with second symbol name (name changed)
        let code2 = format!("# {} {}\nx <- 42", directive_type, symbol_name2);
        let tree2 = parse_r_tree(&code2);
        let metadata2 = parse_directives(&code2);
        let artifacts2 = compute_artifacts_with_metadata(&uri, &tree2, &code2, Some(&metadata2));

        // Interface hash should change when declaration name changes
        prop_assert_ne!(
            artifacts1.interface_hash,
            artifacts2.interface_hash,
            "Interface hash should change when declaration name changes from '{}' to '{}'",
            symbol_name1, symbol_name2
        );
    }

    /// Property 8: For any file, the interface hash SHALL remain stable when only
    /// non-declaration content changes (e.g., comments, local variable values).
    ///
    /// **Feature: lsp-declaration-directives, Property 8: Interface Hash Sensitivity**
    /// **Validates: Requirements 10.4**
    #[test]
    fn prop_interface_hash_stable_when_non_declaration_changes(
        symbol_name in r_symbol_name(),
        directive_type in prop_oneof![
            Just("@lsp-var"),
            Just("@lsp-func"),
        ],
        value1 in 1..100i32,
        value2 in 100..200i32,
        comment1 in "[a-zA-Z ]{1,20}",
        comment2 in "[a-zA-Z ]{1,20}",
    ) {
        use super::directive::parse_directives;
        use super::scope::compute_artifacts_with_metadata;

        prop_assume!(value1 != value2);
        prop_assume!(comment1 != comment2);

        let uri = make_url("test");

        // Code version 1
        let code1 = format!(
            "# {} {}\n# {}\nx <- {}",
            directive_type, symbol_name, comment1, value1
        );
        let tree1 = parse_r_tree(&code1);
        let metadata1 = parse_directives(&code1);
        let artifacts1 = compute_artifacts_with_metadata(&uri, &tree1, &code1, Some(&metadata1));

        // Code version 2 (different comment and value, same declaration)
        let code2 = format!(
            "# {} {}\n# {}\nx <- {}",
            directive_type, symbol_name, comment2, value2
        );
        let tree2 = parse_r_tree(&code2);
        let metadata2 = parse_directives(&code2);
        let artifacts2 = compute_artifacts_with_metadata(&uri, &tree2, &code2, Some(&metadata2));

        // Interface hash should remain the same (same exported symbols and declarations)
        prop_assert_eq!(
            artifacts1.interface_hash,
            artifacts2.interface_hash,
            "Interface hash should remain stable when only non-declaration content changes"
        );
    }

    /// Property 8 extended: Interface hash changes when declaration kind changes
    /// (same symbol declared as variable vs function).
    ///
    /// **Feature: lsp-declaration-directives, Property 8: Interface Hash Sensitivity**
    /// **Validates: Requirements 10.1, 10.2, 10.3**
    #[test]
    fn prop_interface_hash_changes_when_declaration_kind_changes(
        symbol_name in r_symbol_name(),
    ) {
        use super::directive::parse_directives;
        use super::scope::compute_artifacts_with_metadata;

        let uri = make_url("test");

        // Code with variable declaration
        let code_var = format!("# @lsp-var {}\nx <- 42", symbol_name);
        let tree_var = parse_r_tree(&code_var);
        let metadata_var = parse_directives(&code_var);
        let artifacts_var = compute_artifacts_with_metadata(&uri, &tree_var, &code_var, Some(&metadata_var));

        // Code with function declaration (same symbol name)
        let code_func = format!("# @lsp-func {}\nx <- 42", symbol_name);
        let tree_func = parse_r_tree(&code_func);
        let metadata_func = parse_directives(&code_func);
        let artifacts_func = compute_artifacts_with_metadata(&uri, &tree_func, &code_func, Some(&metadata_func));

        // Interface hash should change when declaration kind changes
        prop_assert_ne!(
            artifacts_var.interface_hash,
            artifacts_func.interface_hash,
            "Interface hash should change when declaration kind changes for symbol '{}'",
            symbol_name
        );
    }

    /// Property 8 extended: Interface hash changes when multiple declarations are
    /// added or removed.
    ///
    /// **Feature: lsp-declaration-directives, Property 8: Interface Hash Sensitivity**
    /// **Validates: Requirements 10.1, 10.2**
    #[test]
    fn prop_interface_hash_changes_with_multiple_declarations(
        symbol1 in r_symbol_name(),
        symbol2 in r_symbol_name(),
    ) {
        use super::directive::parse_directives;
        use super::scope::compute_artifacts_with_metadata;

        prop_assume!(symbol1 != symbol2);

        let uri = make_url("test");

        // Code with one declaration
        let code1 = format!("# @lsp-var {}\nx <- 42", symbol1);
        let tree1 = parse_r_tree(&code1);
        let metadata1 = parse_directives(&code1);
        let artifacts1 = compute_artifacts_with_metadata(&uri, &tree1, &code1, Some(&metadata1));

        // Code with two declarations
        let code2 = format!("# @lsp-var {}\n# @lsp-func {}\nx <- 42", symbol1, symbol2);
        let tree2 = parse_r_tree(&code2);
        let metadata2 = parse_directives(&code2);
        let artifacts2 = compute_artifacts_with_metadata(&uri, &tree2, &code2, Some(&metadata2));

        // Interface hash should change when declarations are added
        prop_assert_ne!(
            artifacts1.interface_hash,
            artifacts2.interface_hash,
            "Interface hash should change when additional declaration is added"
        );
    }
}

// ============================================================================
// Feature: lsp-declaration-directives, Property 7: Cross-File Declaration Inheritance
// Validates: Requirements 9.1, 9.2, 9.3, 9.4
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: lsp-declaration-directives, Property 7: Cross-File Declaration Inheritance
    ///
    /// For any parent file with a declaration directive and a source() call, the declared
    /// symbol SHALL be available in the sourced child file if and only if the declaration
    /// directive appears before the source() call in the parent file.
    ///
    /// **Validates: Requirements 9.1, 9.2, 9.3, 9.4**
    #[test]
    fn prop_cross_file_declaration_inheritance_before_source(
        symbol_name in r_symbol_name(),
        is_function in proptest::bool::ANY,
    ) {
        use super::directive::parse_directives;
        use super::scope::{compute_artifacts_with_metadata, scope_at_position_with_graph};
        use super::dependency::DependencyGraph;
        use super::types::ForwardSource;

        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: declaration at line 0, source() at line 1
        // Declaration is BEFORE source() call
        let directive = if is_function {
            format!("# @lsp-func {}", symbol_name)
        } else {
            format!("# @lsp-var {}", symbol_name)
        };
        let parent_code = format!("{}\nsource(\"child.R\")", directive);
        let parent_tree = parse_r_tree(&parent_code);
        let parent_metadata = parse_directives(&parent_code);
        let parent_artifacts = compute_artifacts_with_metadata(
            &parent_uri, &parent_tree, &parent_code, Some(&parent_metadata)
        );

        // Child code: simple assignment
        let child_code = "x <- 1";
        let child_tree = parse_r_tree(child_code);
        let child_artifacts = compute_artifacts_with_metadata(
            &child_uri, &child_tree, child_code, None
        );

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta_for_graph = CrossFileMetadata {
            sources: vec![ForwardSource {
                path: "child.R".to_string(),
                line: 1,
                column: 0,
                is_directive: false,
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            }],
            declared_variables: parent_metadata.declared_variables.clone(),
            declared_functions: parent_metadata.declared_functions.clone(),
            ..Default::default()
        };
        graph.update_file(&parent_uri, &parent_meta_for_graph, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<super::scope::ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta_for_graph.clone())) }
            else { None }
        };

        // Query child's scope at position (0, 0)
        let scope = scope_at_position_with_graph(
            &child_uri, 0, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Auto,
            &|| false,
            None,
            None,
        );

        // Child should have inherited the declared symbol from parent (Requirement 9.1)
        prop_assert!(
            scope.symbols.contains_key(symbol_name.as_str()),
            "Declared symbol '{}' should be available in child file when declaration is BEFORE source() call. Parent code:\n{}",
            symbol_name, parent_code
        );
    }

    /// Feature: lsp-declaration-directives, Property 7: Cross-File Declaration Inheritance
    ///
    /// When a parent file declares a symbol AFTER a source() call, the declared symbol
    /// SHALL NOT be available in the sourced child file.
    ///
    /// **Validates: Requirements 9.2**
    #[test]
    fn prop_cross_file_declaration_inheritance_after_source(
        symbol_name in r_symbol_name(),
        is_function in proptest::bool::ANY,
    ) {
        use super::directive::parse_directives;
        use super::scope::{compute_artifacts_with_metadata, scope_at_position_with_graph};
        use super::dependency::DependencyGraph;
        use super::types::ForwardSource;

        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: source() at line 0, declaration at line 1
        // Declaration is AFTER source() call
        let directive = if is_function {
            format!("# @lsp-func {}", symbol_name)
        } else {
            format!("# @lsp-var {}", symbol_name)
        };
        let parent_code = format!("source(\"child.R\")\n{}", directive);
        let parent_tree = parse_r_tree(&parent_code);
        let parent_metadata = parse_directives(&parent_code);
        let parent_artifacts = compute_artifacts_with_metadata(
            &parent_uri, &parent_tree, &parent_code, Some(&parent_metadata)
        );

        // Child code: simple assignment with a different variable name
        // Use a name that won't conflict with the generated symbol_name
        let child_code = "child_local_var <- 1";
        let child_tree = parse_r_tree(child_code);
        let child_artifacts = compute_artifacts_with_metadata(
            &child_uri, &child_tree, child_code, None
        );

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta_for_graph = CrossFileMetadata {
            sources: vec![ForwardSource {
                path: "child.R".to_string(),
                line: 0,  // source() is at line 0
                column: 0,
                is_directive: false,
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            }],
            declared_variables: parent_metadata.declared_variables.clone(),
            declared_functions: parent_metadata.declared_functions.clone(),
            ..Default::default()
        };
        graph.update_file(&parent_uri, &parent_meta_for_graph, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<super::scope::ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta_for_graph.clone())) }
            else { None }
        };

        // Query child's scope at position (0, 0)
        let scope = scope_at_position_with_graph(
            &child_uri, 0, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );

        // Child should NOT have the declared symbol (declaration is after source() call)
        prop_assert!(
            !scope.symbols.contains_key(symbol_name.as_str()),
            "Declared symbol '{}' should NOT be available in child file when declaration is AFTER source() call. Parent code:\n{}",
            symbol_name, parent_code
        );
    }

    /// Feature: lsp-declaration-directives, Property 7: Cross-File Declaration Inheritance
    ///
    /// Even in the FUNCTION-SCOPED `local=TRUE` case — where regular top-level
    /// symbols are NOT inherited by the child (the child binds to a function frame,
    /// not `.GlobalEnv`) — declared symbols (`# raven: var` / `# raven: func`) STILL
    /// flow to the child, because declarations describe symbol *existence*, not the
    /// runtime environment. This is the declared-only branch the issue #476 fix
    /// deliberately preserves; top-level `local=TRUE` (which now inherits regular
    /// symbols too) is covered by
    /// `prop_cross_file_declaration_vs_regular_symbol_with_top_level_local_true` and
    /// the unit test `test_cross_file_declared_symbols_inherited_with_local_true`.
    ///
    /// Like the function-scoped unit test, this is a **preservation guard** (it
    /// passes under the pre-#476 code too — declared symbols always flowed); the
    /// top-level tests named above are the ones that fail without the fix.
    #[test]
    fn prop_cross_file_declaration_inheritance_with_function_scoped_local_true(
        symbol_name in r_symbol_name(),
        is_function in proptest::bool::ANY,
    ) {
        use super::directive::parse_directives;
        use super::scope::{compute_artifacts_with_metadata, scope_at_position_with_graph};
        use super::dependency::DependencyGraph;
        use super::types::ForwardSource;

        // The parent template hardcodes a scaffolding function `f <- function()`
        // to site the function-scoped `local = TRUE` source. When the random
        // `symbol_name` is also "f", the directive (`# @lsp-var f` / `# @lsp-func
        // f`) collides with that real definition. Per
        // `fold_declarations_into_exported_interface`, a real definition is never
        // downgraded by a declaration, so the merged `f` symbol carries
        // `is_declared = false` and is (correctly) dropped by the declared-only
        // filter for function-scoped local=TRUE: `f` is no longer a *declared*
        // symbol but a real top-level definition, which this test does not probe.
        // Exclude the collision so the test exercises its intended scenario — an
        // independent *declared* symbol flowing to the child. (The sibling test
        // `prop_cross_file_declaration_vs_regular_symbol_with_top_level_local_true`
        // sidesteps the same scaffolding collision differently: it names its
        // scaffolding `__child_local__`, which `r_symbol_name()` never generates,
        // rather than excluding a drawn value.)
        prop_assume!(symbol_name != "f");

        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: declaration at line 0, function-scoped source(local=TRUE).
        let directive = if is_function {
            format!("# @lsp-func {}", symbol_name)
        } else {
            format!("# @lsp-var {}", symbol_name)
        };
        let parent_code =
            format!("{}\nf <- function() {{\n  source(\"child.R\", local = TRUE)\n}}", directive);
        let parent_tree = parse_r_tree(&parent_code);
        let parent_metadata = parse_directives(&parent_code);
        let parent_artifacts = compute_artifacts_with_metadata(
            &parent_uri, &parent_tree, &parent_code, Some(&parent_metadata)
        );

        // Child code: simple assignment
        let child_code = "x <- 1";
        let child_tree = parse_r_tree(child_code);
        let child_artifacts = compute_artifacts_with_metadata(
            &child_uri, &child_tree, child_code, None
        );

        // Build dependency graph with local=TRUE
        let mut graph = DependencyGraph::new();
        let parent_meta_for_graph = CrossFileMetadata {
            sources: vec![ForwardSource {
                path: "child.R".to_string(),
                line: 2, // inside f()'s body
                column: 2,
                is_directive: false,
                locality: SourceLocality::CurrentFrame, //local=TRUE
                is_function_scoped: true, // inside a function → declared-only policy
                ..Default::default()
            }],
            declared_variables: parent_metadata.declared_variables.clone(),
            declared_functions: parent_metadata.declared_functions.clone(),
            ..Default::default()
        };
        graph.update_file(&parent_uri, &parent_meta_for_graph, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<super::scope::ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta_for_graph.clone())) }
            else { None }
        };

        // Query child's scope at position (0, 0)
        let scope = scope_at_position_with_graph(
            &child_uri, 0, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Auto,
            &|| false,
            None,
            None,
        );

        // The declared symbol flows to the child even though the source is
        // function-scoped local=TRUE (declared symbols describe existence, so they
        // are inherited regardless of the runtime environment).
        prop_assert!(
            scope.symbols.contains_key(symbol_name.as_str()),
            "Declared symbol '{}' should be available in the child file even with a \
             function-scoped local=TRUE source. Parent code:\n{}",
            symbol_name, parent_code
        );
    }

    /// Feature: lsp-declaration-directives, Property 7: Cross-File Declaration Inheritance
    ///
    /// When a TOP-LEVEL source() call uses `local=TRUE`, the child evaluates in the
    /// caller's environment, which at top level is `.GlobalEnv` (R `?source`). So
    /// BOTH declared and regular symbols from the parent are visible in the child —
    /// identical to local=FALSE. (Only a `local=TRUE` call inside a function binds
    /// the child to a non-global frame; that case keeps declared-only.)
    ///
    /// **Validates: issue #476 (corrects the former declared-only Requirement 9.4)**
    #[test]
    fn prop_cross_file_declaration_vs_regular_symbol_with_top_level_local_true(
        declared_symbol in r_symbol_name(),
        regular_symbol in r_symbol_name(),
        is_function in proptest::bool::ANY,
    ) {
        use super::directive::parse_directives;
        use super::scope::{compute_artifacts_with_metadata, scope_at_position_with_graph};
        use super::dependency::DependencyGraph;
        use super::types::ForwardSource;

        // Ensure symbols are distinct
        prop_assume!(declared_symbol != regular_symbol);

        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: declaration at line 0, regular definition at line 1, source() with local=TRUE at line 2
        let directive = if is_function {
            format!("# @lsp-func {}", declared_symbol)
        } else {
            format!("# @lsp-var {}", declared_symbol)
        };
        let parent_code = format!("{}\n{} <- 42\nsource(\"child.R\", local = TRUE)", directive, regular_symbol);
        let parent_tree = parse_r_tree(&parent_code);
        let parent_metadata = parse_directives(&parent_code);
        let parent_artifacts = compute_artifacts_with_metadata(
            &parent_uri, &parent_tree, &parent_code, Some(&parent_metadata)
        );

        // Child code: simple assignment with a name that won't collide with generated symbols
        // Using a name with double underscore prefix which is not generated by r_symbol_name()
        let child_code = "__child_local__ <- 1";
        let child_tree = parse_r_tree(child_code);
        let child_artifacts = compute_artifacts_with_metadata(
            &child_uri, &child_tree, child_code, None
        );

        // Build dependency graph with local=TRUE
        let mut graph = DependencyGraph::new();
        let parent_meta_for_graph = CrossFileMetadata {
            sources: vec![ForwardSource {
                path: "child.R".to_string(),
                line: 2,
                column: 0,
                is_directive: false,
                locality: SourceLocality::CurrentFrame, //local=TRUE
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            }],
            declared_variables: parent_metadata.declared_variables.clone(),
            declared_functions: parent_metadata.declared_functions.clone(),
            ..Default::default()
        };
        graph.update_file(&parent_uri, &parent_meta_for_graph, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<super::scope::ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta_for_graph.clone())) }
            else { None }
        };

        // Query child's scope at position (0, 0)
        let scope = scope_at_position_with_graph(
            &child_uri, 0, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Auto,
            &|| false,
            None,
            None,
        );

        // Declared symbol should be available
        prop_assert!(
            scope.symbols.contains_key(declared_symbol.as_str()),
            "Declared symbol '{}' should be available in child file with local=TRUE. Parent code:\n{}",
            declared_symbol, parent_code
        );

        // Regular symbol SHOULD be available: a top-level local=TRUE evaluates in
        // .GlobalEnv, so the parent's prior regular bindings are visible (issue #476)
        prop_assert!(
            scope.symbols.contains_key(regular_symbol.as_str()),
            "Regular symbol '{}' SHOULD be available in child file with a top-level local=TRUE (issue #476). Parent code:\n{}",
            regular_symbol, parent_code
        );
    }

    /// Feature: lsp-declaration-directives, Property 7: Cross-File Declaration Inheritance
    ///
    /// When traversing the dependency chain (grandparent -> parent -> child), declared
    /// symbols SHALL follow the same inheritance rules as regular symbols.
    ///
    /// **Validates: Requirements 9.3**
    #[test]
    fn prop_cross_file_declaration_inheritance_transitive(
        symbol_name in r_symbol_name(),
        is_function in proptest::bool::ANY,
    ) {
        use super::directive::parse_directives;
        use super::scope::{compute_artifacts_with_metadata, scope_at_position_with_graph};
        use super::dependency::DependencyGraph;
        use super::types::ForwardSource;

        let grandparent_uri = make_url("grandparent");
        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Grandparent code: declaration at line 0, source() at line 1
        let directive = if is_function {
            format!("# @lsp-func {}", symbol_name)
        } else {
            format!("# @lsp-var {}", symbol_name)
        };
        let grandparent_code = format!("{}\nsource(\"parent.R\")", directive);
        let grandparent_tree = parse_r_tree(&grandparent_code);
        let grandparent_metadata = parse_directives(&grandparent_code);
        let grandparent_artifacts = compute_artifacts_with_metadata(
            &grandparent_uri, &grandparent_tree, &grandparent_code, Some(&grandparent_metadata)
        );

        // Parent code: source() at line 0
        let parent_code = "source(\"child.R\")";
        let parent_tree = parse_r_tree(parent_code);
        let parent_artifacts = compute_artifacts_with_metadata(
            &parent_uri, &parent_tree, parent_code, None
        );

        // Child code: simple assignment
        let child_code = "x <- 1";
        let child_tree = parse_r_tree(child_code);
        let child_artifacts = compute_artifacts_with_metadata(
            &child_uri, &child_tree, child_code, None
        );

        // Build dependency graph
        let mut graph = DependencyGraph::new();

        // Grandparent -> Parent edge
        let grandparent_meta_for_graph = CrossFileMetadata {
            sources: vec![ForwardSource {
                path: "parent.R".to_string(),
                line: 1,
                column: 0,
                is_directive: false,
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            }],
            declared_variables: grandparent_metadata.declared_variables.clone(),
            declared_functions: grandparent_metadata.declared_functions.clone(),
            ..Default::default()
        };
        graph.update_file(&grandparent_uri, &grandparent_meta_for_graph, Some(&workspace_root), |_| None);

        // Parent -> Child edge
        let parent_meta_for_graph = CrossFileMetadata {
            sources: vec![ForwardSource {
                path: "child.R".to_string(),
                line: 0,
                column: 0,
                is_directive: false,
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            }],
            ..Default::default()
        };
        graph.update_file(&parent_uri, &parent_meta_for_graph, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let grandparent_artifacts = Arc::new(grandparent_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<super::scope::ScopeArtifacts>> {
            if uri == &grandparent_uri { Some(Arc::clone(&grandparent_artifacts)) }
            else if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &grandparent_uri { Some(std::sync::Arc::new(grandparent_meta_for_graph.clone())) }
            else if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta_for_graph.clone())) }
            else { None }
        };

        // Query child's scope at position (0, 0)
        let scope = scope_at_position_with_graph(
            &child_uri, 0, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Auto,
            &|| false,
            None,
            None,
        );

        // Child should have inherited the declared symbol from grandparent through parent (Requirement 9.3)
        prop_assert!(
            scope.symbols.contains_key(symbol_name.as_str()),
            "Declared symbol '{}' should be available in child file through transitive inheritance (Requirement 9.3). Grandparent code:\n{}",
            symbol_name, grandparent_code
        );
    }

    /// Feature: lsp-declaration-directives, Property 7: Cross-File Declaration Inheritance
    ///
    /// Multiple declarations in parent file should all be inherited by child file
    /// when they appear before the source() call.
    ///
    /// **Validates: Requirements 9.1, 9.3**
    #[test]
    fn prop_cross_file_declaration_inheritance_multiple_symbols(
        symbol1 in r_symbol_name(),
        symbol2 in r_symbol_name(),
    ) {
        use super::directive::parse_directives;
        use super::scope::{compute_artifacts_with_metadata, scope_at_position_with_graph};
        use super::dependency::DependencyGraph;
        use super::types::ForwardSource;

        // Ensure symbols are distinct
        prop_assume!(symbol1 != symbol2);

        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: two declarations at lines 0 and 1, source() at line 2
        let parent_code = format!("# @lsp-var {}\n# @lsp-func {}\nsource(\"child.R\")", symbol1, symbol2);
        let parent_tree = parse_r_tree(&parent_code);
        let parent_metadata = parse_directives(&parent_code);
        let parent_artifacts = compute_artifacts_with_metadata(
            &parent_uri, &parent_tree, &parent_code, Some(&parent_metadata)
        );

        // Child code: simple assignment
        let child_code = "x <- 1";
        let child_tree = parse_r_tree(child_code);
        let child_artifacts = compute_artifacts_with_metadata(
            &child_uri, &child_tree, child_code, None
        );

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta_for_graph = CrossFileMetadata {
            sources: vec![ForwardSource {
                path: "child.R".to_string(),
                line: 2,
                column: 0,
                is_directive: false,
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            }],
            declared_variables: parent_metadata.declared_variables.clone(),
            declared_functions: parent_metadata.declared_functions.clone(),
            ..Default::default()
        };
        graph.update_file(&parent_uri, &parent_meta_for_graph, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<super::scope::ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta_for_graph.clone())) }
            else { None }
        };

        // Query child's scope at position (0, 0)
        let scope = scope_at_position_with_graph(
            &child_uri, 0, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Auto,
            &|| false,
            None,
            None,
        );

        // Both declared symbols should be available in child file
        prop_assert!(
            scope.symbols.contains_key(symbol1.as_str()),
            "Declared variable '{}' should be available in child file. Parent code:\n{}",
            symbol1, parent_code
        );
        prop_assert!(
            scope.symbols.contains_key(symbol2.as_str()),
            "Declared function '{}' should be available in child file. Parent code:\n{}",
            symbol2, parent_code
        );
    }

    /// Feature: lsp-declaration-directives, Property 7: Cross-File Declaration Inheritance
    ///
    /// When some declarations are before and some are after the source() call,
    /// only the declarations before should be inherited.
    ///
    /// **Validates: Requirements 9.1, 9.2**
    #[test]
    fn prop_cross_file_declaration_inheritance_mixed_positions(
        symbol_before in r_symbol_name(),
        symbol_after in r_symbol_name(),
    ) {
        use super::directive::parse_directives;
        use super::scope::{compute_artifacts_with_metadata, scope_at_position_with_graph};
        use super::dependency::DependencyGraph;
        use super::types::ForwardSource;

        // Ensure symbols are distinct
        prop_assume!(symbol_before != symbol_after);

        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent code: declaration at line 0, source() at line 1, declaration at line 2
        let parent_code = format!(
            "# @lsp-var {}\nsource(\"child.R\")\n# @lsp-func {}",
            symbol_before, symbol_after
        );
        let parent_tree = parse_r_tree(&parent_code);
        let parent_metadata = parse_directives(&parent_code);
        let parent_artifacts = compute_artifacts_with_metadata(
            &parent_uri, &parent_tree, &parent_code, Some(&parent_metadata)
        );

        // Child code: simple assignment with a name that won't collide with generated symbols
        // Using a name with double underscore prefix which is not generated by r_symbol_name()
        let child_code = "__child_local__ <- 1";
        let child_tree = parse_r_tree(child_code);
        let child_artifacts = compute_artifacts_with_metadata(
            &child_uri, &child_tree, child_code, None
        );

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta_for_graph = CrossFileMetadata {
            sources: vec![ForwardSource {
                path: "child.R".to_string(),
                line: 1,  // source() is at line 1
                column: 0,
                is_directive: false,
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            }],
            declared_variables: parent_metadata.declared_variables.clone(),
            declared_functions: parent_metadata.declared_functions.clone(),
            ..Default::default()
        };
        graph.update_file(&parent_uri, &parent_meta_for_graph, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<super::scope::ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta_for_graph.clone())) }
            else { None }
        };

        // Query child's scope at position (0, 0)
        let scope = scope_at_position_with_graph(
            &child_uri, 0, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Auto,
            &|| false,
            None,
            None,
        );

        // Symbol declared BEFORE source() should be available (Requirement 9.1)
        prop_assert!(
            scope.symbols.contains_key(symbol_before.as_str()),
            "Declared symbol '{}' (before source()) should be available in child file. Parent code:\n{}",
            symbol_before, parent_code
        );

        // Symbol declared AFTER source() should NOT be available (Requirement 9.2)
        prop_assert!(
            !scope.symbols.contains_key(symbol_after.as_str()),
            "Declared symbol '{}' (after source()) should NOT be available in child file. Parent code:\n{}",
            symbol_after, parent_code
        );
    }
}

// ============================================================================
// Feature: lsp-declaration-directives, Property 9: Conflicting Declaration Resolution
// Validates: Requirements 11.1, 11.2, 11.3, 11.4
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: lsp-declaration-directives, Property 9: Conflicting Declaration Resolution
    ///
    /// For any file where the same symbol name is declared as both a variable and a function,
    /// the later declaration (by line number) SHALL determine the symbol kind for completions
    /// and hover.
    ///
    /// **Validates: Requirements 11.1, 11.4**
    #[test]
    fn prop_conflicting_declaration_later_wins_for_kind(
        symbol_name in r_symbol_name(),
        var_first in proptest::bool::ANY,
    ) {
        use super::directive::parse_directives;
        use super::scope::{compute_artifacts_with_metadata, scope_at_position, SymbolKind};

        let uri = make_url("test");

        // Generate code with conflicting declarations
        // If var_first is true: variable on line 0, function on line 1 -> function wins
        // If var_first is false: function on line 0, variable on line 1 -> variable wins
        let (first_directive, second_directive, expected_kind) = if var_first {
            ("@lsp-var", "@lsp-func", SymbolKind::Function)
        } else {
            ("@lsp-func", "@lsp-var", SymbolKind::Variable)
        };

        // Use a different variable name for the assignment to avoid overwriting the declared symbol
        let code = format!(
            "# {} {}\n# {} {}\nother_var <- 42",
            first_directive, symbol_name, second_directive, symbol_name
        );
        let tree = parse_r_tree(&code);
        let metadata = parse_directives(&code);
        let artifacts = compute_artifacts_with_metadata(&uri, &tree, &code, Some(&metadata));

        // Check exported interface - later declaration should win
        let exported_symbol = artifacts.exported_interface.get(symbol_name.as_str());
        prop_assert!(
            exported_symbol.is_some(),
            "Symbol '{}' should be in exported interface. Code:\n{}",
            symbol_name, code
        );
        prop_assert_eq!(
            exported_symbol.unwrap().kind,
            expected_kind,
            "Later declaration should determine symbol kind. First: {}, Second: {}, Expected: {:?}. Code:\n{}",
            first_directive, second_directive, expected_kind, code
        );

        // Check scope at position after both declarations (line 2)
        let scope = scope_at_position(&artifacts, 2, 0, false);
        let scoped_symbol = scope.symbols.get(symbol_name.as_str());
        prop_assert!(
            scoped_symbol.is_some(),
            "Symbol '{}' should be in scope at line 2. Code:\n{}",
            symbol_name, code
        );
        prop_assert_eq!(
            scoped_symbol.unwrap().kind,
            expected_kind,
            "Scope symbol kind should reflect later declaration. Code:\n{}",
            code
        );
    }

    /// Feature: lsp-declaration-directives, Property 9: Conflicting Declaration Resolution
    ///
    /// For any file where the same symbol name is declared as both a variable and a function,
    /// diagnostic suppression SHALL apply regardless of which declaration comes first.
    ///
    /// **Validates: Requirements 11.2**
    #[test]
    fn prop_conflicting_declaration_diagnostic_suppression(
        symbol_name in r_symbol_name(),
        var_first in proptest::bool::ANY,
        usage_line_offset in 0..5u32,
    ) {
        use super::directive::parse_directives;
        use super::scope::{compute_artifacts_with_metadata, scope_at_position};

        let uri = make_url("test");

        // Generate code with conflicting declarations and a usage after both
        let (first_directive, second_directive) = if var_first {
            ("@lsp-var", "@lsp-func")
        } else {
            ("@lsp-func", "@lsp-var")
        };

        // Build code: two declarations, then some filler lines, then usage
        let mut lines = vec![
            format!("# {} {}", first_directive, symbol_name),
            format!("# {} {}", second_directive, symbol_name),
        ];

        // Add filler lines
        for i in 0..usage_line_offset {
            lines.push(format!("filler{} <- {}", i, i));
        }

        // Add usage line
        lines.push(symbol_name.clone());

        let code = lines.join("\n");
        let tree = parse_r_tree(&code);
        let metadata = parse_directives(&code);
        let artifacts = compute_artifacts_with_metadata(&uri, &tree, &code, Some(&metadata));

        // Query scope at the usage line (line 2 + usage_line_offset)
        let usage_line = 2 + usage_line_offset;
        let scope = scope_at_position(&artifacts, usage_line, 0, false);

        // Symbol should be in scope regardless of declaration order (Requirement 11.2)
        prop_assert!(
            scope.symbols.contains_key(symbol_name.as_str()),
            "Symbol '{}' should be in scope at usage line {} (after conflicting declarations). \
             First: {}, Second: {}. Code:\n{}",
            symbol_name, usage_line, first_directive, second_directive, code
        );
    }

    /// Feature: lsp-declaration-directives, Property 9: Conflicting Declaration Resolution
    ///
    /// For any file where the same symbol name is declared as both a variable and a function,
    /// go-to-definition SHALL navigate to the first declaration by line number.
    ///
    /// **Validates: Requirements 11.3**
    #[test]
    fn prop_conflicting_declaration_first_for_definition(
        symbol_name in r_symbol_name(),
        var_first in proptest::bool::ANY,
        prefix_lines in 0..5u32,
    ) {
        use super::directive::parse_directives;
        use super::scope::{compute_artifacts_with_metadata, scope_at_position};

        let uri = make_url("test");

        // Generate code with prefix lines, then conflicting declarations
        let (first_directive, second_directive) = if var_first {
            ("@lsp-var", "@lsp-func")
        } else {
            ("@lsp-func", "@lsp-var")
        };

        let mut lines: Vec<String> = (0..prefix_lines)
            .map(|i| format!("prefix{} <- {}", i, i))
            .collect();

        let first_decl_line = prefix_lines;
        let second_decl_line = prefix_lines + 1;

        lines.push(format!("# {} {}", first_directive, symbol_name));
        lines.push(format!("# {} {}", second_directive, symbol_name));
        lines.push("x <- 42".to_string());

        let code = lines.join("\n");
        let tree = parse_r_tree(&code);
        let metadata = parse_directives(&code);
        let artifacts = compute_artifacts_with_metadata(&uri, &tree, &code, Some(&metadata));

        // Query scope at line after both declarations
        let query_line = second_decl_line + 1;
        let scope = scope_at_position(&artifacts, query_line, 0, false);

        let scoped_symbol = scope.symbols.get(symbol_name.as_str());
        prop_assert!(
            scoped_symbol.is_some(),
            "Symbol '{}' should be in scope at line {}. Code:\n{}",
            symbol_name, query_line, code
        );

        // The symbol's defined_line should be the FIRST declaration line (Requirement 11.3)
        // Note: The scope resolution uses the later declaration's kind but the first declaration's line
        // for go-to-definition purposes. However, the ScopedSymbol in scope stores the line from
        // the declaration that determined the kind (the later one).
        //
        // The actual go-to-definition behavior (navigating to first declaration) is implemented
        // in handlers.rs by scanning metadata for all declarations and finding the minimum line.
        // Here we verify that both declarations are present in metadata.
        prop_assert!(
            !metadata.declared_variables.is_empty() || !metadata.declared_functions.is_empty(),
            "Metadata should contain declarations. Code:\n{}",
            code
        );

        // Verify both declarations are recorded in metadata
        let all_decl_lines: Vec<u32> = metadata.declared_variables.iter()
            .filter(|d| d.name == symbol_name)
            .map(|d| d.line)
            .chain(
                metadata.declared_functions.iter()
                    .filter(|d| d.name == symbol_name)
                    .map(|d| d.line)
            )
            .collect();

        prop_assert_eq!(
            all_decl_lines.len(),
            2,
            "Should have exactly 2 declarations for symbol '{}'. Found lines: {:?}. Code:\n{}",
            symbol_name, all_decl_lines, code
        );

        // Verify the first declaration line is recorded
        let min_line = all_decl_lines.iter().min().copied();
        prop_assert_eq!(
            min_line,
            Some(first_decl_line),
            "First declaration should be at line {}. Found: {:?}. Code:\n{}",
            first_decl_line, min_line, code
        );
    }

    /// Feature: lsp-declaration-directives, Property 9: Conflicting Declaration Resolution
    ///
    /// Extended test: When declarations are on non-consecutive lines, the later declaration
    /// (by line number) still determines the symbol kind.
    ///
    /// **Validates: Requirements 11.1, 11.4**
    #[test]
    fn prop_conflicting_declaration_non_consecutive_lines(
        symbol_name in r_symbol_name(),
        var_first in proptest::bool::ANY,
        gap_lines in 1..5u32,
    ) {
        use super::directive::parse_directives;
        use super::scope::{compute_artifacts_with_metadata, scope_at_position, SymbolKind};

        let uri = make_url("test");

        let (first_directive, second_directive, expected_kind) = if var_first {
            ("@lsp-var", "@lsp-func", SymbolKind::Function)
        } else {
            ("@lsp-func", "@lsp-var", SymbolKind::Variable)
        };

        // Build code with gap between declarations
        let mut lines = vec![format!("# {} {}", first_directive, symbol_name)];

        // Add gap lines
        for i in 0..gap_lines {
            lines.push(format!("gap{} <- {}", i, i));
        }

        lines.push(format!("# {} {}", second_directive, symbol_name));
        // Use a different variable name to avoid overwriting the declared symbol
        lines.push("other_var <- 42".to_string());

        let code = lines.join("\n");
        let tree = parse_r_tree(&code);
        let metadata = parse_directives(&code);
        let artifacts = compute_artifacts_with_metadata(&uri, &tree, &code, Some(&metadata));

        // Query scope at end of file
        let query_line = (lines.len() - 1) as u32;
        let scope = scope_at_position(&artifacts, query_line, 0, false);

        let scoped_symbol = scope.symbols.get(symbol_name.as_str());
        prop_assert!(
            scoped_symbol.is_some(),
            "Symbol '{}' should be in scope. Code:\n{}",
            symbol_name, code
        );
        prop_assert_eq!(
            scoped_symbol.unwrap().kind,
            expected_kind,
            "Later declaration should determine symbol kind even with {} gap lines. Code:\n{}",
            gap_lines, code
        );
    }

    /// Feature: lsp-declaration-directives, Property 9: Conflicting Declaration Resolution
    ///
    /// Extended test: Multiple conflicting declarations (more than 2) - the last one wins.
    ///
    /// **Validates: Requirements 11.1, 11.4**
    #[test]
    fn prop_conflicting_declaration_multiple_declarations(
        symbol_name in r_symbol_name(),
        declaration_count in 2..5usize,
    ) {
        use super::directive::parse_directives;
        use super::scope::{compute_artifacts_with_metadata, scope_at_position, SymbolKind};

        let uri = make_url("test");

        // Generate alternating var/func declarations
        let mut lines = Vec::new();
        let mut last_is_function = false;

        for i in 0..declaration_count {
            let is_function = i % 2 == 1;
            let directive = if is_function { "@lsp-func" } else { "@lsp-var" };
            lines.push(format!("# {} {}", directive, symbol_name));
            last_is_function = is_function;
        }

        // Use a dummy variable name that cannot collide with the declared symbol_name.
        // If symbol_name happens to be "x", a plain `x <- 42` would create a real
        // definition that overrides the declared kind (real definitions take precedence
        // over declarations). Using a guaranteed-unique name avoids this.
        let dummy_var = if symbol_name == "dummy_var_placeholder" {
            "dummy_var_placeholder2".to_string()
        } else {
            "dummy_var_placeholder".to_string()
        };
        lines.push(format!("{} <- 42", dummy_var));

        let code = lines.join("\n");
        let tree = parse_r_tree(&code);
        let metadata = parse_directives(&code);
        let artifacts = compute_artifacts_with_metadata(&uri, &tree, &code, Some(&metadata));

        // Expected kind is determined by the last declaration
        let expected_kind = if last_is_function {
            SymbolKind::Function
        } else {
            SymbolKind::Variable
        };

        // Query scope at end of file
        let query_line = (lines.len() - 1) as u32;
        let scope = scope_at_position(&artifacts, query_line, 0, false);

        let scoped_symbol = scope.symbols.get(symbol_name.as_str());
        prop_assert!(
            scoped_symbol.is_some(),
            "Symbol '{}' should be in scope. Code:\n{}",
            symbol_name, code
        );
        prop_assert_eq!(
            scoped_symbol.unwrap().kind,
            expected_kind,
            "Last declaration (count={}) should determine symbol kind. Expected {:?}. Code:\n{}",
            declaration_count, expected_kind, code
        );
    }

    /// Feature: lsp-declaration-directives, Property 9: Conflicting Declaration Resolution
    ///
    /// Extended test: Conflicting declarations with different syntax variants (colon, quotes)
    /// should still follow the "later wins" rule.
    ///
    /// **Validates: Requirements 11.1, 11.4**
    #[test]
    fn prop_conflicting_declaration_syntax_variants(
        symbol_name in r_symbol_name(),
        var_first in proptest::bool::ANY,
        first_use_colon in proptest::bool::ANY,
        second_use_colon in proptest::bool::ANY,
        first_quote_style in 0..3usize,
        second_quote_style in 0..3usize,
    ) {
        use super::directive::parse_directives;
        use super::scope::{compute_artifacts_with_metadata, scope_at_position, SymbolKind};

        let uri = make_url("test");

        let (first_directive, second_directive, expected_kind) = if var_first {
            ("@lsp-var", "@lsp-func", SymbolKind::Function)
        } else {
            ("@lsp-func", "@lsp-var", SymbolKind::Variable)
        };

        // Build directive strings with syntax variants
        let format_directive = |directive: &str, use_colon: bool, quote_style: usize, name: &str| -> String {
            let colon = if use_colon { ":" } else { "" };
            let quoted_name = match quote_style {
                1 => format!("\"{}\"", name),
                2 => format!("'{}'", name),
                _ => name.to_string(),
            };
            format!("# {}{} {}", directive, colon, quoted_name)
        };

        let first_line = format_directive(first_directive, first_use_colon, first_quote_style, &symbol_name);
        let second_line = format_directive(second_directive, second_use_colon, second_quote_style, &symbol_name);

        // Use a different variable name to avoid overwriting the declared symbol
        let code = format!("{}\n{}\nother_var <- 42", first_line, second_line);
        let tree = parse_r_tree(&code);
        let metadata = parse_directives(&code);
        let artifacts = compute_artifacts_with_metadata(&uri, &tree, &code, Some(&metadata));

        // Query scope at line 2
        let scope = scope_at_position(&artifacts, 2, 0, false);

        let scoped_symbol = scope.symbols.get(symbol_name.as_str());
        prop_assert!(
            scoped_symbol.is_some(),
            "Symbol '{}' should be in scope with syntax variants. Code:\n{}",
            symbol_name, code
        );
        prop_assert_eq!(
            scoped_symbol.unwrap().kind,
            expected_kind,
            "Later declaration should win regardless of syntax variants. Code:\n{}",
            code
        );
    }
}

// ============================================================================
// Feature: lsp-declaration-directives, Property 10: Workspace Index Declaration Extraction
// Validates: Requirements 12.1, 12.2, 12.3
// ============================================================================

proptest! {
    #![proptest_config(ProptestConfig::with_cases(100))]

    /// Feature: lsp-declaration-directives, Property 10: Workspace Index Declaration Extraction
    ///
    /// For any file indexed by the workspace indexer, declared symbols SHALL be extracted
    /// and stored such that when the file participates in a dependency chain, its declared
    /// symbols are available during scope resolution.
    ///
    /// This test verifies Requirement 12.1: When a closed file is indexed by the workspace
    /// indexer, the declared symbols SHALL be extracted and stored.
    ///
    /// **Validates: Requirements 12.1**
    #[test]
    fn prop_workspace_index_extracts_declared_symbols(
        symbol_name in r_symbol_name(),
        is_function in proptest::bool::ANY,
        prefix_lines in 0..5usize,
    ) {
        use super::directive::parse_directives;
        use super::scope::{compute_artifacts_with_metadata, ScopeEvent, SymbolKind};

        let uri = make_url("indexed_file");

        // Build file content with declaration directive
        let directive = if is_function {
            format!("# @lsp-func {}", symbol_name)
        } else {
            format!("# @lsp-var {}", symbol_name)
        };

        let mut lines: Vec<String> = (0..prefix_lines)
            .map(|i| format!("x{} <- {}", i, i))
            .collect();
        lines.push(directive);
        lines.push("y <- 42".to_string());

        let code = lines.join("\n");
        let tree = parse_r_tree(&code);
        let metadata = parse_directives(&code);

        // Simulate workspace indexer behavior: compute artifacts with metadata
        // This is what the on-demand indexing path does when indexing a closed file
        let artifacts = compute_artifacts_with_metadata(&uri, &tree, &code, Some(&metadata));

        // Skip cases where the generated symbol name conflicts with real definitions
        // in the test code ("y <- 42" or prefix vars "x0 <- 0", etc.). When a symbol
        // has both a real definition and a declaration directive, the real definition
        // correctly takes precedence (is_declared == false).
        let prefix_names: Vec<String> = (0..prefix_lines)
            .map(|i| format!("x{}", i))
            .collect();
        prop_assume!(
            symbol_name != "y" && !prefix_names.contains(&symbol_name),
            "Symbol name conflicts with a real definition in the test code"
        );

        // Requirement 12.1: Declared symbols should be extracted and stored
        // Check that the declared symbol is in the exported interface
        prop_assert!(
            artifacts.exported_interface.contains_key(symbol_name.as_str()),
            "Declared symbol '{}' should be in exported interface after indexing. Code:\n{}",
            symbol_name, code
        );

        let symbol = artifacts.exported_interface.get(symbol_name.as_str()).unwrap();
        prop_assert!(
            symbol.is_declared,
            "Symbol '{}' should be marked as declared. Code:\n{}",
            symbol_name, code
        );

        let expected_kind = if is_function {
            SymbolKind::Function
        } else {
            SymbolKind::Variable
        };
        prop_assert_eq!(
            symbol.kind, expected_kind,
            "Symbol '{}' should have correct kind. Code:\n{}",
            symbol_name, code
        );

        // Check that the timeline contains a Declaration event
        let declaration_events: Vec<_> = artifacts.timeline.iter()
            .filter(|e| matches!(e, ScopeEvent::Declaration { symbol, .. } if *symbol.name == *symbol_name))
            .collect();
        prop_assert_eq!(
            declaration_events.len(), 1,
            "Timeline should contain exactly one Declaration event for '{}'. Code:\n{}",
            symbol_name, code
        );
    }

    /// Feature: lsp-declaration-directives, Property 10: Workspace Index Declaration Extraction
    ///
    /// For any dependency chain that includes an indexed (closed) file with declarations,
    /// the declared symbols SHALL be available in scope resolution.
    ///
    /// This test verifies Requirement 12.2: When a dependency chain includes an indexed
    /// (closed) file with declarations, the declared symbols SHALL be available in scope
    /// resolution.
    ///
    /// **Validates: Requirements 12.2**
    #[test]
    fn prop_workspace_index_declarations_available_in_dependency_chain(
        symbol_name in r_symbol_name(),
        is_function in proptest::bool::ANY,
    ) {
        use super::directive::parse_directives;
        use super::scope::{compute_artifacts_with_metadata, scope_at_position_with_graph, SymbolKind};
        use super::dependency::DependencyGraph;
        use super::types::ForwardSource;

        // Skip if symbol conflicts with parent's own definitions
        prop_assume!(symbol_name != "parent_var" && symbol_name != "child_var");

        let parent_uri = make_url("parent");
        let indexed_child_uri = make_url("indexed_child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent file: sources the indexed child (use unique variable name)
        let parent_code = "source(\"indexed_child.R\")\nparent_var <- 1";
        let parent_tree = parse_r_tree(parent_code);
        let parent_metadata = parse_directives(parent_code);
        let parent_artifacts = compute_artifacts_with_metadata(
            &parent_uri, &parent_tree, parent_code, Some(&parent_metadata)
        );

        // Indexed child file: has a declaration directive (use unique variable name)
        // This simulates a closed file that was indexed by the workspace indexer
        let directive = if is_function {
            format!("# @lsp-func {}", symbol_name)
        } else {
            format!("# @lsp-var {}", symbol_name)
        };
        let child_code = format!("{}\nchild_var <- 42", directive);
        let child_tree = parse_r_tree(&child_code);
        let child_metadata = parse_directives(&child_code);
        let child_artifacts = compute_artifacts_with_metadata(
            &indexed_child_uri, &child_tree, &child_code, Some(&child_metadata)
        );

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta_for_graph = CrossFileMetadata {
            sources: vec![ForwardSource {
                path: "indexed_child.R".to_string(),
                line: 0,
                column: 0,
                is_directive: false,
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            }],
            ..Default::default()
        };
        graph.update_file(&parent_uri, &parent_meta_for_graph, Some(&workspace_root), |_| None);

        // Simulate workspace index providing artifacts for the indexed child
        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<super::scope::ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &indexed_child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta_for_graph.clone())) }
            else if uri == &indexed_child_uri { Some(std::sync::Arc::new(child_metadata.clone())) }
            else { None }
        };

        // Query parent's scope at end of file (after source() call)
        let scope = scope_at_position_with_graph(
            &parent_uri, 1, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );

        // Requirement 12.2: Declared symbol from indexed child should be available in parent's scope
        prop_assert!(
            scope.symbols.contains_key(symbol_name.as_str()),
            "Declared symbol '{}' from indexed child file should be available in parent's scope. \
             Parent code:\n{}\nChild code:\n{}",
            symbol_name, parent_code, child_code
        );

        let symbol = scope.symbols.get(symbol_name.as_str()).unwrap();
        prop_assert!(
            symbol.is_declared,
            "Symbol '{}' should be marked as declared. Parent code:\n{}\nChild code:\n{}",
            symbol_name, parent_code, child_code
        );

        let expected_kind = if is_function {
            SymbolKind::Function
        } else {
            SymbolKind::Variable
        };
        prop_assert_eq!(
            symbol.kind, expected_kind,
            "Symbol '{}' should have correct kind. Parent code:\n{}\nChild code:\n{}",
            symbol_name, parent_code, child_code
        );
    }

    /// Feature: lsp-declaration-directives, Property 10: Workspace Index Declaration Extraction
    ///
    /// When an indexed file is opened, the declared symbols SHALL be re-extracted from
    /// the live document content.
    ///
    /// This test verifies Requirement 12.3: When an indexed file is opened, the declared
    /// symbols SHALL be re-extracted from the live document content.
    ///
    /// **Validates: Requirements 12.3**
    #[test]
    fn prop_workspace_index_reextracts_on_open(
        old_symbol in r_symbol_name(),
        new_symbol in r_symbol_name(),
        is_function in proptest::bool::ANY,
    ) {
        use super::directive::parse_directives;
        use super::scope::{compute_artifacts_with_metadata, scope_at_position_with_graph, SymbolKind};
        use super::dependency::DependencyGraph;
        use super::types::ForwardSource;

        // Skip if old and new symbols are the same (can't test re-extraction)
        prop_assume!(old_symbol != new_symbol);
        // Skip if symbols conflict with real definitions in test code.
        // Old code has "y <- 42", new code has "z <- 99", parent has "parent_var <- 1".
        // Real definitions take precedence over declarations, which would break assertions.
        prop_assume!(old_symbol != "parent_var" && new_symbol != "parent_var");
        prop_assume!(old_symbol != "y" && new_symbol != "y");
        prop_assume!(old_symbol != "z" && new_symbol != "z");

        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent file: sources the child (use unique variable name to avoid conflicts)
        let parent_code = "source(\"child.R\")\nparent_var <- 1";
        let parent_tree = parse_r_tree(parent_code);
        let parent_metadata = parse_directives(parent_code);
        let parent_artifacts = compute_artifacts_with_metadata(
            &parent_uri, &parent_tree, parent_code, Some(&parent_metadata)
        );

        // OLD child content (simulating stale workspace index)
        let old_directive = if is_function {
            format!("# @lsp-func {}", old_symbol)
        } else {
            format!("# @lsp-var {}", old_symbol)
        };
        let old_child_code = format!("{}\ny <- 42", old_directive);
        let old_child_tree = parse_r_tree(&old_child_code);
        let old_child_metadata = parse_directives(&old_child_code);
        let old_child_artifacts = compute_artifacts_with_metadata(
            &child_uri, &old_child_tree, &old_child_code, Some(&old_child_metadata)
        );

        // NEW child content (simulating live document after opening)
        let new_directive = if is_function {
            format!("# @lsp-func {}", new_symbol)
        } else {
            format!("# @lsp-var {}", new_symbol)
        };
        let new_child_code = format!("{}\nz <- 99", new_directive);
        let new_child_tree = parse_r_tree(&new_child_code);
        let new_child_metadata = parse_directives(&new_child_code);
        let new_child_artifacts = compute_artifacts_with_metadata(
            &child_uri, &new_child_tree, &new_child_code, Some(&new_child_metadata)
        );

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta_for_graph = CrossFileMetadata {
            sources: vec![ForwardSource {
                path: "child.R".to_string(),
                line: 0,
                column: 0,
                is_directive: false,
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            }],
            ..Default::default()
        };
        graph.update_file(&parent_uri, &parent_meta_for_graph, Some(&workspace_root), |_| None);

        // First, verify old artifacts have old symbol (simulating workspace index state)
        prop_assert!(
            old_child_artifacts.exported_interface.contains_key(old_symbol.as_str()),
            "Old artifacts should contain old symbol '{}'. Old code:\n{}",
            old_symbol, old_child_code
        );
        prop_assert!(
            !old_child_artifacts.exported_interface.contains_key(new_symbol.as_str()),
            "Old artifacts should NOT contain new symbol '{}'. Old code:\n{}",
            new_symbol, old_child_code
        );

        // Simulate opening the file: now use new artifacts (re-extracted from live content)
        let new_child_artifacts = Arc::new(new_child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<super::scope::ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&new_child_artifacts)) }  // Live content
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta_for_graph.clone())) }
            else if uri == &child_uri { Some(std::sync::Arc::new(new_child_metadata.clone())) }  // Live content
            else { None }
        };

        // Query parent's scope at end of file
        let scope = scope_at_position_with_graph(
            &parent_uri, 1, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );

        // Requirement 12.3: After opening, new declared symbol should be available
        prop_assert!(
            scope.symbols.contains_key(new_symbol.as_str()),
            "New declared symbol '{}' should be available after re-extraction from live content. \
             New code:\n{}",
            new_symbol, new_child_code
        );

        // Old symbol should NOT be available (it was in the old content)
        prop_assert!(
            !scope.symbols.contains_key(old_symbol.as_str()),
            "Old declared symbol '{}' should NOT be available after re-extraction. \
             Old code:\n{}\nNew code:\n{}",
            old_symbol, old_child_code, new_child_code
        );

        let symbol = scope.symbols.get(new_symbol.as_str()).unwrap();
        prop_assert!(
            symbol.is_declared,
            "New symbol '{}' should be marked as declared",
            new_symbol
        );

        let expected_kind = if is_function {
            SymbolKind::Function
        } else {
            SymbolKind::Variable
        };
        prop_assert_eq!(
            symbol.kind, expected_kind,
            "New symbol '{}' should have correct kind",
            new_symbol
        );
    }

    /// Feature: lsp-declaration-directives, Property 10: Workspace Index Declaration Extraction
    ///
    /// Extended test: Multiple declarations in an indexed file should all be extracted
    /// and available in the dependency chain.
    ///
    /// **Validates: Requirements 12.1, 12.2**
    #[test]
    fn prop_workspace_index_multiple_declarations(
        var_names in proptest::collection::vec(r_symbol_name(), 1..4),
        func_names in proptest::collection::vec(r_symbol_name(), 1..4),
    ) {
        use super::directive::parse_directives;
        use super::scope::{compute_artifacts_with_metadata, scope_at_position_with_graph, SymbolKind};
        use super::dependency::DependencyGraph;
        use super::types::ForwardSource;

        // Ensure unique names and no conflicts with parent's own definitions
        let all_names: HashSet<_> = var_names.iter().chain(func_names.iter()).collect();
        prop_assume!(all_names.len() == var_names.len() + func_names.len());
        // Skip if any name conflicts with parent's or child's variable
        prop_assume!(!var_names.contains(&"parent_var".to_string()));
        prop_assume!(!func_names.contains(&"parent_var".to_string()));
        prop_assume!(!var_names.contains(&"child_var".to_string()));
        prop_assume!(!func_names.contains(&"child_var".to_string()));

        let parent_uri = make_url("parent");
        let indexed_child_uri = make_url("indexed_child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Parent file: sources the indexed child (use unique variable name)
        let parent_code = "source(\"indexed_child.R\")\nparent_var <- 1";
        let parent_tree = parse_r_tree(parent_code);
        let parent_metadata = parse_directives(parent_code);
        let parent_artifacts = compute_artifacts_with_metadata(
            &parent_uri, &parent_tree, parent_code, Some(&parent_metadata)
        );

        // Indexed child file: has multiple declaration directives (use unique variable name)
        let mut child_lines: Vec<String> = Vec::new();
        for name in &var_names {
            child_lines.push(format!("# @lsp-var {}", name));
        }
        for name in &func_names {
            child_lines.push(format!("# @lsp-func {}", name));
        }
        child_lines.push("child_var <- 42".to_string());

        let child_code = child_lines.join("\n");
        let child_tree = parse_r_tree(&child_code);
        let child_metadata = parse_directives(&child_code);
        let child_artifacts = compute_artifacts_with_metadata(
            &indexed_child_uri, &child_tree, &child_code, Some(&child_metadata)
        );

        // Build dependency graph
        let mut graph = DependencyGraph::new();
        let parent_meta_for_graph = CrossFileMetadata {
            sources: vec![ForwardSource {
                path: "indexed_child.R".to_string(),
                line: 0,
                column: 0,
                is_directive: false,
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            }],
            ..Default::default()
        };
        graph.update_file(&parent_uri, &parent_meta_for_graph, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<super::scope::ScopeArtifacts>> {
            if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &indexed_child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta_for_graph.clone())) }
            else if uri == &indexed_child_uri { Some(std::sync::Arc::new(child_metadata.clone())) }
            else { None }
        };

        // Query parent's scope at end of file
        let scope = scope_at_position_with_graph(
            &parent_uri, 1, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );

        // All declared variables should be available
        for name in &var_names {
            prop_assert!(
                scope.symbols.contains_key(name.as_str()),
                "Declared variable '{}' should be available in parent's scope. Child code:\n{}",
                name, child_code
            );
            let symbol = scope.symbols.get(name.as_str()).unwrap();
            prop_assert!(symbol.is_declared, "Variable '{}' should be marked as declared", name);
            prop_assert_eq!(symbol.kind, SymbolKind::Variable, "Variable '{}' should have Variable kind", name);
        }

        // All declared functions should be available
        for name in &func_names {
            prop_assert!(
                scope.symbols.contains_key(name.as_str()),
                "Declared function '{}' should be available in parent's scope. Child code:\n{}",
                name, child_code
            );
            let symbol = scope.symbols.get(name.as_str()).unwrap();
            prop_assert!(symbol.is_declared, "Function '{}' should be marked as declared", name);
            prop_assert_eq!(symbol.kind, SymbolKind::Function, "Function '{}' should have Function kind", name);
        }
    }

    /// Feature: lsp-declaration-directives, Property 10: Workspace Index Declaration Extraction
    ///
    /// Extended test: Declarations in indexed files should work correctly in transitive
    /// dependency chains (grandparent -> parent -> child).
    ///
    /// **Validates: Requirements 12.2**
    #[test]
    fn prop_workspace_index_transitive_declarations(
        symbol_name in r_symbol_name(),
        is_function in proptest::bool::ANY,
    ) {
        use super::directive::parse_directives;
        use super::scope::{compute_artifacts_with_metadata, scope_at_position_with_graph, SymbolKind};
        use super::dependency::DependencyGraph;
        use super::types::ForwardSource;

        // Skip if symbol conflicts with any file's own definitions
        prop_assume!(symbol_name != "gp_var" && symbol_name != "p_var" && symbol_name != "c_var");

        let grandparent_uri = make_url("grandparent");
        let parent_uri = make_url("parent");
        let child_uri = make_url("child");
        let workspace_root = Url::parse("file:///").unwrap();

        // Grandparent file: sources parent (use unique variable name)
        let grandparent_code = "source(\"parent.R\")\ngp_var <- 1";
        let grandparent_tree = parse_r_tree(grandparent_code);
        let grandparent_metadata = parse_directives(grandparent_code);
        let grandparent_artifacts = compute_artifacts_with_metadata(
            &grandparent_uri, &grandparent_tree, grandparent_code, Some(&grandparent_metadata)
        );

        // Parent file (indexed): sources child (use unique variable name)
        let parent_code = "source(\"child.R\")\np_var <- 2";
        let parent_tree = parse_r_tree(parent_code);
        let parent_metadata = parse_directives(parent_code);
        let parent_artifacts = compute_artifacts_with_metadata(
            &parent_uri, &parent_tree, parent_code, Some(&parent_metadata)
        );

        // Child file (indexed): has declaration directive (use unique variable name)
        let directive = if is_function {
            format!("# @lsp-func {}", symbol_name)
        } else {
            format!("# @lsp-var {}", symbol_name)
        };
        let child_code = format!("{}\nc_var <- 3", directive);
        let child_tree = parse_r_tree(&child_code);
        let child_metadata = parse_directives(&child_code);
        let child_artifacts = compute_artifacts_with_metadata(
            &child_uri, &child_tree, &child_code, Some(&child_metadata)
        );

        // Build dependency graph
        let mut graph = DependencyGraph::new();

        // Grandparent -> Parent edge
        let grandparent_meta_for_graph = CrossFileMetadata {
            sources: vec![ForwardSource {
                path: "parent.R".to_string(),
                line: 0,
                column: 0,
                is_directive: false,
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            }],
            ..Default::default()
        };
        graph.update_file(&grandparent_uri, &grandparent_meta_for_graph, Some(&workspace_root), |_| None);

        // Parent -> Child edge
        let parent_meta_for_graph = CrossFileMetadata {
            sources: vec![ForwardSource {
                path: "child.R".to_string(),
                line: 0,
                column: 0,
                is_directive: false,
                chdir: false,
                is_sys_source: false,
                ..Default::default()
            }],
            ..Default::default()
        };
        graph.update_file(&parent_uri, &parent_meta_for_graph, Some(&workspace_root), |_| None);

        let child_artifacts = Arc::new(child_artifacts);
        let grandparent_artifacts = Arc::new(grandparent_artifacts);
        let parent_artifacts = Arc::new(parent_artifacts);

        let get_artifacts = |uri: &Url| -> Option<Arc<super::scope::ScopeArtifacts>> {
            if uri == &grandparent_uri { Some(Arc::clone(&grandparent_artifacts)) }
            else if uri == &parent_uri { Some(Arc::clone(&parent_artifacts)) }
            else if uri == &child_uri { Some(Arc::clone(&child_artifacts)) }
            else { None }
        };

        let get_metadata = |uri: &Url| -> Option<std::sync::Arc<CrossFileMetadata>> {
            if uri == &grandparent_uri { Some(std::sync::Arc::new(grandparent_meta_for_graph.clone())) }
            else if uri == &parent_uri { Some(std::sync::Arc::new(parent_meta_for_graph.clone())) }
            else if uri == &child_uri { Some(std::sync::Arc::new(child_metadata.clone())) }
            else { None }
        };

        // Query grandparent's scope at end of file
        let scope = scope_at_position_with_graph(
            &grandparent_uri, 1, 0, &get_artifacts, &get_metadata, &graph, Some(&workspace_root), 10, &HashSet::new(),
            false,
            crate::cross_file::config::BackwardDependencyMode::Explicit,
            &|| false,
            None,
            None,
        );

        // Declared symbol from child should be available in grandparent's scope
        // (through transitive dependency chain)
        prop_assert!(
            scope.symbols.contains_key(symbol_name.as_str()),
            "Declared symbol '{}' from child should be available in grandparent's scope \
             through transitive dependency chain. Child code:\n{}",
            symbol_name, child_code
        );

        let symbol = scope.symbols.get(symbol_name.as_str()).unwrap();
        prop_assert!(
            symbol.is_declared,
            "Symbol '{}' should be marked as declared",
            symbol_name
        );

        let expected_kind = if is_function {
            SymbolKind::Function
        } else {
            SymbolKind::Variable
        };
        prop_assert_eq!(
            symbol.kind, expected_kind,
            "Symbol '{}' should have correct kind",
            symbol_name
        );
    }
}

// ============================================================================
// Suppression-parser parity (Probe B second-pass validation of PR #420)
//
// Three parsers must agree on the single question "is this `#` the start of a
// real comment, or is it buried inside a string literal":
//
//   1. analyzer track   — `directive::comment_region_outside_strings`
//      (a deliberate local copy of `nolint::first_hash_body`, with a parity
//      doc comment promising they stay in lockstep);
//   2. lint track       — `nolint::first_hash_body`;
//   3. tree-sitter path — `handlers::lsp_ignored_lines_from_tree`, which walks
//      `comment` nodes of a parsed tree (so strings, raw strings, multi-line
//      strings, and backtick identifiers are never mistaken for comments).
//
// The two byte-scanners (1) and (2) are claimed byte-identical, so they are
// compared at full proptest volume on adversarial lines. The tree-sitter path
// uses a completely different mechanism (a real parser, not a hand-rolled
// scanner), and has DOCUMENTED behavioral divergences from the scanners:
//
//   * a standalone `# @lsp-ignore` (no code before the marker) suppresses
//     NOTHING on the AST path — "use `@lsp-ignore-next` instead"
//     (see `classify_comment_for_ignore`);
//   * `@lsp-ignore-next` is honored only when standalone;
//   * the scanners' single-line quote bookkeeping treats an *unterminated*
//     quote as "string runs to EOL", whereas tree-sitter only treats a `#` as
//     non-comment when the parser actually places it inside a string node.
//
// Those divergences are ENCODED below (the three-way property restricts to the
// shape where they cannot bite: a marker preceded by real, string-free code),
// rather than papered over.
// ============================================================================

mod suppression_parity {
    use super::*;
    use crate::cross_file::directive::comment_region_outside_strings_for_parity_test as comment_region_outside_strings;
    use crate::handlers::lsp_ignored_lines_from_text_for_parity_test;
    use crate::linting::SuppressionsForParityTest as Suppressions;
    use crate::linting::first_hash_body_for_parity_test as first_hash_body;

    /// A single "token" of adversarial line content. Composed into a line by
    /// `adversarial_line`. Deliberately exercises every string/quote/escape/
    /// hash hazard the scanners must handle.
    fn line_token() -> impl Strategy<Value = String> {
        prop_oneof![
            // Bare hashes (comment starts, or mid-string noise).
            Just("#".to_string()),
            Just("##".to_string()),
            // Quote characters of both kinds, alone (toggles string state).
            Just("\"".to_string()),
            Just("'".to_string()),
            // Backslash escapes (consume the next byte inside a string).
            Just("\\".to_string()),
            Just("\\\"".to_string()),
            Just("\\'".to_string()),
            Just("\\\\".to_string()),
            // Complete string literals of both kinds, including ones that
            // embed a `#` and embed the opposite quote.
            Just("\"abc\"".to_string()),
            Just("'abc'".to_string()),
            Just("\"a # b\"".to_string()),
            Just("'a # b'".to_string()),
            Just("\"it's\"".to_string()),
            Just("'say \"hi\"'".to_string()),
            Just("\"esc\\\"q\"".to_string()),
            // The suppression markers themselves, dropped at an arbitrary spot
            // (after code, mid-string, etc.).
            Just("@lsp-ignore".to_string()),
            Just("@lsp-ignore-next".to_string()),
            Just("raven: ignore".to_string()),
            Just("nolint".to_string()),
            // Ordinary code-ish fragments and whitespace.
            Just("x <- 1".to_string()),
            Just("foo(bar)".to_string()),
            Just(" + ".to_string()),
            Just(" ".to_string()),
            Just("`a#b`".to_string()),
        ]
    }

    /// Build an adversarial single line by concatenating 0..=8 tokens. Newlines
    /// are intentionally excluded — both scanners are line-oriented and are
    /// called per-line by their callers.
    fn adversarial_line() -> impl Strategy<Value = String> {
        prop::collection::vec(line_token(), 0..=8).prop_map(|toks| toks.concat())
    }

    proptest! {
        #![proptest_config(ProptestConfig::with_cases(2000))]

        /// CORE PARITY: the analyzer-track scanner and the lint-track scanner
        /// must make the byte-identical decision about where the comment region
        /// begins, for ANY line.
        ///
        /// `comment_region_outside_strings` returns the slice starting at the
        /// first comment `#`; `first_hash_body` returns `(index_of_#, &line[i+1..])`.
        /// So agreement means: both `Some`/`None` together, and when `Some` the
        /// directive slice equals `&line[hash_index..]`.
        #[test]
        fn prop_scanner_parity_directive_vs_nolint(line in adversarial_line()) {
            let dir = comment_region_outside_strings(&line);
            let nol = first_hash_body(&line);

            match (dir, nol) {
                (None, None) => {}
                (Some(region), Some((idx, body))) => {
                    // The directive region starts exactly at the `#` nolint found.
                    prop_assert_eq!(
                        region, &line[idx..],
                        "scanner region mismatch on {:?}: dir slice vs &line[{}..]",
                        line, idx
                    );
                    // And the directive region is `#` followed by nolint's body.
                    prop_assert!(region.starts_with('#'));
                    prop_assert_eq!(&region[1..], body,
                        "comment body mismatch on {:?}", line);
                }
                (d, n) => prop_assert!(
                    false,
                    "scanner disagreement on {:?}: directive={:?} nolint={:?}",
                    line, d, n
                ),
            }
        }
    }

    proptest! {
        #![proptest_config(ProptestConfig::with_cases(2000))]

        /// Idempotence-style invariant tying the scanner to observable behavior:
        /// if (and only if) the lint scanner finds a comment region, that region
        /// is exactly the substring tree-sitter would have to recognize as a
        /// comment node for any marker in it to fire. We assert the cheaper,
        /// scanner-internal half: when a `#` is found, everything before it on
        /// the line parses with balanced quote state (no `#` of the returned
        /// region appears earlier outside strings). This pins the "first hash
        /// outside strings" contract that all three parsers depend on.
        #[test]
        fn prop_first_hash_is_truly_first_outside_strings(line in adversarial_line()) {
            if let Some((idx, _)) = first_hash_body(&line) {
                // No earlier `#` may be a comment start: re-scanning the prefix
                // up to `idx` must itself find no comment region.
                let prefix = &line[..idx];
                prop_assert_eq!(
                    comment_region_outside_strings(prefix), None,
                    "a `#` before idx={} in {:?} was also a comment start",
                    idx, line
                );
            }
        }
    }

    /// Append ` # @lsp-ignore` to a string-free, comment-free code prefix. The
    /// prefix is chosen so that there is exactly one comment region (the one we
    /// append) and no open string at the marker — the shape in which all three
    /// parsers are documented to AGREE.
    fn code_prefix_then_same_line_marker() -> impl Strategy<Value = String> {
        // Simple code with no `#`, no quotes, no backslashes — so the appended
        // marker is unambiguously the first (and only) comment region.
        prop_oneof![
            Just("x <- 1".to_string()),
            Just("foo(bar)".to_string()),
            Just("y = f(a, b)".to_string()),
            Just("z <- g() + h()".to_string()),
        ]
        .prop_map(|code| format!("{code} # @lsp-ignore"))
    }

    proptest! {
        #![proptest_config(ProptestConfig::with_cases(500))]

        /// THREE-WAY AGREEMENT (restricted domain): for a real comment marker
        /// after real, string-free code, all three parsers must agree the line
        /// is suppressed. This is the overlap of their domains; the documented
        /// divergences (standalone-only, `# nolint`, unterminated-quote) are
        /// excluded by construction.
        #[test]
        fn prop_three_way_same_line_marker_agrees(line in code_prefix_then_same_line_marker()) {
            // Analyzer track.
            let meta = parse_directives(&line);
            let dir_suppressed =
                crate::cross_file::directive::is_line_ignored(&meta, 0);
            // Lint track.
            let supp = Suppressions::from_text(&line);
            let lint_suppressed = supp.is_suppressed(0);
            // Tree-sitter path.
            let ts = lsp_ignored_lines_from_text_for_parity_test(&line);
            let ts_suppressed = ts.contains_key(&0);

            prop_assert!(
                dir_suppressed && lint_suppressed && ts_suppressed,
                "three-way disagreement on {:?}: directive={} lint={} tree-sitter={}",
                line, dir_suppressed, lint_suppressed, ts_suppressed
            );
        }
    }

    proptest! {
        #![proptest_config(ProptestConfig::with_cases(500))]

        /// THREE-WAY AGREEMENT on the negative case: a marker buried inside a
        /// *terminated* string literal (so all three agree the string is closed
        /// and the `#` is inside it) must suppress in NONE of the three parsers.
        #[test]
        fn prop_three_way_marker_inside_string_suppresses_none(
            inner in prop_oneof![
                Just("@lsp-ignore".to_string()),
                Just("# @lsp-ignore".to_string()),
                Just("# raven: ignore".to_string()),
            ]
        ) {
            // `x <- "<marker>"` — the marker is wholly inside a closed double
            // quoted string. No real comment exists on the line.
            let line = format!("x <- \"{inner}\"");

            let meta = parse_directives(&line);
            let dir_suppressed =
                crate::cross_file::directive::is_line_ignored(&meta, 0);
            let supp = Suppressions::from_text(&line);
            let lint_suppressed = supp.is_suppressed(0);
            let ts = lsp_ignored_lines_from_text_for_parity_test(&line);
            let ts_suppressed = ts.contains_key(&0);

            prop_assert!(
                !dir_suppressed && !lint_suppressed && !ts_suppressed,
                "marker inside string wrongly suppressed on {:?}: directive={} lint={} tree-sitter={}",
                line, dir_suppressed, lint_suppressed, ts_suppressed
            );
        }
    }

    /// Deterministic adversarial cases for the tree-sitter path, where its
    /// mechanism (a real parser) legitimately diverges from the line scanners.
    /// These are checked at fixed inputs rather than at proptest volume because
    /// they probe parser-specific constructs (raw strings, multi-line strings)
    /// rather than the shared scanner contract.
    #[test]
    fn tree_sitter_multiline_string_hides_marker() {
        // The `# @lsp-ignore-next` lives inside a multi-line string opened on
        // line 0 and closed on line 1. tree-sitter sees one string node, so no
        // comment node, so nothing is suppressed.
        let code = "x <- \"abc\n# @lsp-ignore-next\"\nTRUE <- 1";
        let map = lsp_ignored_lines_from_text_for_parity_test(code);
        assert!(
            map.is_empty(),
            "multi-line string should hide the marker, got {map:?}"
        );
    }

    #[test]
    fn tree_sitter_raw_string_hides_marker() {
        // R raw strings: r"(...)" / R"[...]". A marker inside one is not a
        // comment. (If tree-sitter-r does not model raw strings, the marker is
        // still inside a regular string by the surrounding quotes, so this also
        // serves as a regression guard.)
        let code = "x <- r\"(# @lsp-ignore)\"";
        let map = lsp_ignored_lines_from_text_for_parity_test(code);
        assert!(
            map.is_empty(),
            "raw string should hide the marker, got {map:?}"
        );
    }

    #[test]
    fn tree_sitter_standalone_same_line_marker_suppresses_nothing() {
        // Documented divergence: a standalone `# @lsp-ignore` (no code before
        // it) suppresses nothing on the AST path.
        let code = "# @lsp-ignore\nTRUE <- 1";
        let map = lsp_ignored_lines_from_text_for_parity_test(code);
        assert!(
            !map.contains_key(&0) && !map.contains_key(&1),
            "standalone same-line marker should suppress nothing, got {map:?}"
        );
    }

    #[test]
    fn tree_sitter_standalone_next_line_marker_suppresses_next() {
        // Counterpart: standalone `# @lsp-ignore-next` suppresses the line after.
        let code = "# @lsp-ignore-next\nTRUE <- 1";
        let map = lsp_ignored_lines_from_text_for_parity_test(code);
        assert!(
            map.contains_key(&1) && !map.contains_key(&0),
            "standalone next-line marker should suppress line 1, got {map:?}"
        );
    }

    #[test]
    fn tree_sitter_marker_after_code_in_backtick_identifier_is_not_comment() {
        // A `#` inside a backtick-quoted identifier is not a comment.
        let code = "`a # @lsp-ignore` <- 2";
        let map = lsp_ignored_lines_from_text_for_parity_test(code);
        assert!(
            map.is_empty(),
            "backtick identifier should hide the marker, got {map:?}"
        );
    }
}
