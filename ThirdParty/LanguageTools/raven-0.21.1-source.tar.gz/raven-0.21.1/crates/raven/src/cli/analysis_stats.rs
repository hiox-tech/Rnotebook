// cli/analysis_stats.rs — `raven analysis-stats` subcommand
//
// Loads a workspace and reports timing metrics for each analysis phase,
// inspired by rust-analyzer's `analysis-stats` command.
//
// Phases measured:
//   1. scan     — discovering R files in the workspace
//   2. parse    — tree-sitter parsing all files
//   3. metadata — extracting cross-file metadata
//   4. scope    — scope resolution / cross-file analysis
//   5. packages — package loading/resolution
//
// Requirements: 5.1, 5.2, 5.3, 5.4

use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};

use url::Url;

use crate::cross_file;
use crate::parser_pool;
use crate::perf::TimingGuard;

/// Parsed arguments for the `analysis-stats` subcommand.
#[derive(Debug)]
pub struct AnalysisStatsArgs {
    pub path: PathBuf,
    pub csv: bool,
    pub only: Option<String>,
}

/// Result of running a single analysis phase.
///
/// Note: `peak_rss_bytes` is the process-wide peak RSS at the moment it was
/// sampled (after the phase completes). Since peak RSS is monotonically
/// increasing, later phases will always show values >= earlier phases.
pub struct PhaseResult {
    pub name: String,
    pub duration: Duration,
    pub peak_rss_bytes: Option<u64>,
    pub detail: String,
}

/// All valid phase names.
const VALID_PHASES: &[&str] = &["scan", "parse", "metadata", "scope", "packages"];

/// Parse `analysis-stats` arguments from the remaining CLI args.
///
/// Expected usage: `raven analysis-stats <path> [--csv] [--only <phase>]`
pub fn parse_args(args: &mut impl Iterator<Item = String>) -> Result<AnalysisStatsArgs, String> {
    let mut path: Option<PathBuf> = None;
    let mut csv = false;
    let mut only: Option<String> = None;

    while let Some(arg) = args.next() {
        match arg.as_str() {
            "--help" => return Err("HELP".to_string()),
            "--csv" => csv = true,
            "--only" => {
                let phase = args
                    .next()
                    .ok_or_else(|| "--only requires a phase name".to_string())?;
                if !VALID_PHASES.contains(&phase.as_str()) {
                    return Err(format!(
                        "Unknown phase '{}'. Valid phases: {}",
                        phase,
                        VALID_PHASES.join(", ")
                    ));
                }
                only = Some(phase);
            }
            other if other.starts_with('-') => {
                return Err(format!("Unknown flag: '{}'", other));
            }
            _ => {
                if path.is_some() {
                    return Err("Multiple paths provided; expected exactly one".to_string());
                }
                path = Some(PathBuf::from(arg));
            }
        }
    }

    let path = path.ok_or_else(|| "Missing required <path> argument".to_string())?;
    if !path.exists() {
        return Err(format!("Path does not exist: {}", path.display()));
    }

    Ok(AnalysisStatsArgs { path, csv, only })
}

pub fn print_help() {
    println!(
        "raven analysis-stats {} — profile workspace analysis phases

Usage: raven analysis-stats <path> [OPTIONS]

Loads a workspace and reports timing metrics for each analysis phase:
scan, parse, metadata, scope, and packages.

Options:
  --csv                      Output results in CSV format
  --only PHASE               Run only one phase (scan, parse, metadata, scope, packages)
  --help                     Print this help message
",
        env!("CARGO_PKG_VERSION")
    );
}

/// Run the analysis-stats command and return phase results.
///
/// The provided path is canonicalized to an absolute path before use, so
/// that `Url::from_file_path` always receives an absolute path.
pub fn run_analysis_stats(args: &AnalysisStatsArgs) -> Vec<PhaseResult> {
    // Canonicalize to an absolute path so Url::from_file_path always works.
    let args = match std::fs::canonicalize(&args.path) {
        Ok(canonical) => AnalysisStatsArgs {
            path: canonical,
            csv: args.csv,
            only: args.only.clone(),
        },
        Err(_) => {
            // Fall through with original path; Url::from_file_path may fail
            // but we handle that below.
            AnalysisStatsArgs {
                path: args.path.clone(),
                csv: args.csv,
                only: args.only.clone(),
            }
        }
    };
    let mut results = Vec::new();

    let should_run = |phase: &str| -> bool { args.only.as_ref().is_none_or(|only| only == phase) };

    // Phase 1: Scan — discover R files
    let mut r_files: Vec<(PathBuf, String)> = Vec::new();
    if should_run("scan") {
        let _guard = TimingGuard::new("analysis-stats:scan");
        let start = Instant::now();
        r_files = discover_r_files(&args.path);
        let duration = start.elapsed();
        results.push(PhaseResult {
            name: "scan".to_string(),
            duration,
            peak_rss_bytes: crate::perf::peak_rss_bytes(),
            detail: format!("{} files", r_files.len()),
        });
    }

    // If we skipped scan but need files for later phases, scan without timing
    if r_files.is_empty() && !should_run("scan") {
        r_files = discover_r_files(&args.path);
    }

    // Phase 2: Parse — tree-sitter parse all files
    let mut parsed_trees: Vec<(Url, String, Option<tree_sitter::Tree>)> = Vec::new();
    if should_run("parse") {
        let _guard = TimingGuard::new("analysis-stats:parse");
        let start = Instant::now();
        for (path, content) in &r_files {
            let tree = parser_pool::with_parser(|parser| parser.parse(content, None));
            let uri = match Url::from_file_path(path) {
                Ok(url) => url,
                Err(_) => {
                    log::warn!(
                        "Skipping file with non-convertible path: {}",
                        path.display()
                    );
                    continue;
                }
            };
            parsed_trees.push((uri, content.clone(), tree));
        }
        let duration = start.elapsed();
        let parse_count = parsed_trees.iter().filter(|(_, _, t)| t.is_some()).count();
        results.push(PhaseResult {
            name: "parse".to_string(),
            duration,
            peak_rss_bytes: crate::perf::peak_rss_bytes(),
            detail: format!("{} files parsed ({} succeeded)", r_files.len(), parse_count),
        });
    }

    // If we skipped parse but need trees for later phases, parse without timing
    if parsed_trees.is_empty() && !should_run("parse") {
        for (path, content) in &r_files {
            let tree = parser_pool::with_parser(|parser| parser.parse(content, None));
            let uri = match Url::from_file_path(path) {
                Ok(url) => url,
                Err(_) => {
                    log::warn!(
                        "Skipping file with non-convertible path: {}",
                        path.display()
                    );
                    continue;
                }
            };
            parsed_trees.push((uri, content.clone(), tree));
        }
    }

    // Phase 3: Metadata — extract cross-file metadata
    let mut metadata_map: HashMap<Url, cross_file::CrossFileMetadata> = HashMap::new();
    if should_run("metadata") {
        let _guard = TimingGuard::new("analysis-stats:metadata");
        let start = Instant::now();
        for (uri, content, tree) in &parsed_trees {
            let meta = cross_file::extract_metadata_with_tree(content, tree.as_ref());
            metadata_map.insert(uri.clone(), meta);
        }
        let duration = start.elapsed();
        let total_sources: usize = metadata_map.values().map(|m| m.sources.len()).sum();
        let total_lib_calls: usize = metadata_map.values().map(|m| m.library_calls.len()).sum();
        results.push(PhaseResult {
            name: "metadata".to_string(),
            duration,
            peak_rss_bytes: crate::perf::peak_rss_bytes(),
            detail: format!(
                "{} files, {} source() refs, {} library() calls",
                metadata_map.len(),
                total_sources,
                total_lib_calls
            ),
        });
    }

    // If we skipped metadata but need it for scope, extract without timing
    if metadata_map.is_empty() && !should_run("metadata") {
        for (uri, content, tree) in &parsed_trees {
            let meta = cross_file::extract_metadata_with_tree(content, tree.as_ref());
            metadata_map.insert(uri.clone(), meta);
        }
    }

    // Phase 4: Scope — scope resolution / compute artifacts
    if should_run("scope") {
        let _guard = TimingGuard::new("analysis-stats:scope");
        let start = Instant::now();
        let mut artifacts_count = 0usize;
        let mut total_symbols = 0usize;
        for (uri, content, tree) in &parsed_trees {
            if let Some(tree) = tree {
                let meta = metadata_map.get(uri);
                let artifacts =
                    cross_file::scope::compute_artifacts_with_metadata(uri, tree, content, meta);
                total_symbols += artifacts.timeline.len();
                artifacts_count += 1;
            }
        }
        let duration = start.elapsed();
        results.push(PhaseResult {
            name: "scope".to_string(),
            duration,
            peak_rss_bytes: crate::perf::peak_rss_bytes(),
            detail: format!("{} files, {} scope events", artifacts_count, total_symbols),
        });
    }

    // Phase 5: Packages — package loading/resolution
    // This phase collects unique library() calls and attempts static NAMESPACE
    // resolution. In CLI mode we use PackageLibrary::new_empty() (no R library
    // paths), so find_package_directory() will not locate installed packages.
    // The primary value here is counting unique library() references and
    // measuring the overhead of the package resolution path itself.
    if should_run("packages") {
        let _guard = TimingGuard::new("analysis-stats:packages");
        let start = Instant::now();
        let mut unique_packages = std::collections::HashSet::new();
        for meta in metadata_map.values() {
            for lc in &meta.library_calls {
                unique_packages.insert(lc.package.clone());
            }
        }
        let pkg_count = unique_packages.len();

        // Attempt static NAMESPACE resolution for each package
        let pkg_lib = crate::package_library::PackageLibrary::new_empty();
        let mut resolved = 0usize;
        for pkg_name in &unique_packages {
            if let Some(pkg_dir) = pkg_lib.find_package_directory(pkg_name)
                && pkg_lib.parse_package_static(&pkg_dir).is_some()
            {
                resolved += 1;
            }
        }

        let duration = start.elapsed();
        results.push(PhaseResult {
            name: "packages".to_string(),
            duration,
            peak_rss_bytes: crate::perf::peak_rss_bytes(),
            detail: format!(
                "{} unique packages referenced, {} resolved statically",
                pkg_count, resolved
            ),
        });
    }

    results
}

/// Print phase results in human-readable format.
pub fn print_results(results: &[PhaseResult]) {
    println!("=== Raven Analysis Stats ===\n");
    for result in results {
        let rss_str = match result.peak_rss_bytes {
            Some(bytes) => format_bytes(bytes),
            None => "N/A".to_string(),
        };
        println!(
            "  {:<12} {:>10.2?}   RSS: {:<10}  ({})",
            result.name, result.duration, rss_str, result.detail
        );
    }

    if results.len() > 1 {
        let total: Duration = results.iter().map(|r| r.duration).sum();
        println!("\n  {:<12} {:>10.2?}", "TOTAL", total);
    }
    println!();
}

/// Print phase results in CSV format.
///
/// Note: `detail` is always built from controlled format strings in this
/// module, so it will never contain commas or newlines. The double-quote
/// escaping handles the only remaining RFC 4180 concern.
pub fn print_results_csv(results: &[PhaseResult]) {
    println!("phase,duration_ms,peak_rss_bytes,detail");
    for result in results {
        let rss = result
            .peak_rss_bytes
            .map_or(String::new(), |b| b.to_string());
        println!(
            "{},{:.3},{},\"{}\"",
            result.name,
            result.duration.as_secs_f64() * 1000.0,
            rss,
            result.detail.replace('"', "\"\"")
        );
    }
}

/// Recursively discover all `.R` files under `root` and read their contents.
///
/// Path discovery is shared with `raven check` via
/// [`crate::cli::shared::collect_r_file_paths`]; this reads the contents in a
/// second pass through the shared BOM-aware [`crate::state::read_source`] seam,
/// so the profiler sees the same decoded text the scan does. Unreadable or
/// undecodable files are silently skipped — this is a profiler, not a
/// diagnostic tool, so it emits no findings.
/// Project discovery settings come from the nearest shared configuration. Strong
/// exclusions remain relative to that configuration's directory. Ignore-rule
/// discovery and the file walk start at the requested profiling target, so an
/// outer configuration cannot move its Git boundary or scan unrelated trees.
fn discover_r_files(root: &Path) -> Vec<(PathBuf, String)> {
    let mut paths = Vec::new();
    let (config_root, settings) = match crate::config_file::discover_and_load(root) {
        crate::config_file::DiscoveredLoad::Loaded {
            path,
            settings,
            warnings,
        } => {
            for warning in warnings {
                eprintln!("{warning}");
            }
            (path.parent().unwrap_or(root).to_path_buf(), settings)
        }
        crate::config_file::DiscoveredLoad::LoadFailed { path } => {
            eprintln!(
                "raven analysis-stats: failed to load {}; using default discovery settings",
                path.display()
            );
            (root.to_path_buf(), serde_json::Value::Null)
        }
        crate::config_file::DiscoveredLoad::None => (root.to_path_buf(), serde_json::Value::Null),
    };
    let mut exclusions = crate::config_file::compile_workspace_exclusions(&settings, [config_root]);
    exclusions.refresh_gitignore_for_directory(root);
    crate::cli::shared::collect_r_file_paths_with_exclusions(root, &mut paths, &exclusions);
    let mut files: Vec<(PathBuf, String)> = paths
        .into_iter()
        .filter_map(|p| {
            crate::state::read_source(&p)
                .ok()
                .map(|content| (p, content))
        })
        .collect();
    // Sort for deterministic ordering
    files.sort_by(|a, b| a.0.cmp(&b.0));
    files
}
/// Format a byte count as a human-readable string (e.g., "12.3 MB").
fn format_bytes(bytes: u64) -> String {
    const KB: u64 = 1024;
    const MB: u64 = 1024 * KB;
    const GB: u64 = 1024 * MB;
    if bytes >= GB {
        format!("{:.1} GB", bytes as f64 / GB as f64)
    } else if bytes >= MB {
        format!("{:.1} MB", bytes as f64 / MB as f64)
    } else if bytes >= KB {
        format!("{:.1} KB", bytes as f64 / KB as f64)
    } else {
        format!("{} B", bytes)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_args_basic() {
        let mut args = vec![".".to_string()].into_iter();
        let result = parse_args(&mut args).unwrap();
        assert_eq!(result.path, PathBuf::from("."));
        assert!(!result.csv);
        assert!(result.only.is_none());
    }

    #[test]
    fn test_parse_args_csv_flag() {
        // Use a path that exists (current directory)
        let mut args = vec![".".to_string(), "--csv".to_string()].into_iter();
        let result = parse_args(&mut args).unwrap();
        assert!(result.csv);
    }

    #[test]
    fn test_parse_args_only_flag() {
        let mut args = vec![".".to_string(), "--only".to_string(), "parse".to_string()].into_iter();
        let result = parse_args(&mut args).unwrap();
        assert_eq!(result.only.as_deref(), Some("parse"));
    }

    #[test]
    fn test_parse_args_all_flags() {
        let mut args = vec![
            ".".to_string(),
            "--csv".to_string(),
            "--only".to_string(),
            "scope".to_string(),
        ]
        .into_iter();
        let result = parse_args(&mut args).unwrap();
        assert!(result.csv);
        assert_eq!(result.only.as_deref(), Some("scope"));
    }

    #[test]
    fn test_parse_args_missing_path() {
        let mut args = vec!["--csv".to_string()].into_iter();
        let result = parse_args(&mut args);
        assert!(result.is_err());
        assert!(result.unwrap_err().contains("Missing required <path>"));
    }

    #[test]
    fn test_parse_args_invalid_phase() {
        let mut args =
            vec![".".to_string(), "--only".to_string(), "invalid".to_string()].into_iter();
        let result = parse_args(&mut args);
        assert!(result.is_err());
        assert!(result.unwrap_err().contains("Unknown phase"));
    }

    #[test]
    fn test_parse_args_only_missing_value() {
        let mut args = vec![".".to_string(), "--only".to_string()].into_iter();
        let result = parse_args(&mut args);
        assert!(result.is_err());
        assert!(result.unwrap_err().contains("--only requires a phase name"));
    }

    #[test]
    fn test_parse_args_unknown_flag() {
        let mut args = vec![".".to_string(), "--unknown".to_string()].into_iter();
        let result = parse_args(&mut args);
        assert!(result.is_err());
        assert!(result.unwrap_err().contains("Unknown flag"));
    }

    #[test]
    fn test_valid_phases_list() {
        assert_eq!(
            VALID_PHASES,
            &["scan", "parse", "metadata", "scope", "packages"]
        );
    }

    #[test]
    fn test_parse_args_all_valid_phases() {
        for phase in VALID_PHASES {
            let mut args =
                vec![".".to_string(), "--only".to_string(), phase.to_string()].into_iter();
            let result = parse_args(&mut args);
            assert!(result.is_ok(), "Phase '{}' should be valid", phase);
            assert_eq!(result.unwrap().only.as_deref(), Some(*phase));
        }
    }

    #[test]
    fn test_run_analysis_stats_on_empty_dir() {
        let dir = tempfile::tempdir().unwrap();
        let args = AnalysisStatsArgs {
            path: dir.path().to_path_buf(),
            csv: false,
            only: None,
        };
        let results = run_analysis_stats(&args);
        assert_eq!(results.len(), 5); // all 5 phases
        for result in &results {
            assert!(VALID_PHASES.contains(&result.name.as_str()));
        }
    }

    #[test]
    fn test_run_analysis_stats_only_scan() {
        let dir = tempfile::tempdir().unwrap();
        let args = AnalysisStatsArgs {
            path: dir.path().to_path_buf(),
            csv: false,
            only: Some("scan".to_string()),
        };
        let results = run_analysis_stats(&args);
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].name, "scan");
    }

    #[test]
    fn test_run_analysis_stats_with_r_files() {
        let dir = tempfile::tempdir().unwrap();
        std::fs::write(
            dir.path().join("test.R"),
            "x <- 1\nmy_func <- function(a) a + 1\nlibrary(stats)\n",
        )
        .unwrap();
        std::fs::write(
            dir.path().join("helper.R"),
            "source('test.R')\ny <- x + 2\n",
        )
        .unwrap();

        let args = AnalysisStatsArgs {
            path: dir.path().to_path_buf(),
            csv: false,
            only: None,
        };
        let results = run_analysis_stats(&args);
        assert_eq!(results.len(), 5);

        // Scan should find 2 files
        let scan = &results[0];
        assert_eq!(scan.name, "scan");
        assert!(scan.detail.contains("2 files"));

        // Parse should parse 2 files
        let parse = &results[1];
        assert_eq!(parse.name, "parse");
        assert!(parse.detail.contains("2 files parsed"));
    }

    #[test]
    fn test_csv_output_format() {
        let results = vec![
            PhaseResult {
                name: "scan".to_string(),
                duration: Duration::from_millis(10),
                peak_rss_bytes: Some(1024 * 1024 * 50),
                detail: "5 files".to_string(),
            },
            PhaseResult {
                name: "parse".to_string(),
                duration: Duration::from_millis(25),
                peak_rss_bytes: None,
                detail: "5 files parsed (5 succeeded)".to_string(),
            },
        ];

        // Just verify it doesn't panic; actual output goes to stdout
        print_results_csv(&results);
        print_results(&results);
    }

    #[test]
    fn test_discover_r_files_empty_dir() {
        let dir = tempfile::tempdir().unwrap();
        let files = discover_r_files(dir.path());
        assert!(files.is_empty());
    }

    #[test]
    fn test_discover_r_files_with_files() {
        let dir = tempfile::tempdir().unwrap();
        std::fs::write(dir.path().join("a.R"), "x <- 1").unwrap();
        std::fs::write(dir.path().join("b.r"), "y <- 2").unwrap(); // lowercase .r
        std::fs::write(dir.path().join("c.txt"), "not R").unwrap();

        let files = discover_r_files(dir.path());
        assert_eq!(files.len(), 2);
        // Should be sorted
        assert!(files[0].0 < files[1].0);
    }

    #[test]
    fn analysis_stats_honors_default_and_configured_gitignore_policy() {
        for (setting, expected_count) in [(None, 1), (Some(true), 1), (Some(false), 2)] {
            let dir = tempfile::tempdir().unwrap();
            std::fs::write(dir.path().join(".gitignore"), "ignored.R\n").unwrap();
            std::fs::write(dir.path().join("visible.R"), "visible <- 1\n").unwrap();
            std::fs::write(dir.path().join("ignored.R"), "ignored <- 1\n").unwrap();
            if let Some(setting) = setting {
                std::fs::write(
                    dir.path().join("raven.toml"),
                    format!("[workspace]\nrespectGitignore = {setting}\n"),
                )
                .unwrap();
            }
            let args = AnalysisStatsArgs {
                path: dir.path().to_path_buf(),
                csv: false,
                only: Some("scan".to_owned()),
            };
            let results = run_analysis_stats(&args);
            assert_eq!(results[0].detail, format!("{expected_count} files"));
        }
    }

    #[test]
    fn analysis_stats_parent_config_anchors_exclusions_without_broadening_target() {
        let dir = tempfile::tempdir().unwrap();
        let target = dir.path().join("nested");
        std::fs::create_dir_all(target.join("generated")).unwrap();
        std::fs::write(
            dir.path().join("raven.toml"),
            "[workspace]\nrespectGitignore = false\nexclude = [\"nested/generated/**\"]\n",
        )
        .unwrap();
        std::fs::write(dir.path().join(".gitignore"), "*.R\n").unwrap();
        std::fs::write(dir.path().join("outside.R"), "outside <- 1\n").unwrap();
        std::fs::write(target.join("included.R"), "included <- 1\n").unwrap();
        std::fs::write(target.join("generated/excluded.R"), "excluded <- 1\n").unwrap();
        let files = discover_r_files(&target);
        assert_eq!(files.len(), 1);
        assert_eq!(files[0].0, target.join("included.R"));

        // The untimed discovery path used when scan is omitted uses the same
        // settings, including when a parent config disabled Git ignore rules.
        let results = run_analysis_stats(&AnalysisStatsArgs {
            path: target,
            csv: false,
            only: Some("parse".to_owned()),
        });
        assert_eq!(results[0].detail, "1 files parsed (1 succeeded)");
    }

    #[test]
    fn analysis_stats_parent_config_does_not_move_target_git_boundary() {
        let dir = tempfile::tempdir().unwrap();
        let target = dir.path().join("nested");
        std::fs::create_dir_all(target.join("generated")).unwrap();
        std::fs::write(
            dir.path().join("raven.toml"),
            "[workspace]\nexclude = [\"nested/generated/**\"]\n",
        )
        .unwrap();
        std::fs::write(dir.path().join(".gitignore"), "*.R\n").unwrap();
        std::fs::write(target.join(".git"), "gitdir: elsewhere\n").unwrap();
        std::fs::write(target.join(".gitignore"), "local.R\n").unwrap();
        std::fs::write(target.join("included.R"), "included <- 1\n").unwrap();
        std::fs::write(target.join("local.R"), "local <- 1\n").unwrap();
        std::fs::write(target.join("generated/excluded.R"), "excluded <- 1\n").unwrap();

        let files = discover_r_files(&target);
        assert_eq!(files.len(), 1, "{files:?}");
        assert_eq!(files[0].0, target.join("included.R"));
    }

    #[test]
    fn test_discover_r_files_skips_git() {
        let dir = tempfile::tempdir().unwrap();
        std::fs::create_dir(dir.path().join(".git")).unwrap();
        std::fs::write(dir.path().join(".git/config.R"), "x <- 1").unwrap();
        std::fs::write(dir.path().join("real.R"), "y <- 2").unwrap();

        let files = discover_r_files(dir.path());
        assert_eq!(files.len(), 1);
        assert!(files[0].0.ends_with("real.R"));
    }

    #[test]
    fn test_discover_r_files_strips_utf8_bom() {
        let dir = tempfile::tempdir().unwrap();
        let mut bytes = vec![0xEF, 0xBB, 0xBF];
        bytes.extend_from_slice(b"x <- 1\n");
        std::fs::write(dir.path().join("bom.R"), bytes).unwrap();

        let files = discover_r_files(dir.path());
        assert_eq!(files.len(), 1);
        // Reading through the BOM-aware seam strips the leading U+FEFF; a raw
        // read_to_string would leave it on the first token, skewing the profiled
        // parse/scope work and diverging from the workspace scan.
        assert_eq!(files[0].1, "x <- 1\n");
    }

    #[test]
    fn test_discover_r_files_skips_undecodable() {
        let dir = tempfile::tempdir().unwrap();
        // A Latin-1 file (a bare 0xA0 with no UTF-16 BOM) can't be decoded.
        // analysis-stats is a profiler, not a diagnostic tool, so it silently
        // skips the file rather than reporting a finding.
        let mut bytes = b"x <- 1\n".to_vec();
        bytes.push(0xA0);
        std::fs::write(dir.path().join("latin1.R"), bytes).unwrap();
        std::fs::write(dir.path().join("clean.R"), "y <- 2\n").unwrap();

        let files = discover_r_files(dir.path());
        assert_eq!(
            files.len(),
            1,
            "the undecodable file must be skipped; got {files:?}"
        );
        assert!(files[0].0.ends_with("clean.R"));
    }

    #[test]
    fn test_format_bytes() {
        assert_eq!(format_bytes(0), "0 B");
        assert_eq!(format_bytes(512), "512 B");
        assert_eq!(format_bytes(1024), "1.0 KB");
        assert_eq!(format_bytes(1536), "1.5 KB");
        assert_eq!(format_bytes(1024 * 1024), "1.0 MB");
        assert_eq!(format_bytes(50 * 1024 * 1024), "50.0 MB");
        assert_eq!(format_bytes(1024 * 1024 * 1024), "1.0 GB");
        assert_eq!(format_bytes(2 * 1024 * 1024 * 1024), "2.0 GB");
    }

    #[test]
    fn test_phase_result_has_peak_rss() {
        let result = PhaseResult {
            name: "test".to_string(),
            duration: Duration::from_millis(100),
            peak_rss_bytes: Some(1024 * 1024 * 42),
            detail: "test detail".to_string(),
        };
        assert_eq!(result.peak_rss_bytes, Some(1024 * 1024 * 42));

        let result_none = PhaseResult {
            name: "test".to_string(),
            duration: Duration::from_millis(100),
            peak_rss_bytes: None,
            detail: "test detail".to_string(),
        };
        assert!(result_none.peak_rss_bytes.is_none());
    }
}
