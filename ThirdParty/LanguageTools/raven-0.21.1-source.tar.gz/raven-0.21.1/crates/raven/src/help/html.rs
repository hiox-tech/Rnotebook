//! HTML help fetch — R subprocess running tools::Rd2HTML, metadata via tempfile.
//!
//! Sync function (mirrors `get_help`); callers wrap in `tokio::task::spawn_blocking`.
//! See spec "Server-side help renderer" for the full contract.

use std::io::Read;
use std::path::Path;
use std::process::{Command, Stdio};
use std::sync::atomic::{AtomicU32, Ordering};
use std::time::Duration;

use tempfile::NamedTempFile;

use super::rewrite::rewrite_help_html;
use super::sanitize::{sanitize_help_html, strip_dead_links};
use super::types::{HelpHtml, HelpHtmlError};
use super::validate::is_valid_help_topic;

pub const HELP_HTML_TIMEOUT: Duration = Duration::from_secs(10);
pub const HELP_HTML_MAX_BYTES: usize = 8 * 1024 * 1024;

/// Returns the effective timeout, overridable by `RAVEN_HELP_TIMEOUT_MS` for tests.
fn timeout_from_env() -> Duration {
    match std::env::var("RAVEN_HELP_TIMEOUT_MS")
        .ok()
        .and_then(|s| s.parse::<u64>().ok())
    {
        Some(ms) => Duration::from_millis(ms),
        None => HELP_HTML_TIMEOUT,
    }
}

/// Returns the effective stdout cap, overridable by `RAVEN_HELP_HTML_MAX_BYTES` for tests.
fn max_bytes_from_env() -> usize {
    match std::env::var("RAVEN_HELP_HTML_MAX_BYTES")
        .ok()
        .and_then(|s| s.parse::<usize>().ok())
    {
        Some(n) => n,
        None => HELP_HTML_MAX_BYTES,
    }
}

pub fn get_help_html(
    topic: &str,
    package: Option<&str>,
    r_path: &Path,
) -> Result<HelpHtml, HelpHtmlError> {
    get_help_html_inner(topic, package, r_path, include_str!("rd_to_html.R"), None)
}

/// Inner implementation that accepts the R script as a parameter.
///
/// This allows tests to inject custom R code (e.g., `Sys.sleep(60)` for timeout
/// testing) without duplicating the full implementation. The public `get_help_html`
/// always passes the bundled `rd_to_html.R` script.
///
/// The optional `pid_capture` parameter, when provided, receives the spawned child's
/// PID immediately after a successful `spawn()`. This is used only in tests to verify
/// that the watchdog reaps the child process after a timeout.
fn get_help_html_inner(
    topic: &str,
    package: Option<&str>,
    r_path: &Path,
    r_code: &str,
    pid_capture: Option<&AtomicU32>,
) -> Result<HelpHtml, HelpHtmlError> {
    // 1) Validate inputs.
    if !is_valid_help_topic(topic) {
        return Err(HelpHtmlError::InvalidTopic {
            message: format!("invalid topic: {}", topic.escape_debug()),
        });
    }
    if let Some(p) = package
        && !crate::r_subprocess::is_valid_package_name(p)
    {
        return Err(HelpHtmlError::InvalidTopic {
            message: format!("invalid package: {}", p.escape_debug()),
        });
    }

    let timeout = timeout_from_env();
    let max_bytes = max_bytes_from_env();

    // 2) Tempfile (RAII cleanup).
    let meta = NamedTempFile::new().map_err(|e| HelpHtmlError::RenderFailed {
        message: format!("tempfile create: {e}"),
    })?;
    let meta_path = meta.path().to_path_buf();

    // 3) Spawn R with the fixed three-arg ordering: topic, package-or-empty, meta-path.
    let pkg_arg = package.unwrap_or("");
    let mut cmd = Command::new(r_path);
    cmd.args([
        "--slave",
        "--no-save",
        "--no-restore",
        "-e",
        r_code,
        "--args",
        topic,
        pkg_arg,
    ]);
    cmd.arg(meta_path.as_os_str());
    cmd.stdout(Stdio::piped()).stderr(Stdio::piped());
    let mut child = cmd.spawn().map_err(|e| HelpHtmlError::RUnavailable {
        message: format!("R spawn failed: {e}"),
    })?;
    let pid = child.id();
    // Store the pid before heavy work so tests can observe it even if we return early.
    if let Some(cap) = pid_capture {
        cap.store(pid, Ordering::SeqCst);
    }

    // 4) Drain stdout / stderr on background threads. Reading pipes from
    //    separate threads prevents deadlock when pipe buffers fill before
    //    the child exits.
    let stdout = child.stdout.take().expect("piped stdout");
    let stderr = child.stderr.take().expect("piped stderr");

    let stdout_thread = std::thread::spawn(move || -> Result<Vec<u8>, HelpHtmlError> {
        let mut buf = Vec::with_capacity(64 * 1024);
        let mut reader = stdout;
        let mut chunk = [0u8; 8192];
        loop {
            match reader.read(&mut chunk) {
                Ok(0) => break,
                Ok(n) => {
                    if buf.len() + n > max_bytes {
                        return Err(HelpHtmlError::TooLarge);
                    }
                    buf.extend_from_slice(&chunk[..n]);
                }
                Err(e) => {
                    return Err(HelpHtmlError::RenderFailed {
                        message: format!("stdout read: {e}"),
                    });
                }
            }
        }
        Ok(buf)
    });
    let stderr_thread = std::thread::spawn(move || -> Vec<u8> {
        let mut buf = Vec::new();
        let mut s = stderr;
        let _ = s.read_to_end(&mut buf);
        buf
    });

    // 5) Watchdog: a sleeper thread sends a one-shot timeout signal. The main
    //    thread polls `try_wait()` and the signal channel together. We kill
    //    via `child.kill()` only after a `try_wait()` that returned `Ok(None)`
    //    — meaning we have NOT reaped the PID yet — so the kill cannot land
    //    on a recycled PID. This is the structural cure for the old
    //    "atomic flag plus bare-PID SIGKILL from a detached thread" race in
    //    `text.rs::get_help` (commit b867a57): a watchdog firing between
    //    `wait()` reaping the child and the atomic store could SIGKILL an
    //    unrelated process that had grabbed the freed PID.
    let (timeout_tx, timeout_rx) = std::sync::mpsc::channel::<()>();
    std::thread::spawn(move || {
        std::thread::sleep(timeout);
        let _ = timeout_tx.send(());
    });

    const POLL_INTERVAL: Duration = Duration::from_millis(50);
    let mut killed_by_watchdog = false;
    let wait_result: std::io::Result<std::process::ExitStatus> = loop {
        match child.try_wait() {
            Ok(Some(status)) => break Ok(status),
            Ok(None) => {
                if timeout_rx.try_recv().is_ok() {
                    log::trace!(
                        "get_help_html: timeout after {:?}, killing pid {}",
                        timeout,
                        pid
                    );
                    // Safe: try_wait returned None, so the child has not been
                    // reaped and `pid` still names this child.
                    let _ = child.kill();
                    killed_by_watchdog = true;
                    break child.wait();
                }
                std::thread::sleep(POLL_INTERVAL);
            }
            Err(e) => break Err(e),
        }
    };

    let stdout_bytes = stdout_thread
        .join()
        .unwrap_or(Err(HelpHtmlError::RenderFailed {
            message: "stdout thread panicked".into(),
        }))?;
    let stderr_bytes = stderr_thread.join().unwrap_or_default();

    let status = wait_result.map_err(|e| HelpHtmlError::RenderFailed {
        message: format!("wait: {e}"),
    })?;

    if !status.success() {
        // 6) Watchdog kill takes precedence over stderr heuristics: if we
        //    fired the kill ourselves, classify as Timeout regardless of
        //    whatever stderr contains.
        if killed_by_watchdog {
            return Err(HelpHtmlError::Timeout);
        }
        let err = String::from_utf8_lossy(&stderr_bytes).to_string();
        if err.contains("there is no package called") {
            return Err(HelpHtmlError::PackageNotInstalled);
        }
        if err.contains("No documentation") || err.contains("no help found") {
            return Err(HelpHtmlError::NotFound);
        }
        return Err(HelpHtmlError::RenderFailed { message: err });
    }

    // 7) Parse metadata tempfile.
    let meta_text =
        std::fs::read_to_string(&meta_path).map_err(|e| HelpHtmlError::RenderFailed {
            message: format!("metadata read: {e}"),
        })?;
    drop(meta); // RAII cleanup
    let mut meta_topic = None;
    let mut meta_pkg = None;
    let mut meta_help_dir = None;
    let mut meta_lib_paths: Vec<std::path::PathBuf> = Vec::new();
    for line in meta_text.lines() {
        if let Some((k, v)) = line.split_once('\t') {
            match k {
                "topic" => meta_topic = Some(v.to_string()),
                "package" => meta_pkg = Some(v.to_string()),
                "helpDir" => meta_help_dir = Some(std::path::PathBuf::from(v)),
                "libPath" => meta_lib_paths.push(std::path::PathBuf::from(v)),
                _ => {}
            }
        }
    }
    let canonical_topic = meta_topic.ok_or(HelpHtmlError::RenderFailed {
        message: "missing topic in metadata".into(),
    })?;
    let canonical_pkg = meta_pkg.ok_or(HelpHtmlError::RenderFailed {
        message: "missing package in metadata".into(),
    })?;
    let help_dir = meta_help_dir.ok_or(HelpHtmlError::RenderFailed {
        message: "missing helpDir in metadata".into(),
    })?;
    if meta_lib_paths.is_empty() {
        return Err(HelpHtmlError::RenderFailed {
            message: "missing libPath entries in metadata".into(),
        });
    }

    // 8) Strip dead links FIRST, then rewrite cross-references, then sanitize.
    //
    // strip_dead_links removes the `Run examples` paragraph (points at R's
    // dynamic help server's example runner, which we don't have) and the
    // `00Index.html` footer link (per-package index page, also unimplemented).
    // Both must run on the raw R output: the rewriter converts unrecognized
    // hrefs to `javascript:void(0)`+`data-raven-dropped`, which would prevent
    // the strip regexes from matching by the original href.
    //
    // The rewriter then performs two transforms on `<a href>`:
    //   - `<a href="../../<pkg>/help/<topic>">` (relative, produced by
    //     `Rd2HTML(dynamic = TRUE)`) becomes `raven-help://...`, an explicit
    //     allowlisted scheme the webview navigates in-panel.
    //   - `<a href="/doc/manual/<basename>.html[#anchor]">` (R's internal
    //     dynamic-help server's manual paths, e.g. for `\link[R-exts]{...}`)
    //     becomes the canonical CRAN URL for the manuals on the
    //     `R_MANUAL_BASENAMES` allowlist, so external browsers can open them.
    //     Unknown basenames Drop.
    // Running the rewriter before sanitization means ammonia sees a scheme
    // it recognizes (raven-help, https) and keeps the href; running it after
    // would mean ammonia stripped the relative/absolute href first and the
    // rewriter had nothing to convert.
    //
    // Both the strip and rewrite passes are regex-only transforms on `<a>`
    // tags and are safe to run on raw R output — neither can introduce
    // dangerous tags or scripts.
    let html_raw = String::from_utf8_lossy(&stdout_bytes).to_string();
    let stripped_raw = strip_dead_links(&html_raw);
    let rewritten_raw = rewrite_help_html(&stripped_raw, &canonical_pkg);
    let rewritten =
        std::panic::catch_unwind(|| sanitize_help_html(&rewritten_raw)).map_err(|_| {
            HelpHtmlError::RenderFailed {
                message: "ammonia panic".into(),
            }
        })?;

    // 9) Title from first <h2>.
    let title = extract_h2_title(&rewritten).unwrap_or_else(|| canonical_topic.clone());

    Ok(HelpHtml {
        topic: canonical_topic,
        package: canonical_pkg,
        title,
        html: rewritten,
        help_dir,
        lib_paths: meta_lib_paths,
    })
}

fn extract_h2_title(html: &str) -> Option<String> {
    let start = html.find("<h2")?;
    let after_open = &html[start..];
    let close_open = after_open.find('>')? + 1;
    let body = &after_open[close_open..];
    let end = body.find("</h2>")?;
    let inner = &body[..end];
    // Strip any nested tags by removing `< ... >` substrings.
    let mut out = String::with_capacity(inner.len());
    let mut in_tag = false;
    for c in inner.chars() {
        match c {
            '<' => in_tag = true,
            '>' => in_tag = false,
            _ if !in_tag => out.push(c),
            _ => {}
        }
    }
    let trimmed = out.trim().to_string();
    if trimmed.is_empty() {
        None
    } else {
        Some(trimmed)
    }
}

/// Test-only entry point that injects custom R code instead of the bundled script.
///
/// Used by timeout and stdout-cap tests to inject hanging or large-output R snippets
/// without touching the public API or duplicating the full implementation.
#[cfg(test)]
pub(crate) fn get_help_html_with_code(
    topic: &str,
    package: Option<&str>,
    r_path: &Path,
    r_code: &str,
) -> Result<HelpHtml, HelpHtmlError> {
    get_help_html_inner(topic, package, r_path, r_code, None)
}

/// Test-only entry point that injects custom R code and captures the spawned PID.
///
/// Writes the child's PID into `pid_capture` immediately after a successful spawn,
/// allowing the caller to probe whether the watchdog has reaped the process.
#[cfg(test)]
pub(crate) fn get_help_html_with_code_capturing_pid(
    topic: &str,
    package: Option<&str>,
    r_path: &Path,
    r_code: &str,
    pid_capture: &AtomicU32,
) -> Result<HelpHtml, HelpHtmlError> {
    get_help_html_inner(topic, package, r_path, r_code, Some(pid_capture))
}

/// RAII guard that sets an environment variable on creation and restores the
/// prior value (or removes the var if it was unset) on drop.
///
/// Keeps env-var mutations local to a single test even in the presence of
/// panics. Storing the previous value matters when a parent process or an
/// outer test set the variable: unconditionally removing on drop would
/// clobber that state.
#[cfg(test)]
struct EnvGuard {
    key: &'static str,
    previous: Option<std::ffi::OsString>,
}

#[cfg(test)]
impl EnvGuard {
    fn set(key: &'static str, val: &str) -> Self {
        let previous = std::env::var_os(key);
        // SAFETY: single-threaded test context; we restore in Drop.
        unsafe { std::env::set_var(key, val) };
        EnvGuard { key, previous }
    }
}

#[cfg(test)]
impl Drop for EnvGuard {
    fn drop(&mut self) {
        // SAFETY: mirrors the set_var above.
        unsafe {
            match self.previous.take() {
                Some(prev) => std::env::set_var(self.key, prev),
                None => std::env::remove_var(self.key),
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn extract_h2_basic() {
        assert_eq!(extract_h2_title("<h2>Title</h2>"), Some("Title".into()));
        assert_eq!(
            extract_h2_title(r#"<h2 class="x">Title <em>Sub</em></h2>"#),
            Some("Title Sub".into())
        );
        assert_eq!(extract_h2_title("<p>no h2</p>"), None);
    }

    use crate::r_subprocess::RSubprocess;

    fn r_path() -> Option<std::path::PathBuf> {
        RSubprocess::new(None).map(|s| s.r_path().clone())
    }

    #[test]
    fn renders_base_mean() {
        let Some(r) = r_path() else {
            eprintln!("skip: no R");
            return;
        };
        let res = get_help_html("mean", Some("base"), &r).expect("render");
        assert_eq!(res.package, "base");
        assert!(res.html.contains("Arithmetic Mean") || res.title.contains("Mean"));
        assert!(res.help_dir.ends_with("help"));
        assert!(!res.lib_paths.is_empty());
    }

    #[test]
    fn renders_clickable_cross_references() {
        // Regression for the smoke-test bug where every link in the rendered
        // help page lost its href: Rd2HTML default mode emits `<code>` instead
        // of `<a>` for cross-references, so even with a working rewriter
        // there were no anchors to convert. The fix passes `dynamic = TRUE`
        // to Rd2HTML and runs the rewriter before ammonia.
        //
        // `mean` is reliable because base::weighted.mean and base::colMeans
        // are always referenced in its See Also section.
        let Some(r) = r_path() else {
            eprintln!("skip: no R");
            return;
        };
        let res = get_help_html("mean", Some("base"), &r).expect("render");
        assert!(
            res.html.contains("raven-help://topic/base/weighted.mean"),
            "expected rewritten cross-reference to weighted.mean; html was:\n{}",
            res.html
        );
        // Decorative `<title>R: ...</title>` chrome must be stripped.
        assert!(
            !res.html.contains("R: Arithmetic Mean"),
            "decorative title chrome must not leak into rendered body; html was:\n{}",
            res.html
        );
        // Decorative one-row `topic {pkg}` / `R Documentation` table must be stripped.
        assert!(
            !res.html.contains("R Documentation"),
            "decorative R Documentation table must be removed; html was:\n{}",
            res.html
        );
    }

    #[test]
    fn invalid_topic_short_circuits() {
        // Path doesn't exist; this should still fail BEFORE spawning R.
        let bogus = std::path::PathBuf::from("/no/such/R");
        let res = get_help_html("with\nnewline", None, &bogus);
        assert!(matches!(res, Err(HelpHtmlError::InvalidTopic { .. })));
    }

    #[test]
    fn unknown_topic_returns_not_found() {
        let Some(r) = r_path() else {
            eprintln!("skip: no R");
            return;
        };
        let res = get_help_html("definitely_not_a_real_topic_zzz", Some("base"), &r);
        assert!(matches!(
            res,
            Err(HelpHtmlError::NotFound) | Err(HelpHtmlError::RenderFailed { .. })
        ));
    }

    #[test]
    fn unknown_package_returns_package_not_installed() {
        let Some(r) = r_path() else {
            eprintln!("skip: no R");
            return;
        };
        let res = get_help_html("filter", Some("totally_not_installed_pkg_xyz"), &r);
        assert!(matches!(
            res,
            Err(HelpHtmlError::PackageNotInstalled) | Err(HelpHtmlError::RenderFailed { .. })
        ));
    }

    #[test]
    fn operator_topic_works() {
        let Some(r) = r_path() else {
            eprintln!("skip: no R");
            return;
        };
        let res = get_help_html("[", Some("base"), &r).expect("render");
        assert_eq!(res.package, "base");
    }

    #[test]
    fn cross_package_fallback_resolves_misattributed_link() {
        // Regression for the smoke-test bug where Rd2HTML(dynamic = TRUE)
        // emits links of the form `../../<source-pkg>/help/<topic>` even
        // when <topic> lives in a different package — e.g. base::plot links
        // to `base/plot.default`, but plot.default is in graphics. Without
        // a fallback, `help("plot.default", package = "base")` returns
        // length 0 and `.getHelpFile()` then throws "argument is of length
        // zero". The fix in rd_to_html.R falls back to `help(topic)` when
        // the package-qualified search returns nothing.
        let Some(r) = r_path() else {
            eprintln!("skip: no R");
            return;
        };
        let res = get_help_html("plot.default", Some("base"), &r).expect("render");
        assert_eq!(
            res.package, "graphics",
            "fallback must resolve to graphics, not base"
        );
        assert_eq!(res.topic, "plot.default");
    }

    #[test]
    fn cross_package_fallback_resolves_alias() {
        // Aliases are another flavor of the misattribution: `finite` is an
        // alias for `is.finite` in base, but graphics::plot.default emits
        // `graphics/help/finite` for it. The fallback resolves the alias.
        let Some(r) = r_path() else {
            eprintln!("skip: no R");
            return;
        };
        let res = get_help_html("finite", Some("graphics"), &r).expect("render");
        assert_eq!(
            res.package, "base",
            "alias must resolve to base, not graphics"
        );
    }

    #[test]
    fn rendered_output_strips_dead_links() {
        // Regression for two smoke-test bugs: Rd2HTML(dynamic = TRUE) emits a
        // `<p><a href='../Example/<topic>'>Run examples</a></p>` paragraph and
        // an `<a href="00Index.html">Index</a>` footer. Both point at endpoints
        // we don't implement; clicking does nothing. They must be removed
        // before the cross-reference rewriter runs (the rewriter converts
        // unknown hrefs to javascript:void(0) which would prevent strip-by-href
        // from matching), so the actual rendered HTML must contain neither.
        let Some(r) = r_path() else {
            eprintln!("skip: no R");
            return;
        };
        let res = get_help_html("mean", Some("base"), &r).expect("render");
        assert!(
            !res.html.contains("Run examples"),
            "Run examples link must not survive into rendered HTML; html was:\n{}",
            res.html
        );
        assert!(
            !res.html.contains("00Index.html"),
            "00Index.html link must not survive into rendered HTML; html was:\n{}",
            res.html
        );
        // The footer text "[Package base version X.Y.Z]" should still be there;
        // we strip only the trailing Index anchor, not the brackets.
        assert!(
            !res.html.contains(">Index<"),
            "Index anchor text must be gone (cursor would be I-beam on a naked <a>); html was:\n{}",
            res.html
        );
    }

    #[test]
    fn r_manual_links_become_cran_urls() {
        // End-to-end regression for the reported `utils::package.skeleton`
        // bug: Rd2HTML emits `<a href="/doc/manual/R-exts.html">` for the
        // `Writing R Extensions` reference. Previously the rewriter dropped
        // the absolute path to `javascript:void(0)`, ammonia then stripped
        // that scheme, and the rendered HTML contained a bare <a> with no
        // href — styled like a link by the CSS but rendered with the I-beam
        // cursor and dead clicks.
        //
        // Whether `package.skeleton`'s reference is rendered as a *link* is
        // R-version-dependent: some versions mark it up as a
        // `\link[R-exts]{...}` cross-reference (Rd2HTML emits the
        // `/doc/manual/R-exts.html` anchor this test guards), while others —
        // e.g. R 4.3.x shipped as Ubuntu's `r-base-core` — render it as a
        // plain `\sQuote{Writing R Extensions}` with no anchor at all. So the
        // CRAN-URL assertions are gated on this R version actually emitting a
        // manual link; the *version-independent* invariant — a raw
        // `/doc/manual/` href must never leak into the rendered HTML — is
        // always enforced. The rewrite-and-sanitize transform itself is
        // covered exhaustively by the unit tests in `help::rewrite`.
        let Some(r) = r_path() else {
            eprintln!("skip: no R");
            return;
        };
        let res = get_help_html("package.skeleton", Some("utils"), &r).expect("render");
        // The absolute /doc/manual path must not leak through, regardless of
        // whether this R version emits the manual link.
        assert!(
            !res.html.contains(r#"href="/doc/manual/"#),
            "raw /doc/manual/ href must not survive into rendered HTML; html was:\n{}",
            res.html
        );
        if !res
            .html
            .contains("https://cran.r-project.org/doc/manuals/r-release/R-exts.html")
        {
            eprintln!(
                "skip: this R version renders package.skeleton's R-exts reference as \
                 plain text (no /doc/manual/ link to rewrite)"
            );
            return;
        }
        // The R-Extensions cross-reference must end up as a real <a href=...>
        // anchor (i.e. NOT a bare <a> without href), which is what produced
        // the I-beam cursor before the fix.
        assert!(
            res.html.contains(r#"<a href="https://cran.r-project.org"#),
            "R manual link must be a real anchor with an https href; html was:\n{}",
            res.html
        );
    }

    /// Verifies that `get_help_html` returns `Err(TooLarge)` when the rendered
    /// HTML exceeds the configured stdout cap.
    ///
    /// Sets `RAVEN_HELP_HTML_MAX_BYTES=1024` so that the `mean` help page (well
    /// over 1 KiB) triggers the cap.  The env var is removed via RAII after the
    /// test regardless of outcome.
    ///
    /// Marked `#[ignore]` because it mutates a process-wide env var; run explicitly
    /// with `-- --include-ignored --test-threads=1` to avoid interference with
    /// parallel tests.
    #[test]
    #[ignore]
    fn stdout_cap_returns_too_large() {
        let Some(r) = r_path() else {
            eprintln!("skip: no R");
            return;
        };
        let _guard = EnvGuard::set("RAVEN_HELP_HTML_MAX_BYTES", "1024");
        let res = get_help_html("mean", Some("base"), &r);
        assert!(
            matches!(res, Err(HelpHtmlError::TooLarge)),
            "expected TooLarge, got {res:?}"
        );
    }

    /// Verifies that `get_help_html` returns `Err(Timeout)` when R hangs, and
    /// that it does so well within 1 second.
    ///
    /// Uses a 200 ms timeout (via `RAVEN_HELP_TIMEOUT_MS`) and injects a
    /// `Sys.sleep(60)` snippet via `get_help_html_with_code` so R never produces
    /// any output.  The env var is removed via RAII after the test.
    ///
    /// Marked `#[ignore]` because it mutates a process-wide env var; run explicitly
    /// with `-- --include-ignored --test-threads=1` to avoid interference with
    /// parallel tests.
    #[test]
    #[ignore]
    fn get_help_html_timeout() {
        let Some(r) = r_path() else {
            eprintln!("skip: no R");
            return;
        };
        let _guard = EnvGuard::set("RAVEN_HELP_TIMEOUT_MS", "200");
        let start = std::time::Instant::now();
        let res = get_help_html_with_code("mean", Some("base"), &r, "Sys.sleep(60)");
        let elapsed = start.elapsed();
        assert!(
            matches!(res, Err(HelpHtmlError::Timeout)),
            "expected Timeout, got {res:?}"
        );
        assert!(
            elapsed.as_millis() < 1000,
            "timeout test took too long: {elapsed:?}"
        );
    }

    /// Paranoia check: after a watchdog-triggered timeout, the R child process must
    /// actually be gone (reaped by the OS).
    ///
    /// After `get_help_html` returns `Err(Timeout)` we send signal 0 (`kill(pid, 0)`)
    /// to the captured PID and assert that it returns -1 with errno ESRCH (no such
    /// process). Signal 0 never delivers — it only probes process existence.
    ///
    /// Marked `#[ignore]` because it mutates a process-wide env var; run explicitly
    /// with `-- --include-ignored --test-threads=1`.
    #[cfg(unix)]
    #[test]
    #[ignore]
    fn get_help_html_timeout_reaps_process() {
        let Some(r) = r_path() else {
            eprintln!("skip: no R");
            return;
        };
        let _guard = EnvGuard::set("RAVEN_HELP_TIMEOUT_MS", "200");

        let pid_capture = AtomicU32::new(0);
        let res = get_help_html_with_code_capturing_pid(
            "mean",
            Some("base"),
            &r,
            "Sys.sleep(60)",
            &pid_capture,
        );

        assert!(
            matches!(res, Err(HelpHtmlError::Timeout)),
            "expected Timeout, got {res:?}"
        );

        let pid = pid_capture.load(Ordering::SeqCst);
        assert!(pid != 0, "expected a captured pid after spawn");

        // Brief delay to allow the watchdog kill to take effect before probing.
        std::thread::sleep(std::time::Duration::from_millis(50));

        // SAFETY: signal 0 never delivers; it only checks whether the pid exists.
        let kill_result = unsafe { libc::kill(pid as libc::pid_t, 0) };
        assert_eq!(
            kill_result, -1,
            "expected kill(pid, 0) == -1 (process should be reaped); got {}",
            kill_result
        );
        let errno = std::io::Error::last_os_error().raw_os_error();
        assert_eq!(
            errno,
            Some(libc::ESRCH),
            "expected ESRCH; got errno {:?}",
            errno
        );
    }
}
