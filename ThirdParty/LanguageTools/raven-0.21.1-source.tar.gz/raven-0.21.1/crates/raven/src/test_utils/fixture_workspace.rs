//! Deterministic fixture workspace generator for benchmarks and tests.
//!
//! Generates synthetic R workspaces with controlled characteristics:
//! file count, functions per file, source() chains, library() calls,
//! and extra lines of non-function code.
//!
//! All output is deterministic — no randomness — so benchmarks are reproducible.

use std::fmt::Write;
use std::path::Path;
use tempfile::TempDir;
use url::Url;

/// Configuration for generating a fixture workspace.
#[derive(Debug, Clone)]
pub struct FixtureConfig {
    pub file_count: usize,
    pub functions_per_file: usize,
    pub source_chain_depth: usize,
    pub library_calls_per_file: usize,
    pub extra_lines_per_file: usize,
}

/// A set of well-known library names used deterministically in generated code.
const LIBRARIES: &[&str] = &[
    "stats", "utils", "dplyr", "ggplot2", "tidyr", "stringr", "purrr", "readr", "tibble", "forcats",
];

impl FixtureConfig {
    /// Small workspace: 10 files, 5 functions each, source chain depth 3.
    pub fn small() -> Self {
        Self {
            file_count: 10,
            functions_per_file: 5,
            source_chain_depth: 3,
            library_calls_per_file: 1,
            extra_lines_per_file: 5,
        }
    }

    /// Medium workspace: 50 files, 10 functions each, source chain depth 10.
    pub fn medium() -> Self {
        Self {
            file_count: 50,
            functions_per_file: 10,
            source_chain_depth: 10,
            library_calls_per_file: 2,
            extra_lines_per_file: 10,
        }
    }

    /// Large workspace: 200 files, 20 functions each, source chain depth 15.
    pub fn large() -> Self {
        Self {
            file_count: 200,
            functions_per_file: 20,
            source_chain_depth: 15,
            library_calls_per_file: 3,
            extra_lines_per_file: 20,
        }
    }
}

/// Generate the content of a single R file deterministically.
///
/// - `index`: file index (0-based), used for naming and source chain linkage
/// - `config`: the workspace configuration
fn generate_r_file_content(index: usize, config: &FixtureConfig) -> String {
    let mut content = String::new();

    // Library calls — cycle through the known library list deterministically
    for lib_i in 0..config.library_calls_per_file {
        let lib_name = LIBRARIES[(index * config.library_calls_per_file + lib_i) % LIBRARIES.len()];
        writeln!(content, "library({})", lib_name).unwrap();
    }

    if config.library_calls_per_file > 0 {
        content.push('\n');
    }

    // Source chain: file_0 sources file_1, file_1 sources file_2, etc.
    // Only files within the chain depth get a source() call.
    if index < config.source_chain_depth && index + 1 < config.file_count {
        writeln!(content, "source(\"file_{}.R\")", index + 1).unwrap();
        content.push('\n');
    }

    // Function definitions
    for func_i in 0..config.functions_per_file {
        writeln!(
            content,
            "func_{}_{} <- function(x, y = {}) {{",
            index,
            func_i,
            func_i + 1
        )
        .unwrap();
        writeln!(content, "    result <- x + y * {}", func_i + 1).unwrap();
        writeln!(content, "    if (is.na(result)) {{").unwrap();
        writeln!(content, "        return(NULL)").unwrap();
        writeln!(content, "    }}").unwrap();
        writeln!(content, "    result").unwrap();
        writeln!(content, "}}").unwrap();
        content.push('\n');
    }

    // Extra lines of non-function code (variable assignments, data frames)
    for line_i in 0..config.extra_lines_per_file {
        writeln!(content, "var_{}_{} <- {}", index, line_i, line_i + 1).unwrap();
    }

    content
}

/// Create a temporary fixture workspace from the given configuration.
///
/// Returns a `TempDir` whose path contains the generated `.R` files.
/// The directory is cleaned up when the `TempDir` is dropped.
///
/// Calling this twice with the same `FixtureConfig` produces byte-identical files.
pub fn create_fixture_workspace(config: &FixtureConfig) -> TempDir {
    let temp_dir = TempDir::new().expect("Failed to create temp directory for fixture workspace");
    write_fixture_workspace(temp_dir.path(), config);
    temp_dir
}

/// Create a temporary single-file workspace containing exactly `file_0.R` with
/// the given content.
///
/// For benchmarks/tests that need to exercise a specific code shape (e.g. an
/// NSE-saturated document) rather than the synthetic [`FixtureConfig`] output.
/// The returned `TempDir` cleans up on drop; the file is always named
/// `file_0.R` so callers can reuse the existing `file_0_uri` helper.
pub fn create_single_file_workspace(content: &str) -> TempDir {
    let temp_dir = TempDir::new().expect("Failed to create temp directory for fixture workspace");
    let filepath = temp_dir.path().join("file_0.R");
    std::fs::write(&filepath, content)
        .unwrap_or_else(|e| panic!("Failed to write single-file fixture: {}", e));
    temp_dir
}

/// Write fixture files into an existing directory.
///
/// Useful when you need to control the directory path (e.g., for named temp dirs).
pub fn write_fixture_workspace(dir: &Path, config: &FixtureConfig) {
    for i in 0..config.file_count {
        let content = generate_r_file_content(i, config);
        let filename = format!("file_{}.R", i);
        let filepath = dir.join(&filename);
        std::fs::write(&filepath, &content)
            .unwrap_or_else(|e| panic!("Failed to write fixture file {}: {}", filename, e));
    }
}

/// Number of distinct functions defined in `shared.R` of the fanout fixture.
///
/// Each parent file calls one of these functions, indexed by `i mod K`.
const FANOUT_SHARED_FUNCTIONS: usize = 5;

/// Generate the deterministic content of `shared.R` for the fanout fixture.
///
/// The file defines `FANOUT_SHARED_FUNCTIONS` simple functions that any
/// parent can call. Each function takes a single argument and returns a
/// linear combination — enough to give the cross-file scope resolver real
/// symbols to thread through.
fn generate_fanout_shared_content() -> String {
    let mut content = String::new();
    content.push_str("library(stats)\n\n");
    for k in 0..FANOUT_SHARED_FUNCTIONS {
        writeln!(content, "shared_func_{} <- function(x) {{", k).unwrap();
        writeln!(content, "    result <- x + {}", k + 1).unwrap();
        writeln!(content, "    if (is.na(result)) {{").unwrap();
        writeln!(content, "        return(NULL)").unwrap();
        writeln!(content, "    }}").unwrap();
        writeln!(content, "    result").unwrap();
        writeln!(content, "}}").unwrap();
        content.push('\n');
    }
    content
}

/// Generate the deterministic content of one parent file in the fanout fixture.
///
/// Each parent sources `shared.R` and calls one of its functions, picked
/// deterministically by `index mod FANOUT_SHARED_FUNCTIONS`.
fn generate_fanout_parent_content(index: usize) -> String {
    let mut content = String::new();
    writeln!(content, "library(stats)").unwrap();
    writeln!(content, "source(\"shared.R\")").unwrap();
    content.push('\n');
    writeln!(
        content,
        "result_{} <- shared_func_{}({})",
        index,
        index % FANOUT_SHARED_FUNCTIONS,
        index
    )
    .unwrap();
    content
}

/// Create a temporary fanout-shaped fixture workspace.
///
/// Layout:
/// - `shared.R` defines `FANOUT_SHARED_FUNCTIONS` functions.
/// - `parent_0.R` … `parent_{N-1}.R` each `source("shared.R")` and call one
///   of the shared functions.
///
/// This is the shape the production watched-file revalidation cascade walks
/// after a change to `shared.R` — every parent must be rediagnosed.
///
/// Calling this twice with the same `parent_count` produces byte-identical files.
pub fn create_fanout_fixture_workspace(parent_count: usize) -> TempDir {
    let temp_dir =
        TempDir::new().expect("Failed to create temp directory for fanout fixture workspace");
    write_fanout_fixture_workspace(temp_dir.path(), parent_count);
    temp_dir
}

/// Write fanout fixture files into an existing directory.
pub fn write_fanout_fixture_workspace(dir: &Path, parent_count: usize) {
    let shared_path = dir.join("shared.R");
    std::fs::write(&shared_path, generate_fanout_shared_content())
        .expect("Failed to write fanout shared.R");

    for i in 0..parent_count {
        let content = generate_fanout_parent_content(i);
        let filename = format!("parent_{}.R", i);
        let filepath = dir.join(&filename);
        std::fs::write(&filepath, &content)
            .unwrap_or_else(|e| panic!("Failed to write fanout fixture file {}: {}", filename, e));
    }
}

/// Return the URIs of the fanout parents in deterministic order
/// (`parent_0.R` first through `parent_{parent_count - 1}.R`).
pub fn fanout_parent_uris(workspace: &Path, parent_count: usize) -> Vec<Url> {
    (0..parent_count)
        .map(|i| {
            Url::from_file_path(workspace.join(format!("parent_{}.R", i)))
                .expect("URI from fanout parent path")
        })
        .collect()
}

/// Fixture for testing cross-file scope invariants: a 10-file linear
/// source() chain with a self-referential assignment in the middle file.
#[derive(Debug)]
pub struct SelfRefChainFixture {
    /// Keeps the TempDir alive for the test's duration. Prefixed with `_`
    /// to signal intentional non-use while still dropping at end of scope.
    pub _dir: TempDir,
    /// All 10 file URIs in chain order: file_0.R (root) through file_9.R (leaf).
    pub all_uris: Vec<Url>,
    /// URI of file_5.R — the "mid-chain" file containing `xyz <- xyz`.
    pub mid_file_uri: Url,
    /// 0-indexed line of `xyz <- xyz` in file_5.R (line 2).
    pub mid_xyz_line: u32,
    /// 0-indexed column of the RHS `xyz` in `xyz <- xyz` (column 7,
    /// after the `xyz <- ` prefix: 3 chars + 4 operator/space chars = 7).
    pub mid_xyz_rhs_col: u32,
}

/// Creates a self-contained 10-file fixture workspace for testing cross-file
/// scope invariants.
///
/// Chain layout: file_0.R → file_1.R → … → file_9.R
///
/// - file_0.R: `library(dplyr)` + `source("file_1.R")`
/// - file_1.R–file_4.R: pass-through (define func_N, source next)
/// - file_5.R: `func_5`, `source("file_6.R")`, `xyz <- xyz`  ← key file
/// - file_6.R–file_8.R: pass-through
/// - file_9.R: `func_9`, `leaf_var <- 42`  ← leaf definition
pub fn create_self_ref_chain_fixture() -> SelfRefChainFixture {
    let dir = TempDir::new().expect("create temp dir for self-ref chain fixture");

    for i in 0..10usize {
        let content = match i {
            0 => "library(dplyr)\nsource(\"file_1.R\")\n".to_owned(),
            5 => "func_5 <- function(x) x + 1\nsource(\"file_6.R\")\nxyz <- xyz\n".to_owned(),
            9 => "func_9 <- function(x) x + 1\nleaf_var <- 42\n".to_owned(),
            n => format!(
                "func_{n} <- function(x) x + 1\nsource(\"file_{next}.R\")\n",
                n = n,
                next = n + 1
            ),
        };
        let path = dir.path().join(format!("file_{}.R", i));
        std::fs::write(&path, content).expect("write fixture file");
    }

    let all_uris: Vec<Url> = (0..10)
        .map(|i| {
            Url::from_file_path(dir.path().join(format!("file_{}.R", i)))
                .expect("URI from fixture path")
        })
        .collect();

    let mid_file_uri = all_uris[5].clone();

    SelfRefChainFixture {
        _dir: dir,
        all_uris,
        mid_file_uri,
        mid_xyz_line: 2,
        mid_xyz_rhs_col: 7,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_small_preset_values() {
        let config = FixtureConfig::small();
        assert_eq!(config.file_count, 10);
        assert_eq!(config.functions_per_file, 5);
        assert_eq!(config.source_chain_depth, 3);
    }

    #[test]
    fn test_medium_preset_values() {
        let config = FixtureConfig::medium();
        assert_eq!(config.file_count, 50);
        assert_eq!(config.functions_per_file, 10);
        assert_eq!(config.source_chain_depth, 10);
    }

    #[test]
    fn test_large_preset_values() {
        let config = FixtureConfig::large();
        assert_eq!(config.file_count, 200);
        assert_eq!(config.functions_per_file, 20);
        assert_eq!(config.source_chain_depth, 15);
    }

    #[test]
    fn test_file_count_matches_config() {
        let config = FixtureConfig::small();
        let workspace = create_fixture_workspace(&config);
        let r_files: Vec<_> = std::fs::read_dir(workspace.path())
            .unwrap()
            .filter_map(|e| e.ok())
            .filter(|e| e.path().extension().map(|ext| ext == "R").unwrap_or(false))
            .collect();
        assert_eq!(r_files.len(), config.file_count);
    }

    #[test]
    fn test_deterministic_output() {
        let config = FixtureConfig::small();
        let ws1 = create_fixture_workspace(&config);
        let ws2 = create_fixture_workspace(&config);

        for i in 0..config.file_count {
            let filename = format!("file_{}.R", i);
            let content1 = std::fs::read_to_string(ws1.path().join(&filename)).unwrap();
            let content2 = std::fs::read_to_string(ws2.path().join(&filename)).unwrap();
            assert_eq!(
                content1, content2,
                "File {} should be identical across runs",
                filename
            );
        }
    }

    #[test]
    fn test_source_chain_structure() {
        let config = FixtureConfig {
            file_count: 5,
            functions_per_file: 1,
            source_chain_depth: 3,
            library_calls_per_file: 0,
            extra_lines_per_file: 0,
        };
        let workspace = create_fixture_workspace(&config);

        // file_0 should source file_1
        let content_0 = std::fs::read_to_string(workspace.path().join("file_0.R")).unwrap();
        assert!(
            content_0.contains("source(\"file_1.R\")"),
            "file_0 should source file_1"
        );

        // file_1 should source file_2
        let content_1 = std::fs::read_to_string(workspace.path().join("file_1.R")).unwrap();
        assert!(
            content_1.contains("source(\"file_2.R\")"),
            "file_1 should source file_2"
        );

        // file_2 should source file_3
        let content_2 = std::fs::read_to_string(workspace.path().join("file_2.R")).unwrap();
        assert!(
            content_2.contains("source(\"file_3.R\")"),
            "file_2 should source file_3"
        );

        // file_3 should NOT source anything (depth = 3 means indices 0,1,2 source)
        let content_3 = std::fs::read_to_string(workspace.path().join("file_3.R")).unwrap();
        assert!(
            !content_3.contains("source("),
            "file_3 should not have source() calls"
        );

        // file_4 should NOT source anything
        let content_4 = std::fs::read_to_string(workspace.path().join("file_4.R")).unwrap();
        assert!(
            !content_4.contains("source("),
            "file_4 should not have source() calls"
        );
    }

    #[test]
    fn test_generated_files_parse_without_errors() {
        use crate::parser_pool::with_parser;

        let config = FixtureConfig::small();
        let workspace = create_fixture_workspace(&config);

        for i in 0..config.file_count {
            let filename = format!("file_{}.R", i);
            let content = std::fs::read_to_string(workspace.path().join(&filename)).unwrap();
            let tree = with_parser(|parser| parser.parse(&content, None))
                .unwrap_or_else(|| panic!("Failed to parse {}", filename));

            let root = tree.root_node();
            assert!(
                !root.has_error(),
                "File {} should parse without errors. Content:\n{}",
                filename,
                content
            );
        }
    }

    #[test]
    fn test_library_calls_present() {
        let config = FixtureConfig {
            file_count: 1,
            functions_per_file: 0,
            source_chain_depth: 0,
            library_calls_per_file: 3,
            extra_lines_per_file: 0,
        };
        let workspace = create_fixture_workspace(&config);
        let content = std::fs::read_to_string(workspace.path().join("file_0.R")).unwrap();

        let lib_count = content
            .lines()
            .filter(|l| l.starts_with("library("))
            .count();
        assert_eq!(lib_count, 3, "Should have exactly 3 library() calls");
    }

    #[test]
    fn test_functions_present() {
        let config = FixtureConfig {
            file_count: 1,
            functions_per_file: 4,
            source_chain_depth: 0,
            library_calls_per_file: 0,
            extra_lines_per_file: 0,
        };
        let workspace = create_fixture_workspace(&config);
        let content = std::fs::read_to_string(workspace.path().join("file_0.R")).unwrap();

        let func_count = content
            .lines()
            .filter(|l| l.contains("<- function("))
            .count();
        assert_eq!(func_count, 4, "Should have exactly 4 function definitions");
    }
}
